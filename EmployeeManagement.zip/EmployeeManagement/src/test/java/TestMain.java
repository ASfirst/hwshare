import com.dingtalk.api.DefaultDingTalkClient;
import com.dingtalk.api.DingTalkClient;
import com.dingtalk.api.request.OapiDepartmentGetRequest;
import com.dingtalk.api.request.OapiDepartmentListRequest;
import com.dingtalk.api.request.OapiUserGetRequest;
import com.dingtalk.api.response.OapiDepartmentGetResponse;
import com.dingtalk.api.response.OapiDepartmentListResponse;
import com.dingtalk.api.response.OapiUserGetResponse;
import com.jeramtough.jtlog.facade.L;
import com.taobao.api.ApiException;
import org.junit.Test;

/**
 * Created on 2019-06-10 23:24
 * by @author JeramTough
 */
public class TestMain {

    @Test
    public void test(){
        String accessToken="18aa0de856ba3645babc6183115567f2";

        DingTalkClient client = new DefaultDingTalkClient("https://oapi.dingtalk.com/department/list");
        OapiDepartmentListRequest request = new OapiDepartmentListRequest();
        request.setId("1");
        request.setHttpMethod("GET");
        try {
            OapiDepartmentListResponse response = client.execute(request, accessToken);
            L.debug(response.getErrmsg());
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
    }

}
