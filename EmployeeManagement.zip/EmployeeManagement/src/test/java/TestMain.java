import com.dingtalk.api.DefaultDingTalkClient;
import com.dingtalk.api.DingTalkClient;
import com.dingtalk.api.request.OapiDepartmentGetRequest;
import com.dingtalk.api.request.OapiDepartmentListRequest;
import com.dingtalk.api.request.OapiUserGetRequest;
import com.dingtalk.api.response.OapiDepartmentGetResponse;
import com.dingtalk.api.response.OapiDepartmentListResponse;
import com.dingtalk.api.response.OapiUserGetResponse;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.hwagain.sync.component.dingtalk.net.MyDingTalkHttpClient;
import com.hwagain.sync.component.structure.DefaultStructure;
import com.hwagain.sync.component.structure.SortType;
import com.hwagain.sync.component.structure.Structure;
import com.jeramtough.jtcomponent.task.response.DefaultTaskResponse;
import com.jeramtough.jtlog.facade.L;
import com.taobao.api.ApiException;
import org.junit.Test;

import java.util.List;

/**
 * Created on 2019-06-10 23:24
 * by @author JeramTough
 */
public class TestMain {

    MyDingTalkHttpClient dingTalkHttpClient=new MyDingTalkHttpClient
            ("dingygcsukslkbenrzvc","1eziN1b63ExHqFUu7oYJX51IWm_zO0KeXvNPVDQPDbeyeDdZV-VdBZ-PTghS0MzJ");

    @Test
    public void test() {
        List<DingtalkDepartment> dingtalkDepartments=dingTalkHttpClient.getDepartmentList(1);
    }

    @Test
    public void testStructure() {
        Structure structure = new DefaultStructure();
        Structure structure1 = new DefaultStructure();
        Structure structure2 = new DefaultStructure();
        Structure structure3 = new DefaultStructure();
        Structure structure4 = new DefaultStructure();
        Structure structure5 = new DefaultStructure();
        Structure structure6 = new DefaultStructure();
        Structure structure7 = new DefaultStructure();

        structure.setValue(1);
        structure1.setValue(10);
        structure2.setValue(20);
        structure3.setValue(30);
        structure4.setValue(40);
        structure5.setValue(50);
        structure6.setValue(60);
        structure7.setValue(70);

        structure.addSub(structure1);
        structure.addSub(structure2);
        structure1.addSub(structure3);
        structure1.addSub(structure4);
        structure1.addSub(structure7);
        structure2.addSub(structure5);
        structure2.addSub(structure6);

        List<Structure> structures = DefaultStructure.getSubsAndSort(structure,
                SortType.ASCENDING);
        for (Structure structureA:structures){
            L.debug(structureA.getValue());
        }

    }

}
