package com.hwagain.sync.component.dingtalk.transverter;

import com.dingtalk.api.request.OapiDepartmentUpdateRequest;
import com.dingtalk.api.response.OapiDepartmentListResponse;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * Created on 2019/6/11 14:40
 * by @author JeramTough
 */

public class DingtalkDepartmentTransverter {

    public @NotNull
    DingtalkDepartment getDingtalkDepartment(
            OapiDepartmentListResponse.Department department) {
        DingtalkDepartment dingtalkEmployee = new DingtalkDepartment();
        dingtalkEmployee.setId(department.getId());
        dingtalkEmployee.setName(department.getName());
        dingtalkEmployee.setOrder(0L);
        dingtalkEmployee.setParentid(department.getParentid());
        dingtalkEmployee.setSourceIdentifier(department.getSourceIdentifier());
        return dingtalkEmployee;
    }

    public @NotNull
    List<DingtalkDepartment> getDingtalkDepartmentList(
            List<OapiDepartmentListResponse.Department> departmentList) {

        List<DingtalkDepartment> dingtalkEmployee = new ArrayList<>();
        for (OapiDepartmentListResponse.Department department : departmentList) {
            dingtalkEmployee.add(getDingtalkDepartment(department));
        }
        return dingtalkEmployee;
    }

    public @NotNull
    OapiDepartmentUpdateRequest getOapiDepartmentUpdateRequest(
            DingtalkDepartment dingtalkDepartment) {
        OapiDepartmentUpdateRequest request = new OapiDepartmentUpdateRequest();
        request.setId(dingtalkDepartment.getId());
        request.setParentid(dingtalkDepartment.getParentid() + "");
        request.setOrder(dingtalkDepartment.getOrder() + "");
        request.setName(dingtalkDepartment.getName());
        return request;
    }


}
