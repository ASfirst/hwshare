package com.hwagain.sync.service.impl;

import com.hwagain.framework.api.org.api.ISysOrgDepartmentApi;
import com.hwagain.framework.api.org.api.ISysOrgService;
import com.hwagain.framework.api.org.dto.SysOrgDepartmentDto;
import com.hwagain.framework.api.org.dto.SysOrgPersonDto;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;
import com.hwagain.sync.component.dingtalk.net.DingTalkHttpClient;
import com.hwagain.sync.component.dingtalk.net.MyDingTalkHttpClient;
import com.hwagain.sync.component.dingtalk.processor.DingtalkDepartmentProcessor;
import com.hwagain.sync.component.dingtalk.processor.StructureProcessor;
import com.hwagain.sync.component.structure.DefaultStructure;
import com.hwagain.sync.component.structure.SortType;
import com.hwagain.sync.component.structure.Structure;
import com.hwagain.sync.service.SyncSchedulingService;
import com.hwagain.sync.util.SysOrgDepartmentUtil;
import com.hwagain.sync.util.SysOrgPersonUtil;
import com.jeramtough.jtlog.facade.L;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created on 2019/6/11 9:36
 * by @author JeramTough
 */
@Service
public class SyncSchedulingServiceImpl implements SyncSchedulingService {

    private final ISysOrgService sysOrgService;
    private final ISysOrgDepartmentApi sysOrgDepartmentService;
    private final DingTalkHttpClient dingTalkHttpClient;

    @Autowired
    public SyncSchedulingServiceImpl(
            ISysOrgService sysOrgService,
            ISysOrgDepartmentApi sysOrgDepartmentService,
            MyDingTalkHttpClient dingTalkHttpClient) {
        this.sysOrgService = sysOrgService;
        this.sysOrgDepartmentService = sysOrgDepartmentService;
        this.dingTalkHttpClient = dingTalkHttpClient;
    }

    @Override
    public void executeSyncEmployeeTask() {
        //所有【化劲】员工信息list集合
        List<SysOrgPersonDto> sysOrgPersonDtos = sysOrgService.findPersonAll();

        //以工号为键值的【钉钉】员工信息map集合
        Map<String, DingtalkEmployee> dingtalkEmployeeMap = dingTalkHttpClient
                .getAllEmployees();

        //所有【钉钉】应用部门信息List集合
        List<DingtalkDepartment> dingtalkDepartments =
                dingTalkHttpClient.getDepartmentList(1);

        //以化劲部门Id作为键
        Map<String, DingtalkDepartment> dingtalkDepartmentMap = new HashMap<>();

        //新增到钉钉应用的员工集合
        List<DingtalkEmployee> newDingtalkEmployees = new ArrayList<>();
        //需要更新信息的员工集合
        List<DingtalkEmployee> updateDingtalkEmployees = new ArrayList<>();
        //被删除从钉钉应用的员工集合
        List<DingtalkEmployee> deletedDingtalkEmployees = new ArrayList<>();


        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            dingtalkDepartmentMap.put(dingtalkDepartment.getSourceIdentifier(),
                    dingtalkDepartment);
        }

        for (SysOrgPersonDto sysOrgPersonDto : sysOrgPersonDtos) {
            //如果钉钉应用系统里边不存在该用户
            boolean isContained =
                    dingtalkEmployeeMap.containsKey(sysOrgPersonDto.getFdEmployeeNumber());
            if (!isContained) {
                String hwDepartmentId =
                        sysOrgDepartmentService.getDeptByCode(
                                sysOrgPersonDto.getFdParentid()).getFdId();
                DingtalkDepartment dingtalkDepartment =
                        dingtalkDepartmentMap.get(hwDepartmentId);
                DingtalkEmployee newDingtalkEmployee =
                        SysOrgPersonUtil.toDingtalkEmployee(sysOrgPersonDto,
                                dingtalkDepartment);
                newDingtalkEmployees.add(newDingtalkEmployee);
            }
            else {
                DingtalkEmployee dingtalkEmployee =
                        dingtalkEmployeeMap.get(sysOrgPersonDto.getFdEmployeeNumber());
                //如果该用户信息在化劲员系统里面已经更新过
                boolean isModified = SysOrgPersonUtil.isModified(sysOrgPersonDto,
                        dingtalkEmployee);
                if (isModified) {
                    DingtalkDepartment dingtalkDepartment =
                            dingtalkDepartmentMap.get(sysOrgPersonDto.getFdParentid());
                    dingtalkEmployee = SysOrgPersonUtil.toDingtalkEmployee(sysOrgPersonDto,
                            dingtalkDepartment);
                    updateDingtalkEmployees.add(dingtalkEmployee);
                }
            }

            dingtalkEmployeeMap.remove(sysOrgPersonDto.getFdEmployeeNumber());
        }

        //如果化劲员工系统里面不存在而钉钉应用还存在该用户，则需要删除
        if (dingtalkEmployeeMap.size() > 0) {
            deletedDingtalkEmployees = new ArrayList<>(
                    dingtalkEmployeeMap.values());
        }

        L.debugs(newDingtalkEmployees.size(), updateDingtalkEmployees.size(),
                deletedDingtalkEmployees.size());


        //先拿100个做测试
        List<DingtalkEmployee> newDingtalkEmployees1 = new ArrayList<>();
        for (int i = 0; i < 50; i++) {
            newDingtalkEmployees1.add(newDingtalkEmployees.get(i));
        }
        //开始更新操作
        dingTalkHttpClient.createBundleEmployees(newDingtalkEmployees1);
        dingTalkHttpClient.updateBundleEmployees(updateDingtalkEmployees);
        dingTalkHttpClient.deleteBundleEmployees(deletedDingtalkEmployees);

    }

    @Override
    public void executeSyncDepartmentTask() {
        //所有【化劲】部门信息list集合
        List<SysOrgDepartmentDto> sysOrgDepartmentDtos = sysOrgDepartmentService.getListAll();
        //所有【钉钉】应用部门信息List集合
        List<DingtalkDepartment> dingtalkDepartments =
                dingTalkHttpClient.getDepartmentList(1);
        ////以化劲部门Id作为键的部门信息map集合
        Map<String, DingtalkDepartment> dingtalkDepartmentMap = new HashMap<>();

        List<DingtalkDepartment> newDingtalkDepartments = new ArrayList<>();
        List<DingtalkDepartment> updateDingtalkDepartments = new ArrayList<>();

        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            dingtalkDepartmentMap.put(dingtalkDepartment.getSourceIdentifier(),
                    dingtalkDepartment);
        }

        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            if (!dingtalkDepartmentMap.containsKey(sysOrgDepartmentDto.getFdId())) {
                DingtalkDepartment newDingtalkDepartment =
                        SysOrgDepartmentUtil.toDingtalkDepartment(sysOrgDepartmentDto);
                newDingtalkDepartment.setName(
                        "TEMP" + newDingtalkDepartment.getSourceIdentifier());
                newDingtalkDepartments.add(newDingtalkDepartment);
            }
        }

        L.arrive();

        dingTalkHttpClient.createdBundleDepartments(
                newDingtalkDepartments);

        dingtalkDepartments =
                dingTalkHttpClient.getDepartmentList(1);
        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            if (dingtalkDepartment.getName().contains("TEMP")) {
                updateDingtalkDepartments.add(dingtalkDepartment);
            }
            dingtalkDepartmentMap.put(dingtalkDepartment.getSourceIdentifier(),
                    dingtalkDepartment);
        }

        L.arrive();
        StructureProcessor structureProcessor =
                new DingtalkDepartmentProcessor(sysOrgDepartmentDtos);
        Structure structure = structureProcessor.processing();
        List<Structure> structures = DefaultStructure.getSubsAndSort(structure,
                SortType.ASCENDING);

        List<DingtalkDepartment> sortNewDingtalkDepartments = new ArrayList<>();
        for (Structure structure1 : structures) {
            String id = structure1.getValue().toString();
            SysOrgDepartmentDto sysOrgDepartmentDto = sysOrgDepartmentService.getDeptById(id);
            DingtalkDepartment dingtalkDepartment = SysOrgDepartmentUtil.toDingtalkDepartment(
                    sysOrgDepartmentDto);
            Long dingtalkParentId = 1L;
            if (sysOrgDepartmentDto.getFdParentid() != null) {
                dingtalkParentId=
                        dingtalkDepartmentMap.get(sysOrgDepartmentDto.getFdParentid()).getId();
            }
            Long dingtalkId = dingtalkDepartmentMap.get(id).getId();
            dingtalkDepartment.setParentid(dingtalkParentId);
            dingtalkDepartment.setId(dingtalkId);
            sortNewDingtalkDepartments.add(dingtalkDepartment);
        }

        for (DingtalkDepartment dingtalkDepartment : sortNewDingtalkDepartments) {
            dingTalkHttpClient.updateDepartment(dingtalkDepartment);
        }
    }

}
