package com.hwagain.sync.component.dingtalk.processor;

import com.hwagain.sync.component.structure.Structure;

/**
 * Created on 2019-06-13 00:32
 * by @author JeramTough
 */
public interface StructureProcessor {

    Structure processing();

}
