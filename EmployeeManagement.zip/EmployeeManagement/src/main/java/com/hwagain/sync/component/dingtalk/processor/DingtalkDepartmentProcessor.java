package com.hwagain.sync.component.dingtalk.processor;

import com.hwagain.framework.api.org.dto.SysOrgDepartmentDto;
import com.hwagain.sync.component.structure.DefaultStructure;
import com.hwagain.sync.component.structure.Structure;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created on 2019-06-12 20:59
 * by @author JeramTough
 */
public class DingtalkDepartmentProcessor implements StructureProcessor {

    private List<SysOrgDepartmentDto> sysOrgDepartmentDtos;
    private Map<String, SysOrgDepartmentDto> departmentDtoMap;
    private Map<String, Structure> structureMap;

    public DingtalkDepartmentProcessor(
            List<SysOrgDepartmentDto> sysOrgDepartmentDtos) {
        this.sysOrgDepartmentDtos = sysOrgDepartmentDtos;
        departmentDtoMap = new HashMap<>();
        structureMap = new HashMap<>();

        init();
    }

    protected void init() {
        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            departmentDtoMap.put(sysOrgDepartmentDto.getFdId(), sysOrgDepartmentDto);
        }
    }

    @Override
    public Structure processing() {
        Structure rootStructure = new DefaultStructure();

        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            Structure structure = structureMap.get(sysOrgDepartmentDto.getFdId());
            Structure parentStructure = structureMap.get(sysOrgDepartmentDto.getFdParentid());
            if (structure == null) {
                structure = new DefaultStructure();
                structure.setValue(sysOrgDepartmentDto.getFdId());
                structureMap.put(sysOrgDepartmentDto.getFdId(), structure);
            }
            if (parentStructure == null && sysOrgDepartmentDto.getFdParentid() != null) {
                parentStructure = new DefaultStructure();
                parentStructure.setValue(sysOrgDepartmentDto.getFdParentid());
                structureMap.put(sysOrgDepartmentDto.getFdParentid(), parentStructure);
            }

            if (parentStructure != null) {
                parentStructure.addSub(structure);
            }
            else{
                rootStructure.addSub(structure);
            }
        }

        return rootStructure;
    }
}
