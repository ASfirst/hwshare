package com.hwagain.sync.util;

import com.hwagain.framework.api.org.dto.SysOrgPersonDto;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;

import java.util.Collections;

/**
 * 关于SysOrgPersonDto的工具类Util
 * Created on 2019/6/11 16:30
 * by @author WeiBoWen
 */
public class SysOrgPersonUtil {

    /**
     * 将化劲员工对象转换成钉钉员工对象
     *
     * @param sysOrgPersonDto 化劲员工
     * @return 钉钉员工
     */
    public static DingtalkEmployee toDingtalkEmployee(SysOrgPersonDto sysOrgPersonDto,
                                                      DingtalkDepartment dingtalkDepartment) {
        DingtalkEmployee dingtalkEmployee = new DingtalkEmployee();
        dingtalkEmployee.setName(sysOrgPersonDto.getFdName());
        dingtalkEmployee.setUserId(sysOrgPersonDto.getFdUid());
        dingtalkEmployee.setEmail(sysOrgPersonDto.getFdEmail());
        dingtalkEmployee.setDepartment(Collections.singletonList(dingtalkDepartment.getId()));
        dingtalkEmployee.setMobile(sysOrgPersonDto.getFdMobile());
        dingtalkEmployee.setHiredDate(sysOrgPersonDto.getFdCreateTime());
        dingtalkEmployee.setPosition(sysOrgPersonDto.getFdPositionName());
        dingtalkEmployee.setJobnumber(sysOrgPersonDto.getFdEmployeeNumber());

        return dingtalkEmployee;
    }

    /**
     * 比较化劲员工是否和钉钉员工是同一个人
     *
     * @param sysOrgPersonDto  化劲员工
     * @param dingtalkEmployee 钉钉员工
     * @return 是否是同一个员工
     */
    public static boolean equalDingtalkEmployee(SysOrgPersonDto sysOrgPersonDto,
                                                DingtalkEmployee dingtalkEmployee) {
        return sysOrgPersonDto.getFdEmployeeNumber().equals(dingtalkEmployee.getJobnumber());
    }


    /**
     * 化劲员工是否以更新，是否需要修改钉钉员工信息
     *
     * @param sysOrgPersonDto  化劲员工
     * @param dingtalkEmployee 钉钉员工
     * @return 是否是同一个员工
     */
    public static boolean isModified(SysOrgPersonDto sysOrgPersonDto,
                                     DingtalkEmployee dingtalkEmployee) {

        //比较部门是否一致的代码没写
        if (!dingtalkEmployee.getName().equals(sysOrgPersonDto.getFdName())) {
            return true;
        }
        if (!dingtalkEmployee.getUserId().equals(sysOrgPersonDto.getFdUid())) {
            return true;
        }
        if (!dingtalkEmployee.getEmail().equals(sysOrgPersonDto.getFdEmail())) {
            return true;
        }
        if (!dingtalkEmployee.getMobile().equals(sysOrgPersonDto.getFdMobile())) {
            return true;
        }
        if (!dingtalkEmployee.getHiredDate().equals(sysOrgPersonDto.getFdCreateTime())) {
            return true;
        }
        if (!dingtalkEmployee.getPosition().equals(sysOrgPersonDto.getFdPortalName())) {
            return true;
        }
        return false;
    }

}
