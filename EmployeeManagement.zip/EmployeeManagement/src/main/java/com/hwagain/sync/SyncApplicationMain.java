package com.hwagain.sync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication(scanBasePackages = { "com.hwagain" })
public class SyncApplicationMain {
	

	public static void main(final String[] args) throws Exception {
		SpringApplication.run(SyncApplicationMain.class, args);
		System.err.println("启动成功");
	}

}