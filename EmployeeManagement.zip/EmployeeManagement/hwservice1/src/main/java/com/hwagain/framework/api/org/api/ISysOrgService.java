package com.hwagain.framework.api.org.api;

import com.hwagain.framework.api.org.dto.SysOrgPersonDto;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * Created on 2019-06-12 19:29
 * by @author JeramTough
 */
@Service
public class ISysOrgService {
    public List<SysOrgPersonDto> findPersonAll() {
        List<SysOrgPersonDto> sysOrgPersonDtos = new ArrayList<>();
        SysOrgPersonDto sysOrgPersonDto1 = new SysOrgPersonDto();
        SysOrgPersonDto sysOrgPersonDto2 = new SysOrgPersonDto();
        SysOrgPersonDto sysOrgPersonDto3 = new SysOrgPersonDto();
        SysOrgPersonDto sysOrgPersonDto4 = new SysOrgPersonDto();
        SysOrgPersonDto sysOrgPersonDto5 = new SysOrgPersonDto();
        SysOrgPersonDto sysOrgPersonDto6 = new SysOrgPersonDto();
        
        sysOrgPersonDto1.setFdName("韦博文1");
        sysOrgPersonDto1.setFdUid("1");
        sysOrgPersonDto1.setFdEmail("asdfsd@qq.com");
        sysOrgPersonDto1.setFdMobile("13367676785");
        sysOrgPersonDto1.setFdCreateTime(new Date());
        sysOrgPersonDto1.setFdPositionName("员工");
        sysOrgPersonDto1.setFdEmployeeNumber("1");
        sysOrgPersonDto1.setFdParentid("10");

        sysOrgPersonDto2.setFdName("韦博文2");
        sysOrgPersonDto2.setFdUid("2");
        sysOrgPersonDto2.setFdEmail("sadsadsa@qq.com");
        sysOrgPersonDto2.setFdMobile("13443376785");
        sysOrgPersonDto2.setFdCreateTime(new Date());
        sysOrgPersonDto2.setFdPositionName("员工");
        sysOrgPersonDto2.setFdEmployeeNumber("2");
        sysOrgPersonDto2.setFdParentid("20");

        sysOrgPersonDto3.setFdName("韦博文3");
        sysOrgPersonDto3.setFdUid("3");
        sysOrgPersonDto3.setFdEmail("sadsgddgfdgfdsa@qq.com");
        sysOrgPersonDto3.setFdMobile("19963376785");
        sysOrgPersonDto3.setFdCreateTime(new Date());
        sysOrgPersonDto3.setFdPositionName("员工");
        sysOrgPersonDto3.setFdEmployeeNumber("3");
        sysOrgPersonDto3.setFdParentid("30");

        sysOrgPersonDto4.setFdName("韦博文4");
        sysOrgPersonDto4.setFdUid("4");
        sysOrgPersonDto4.setFdEmail("sadsgddgfdgfdsa@qq.com");
        sysOrgPersonDto4.setFdMobile("19964476785");
        sysOrgPersonDto4.setFdCreateTime(new Date());
        sysOrgPersonDto4.setFdPositionName("员工");
        sysOrgPersonDto4.setFdEmployeeNumber("4");
        sysOrgPersonDto4.setFdParentid("40");

        sysOrgPersonDto5.setFdName("韦博文5");
        sysOrgPersonDto5.setFdUid("5");
        sysOrgPersonDto5.setFdEmail("sadsgddgfdgfdsa@qq.com");
        sysOrgPersonDto5.setFdMobile("19965576785");
        sysOrgPersonDto5.setFdCreateTime(new Date());
        sysOrgPersonDto5.setFdPositionName("员工");
        sysOrgPersonDto5.setFdEmployeeNumber("5");
        sysOrgPersonDto5.setFdParentid("50");

        sysOrgPersonDto6.setFdName("韦博文6");
        sysOrgPersonDto6.setFdUid("6");
        sysOrgPersonDto6.setFdEmail("sadsgddgfdgfdsa@qq.com");
        sysOrgPersonDto6.setFdMobile("19966676785");
        sysOrgPersonDto6.setFdCreateTime(new Date());
        sysOrgPersonDto6.setFdPositionName("员工");
        sysOrgPersonDto6.setFdEmployeeNumber("6");
        sysOrgPersonDto6.setFdParentid("60");

        sysOrgPersonDtos.add(sysOrgPersonDto1);
        sysOrgPersonDtos.add(sysOrgPersonDto2);
        sysOrgPersonDtos.add(sysOrgPersonDto3);
        sysOrgPersonDtos.add(sysOrgPersonDto4);
        sysOrgPersonDtos.add(sysOrgPersonDto5);
        sysOrgPersonDtos.add(sysOrgPersonDto6);
        return sysOrgPersonDtos;
    }
}
