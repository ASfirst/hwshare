package com.hwagain.framework.api.org.api;

import com.hwagain.framework.api.org.dto.SysOrgDepartmentDto;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created on 2019-06-12 19:29
 * by @author JeramTough
 */
@Service
public class ISysOrgDepartmentApi {

    private List<SysOrgDepartmentDto> sysOrgDepartmentDtos;
    private Map<String, SysOrgDepartmentDto> sysOrgDepartmentDtoMap;

    public ISysOrgDepartmentApi() {
        sysOrgDepartmentDtos = new ArrayList<>();
        sysOrgDepartmentDtoMap = new HashMap<>();
        SysOrgDepartmentDto sysOrgDepartmentDto1 = new SysOrgDepartmentDto();
        SysOrgDepartmentDto sysOrgDepartmentDto2 = new SysOrgDepartmentDto();
        SysOrgDepartmentDto sysOrgDepartmentDto3 = new SysOrgDepartmentDto();
        SysOrgDepartmentDto sysOrgDepartmentDto4 = new SysOrgDepartmentDto();
        SysOrgDepartmentDto sysOrgDepartmentDto5 = new SysOrgDepartmentDto();
        SysOrgDepartmentDto sysOrgDepartmentDto6 = new SysOrgDepartmentDto();
        SysOrgDepartmentDto sysOrgDepartmentDto7 = new SysOrgDepartmentDto();

        sysOrgDepartmentDto1.setFdDepartmentName("部门1");
        sysOrgDepartmentDto1.setFdOrder(new BigDecimal(1));
        sysOrgDepartmentDto1.setFdId("10");
        sysOrgDepartmentDto1.setFdParentid(null);

        sysOrgDepartmentDto2.setFdDepartmentName("部门2");
        sysOrgDepartmentDto2.setFdOrder(new BigDecimal(2));
        sysOrgDepartmentDto2.setFdId("20");
        sysOrgDepartmentDto2.setFdParentid(null);

        sysOrgDepartmentDto3.setFdDepartmentName("部门3");
        sysOrgDepartmentDto3.setFdOrder(new BigDecimal(3));
        sysOrgDepartmentDto3.setFdId("30");
        sysOrgDepartmentDto3.setFdParentid("10");

        sysOrgDepartmentDto4.setFdDepartmentName("部门4");
        sysOrgDepartmentDto4.setFdOrder(new BigDecimal(4));
        sysOrgDepartmentDto4.setFdId("40");
        sysOrgDepartmentDto4.setFdParentid("20");

        sysOrgDepartmentDto5.setFdDepartmentName("部门5");
        sysOrgDepartmentDto5.setFdOrder(new BigDecimal(1));
        sysOrgDepartmentDto5.setFdId("50");
        sysOrgDepartmentDto5.setFdParentid("30");

        sysOrgDepartmentDto6.setFdDepartmentName("部门6");
        sysOrgDepartmentDto6.setFdOrder(new BigDecimal(6));
        sysOrgDepartmentDto6.setFdId("60");
        sysOrgDepartmentDto6.setFdParentid("40");

        sysOrgDepartmentDto7.setFdDepartmentName("部门7");
        sysOrgDepartmentDto7.setFdOrder(new BigDecimal(1));
        sysOrgDepartmentDto7.setFdId("70");
        sysOrgDepartmentDto7.setFdParentid(null);

        sysOrgDepartmentDtos.add(sysOrgDepartmentDto1);
        sysOrgDepartmentDtos.add(sysOrgDepartmentDto2);
        sysOrgDepartmentDtos.add(sysOrgDepartmentDto3);
        sysOrgDepartmentDtos.add(sysOrgDepartmentDto4);
        sysOrgDepartmentDtos.add(sysOrgDepartmentDto5);
        sysOrgDepartmentDtos.add(sysOrgDepartmentDto6);
        sysOrgDepartmentDtos.add(sysOrgDepartmentDto7);

        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            sysOrgDepartmentDtoMap.put(sysOrgDepartmentDto.getFdId(), sysOrgDepartmentDto);
        }
    }

    public SysOrgDepartmentDto getDeptByCode(String fdParentid) {
        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            if (sysOrgDepartmentDto.getFdParentid().equals(fdParentid)) {
                return sysOrgDepartmentDto;
            }
            else {
                return null;
            }
        }
        return null;
    }

    public SysOrgDepartmentDto getDeptById(String id) {
        return sysOrgDepartmentDtoMap.get(id);
    }

    public List<SysOrgDepartmentDto> getListAll() {
        return sysOrgDepartmentDtos;
    }
}
