package com.hwagain.framework.api.org.dto;

/**
 * Created on 2019-06-12 19:34
 * by @author JeramTough
 */
public class BaseDto {
}
