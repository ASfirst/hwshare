'use strict'
module.exports = {
  NODE_ENV: '"production"',
  BASE_API:'"http://java-sit.hwagain.com:60020/sp"',
  LOGIN_PATH:'"http://console-sit.hwagain.com:10000/#/login?url="',
}
