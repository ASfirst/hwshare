
const permission = {
  state: {
    // routers: constantRouterMap
  },
  mutations: {},
  actions: {}
}

export default permission
