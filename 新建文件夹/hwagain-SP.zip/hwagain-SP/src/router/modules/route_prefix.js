export default {
    BasePrefix:'/base',
    DeductPrefix:'/deduct',
    DepositPrefix:'/deposit',
    DiscountPrefix:'/discount',
    OrderPrefix:'/order',
    PolicyPrefix:'/policy',
    PricePrefix:'/price',
    ProductPrefix:'/product',
    ReconciliationPrefix:'/reconciliation',
    SaledispsalPrefix:'/saledispsal',
}