import RoutePrefix from './route_prefix'

const { PolicyPrefix } = RoutePrefix;

export default [
  {
    path: `${PolicyPrefix}/import/policyCurrent`,
    name: '当月销售政策',
    component: () => import('@/views/policy/layout'),
    meta: {
      title: '一、当月销售政策'
    },
    children: [
      {
        path: `${PolicyPrefix}/import/policyMaintainPrice/execute`,
        name: '生活原纸产品出厂价格执行表',
        component: () => import('@/views/policy/layout'),
        meta: {
          title: '(一) 生活原纸产品出厂价格执行表'
        }
      },
      {
        path: `${PolicyPrefix}/import/policyMaintainLevelOver/execute`,
        name: '级别优惠及超量奖奖励标准执行',
        component: () => import('@/views/policy/layout'),
        meta: {
          title: '(二) 级别优惠及超量奖奖励标准执行'
        },
        children:[
          {
            path: `${PolicyPrefix}/import/policyMaintainLevel/execute`,
            name: '当月生活原纸[优惠政策]维护奖励标准执行表',
            component: () => import('@/views/policy/import/policyMaintainLevelExecute'),
            meta: {
              title: '1.当月生活原纸[优惠政策]维护奖励标准执行表'
              ,executeStatus:1
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOver/execute`,
            name: '当月生活原纸[超量奖]维护奖励标准执行表',
            component: () => import('@/views/policy/import/policyMaintainOver'),
            meta: {
              title: '2.当月生活原纸[超量奖]维护奖励标准执行表',
              executeStatus:1
            }
          }
        ],
      },
      {
        path: `${PolicyPrefix}/import/policyMaintainLevelMonth/execute`,
        name: '客户优惠政策维护',
        component: () => import('@/views/policy/layout'),
        meta: {
          title: '(三) 客户优惠政策维护'
        },
        children:[
          {
            path: `${PolicyPrefix}/import/policyMaintainSupply/execute`,
            name: '当月生活原纸机台产能及供货计划执行表',
            component: () => import('@/views/policy/import/policyMaintainSupply'),
            meta: {
              title: '1.当月生活原纸机台产能及供货计划执行表'
              ,executeStatus:1
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainLevelMonthCustomer/execute`,
            name: '当月客户【级别优惠】奖励执行表',
            component: () => import('@/views/policy/import/policyMaintainLevelMonthCustomer'),
            meta: {
              title: '2.当月客户【级别优惠】奖励执行表'
              ,executeStatus:1
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOverRewardCustomer/execute/3`,
            name: '当月【3900纸机白色】客户基础量及超量执行表',
            component: () => import('@/views/policy/import/policyMaintainOverRewardCustomer'),
            meta: {
              title: '3.当月【3900纸机白色】客户基础量及超量执行表',
              platform: '3900纸机',
              paperType: '白色'
              ,executeStatus:1
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOverRewardCustomer/execute/4`,
            name: '当月【3900纸机本色】客户基础量及超量执行表',
            component: () => import('@/views/policy/import/policyMaintainOverRewardCustomer'),
            meta: {
              title: '4.当月【3900纸机本色】客户基础量及超量执行表',
              platform: '3900纸机',
              paperType: '本色'
              ,executeStatus:1
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOverRewardCustomer/execute/5`,
            name: '当月【1575纸机白色】客户基础量及超量执行表',
            component: () => import('@/views/policy/import/policyMaintainOverRewardCustomer'),
            meta: {
              title: '5.当月【1575纸机白色】客户基础量及超量执行表',
              platform: '1575纸机',
              paperType: '白色'
              ,executeStatus:1
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOverRewardCustomer/execute/6`,
            name: '当月【高速纸机白色】客户基础量及超量执行表',
            component: () => import('@/views/policy/import/policyMaintainOverRewardCustomer'),
            meta: {
              title: '6.当月【高速纸机白色】客户基础量及超量执行表',
              platform: '高速纸机',
              paperType: '白色'
              ,executeStatus:1
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOverRewardCustomer/execute/7`,
            name: '当月【高速纸机本色】客户基础量及超量执行表',
            component: () => import('@/views/policy/import/policyMaintainOverRewardCustomer'),
            meta: {
              title: '7.当月【高速纸机本色】客户基础量及超量执行表',
              platform: '高速纸机',
              paperType: '本色'
              ,executeStatus:1
            },
          },
        ],
      },
    ]
  },
  {
    path: `${PolicyPrefix}/import/policyMaintain`,
    name: '销售政策维护',
    component: () => import('@/views/policy/layout'),
    meta: {
      title: '二、销售政策维护'
    },
    children: [
      {
        path: `${PolicyPrefix}/import/policyMaintainPrice`,
        name: '生活原纸产品出厂价格维护',
        component: () => import('@/views/policy/layout'),
        meta: {
          title: '(一) 生活原纸产品出厂价格维护'
        }
      },
      {
        path: `${PolicyPrefix}/import/policyMaintainLevelOver`,
        name: '级别优惠及超量奖奖励标准维护',
        component: () => import('@/views/policy/layout'),
        meta: {
          title: '(二) 级别优惠及超量奖奖励标准维护'
        },
        children:[
          {
            path: `${PolicyPrefix}/import/policyMaintainLevel`,
            name: '当月生活原纸[优惠政策]维护奖励标准维护表',
            component: () => import('@/views/policy/import/policyMaintainLevel'),
            meta: {
              title: '1.当月生活原纸[优惠政策]维护奖励标准维护表'
              ,executeStatus:0
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOver`,
            name: '当月生活原纸[超量奖]维护奖励标准维护表',
            component: () => import('@/views/policy/import/policyMaintainOver'),
            meta: {
              title: '2.当月生活原纸[超量奖]维护奖励标准维护表'
              ,executeStatus:0
            }
          }
        ],
      },
      {
        path: `${PolicyPrefix}/import/policyMaintainLevelMonth`,
        name: '客户优惠政策维护',
        component: () => import('@/views/policy/layout'),
        meta: {
          title: '(三) 客户优惠政策维护'
        },
        children:[
          {
            path: `${PolicyPrefix}/import/policyMaintainSupply`,
            name: '当月生活原纸机台产能及供货计划维护表',
            component: () => import('@/views/policy/import/policyMaintainSupply'),
            meta: {
              title: '1.当月生活原纸机台产能及供货计划维护表'
              ,executeStatus:0
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainLevelMonthCustomer`,
            name: '当月客户【级别优惠】奖励维护表',
            component: () => import('@/views/policy/import/policyMaintainLevelMonthCustomer'),
            meta: {
              title: '2.当月客户【级别优惠】奖励维护表'
              ,executeStatus:0
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOverRewardCustomer/3`,
            name: '当月【3900纸机白色】客户基础量及超量维护',
            component: () => import('@/views/policy/import/policyMaintainOverRewardCustomer'),
            meta: {
              title: '3.当月【3900纸机白色】客户基础量及超量维护',
              platform: '3900纸机',
              paperType: '白色'
              ,executeStatus:0
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOverRewardCustomer/4`,
            name: '当月【3900纸机本色】客户基础量及超量维护',
            component: () => import('@/views/policy/import/policyMaintainOverRewardCustomer'),
            meta: {
              title: '4.当月【3900纸机本色】客户基础量及超量维护',
              platform: '3900纸机',
              paperType: '本色'
              ,executeStatus:0
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOverRewardCustomer/5`,
            name: '当月【1575纸机白色】客户基础量及超量维护',
            component: () => import('@/views/policy/import/policyMaintainOverRewardCustomer'),
            meta: {
              title: '5.当月【1575纸机白色】客户基础量及超量维护',
              platform: '1575纸机',
              paperType: '白色'
              ,executeStatus:0
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOverRewardCustomer/6`,
            name: '当月【高速纸机白色】客户基础量及超量维护',
            component: () => import('@/views/policy/import/policyMaintainOverRewardCustomer'),
            meta: {
              title: '6.当月【高速纸机白色】客户基础量及超量维护',
              platform: '高速纸机',
              paperType: '白色'
              ,executeStatus:0
            },
          },
          {
            path: `${PolicyPrefix}/import/policyMaintainOverRewardCustomer/7`,
            name: '当月【高速纸机本色】客户基础量及超量维护',
            component: () => import('@/views/policy/import/policyMaintainOverRewardCustomer'),
            meta: {
              title: '7.当月【高速纸机本色】客户基础量及超量维护',
              platform: '高速纸机',
              paperType: '本色'
              ,executeStatus:0
            },
          },
        ],
      },
    ]
  }
]
