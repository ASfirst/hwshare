<template>
    <div class="product-container">
        <router-view></router-view>
    </div>
</template>

<script>
export default {

}
</script>
