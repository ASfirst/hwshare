<template>
    <div>纸巾纸</div>
</template>

<script>
export default {

}
</script>
<style lang="scss" >

</style>
