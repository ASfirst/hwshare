<template>
  <div>
    <el-row>
      <el-col :span="24">
        <div><b>常规、非常规产品统一销售价格表</b></div>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="16">
        <div>&nbsp;</div>
      </el-col>
      <el-col :span="8" class="text-right">
        <div>
          <el-button type="primary">说明</el-button>
          <el-button type="primary" @click="goHistoryList()">历史价格查询</el-button>
          <el-button type="primary" @click="goAdjustList">价格调整</el-button>
          <el-button type="primary" @click="goAdd()">价格录入</el-button>
        </div>
      </el-col>
    </el-row>
    <el-table
      :data="tableData" v-loading="loading" element-loading-text="拼命加载中"
      element-loading-spinner="el-icon-loading"
      stripe border
      style="width: 100%">
      <el-table-column type="index" header-align="center" label="序号" width="35"></el-table-column>
      <el-table-column prop="classText" header-align="center" label="品类" min-width="100"></el-table-column>
      <el-table-column prop="color" header-align="center" label="颜色" width="55"></el-table-column>
      <el-table-column prop="kindText" header-align="center" label="产品类型" width="70"></el-table-column>
      <el-table-column prop="unit" header-align="center" label="定价单位" width="70"></el-table-column>
      <el-table-column prop="ration" header-align="center" label="定量</br>(g/㎡)" :render-header="renderheader"
                       width="75"></el-table-column>
      <el-table-column prop="wrinkleRate" header-align="center" label="起皱率(%)" :render-header="renderheader"
                       width="55"></el-table-column>
      <el-table-column prop="layers" header-align="center" label="层数" width="60"></el-table-column>
      <el-table-column prop="width" header-align="center" label="分切幅宽合计(mm)" :render-header="renderheader"
                       min-width="80"></el-table-column>
      <el-table-column prop="diameter" header-align="center" label="单幅幅宽</br>(mm)" :render-header="renderheader"
                       min-width="70"></el-table-column>
      <el-table-column prop="addPrice" header-align="center" label="直径</br>(mm)" :render-header="renderheader"
                       width="55"></el-table-column>
      <el-table-column prop="price" header-align="center" label="增加价格</br>(元/吨)" :render-header="renderheader"
                       width="70"></el-table-column>
      <el-table-column prop="price" header-align="center" label="执行价格" width="50"></el-table-column>
      <el-table-column prop="startDate" header-align="center" label="执行时间" min-width="85"></el-table-column>
      <el-table-column prop="endDate" header-align="center" label="结束时间" min-width="85"></el-table-column>
      <el-table-column prop="isPolicyText" header-align="center" align="center" label="是否享受政策"
                       width="60"></el-table-column>
      <el-table-column prop="remark" header-align="center" label="备注" min-width="100"></el-table-column>
    </el-table>
  </div>
</template>

<script>
  import Price_API from '@/api/import/price'

  export default {
    name: "price-list",
    data() {
      return {
        loading: false,
        ruleForm: [],
        tableData: [],
      }
    },
    components: {},
    methods: {
      renderheader(h, {column, $index}) {
        return h('span', {}, [
          h('span', {}, column.label.split('</br>')[0]),
          h('br'),
          h('span', {}, column.label.split('</br>')[1])
        ])
      },
      queryImPriceList() {
        this.loading = true;
        Price_API.findAllList().then(res => {
          this.tableData = res.data || [];
          console.log(this.tableData)
          this.loading = false;
        }).catch(err => {
          this.loading = false;
          this.$message({type: 'error', message: '请求异常：' + err.msg})
          console.log(err.errorCode);
        });
      },
      //跳转
      goHistoryList() {
        this.$router.push({
          path: '/price/import/priceListOld'
        })
      },
      goAdjustList() {
        this.$router.push({
          path: '/price/import/priceAdjustA'
        });
      },
      goAdd() {
        this.$router.push({
          path: '/price/import/priceAdd'
        })
      },
    },
    created() {
    },
    mounted() {
      this.queryImPriceList();
    }
  }
</script>

<style lang="scss" scoped>

</style>


