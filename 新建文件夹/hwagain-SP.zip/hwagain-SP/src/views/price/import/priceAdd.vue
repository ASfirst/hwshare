<template>
  <div>
    <el-row>
      <el-col :span="24">
        <div><b>产品价格录入</b></div>
      </el-col>
    </el-row>
    <el-row>
      <el-col :span="12">
        <div>&nbsp;</div>
      </el-col>
      <el-col :span="12" class="text-right">
        <div>
          <el-button type="primary">说明</el-button>
          <el-button type="primary" @click="showProdListForm()">增加产品</el-button>
          <el-button type="danger" @click="inputDeleteOne()">删除行</el-button>
          <el-button type="primary" @click="doSave()">保存</el-button>
          <el-button type="primary" @click="sendToOA()">提交OA</el-button>
          <el-button type="danger" @click="$router.go(-1)">返回上一级</el-button>
        </div>
      </el-col>
    </el-row>
    <el-table
      :data="tableData" v-loading="loading" element-loading-text="拼命加载中" element-loading-spinner="el-icon-loading"
      stripe border ref="multipleTable" @selection-change="handleSelectionChange"
      style="width: 100%">
      <el-table-column fixed="left" type="selection" width="40" title="全选(用于删除行)"></el-table-column>
      <el-table-column fixed="left" type="index" header-align="center" align="center" label="序号"
                       width="45"></el-table-column>
      <el-table-column fixed="left" prop="classText" header-align="center" label="品类" min-width="100"></el-table-column>
      <el-table-column fixed="left" prop="color" header-align="center" label="颜色" width="55"></el-table-column>
      <el-table-column fixed="left" prop="kindText" header-align="center" label="产品类型" width="70"></el-table-column>
      <el-table-column prop="unit" header-align="center" label="定价单位" width="70"></el-table-column>
      <el-table-column prop="ration" header-align="center" label="定量</br>(g/㎡)" :render-header="renderheader"
                       width="75"></el-table-column>
      <el-table-column prop="wrinkleRate" header-align="center" label="起皱率(%)" :render-header="renderheader"
                       width="65"></el-table-column>
      <el-table-column prop="layers" header-align="center" label="层数" width="60"></el-table-column>
      <el-table-column prop="width" header-align="center" label="分切幅宽合计(mm)" :render-header="renderheader"
                       min-width="80"></el-table-column>
      <el-table-column prop="diameter" header-align="center" label="单幅幅宽</br>(mm)" :render-header="renderheader"
                       min-width="70"></el-table-column>
      <el-table-column prop="addPrice" header-align="center" label="直径</br>(mm)" :render-header="renderheader"
                       width="55"></el-table-column>
      <el-table-column header-align="center" label="增加价格</br>(元/吨)"
                       :render-header="renderheader"
                       width="110">
        <template slot-scope="scope">
          <el-input-number v-model="scope.row.addPrice" controls-position="right" :step="100">
          </el-input-number>
        </template>
      </el-table-column>
      <el-table-column prop="price" header-align="center" label="执行价格" width="110">
        <template slot-scope="scope">
          <el-input-number v-model="scope.row.price" controls-position="right"
                           :step="100">
          </el-input-number>
        </template>
      </el-table-column>
      <el-table-column prop="startDate" header-align="center" label="执行时间" min-width="150">
        <template slot-scope="scope">
          <el-date-picker
            v-model="scope.row.startDate" align="right" type="date" placeholder="执行时间">
          </el-date-picker>
        </template>
      </el-table-column>
      <el-table-column prop="endDate" header-align="center" label="结束时间" min-width="150">
        <template slot-scope="scope">
          <el-date-picker v-model="scope.row.endDate" align="right" type="date" placeholder="结束时间">
          </el-date-picker>
        </template>
      </el-table-column>
      <el-table-column prop="isPolicyText" header-align="center" label="是否享受政策" width="80">
        <template slot-scope="scope">
          <el-select v-model="scope.row.isPolicyText">
            <el-option value="是">
              <span style="float: left">是</span>
            </el-option>
            <el-option value="否"><span style="float: left">否</span></el-option>
          </el-select>
        </template>
      </el-table-column>
      <el-table-column prop="remark" header-align="center" label="备注" min-width="150">
        <template slot-scope="scope">
          <el-input v-model="scope.row.remark" placeholder="请输入备注"></el-input>
        </template>
      </el-table-column>
    </el-table>
    <el-dialog title="产品列表"
               :visible.sync="dialogProdVisible">
      <el-table :data="prodData" v-loading="loading" element-loading-text="拼命加载中"
                element-loading-spinner="el-icon-loading"
                stripe border ref="multipleTable" @selection-change="handleSelectionProdChange">
        <el-table-column type="selection" width="40"></el-table-column>
        <el-table-column type="index" header-align="center" label="序号" width="45"></el-table-column>
        <el-table-column prop="classText" header-align="center" label="品类" min-width="100"></el-table-column>
        <el-table-column prop="kindText" header-align="center" label="产品类型" min-width="80"></el-table-column>
        <el-table-column prop="ration" header-align="center" label="定量" min-width="80"></el-table-column>
        <el-table-column prop="layers" header-align="center" label="层数" min-width="70"></el-table-column>
        <el-table-column prop="width" header-align="center" label="幅宽(mm)" min-width="80"></el-table-column>
        <el-table-column prop="totalWidth" header-align="center" label="总幅宽" min-width="80"></el-table-column>
      </el-table>
      <div slot="footer">
        <el-button @click="selectProdConfirm()">确定</el-button>
        <el-button @click="dialogProdVisible=false">取消</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import Price_API from '@/api/import/price'

  export default {
    name: "price-list",
    data() {
      return {
        loading: false,
        dialogProdVisible: false,
        ruleForm: [],
        tableData: [],
        prodData: [],
        multipleSelection: [],
        selectedProd: []
      }
    },
    components: {},
    methods: {
      renderheader(h, {column, $index}) {
        return h('span', {}, [
          h('span', {}, column.label.split('</br>')[0]),
          h('br'),
          h('span', {}, column.label.split('</br>')[1])
        ])
      },
      initPage() {
        this.inputQueryList();
      },
      inputQueryList() {
        this.loading=true;
        Price_API.inputQueryList().then(res => {
          this.tableData = res.data || [];
          this.loading=false;
          console.log(this.tableData)
        }).catch(err => {
          this.loading=false;
          this.$message({type: 'error', message: "加载列表异常：" + err.msg})
          console.log(JSON.stringify(err));
        });
      },
      selectProdConfirm() {
        if (this.selectedProd.length <= 0) {
          this.$message({type: 'warning', message: '请选择产品'})
          return;
        }
        let prodBaseIds = this.selectedProd.map(item => item.fdId).join(';');
        Price_API.inputSelectProd(prodBaseIds).then(res => {
          this.initPage();
          this.dialogProdVisible = false;
        }).catch(err => {
          this.$message({type: 'warning', message: err.msg})
          console.log(JSON.stringify(err));
        });
      },
      inputQuerySelect() {
        Price_API.inputQuerySelect().then(res => {
          this.prodData = res.data || [];
          console.log(this.tableData)
        }).catch(err => {
          this.$message({type: 'error', message: '请求异常：' + err.msg})
          console.log(JSON.stringify(err));
        });
      },
      showProdListForm() {
        this.dialogProdVisible = true;
        this.inputQuerySelect();
      },
      inputDeleteOne() {
        if (this.multipleSelection.length <= 0) {
          this.$message({type: 'warning', message: '请选择需要删除的内容'})
          return;
        }
        this.$confirm('确定要删除所选的' + this.multipleSelection.length + '行内容吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: '警告'
        }).then(() => {
            //循环，单条删除？？
            this.multipleSelection.forEach(item => {
              Price_API.inputDeleteOne(item.fdId).then(res => {
                this.$message({
                  type: res.success ? 'success' : 'info'
                  , message: res.success ? ('删除成功【' + item.classText + '】') : res.msg
                });
                this.initPage();
              }).catch(err => {
                this.$message(
                  {
                    type: 'error'
                    , message: err.msg
                  }
                )
              })
            })
          }
        ).catch((ex) => {
          console.log(ex);
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      doSave() {
        let params = this.tableData || [];
        if (params.length == 0) {
          this.$message({
            type: 'info',
            message: '没有需要提交的数据！'
          })
          return;
        }
        let _this = this;
        Price_API.inputUpdateSome(params).then(res => {
          this.initPage();
          this.$message({
            type: res.success ? 'success' : 'info',
            message: res.success ? "保存成功" : res.msg
          })
        }).catch(err => {
          this.$message({
            type: 'error',
            message: "保存异常：" + err.msg
          })
        })
      },
      sendToOA() {
        this.$confirm('确定要提交OA吗？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: '警告'
        }).then(() => {
            Price_API.inputSentToOa().then(res => {
              this.initPage();
              this.$message({
                type: res.success ? 'success' : 'info'
                , message: res.success ? '提交成功' : res.msg
              })
            }).catch(err => {
              this.$message(
                {
                  type: 'error'
                  , message: err.msg
                }
              )
            })

          }
        ).catch((ex) => {
          console.log(ex);
          this.$message({
            type: 'info',
            message: '已取消提交OA'
          })
        })
        console.log(this.multipleSelection)
      },

      //选择
      handleSelectionChange(val) {
        this.multipleSelection = val;
      },
      handleSelectionProdChange(val) {
        this.selectedProd = val;
      }
    },
    created() {
    },
    mounted() {
      this.initPage();
    }
  }
</script>

<style lang="scss" scoped>
  .el-table td div {
    width: 100%;
    /*padding-left: 0px!important;*/
    /*padding-right:  0px!important;;*/
  }


</style>
