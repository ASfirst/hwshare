<template>
    <router-view  class="price-container"></router-view>
</template>

<script>
export default {

}
</script>
<style lang="scss" >
  .price-container{
    /*.el-row {*/
      /*margin-bottom: 10px;*/
      /*&:last-child {*/
        /*margin-bottom: 0;*/
      /*}*/
    /*}*/
  }

</style>
