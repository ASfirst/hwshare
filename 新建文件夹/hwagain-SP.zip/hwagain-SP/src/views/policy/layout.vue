<template>
    <div class="policy-container">
        <router-view></router-view>
    </div>
</template>

<script>
export default {

}
</script>
