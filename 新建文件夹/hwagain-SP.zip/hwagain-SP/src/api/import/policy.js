import fetch from '@/utils/request'

/**
 *
 * @type {{findPolicyMaintain: (function(*): *), deletePolicyMaintainOverRewardCustomer: (function(*): *), addPolicyMaintainOver: (function(*=): (AxiosPromise<any> | * | void)), deletePolicyMaintain: (function(*): *), deletePolicyMaintainOver: (function(*): *), findPolicyMaintainExecute: (function(*): *), addPolicyMaintain: (function(*=): (AxiosPromise<any> | * | void)), deleteSupplyByDetailId: (function(*): *), deletePolicyMaintainMonthCustomer: (function(*): *), addPolicyMaintainOverRewardCustomer: (function(*=): (AxiosPromise<any> | * | void)), findPolicyMaintainOver: (function(*): *), addPolicyMaintainMonthCustomer: (function(*=): (AxiosPromise<any> | * | void)), findPolicyMaintainOverRewardCustomer: (function(*): *), editControlRatePolicyMaintainOverRewardCustomer: (function(*): *), findCustomersNotInOverReward: (function(*): *), findCustomersNotIn: (function(*): *), findPolicyMaintainSupply: (function(*): *), addPolicyMaintainSupply: (function(*=): (AxiosPromise<any> | * | void)), findPolicyMaintainMonthCustomer: (function(*): *)}}
 */
const Policy_API = {
  /**
   * 二、销售政策维护
   *  */
  //(二) 级别优惠及超量奖奖励标准维护-->1.当月生活原纸【标准政策】维护奖励标准维护表
  findPolicyMaintain: (params) => {
    return fetch.get(`/policy/poPolicy/findPolicyMaintain`, {params});
  },
  findPolicyMaintainExecute: (params) => {
    return fetch.get(`/policy/poPolicy/findPolicyMaintainExecute`, {params});
  },
  deletePolicyMaintain: (params) => {
    return fetch.get(`/policy/poPolicy/deletePolicyMaintain`, {params});
  },
  addPolicyMaintain: (params) => {
    return fetch.post(`/policy/poPolicy/addPolicyMaintain`, params);
  },
  //2.当月生活原纸【超量奖】维护奖励标准维护表
  findPolicyMaintainOver: (params) => {
    return fetch.get(`/policy/poOver/findPolicyMaintainOver`, {params});
  },
  addPolicyMaintainOver: (params) => {
    return fetch.post(`/policy/poOver/addPolicyMaintainOver`, params);
  },
  deletePolicyMaintainOver: (params) => {
    return fetch.get(`/policy/poOver/deletePolicyMaintainOver`, {params});
  },
  /**(三)客户优惠奖励维护 */
  //当月生活原纸机台产能和供货计划维护
  findPolicyMaintainSupply: (params) => {
    return fetch.get(`/policy/poSupply/findPolicyMaintainSupply`, {params});
  },
  addPolicyMaintainSupply: (params) => {
    return fetch.post(`/policy/poSupply/addPolicyMaintainSupply`, params);
  },
  deleteSupplyByDetailId: (params) => {
    return fetch.get(`/policy/poSupply/deleteByDetailId`, {params});
  },
  //客户级别优惠维护
  findPolicyMaintainMonthCustomer: (params) => {
    return fetch.get(`/policy/poPolicyMonth/findPolicyMaintainMonthCustomer`, {params});
  },
  findCustomersNotIn: (params) => {
    return fetch.get(`/policy/poPolicyMonth/findCustomersNotIn`, {params});
  },
  addPolicyMaintainMonthCustomer: (params) => {
    return fetch.post(`/policy/poPolicyMonth/addPolicyMaintainMonthCustomer`, params);
  },
  deletePolicyMaintainMonthCustomer: (params) => {
    return fetch.get(`/policy/poPolicyMonth/deletePolicyMaintainMonthCustomer`, {params});
  },
  //客户超量奖维护
  findPolicyMaintainOverRewardCustomer: (params) => {
    return fetch.get(`/policy/poOverReward/findPolicyMaintainOverRewardCustomer`, {params});
  },
  addPolicyMaintainOverRewardCustomer: (params) => {
    return fetch.post(`/policy/poOverReward/addPolicyMaintainOverRewardCustomer`, params);
  },
  deletePolicyMaintainOverRewardCustomer: (params) => {
    return fetch.get(`/policy/poOverReward/deletePolicyMaintainOverRewardCustomer`, {params});
  },
  editControlRatePolicyMaintainOverRewardCustomer: (params) => {
    return fetch.get(`/policy/poOverReward/editControlRatePolicyMaintainOverRewardCustomer`, {params});
  },
  findCustomersNotInOverReward: (params) => {
    return fetch.get(`/policy/poOverReward/findCustomersNotInOverReward`, {params});
  },


  /**
   * 当月生活原纸【运输补贴】审核表维护接口
   */
  findAllPoTransport: (params) => {
    return fetch.get(`/policy/poTransport/findAll`, {params});
  },
  savePoTransport:(params)=>{
    return fetch.post(`/policy/poTransport/save`, params);
  }
};
export default Policy_API
