import Product_API from './product'

export default {
    Product_API
}