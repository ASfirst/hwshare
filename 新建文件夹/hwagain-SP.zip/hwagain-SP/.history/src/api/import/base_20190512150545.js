import fetch from '@/utils/request'

const Base_API = {
  //产品品类
  findAllProductClass: (params) => {
    return fetch.get(`/product/productClass/findAll?platform=`+params)
  },
  
  addOneProductclass:(params) =>{
    return fetch.post(`/product/productClass/addOne`,params)
  },
  //产品类型
  findAllProductKind: (params) => {
    return fetch.get(`/product/productKind/findAll?platform=`+params)
  },

  addOneProductKind:(params)=>{
    return fetch.post(`/product/productKind/addOne`,params)
  },

  //常规品、非常规品定义
  findAllProductBase: (params) => {
    return fetch.get(`product/productBase/findAll?platform=`+params)
  },

  inputSentProductBaseToOa: (params) =>{
    return fetch.post(`/product/productBase/inputSentProductBaseToOa`,{params})
  },

  addOneProductBase: (params) =>{
    return fetch.post(`/product/productBase/addOne`,params)
  },

  updateProductBase:(params) =>{
    return fetch.post(`/product/productBase/updateOne`,params)
  },

  //客户基本资料
  findAllCustomer: (params) => {
    return fetch.get(`customer/customer/findCooperatingCustomer`,{params})
  },
  
  findOneCustomer: (params) => {
    return fetch.get(`/customer/customer/findOne?fdId=`+params)
  },
  
  findByPage: (params) => {
    return fetch.get(`/customer/customer/findByPage`,{params})
  },

  findAllCustomerManager:(params)=>{
    return fetch.get(`/customer/baseCustomerManager/findAll`,{params})
  },

  editOneCustomerManager:(params)=>{
    return fetch.post(`/customer/baseCustomerManager/editOne`,params)
  },

  //生产机器产能维护表
  findAll:(params)=>{
    return fetch.get(`/base/baseMachine/findAll`,{params})
  },

  addOneMachine:(params)=>{
    return fetch.post(`/base/baseMachine/save`,params)
  }

}

export default Base_API;
