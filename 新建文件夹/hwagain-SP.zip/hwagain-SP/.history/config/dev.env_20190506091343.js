'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  // BASE_API:'"http://java-sit.hwagain.com:60020/sp"',
  BASE_API:'"http://xlz.hwagain.com:8080/sp"',
  LOGIN_PATH:'"http://console-sit.hwagain.com:10000/#/login?url="',
})
