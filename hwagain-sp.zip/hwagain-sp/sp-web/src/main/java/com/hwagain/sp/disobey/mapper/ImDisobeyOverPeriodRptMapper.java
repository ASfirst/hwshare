package com.hwagain.sp.disobey.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;
import com.hwagain.sp.disobey.dto.ImDisobeyOverPeriodListDto;
import com.hwagain.sp.disobey.dto.ImDisobeyOverPeriodRptDto;
import com.hwagain.sp.disobey.entity.ImDisobeyOverPeriod;

public interface ImDisobeyOverPeriodRptMapper extends BaseMapper<ImDisobeyOverPeriod>  {
	public List<ImDisobeyOverPeriodListDto> queryOverPeriodCustomer();
	public List<ImDisobeyOverPeriodListDto> queryOverPeriodFromOrder(@Param("customerId") String customerId);
	public List<ImDisobeyOverPeriodListDto> queryOverPeriodGroupByCust();
	public List<ImDisobeyOverPeriodRptDto> queryOverPeriodeDetailByCustomerId(@Param("customerId") String customerId);
	public List<ImDisobeyOverPeriodListDto> queryOverPeriodDeductList(@Param("date1") String date1,@Param("date2") String date2);
	public List<ImDisobeyOverPeriodRptDto> queryOverPeriodDeductDetailList(@Param("customerId") String customerId,@Param("date1") String date1,@Param("date2") String date2);
	
}
