package com.hwagain.sp.disobey.web;

import java.math.BigDecimal;
import java.util.List;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponse;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.disobey.dto.BaseDisobeyDto;
import com.hwagain.sp.disobey.dto.BaseDisobeyEditDto;
import com.hwagain.sp.disobey.service.IBaseDisobeyEditService;
import com.hwagain.sp.disobey.service.IBaseDisobeyService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
@RestController
@RequestMapping(value="/disobey/baseDisobey",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "违约扣款标准", description = "违约扣款标准")
public class BaseDisobeyController extends BaseController{
	
	@Autowired
	IBaseDisobeyService baseDisobeyService;
	
	@Autowired
	IBaseDisobeyEditService baseDisobeyEditService;
	
	//查询所有违约扣款标准
	@RequestMapping("/findAll")
	@ApiOperation(value="查询所有违约扣款标准",notes="查询所有违约扣款标准",httpMethod="GET")
	public Response findAll(){
		return SuccessResponseData.newInstance(baseDisobeyService.findAll());
	}	
	
	/**
	 * 新增双人录入记录
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/save",method={RequestMethod.POST})
	@ApiOperation(value = "双人录入", notes = "双人录入",httpMethod="POST")
	public Response save(@RequestBody BaseDisobeyEditDto dto){
		return SuccessResponseData.newInstance(baseDisobeyEditService.insert(dto));
	}
	
	@RequestMapping("/matching")
	@ApiOperation(value="双人录入数据匹配",notes="双人录入数据匹配",httpMethod="POST")
	public Response matching(@RequestBody List<BaseDisobeyEditDto> list){
		return SuccessResponseData.newInstance(baseDisobeyEditService.matching(list));
	}
	
	@RequestMapping("/update")
	@ApiOperation(value="调整",notes="update",httpMethod="POST")
	public Response updateOne(@RequestBody BaseDisobeyDto dto){
		return SuccessResponseData.newInstance(baseDisobeyService.updateOne(dto));
	}
	
	@RequestMapping("/findDisobeyList")
	@ApiOperation(value="当前用户记录",notes="当前用户记录",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="disobeyContent",value="违约事项",paramType="query",required=true,dataType="String"),
		@ApiImplicitParam(name="unit",value="计算单位",paramType="query",required=true,dataType="String"),
		@ApiImplicitParam(name="penaltyStandard",value="扣款标准",paramType="query",required=true,dataType="BigDecimal")
	})
	public Response findDisobeyList(String disobeyContent,String unit,BigDecimal penaltyStandard){
		return SuccessResponseData.newInstance(baseDisobeyEditService.findDisobeyList(disobeyContent, unit, penaltyStandard));
	}
//	/**
//	 * 新增一条违约扣款标准
//	 * 
//	 * @param dto
//	 * @return
//	 */
//	@RequestMapping(value="/updateOneDisobey",method={RequestMethod.POST})
//	@ApiOperation(value = "新增一条违约扣款标准", notes = "新增一条违约扣款标准",httpMethod="POST")
//	public Response updateOneDisobey(@RequestBody BaseDisobeyEditDto dto){
//		return SuccessResponseData.newInstance(
//				baseDisobeyEditService.updateOneDisobey(dto.getFdId().toString(), dto.getDisobeyContent(), dto.getUnit(), dto.getPenaltyStandard(), dto.getStartTime(), dto.getRemark()));
//	}
	
//	/**
//	 * 新增多条违约扣款标准
//	 * 
//	 * @param dto
//	 * @return
//	 */
//	@RequestMapping(value="/updateMoreDisobey",method={RequestMethod.POST})
//	@ApiOperation(value = "新增多条违约扣款标准", notes = "新增多条违约扣款标准",httpMethod="POST")
//	public Response updateMoreDisobey(@RequestBody List<BaseDisobeyEditDto> list){
//		return SuccessResponseData.newInstance(
//				baseDisobeyEditService.updateMoreDisobey(list));
//	}
	
	/**
	 * 删除数据，可批量
	 * 
	 * @param ids  格式：1;2;3;4....
	 * @return
	 */
	@RequestMapping(value="/delete",method={RequestMethod.GET})
	@ApiOperation(value = "删除数据", notes = "删除数据",httpMethod="GET")
		@ApiImplicitParams({
		@ApiImplicitParam(name = "ids", value = "数据集,格式：1;2;3;4....", paramType = "query", required = false, dataType = "String")
	})
	public Response delete(String ids){
		Boolean isOk = baseDisobeyEditService.deleteByIds(ids);
		return SuccessResponse.newInstance(isOk?"删除成功！":"删除失败！");
	}
	
	/**
	 * 启用数据
	 * 
	 * @param id
	 * @param statusText
	 * @return
	 */
	@RequestMapping(value="/updateStatus",method={RequestMethod.GET})
	@ApiOperation(value = "是否启用", notes = "是否启用",httpMethod="GET")
		@ApiImplicitParams({
		@ApiImplicitParam(name = "id", value = "id", paramType = "query", required = true, dataType = "String"),
		@ApiImplicitParam(name = "statusText", value = "启用或停用", paramType = "query", required = true, dataType = "String")
	})
	public Response updateStatus(String id,String statusText){
		Boolean isOk = baseDisobeyService.updateStatus(id,statusText);
		return SuccessResponse.newInstance(isOk?"启用成功！":"启用失败！");
	}

}
