package com.hwagain.sp.process.mapper;

import com.hwagain.sp.process.entity.ImProcessBatch;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public interface ImProcessBatchMapper extends BaseMapper<ImProcessBatch> {

}