package com.hwagain.sp.policy.service.impl;

import java.util.*;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;
import com.hwagain.sp.customer.dto.CustomerDto;
import com.hwagain.sp.customer.entity.Customer;
import com.hwagain.sp.customer.service.ICustomerService;
import com.hwagain.sp.policy.dto.params.IdNotNullDto;
import com.hwagain.sp.policy.dto.params.area.CheckPoAreaDto;
import com.hwagain.sp.policy.dto.params.area.PoAreaAndCustomerDto;
import com.hwagain.sp.policy.dto.params.area.SavePoAreaDto;
import com.hwagain.sp.policy.entity.PoArea;
import com.hwagain.sp.policy.dto.PoAreaDto;
import com.hwagain.sp.policy.mapper.PoAreaMapper;
import com.hwagain.sp.policy.service.IPoAreaService;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author weibw
 * @since 2019-06-24
 */
@Service("poAreaService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoAreaServiceImpl extends ServiceImpl<PoAreaMapper, PoArea>
        implements IPoAreaService {

    // entity转dto
    static MapperFacade entityToDtoMapper;

    // dto转entity
    static MapperFacade dtoToEntityMapper;

    private final ICustomerService iCustomerService;


    static {
        MapperFactory factory = new DefaultMapperFactory.Builder().build();
        factory.classMap(PoArea.class, PoAreaDto.class).byDefault().register();
        entityToDtoMapper = factory.getMapperFacade();

        MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
        factorytwo.classMap(PoAreaDto.class, PoArea.class).byDefault().register();
        dtoToEntityMapper = factorytwo.getMapperFacade();
    }

    @Autowired
    public PoAreaServiceImpl(ICustomerService iCustomerService) {
        this.iCustomerService = iCustomerService;
    }

    @Override
    public List<PoAreaAndCustomerDto> findAll() {
        Wrapper<PoArea> wrapper = new CriterionWrapper<PoArea>(PoArea.class);
        List<PoArea> list = super.selectList(wrapper);
        List<PoAreaAndCustomerDto> poAreaAndCustomerDtos = new ArrayList<>(list.size());
        for (PoArea poArea : list) {
            poAreaAndCustomerDtos.add(this.findOne(poArea.getFdId() + ""));
        }
        return poAreaAndCustomerDtos;
    }

    @Override
    public PoAreaAndCustomerDto findOne(String fdId) {
        try {
            PoArea poArea = super.selectById(fdId);
            CustomerDto customerDto = iCustomerService.findOne(poArea.getCustomerId());
            PoAreaAndCustomerDto poAreaAndCustomerDto = entityToDtoMapper.map(poArea,
                    PoAreaAndCustomerDto.class);
            poAreaAndCustomerDto.setCounty(customerDto.getCounty());
            poAreaAndCustomerDto.setCity(customerDto.getCity());
            poAreaAndCustomerDto.setCustName(customerDto.getCustName());
            poAreaAndCustomerDto.setShortName(customerDto.getShortName());
            return poAreaAndCustomerDto;
        }
        catch (Exception e) {
            e.printStackTrace();
        }
        return null;

    }

    @Override
    public PoAreaDto save(PoAreaDto dto) {

        //校验参数的合法性
        verifyDto(dtoToEntityMapper.map(dto, SavePoAreaDto.class));

        PoArea entity = dtoToEntityMapper.map(dto, PoArea.class);

        entity.setFdId(IdWorker.getId());
        entity.setLastAlterTime(new Date());
        entity.setCreaterId(UserUtils.getUserInfo().getId());
        entity.setCreateTime(new Date());
        super.insert(entity);
        return dto;
    }

    @Override
    public PoAreaDto update(PoAreaDto dto) {
        //校验参数的合法性
        verifyDto(dtoToEntityMapper.map(dto, IdNotNullDto.class));

        PoArea entity = dtoToEntityMapper.map(dto, PoArea.class);
        super.updateById(entity);
        return dto;
    }

    @Override
    public Boolean deleteByIds(String ids) {
        String[] id = ids.split(";");
        return super.deleteBatchIds(Arrays.asList(id));
    }

    @Override
    public Boolean check(CheckPoAreaDto checkPoAreaDto) throws CustomException {
        //校验参数的合法性
        verifyDto(checkPoAreaDto);

        PoArea entity = dtoToEntityMapper.map(checkPoAreaDto, PoArea.class);
        entity.setLastAlterTime(new Date());
        entity.setCheckedBy(UserUtils.getUserInfo().getName());
        entity.setCheckedDate(new Date());

        return super.updateById(entity);
    }
	
	/*@Override
	public PageDto<PoAreaDto> findByPage(PoAreaDto dto,PageVO pageVo) {
		PageDto<PoAreaDto> pageDto = new PageDto<PoAreaDto>();
		pageDto.setPage(pageVo.getPage()+1);
		pageDto.setPageSize(pageVo.getPageSize());
		Wrapper< PoArea> wrapper = new CriterionWrapper< PoArea>( PoArea.class);
		Page< PoArea> page = super.selectPage(new Page< PoArea>(pageDto.getPage(), pageDto.getPageSize()), wrapper);
		if (ArraysUtil.notEmpty(page.getRecords())) {
			pageDto.setList(entityToDtoMapper.mapAsList(page.getRecords(), PoAreaDto.class));
		}
		pageDto.setRowCount(page.getTotal());
		return pageDto;
	}*/
    //*************

    private void verifyDto(Object checkDto) {
        //表单数据合法性校验
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> constraintViolations =
                validator.validate(checkDto);
        for (ConstraintViolation<Object> constraintViolation : constraintViolations) {
            //拿到数据校验信息
            Assert.throwException("校验参数失败," + constraintViolation.getMessage());
        }
    }
}
