package com.hwagain.sp.order.service.impl;

import com.hwagain.sp.order.entity.ImOrderSpec;
import com.hwagain.sp.order.dto.ImOrderSpecDto;
import com.hwagain.sp.order.mapper.ImOrderSpecMapper;
import com.hwagain.sp.order.service.IImOrderSpecService;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@Service("imOrderSpecService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImOrderSpecServiceImpl extends ServiceImpl<ImOrderSpecMapper, ImOrderSpec> implements IImOrderSpecService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImOrderSpec.class, ImOrderSpecDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImOrderSpecDto.class, ImOrderSpec.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
}
