package com.hwagain.sp.customer.service.impl;

import com.hwagain.sp.customer.entity.BaseCustomerManager;
import com.hwagain.sp.customer.entity.Customer;
import com.hwagain.sp.customer.dto.BaseCustomerManagerDto;
import com.hwagain.sp.customer.dto.CustomerBalanceDto;
import com.hwagain.sp.customer.dto.CustomerDto;
import com.hwagain.sp.customer.mapper.CustomerMapper;
import com.hwagain.sp.customer.service.ICustomerService;
import com.hwagain.sp.price.dto.ImTransPriceDto;
import com.hwagain.sp.product.dto.ProductInventoryDto;
import com.hwagain.sp.util.JDBCConfig;
import com.hwagain.util.PageDto;
import com.alibaba.dubbo.common.utils.StringUtils;
import com.hwagain.framework.core.dto.PageVO;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.ArraysUtil;
import com.hwagain.framework.core.util.SpringBeanUtil;
import com.hwagain.framework.core.util.StringUtil;
import com.hwagain.framework.mybatisplus.enums.SqlLike;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.plugins.Page;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author hanj
 * @since 2018-10-11
 */
@Service("customerService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class CustomerServiceImpl extends ServiceImpl<CustomerMapper, Customer> implements ICustomerService {
	
	// entity转dto
	public static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(Customer.class, CustomerDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(CustomerDto.class, Customer.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

//	@Override
//	public Customer findById(Integer id) {
//		// TODO Auto-generated method stub
//		Wrapper<Customer> wrapper=new CriterionWrapper<Customer>(Customer.class);
//		wrapper.eq("id", id);
//		return super.selectFirst(wrapper);
//	}
	@Override
	public List<CustomerDto> findCooperatingCustomer(){
		Wrapper<Customer> wrapper=new CriterionWrapper<Customer>(Customer.class);
		wrapper.eq("status", "使用");
		wrapper.orderBy("business_start_date");
		List<Customer> list=super.selectList(wrapper);
		return  entityToDtoMapper.mapAsList(list,CustomerDto.class);
		
	}
	@Override
	public List<CustomerDto> findByPage(String custName,String province,String city,String county,String custTypeName){
		Wrapper<Customer> wrapper=new CriterionWrapper<Customer>(Customer.class);
		wrapper.eq("status", "使用");
		wrapper.like("cust_name", custName,SqlLike.DEFAULT);
		wrapper.eq("province", province);
		wrapper.eq("city", city);
		wrapper.eq("county",county);
		wrapper.eq("cust_type_name", custTypeName);
		List<Customer> list=super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list,CustomerDto.class);	
	}
	@Override
	public CustomerDto findOne(Long fdId){
		return entityToDtoMapper.map(super.selectById(fdId),CustomerDto.class);	
	}

	//生成K3资金转移单
	//调用参数说明
	//SourceID=源单ID BillNo=订单编号   sDate=日期  sCustName=提货客户名称  DepositAmountTotal=订金金额  sCooperationCustomerName=合作客户名称
	@Override
	public boolean createDepositmove(int SourceID, String BillNo, Date orderDate, String sCustName,
			BigDecimal DepositAmountTotal, String sCooperationCustomerName) throws CustomException {
		// TODO Auto-generated method stub
		JDBCConfig jDBCConfig=SpringBeanUtil.getBean(JDBCConfig.class);
		String url = jDBCConfig.getK3Url();// 127.0.0.1是本机地址，XE是精简版Oracle的默认数据库名
		String username = jDBCConfig.getK3Username();// 用户名,系统默认的账户名
		String password = jDBCConfig.getK3Password();// 你安装时选设置的密码

		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");// 加载sql驱动程序
			con = DriverManager.getConnection(url, username, password);// 获取连接
			
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
			String dateString = formatter.format(orderDate);

			String sql = "exec DB241.赣州纸品.dbo.CreateDepositmove "+String.valueOf(SourceID)
			+",'"+BillNo+"','"+dateString+"','"+sCustName+"','"+DepositAmountTotal.toString()+"','"
			+sCooperationCustomerName+"'";
			
			pre = con.prepareStatement(sql);// 实例化预编译语句
			if (pre.executeUpdate() > 0) {
				return true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return false;
	}
	
	//获取K3客户定金和可用余额
	@Override
	public List<CustomerBalanceDto> getGoodsBanlanceByCust(String custName, Integer year, Integer month)
			throws CustomException {
		// TODO Auto-generated method stub
		JDBCConfig jDBCConfig=SpringBeanUtil.getBean(JDBCConfig.class);
		List<CustomerBalanceDto> list= new ArrayList<CustomerBalanceDto>();
		String url = jDBCConfig.getK3Url();// 127.0.0.1是本机地址，XE是精简版Oracle的默认数据库名
		String username = jDBCConfig.getK3Username();// 用户名,系统默认的账户名
		String password = jDBCConfig.getK3Password();// 你安装时选设置的密码

		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");// 加载sql驱动程序
			con = DriverManager.getConnection(url, username, password);// 获取连接
			
			String sql = "exec DB241.赣州纸品.dbo.GetCustBanlance '"+custName+"'," +year.toString()+"," +month.toString();// 预编译语句，“？”代表参数
			
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result = pre.executeQuery();// 执行查询，注意括号中不需要再加参数
			ResultSetMetaData md = pre.getMetaData();
			int columnCount = md.getColumnCount();
			while (result.next()) {
				Map<String, Object> map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++)
					map.put(md.getColumnName(i).toString(), result.getObject(i));
				CustomerBalanceDto dto=new CustomerBalanceDto();
				
				dto=customerBalanceAdd(map);
				list.add(dto);
			}
			
			//查询不到数据负空值
			if (list.size()==0) {
				CustomerBalanceDto dto=new CustomerBalanceDto();
				list.add(dto);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return entityToDtoMapper.mapAsList(list, CustomerBalanceDto.class);
	}
	
	private CustomerBalanceDto customerBalanceAdd(Map<String, Object> obj) {
		CustomerBalanceDto dto=new CustomerBalanceDto();
		Integer FCustID=(Integer) obj.get("FCustID");
		String FCustNumber=(String) obj.get("FCustNumber");
		String FCustName=(String) obj.get("FCustName");
		
		Integer FCooperationCustID=(Integer) obj.get("FCooperationCustID");
		String FCooperationCustNumber=(String) obj.get("FCooperationCustNumber");
		String FCooperationCustName=(String) obj.get("FCooperationCustName");
		
		//BigDecimal FTotalAmount=(BigDecimal) obj.get("FTotalAmount");
		//BigDecimal FDownPayment=(BigDecimal) obj.get("FDownPayment");
		BigDecimal FBanlance=(BigDecimal) obj.get("FBanlance");
		
		dto.setFCustID(FCustID);
		dto.setFCustNumber(FCustNumber);
		dto.setFCustName(FCustName);
		dto.setFCooperationCustID(FCooperationCustID);
		dto.setFCooperationCustNumber(FCooperationCustNumber);
		dto.setFCooperationCustName(FCooperationCustName);
		//dto.setFTotalAmount(FTotalAmount);
		//dto.setFDownPayment(FDownPayment);
		dto.setFBanlance(FBanlance);
		
		
		return dto;
	}
	
	
	//获取K3客户定金和可用余额
	@Override
	public List<CustomerBalanceDto> getDepositBanlanceByCust(String custName, Integer year, Integer month)
			throws CustomException {
		// TODO Auto-generated method stub
		JDBCConfig jDBCConfig=SpringBeanUtil.getBean(JDBCConfig.class);
		List<CustomerBalanceDto> list= new ArrayList<CustomerBalanceDto>();
		String url = jDBCConfig.getK3Url();// 127.0.0.1是本机地址，XE是精简版Oracle的默认数据库名
		String username = jDBCConfig.getK3Username();// 用户名,系统默认的账户名
		String password = jDBCConfig.getK3Password();// 你安装时选设置的密码

		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");// 加载sql驱动程序
			con = DriverManager.getConnection(url, username, password);// 获取连接
			
			String sql = "exec DB241.赣州纸品.dbo.GetDepositBalance '"+custName+"'," +year.toString()+"," +month.toString();// 预编译语句，“？”代表参数
			
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result = pre.executeQuery();// 执行查询，注意括号中不需要再加参数
			ResultSetMetaData md = pre.getMetaData();
			int columnCount = md.getColumnCount();
			while (result.next()) {
				Map<String, Object> map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++)
					map.put(md.getColumnName(i).toString(), result.getObject(i));
				CustomerBalanceDto dto=new CustomerBalanceDto();
				
				dto=depositBanlanceAdd(map);
				list.add(dto);
			}
			
			//查询不到数据负空值
			if (list.size()==0) {
				CustomerBalanceDto dto=new CustomerBalanceDto();
				list.add(dto);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return entityToDtoMapper.mapAsList(list, CustomerBalanceDto.class);
	}	
	
	private CustomerBalanceDto depositBanlanceAdd(Map<String, Object> obj) {
		CustomerBalanceDto dto=new CustomerBalanceDto();
		Integer FCustID=(Integer) obj.get("FCustID");
		String FCustNumber=(String) obj.get("FCustNumber");
		String FCustName=(String) obj.get("FCustName");
		BigDecimal FBanlance=(BigDecimal) obj.get("FBanlance");
		
		dto.setFCustID(FCustID);
		dto.setFCustNumber(FCustNumber);
		dto.setFCustName(FCustName);
		dto.setFBanlance(FBanlance);
		
		
		return dto;
	}
	@Override
	public Customer findByCustName(String custName) throws CustomException {
		Wrapper<Customer> wrapper=new CriterionWrapper<Customer>(Customer.class);
//		System.err.println(custName);
		wrapper.eq("cust_name", custName);
		return super.selectFirst(wrapper);	
	}
	
	//获取当前登录客户的客户资料
	@Override
	public List<CustomerDto> customerByUserId(){
		String UserId="A11111";
		return null;
	}
	/**
	 * 获取客户资料--分页
	 */
	@Override
	public PageDto<CustomerDto> findByPage(CustomerDto dto, PageVO pageVO) {
		Wrapper<Customer> wrapper=new CriterionWrapper<Customer>(Customer.class);
		wrapper.eq("status", "使用");
		if(!StringUtils.isEmpty(dto.getCustName())){
			wrapper.like("cust_name", dto.getCustName(), SqlLike.DEFAULT);
		}
		if(!StringUtils.isEmpty(dto.getProvince())){
			wrapper.eq("province", dto.getProvince());
		}
		if(!StringUtils.isEmpty(dto.getCity())){
			wrapper.eq("city", dto.getCity());
		}
		if(!StringUtils.isEmpty(dto.getCounty())){
			wrapper.eq("county",dto.getCounty());
		}
		if(!StringUtils.isEmpty(dto.getCustTypeName())){
			wrapper.eq("cust_type_name", dto.getCustTypeName());
		}
		wrapper.orderBy("province");
		wrapper.orderBy("city");
		PageDto<CustomerDto> result = new PageDto<CustomerDto>();
		
		Page<Customer> page = super.selectPage(new Page<Customer>(pageVO.getPage()+1, pageVO.getPageSize()), wrapper);
		if (ArraysUtil.notEmpty(page.getRecords())) {
			result.setList(entityToDtoMapper.mapAsList(page.getRecords(), CustomerDto.class));
		}
		result.setPage(page.getCurrent());
		result.setPageSize(page.getSize());
		result.setRowCount(page.getTotal());
		
		return result;
	}
}
