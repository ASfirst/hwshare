package com.hwagain.sp.order.service.impl;

import com.hwagain.sp.order.entity.ProductSetDetail;
import com.hwagain.sp.order.dto.ProductSetDetailDto;
import com.hwagain.sp.order.mapper.ProductSetDetailMapper;
import com.hwagain.sp.order.service.IProductSetDetailService;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@Service("productSetDetailService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ProductSetDetailServiceImpl extends ServiceImpl<ProductSetDetailMapper, ProductSetDetail> implements IProductSetDetailService {
	
	// entity转dto
	public static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ProductSetDetail.class, ProductSetDetailDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ProductSetDetailDto.class, ProductSetDetail.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
}
