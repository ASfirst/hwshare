package com.hwagain.sp.base.mapper;

import com.hwagain.sp.base.entity.BaseMachine;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huangdh
 * @since 2019-05-12
 */
public interface BaseMachineMapper extends BaseMapper<BaseMachine> {

}