package com.hwagain.sp.order.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author huangdh
 * @since 2018-11-16
 */
@TableName("im_pickup_order_detail")
public class ImPickupOrderDetail implements Serializable {

    private static final long serialVersionUID = 1L;

	@TableId("fd_id")
	private Long fdId;
    /**
     * 提货单主表ID
     */
	@TableField("pickup_order_id")
	private Long pickupOrderId;
    /**
     * 订单ID
     */
	@TableField("order_no")
	private String orderNo;
    /**
     * 产品ID
     */
	@TableField("class_no")
	private String classNo;
	@TableField("kind_no")
	private String kindNo;
	private String ration;
	private String layer;
	private Integer width;
    /**
     * 等级：优先品，副品
     */
	private String grade;
    /**
     * 对应K3物料代码
     */
	@TableField("material_code")
	private String materialCode;
    /**
     * 可提货量（吨）
     */
	@TableField("avaliable_weight")
	private BigDecimal avaliableWeight;
    /**
     * 本次提货量（吨）
     */
	private BigDecimal weight;
    /**
     * 结算方式：现金，承况汇票。默认为现金
     */
	@TableField("settlement_method")
	private String settlementMethod;
    /**
     * 出厂单价（元/吨）
     */
	private BigDecimal price;
    /**
     * 折前金额
     */
	private BigDecimal amount;
    /**
     * 折后单价（元/吨）
     */
	@TableField("dscount_price")
	private BigDecimal dscountPrice;
    /**
     * 折后金额
     */
	@TableField("discount_amount")
	private BigDecimal discountAmount;
	@TableField("over_weight")
	private BigDecimal overWeight;
	@TableField("over_weight_price")
	private BigDecimal overWeightPrice;
	@TableField("over_weight_amount")
	private BigDecimal overWeightAmount;
    /**
     * 折扣金额
     */
	private BigDecimal discount;
    /**
     * 汽运单价
     */
	@TableField("car_fee_price")
	private BigDecimal carFeePrice;
    /**
     * 汽运金额
     */
	@TableField("car_fee_amount")
	private BigDecimal carFeeAmount;
    /**
     * 应缴金额（货款及运费合计）
     */
	@TableField("payment_amount")
	private BigDecimal paymentAmount;
    /**
     * 生产机型：高速纸机，3900，1575
     */
	@TableField("machine_type")
	private String machineType;
    /**
     * 备注
     */
	private String remark;
    /**
     * 状态
     */
	private Integer status;
	@TableField("creator_id")
	private String creatorId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 更新时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getPickupOrderId() {
		return pickupOrderId;
	}

	public void setPickupOrderId(Long pickupOrderId) {
		this.pickupOrderId = pickupOrderId;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getKindNo() {
		return kindNo;
	}

	public void setKindNo(String kindNo) {
		this.kindNo = kindNo;
	}

	public String getRation() {
		return ration;
	}

	public void setRation(String ration) {
		this.ration = ration;
	}

	public String getLayer() {
		return layer;
	}

	public void setLayer(String layer) {
		this.layer = layer;
	}

	public Integer getWidth() {
		return width;
	}

	public void setWidth(Integer width) {
		this.width = width;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getMaterialCode() {
		return materialCode;
	}

	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	public BigDecimal getAvaliableWeight() {
		return avaliableWeight;
	}

	public void setAvaliableWeight(BigDecimal avaliableWeight) {
		this.avaliableWeight = avaliableWeight;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public String getSettlementMethod() {
		return settlementMethod;
	}

	public void setSettlementMethod(String settlementMethod) {
		this.settlementMethod = settlementMethod;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getDscountPrice() {
		return dscountPrice;
	}

	public void setDscountPrice(BigDecimal dscountPrice) {
		this.dscountPrice = dscountPrice;
	}

	public BigDecimal getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(BigDecimal discountAmount) {
		this.discountAmount = discountAmount;
	}

	public BigDecimal getOverWeight() {
		return overWeight;
	}

	public void setOverWeight(BigDecimal overWeight) {
		this.overWeight = overWeight;
	}

	public BigDecimal getOverWeightPrice() {
		return overWeightPrice;
	}

	public void setOverWeightPrice(BigDecimal overWeightPrice) {
		this.overWeightPrice = overWeightPrice;
	}

	public BigDecimal getOverWeightAmount() {
		return overWeightAmount;
	}

	public void setOverWeightAmount(BigDecimal overWeightAmount) {
		this.overWeightAmount = overWeightAmount;
	}

	public BigDecimal getDiscount() {
		return discount;
	}

	public void setDiscount(BigDecimal discount) {
		this.discount = discount;
	}

	public BigDecimal getCarFeePrice() {
		return carFeePrice;
	}

	public void setCarFeePrice(BigDecimal carFeePrice) {
		this.carFeePrice = carFeePrice;
	}

	public BigDecimal getCarFeeAmount() {
		return carFeeAmount;
	}

	public void setCarFeeAmount(BigDecimal carFeeAmount) {
		this.carFeeAmount = carFeeAmount;
	}

	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public String getMachineType() {
		return machineType;
	}

	public void setMachineType(String machineType) {
		this.machineType = machineType;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
