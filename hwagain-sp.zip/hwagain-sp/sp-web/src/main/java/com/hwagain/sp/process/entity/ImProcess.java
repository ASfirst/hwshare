package com.hwagain.sp.process.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
@TableName("im_process")
public class ImProcess implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	@TableId("fd_id")
	private Long fdId;
    /**
     * 处理品批号
     */
	@TableField("batch_no")
	private String batchNo;
    /**
     * 第一录入人
     */
	@TableField("first_man")
	private String firstMan;
    /**
     * 第二录入人
     */
	@TableField("second_man")
	private String secondMan;
    /**
     * 总重
     */
	@TableField("total_weight")
	private BigDecimal totalWeight;
    /**
     * 处理原因说明
     */
	private String reason;
    /**
     * 备注
     */
	private String remark;
	/**
     * 开始销售日期
     */
	@TableField("stard_date")
	private Date stardDate;
    /**
     * 结束销售日期
     */
	@TableField("end_date")
	private Date endDate;
    /**
    /**
     * 状态
     */
	private Integer status;
	/**
     * 创建人
     */
	@TableField("creater_id")
	private String createrId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
    /**
     * 最后修改人
     */
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getFirstMan() {
		return firstMan;
	}

	public void setFirstMan(String firstMan) {
		this.firstMan = firstMan;
	}

	public String getSecondMan() {
		return secondMan;
	}

	public void setSecondMan(String secondMan) {
		this.secondMan = secondMan;
	}

	public BigDecimal getTotalWeight() {
		return totalWeight;
	}

	public void setTotalWeight(BigDecimal totalWeight) {
		this.totalWeight = totalWeight;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getStardDate() {
		return stardDate;
	}

	public void setStardDate(Date stardDate) {
		this.stardDate = stardDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
