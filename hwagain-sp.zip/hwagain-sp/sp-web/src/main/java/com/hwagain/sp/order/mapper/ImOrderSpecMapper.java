package com.hwagain.sp.order.mapper;

import com.hwagain.sp.order.entity.ImOrderSpec;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
public interface ImOrderSpecMapper extends BaseMapper<ImOrderSpec> {

}