package com.hwagain.sp.policy.service;

import com.hwagain.sp.policy.dto.PoPolicyFormatDto;
import com.hwagain.sp.policy.entity.PoPolicyDetails;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
public interface IPoPolicyDetailsService extends IService<PoPolicyDetails> {

	void saveDetails(PoPolicyFormatDto dto);
	
}
