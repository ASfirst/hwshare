package com.hwagain.sp.policy.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author linhl
 * @since 2018-11-02
 */
public interface IPoDiscountApi {
	
}
