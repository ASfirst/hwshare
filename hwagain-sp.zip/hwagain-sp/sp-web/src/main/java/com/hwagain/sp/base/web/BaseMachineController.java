package com.hwagain.sp.base.web;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.base.service.IBaseMachineService;
import com.hwagain.sp.base.dto.BaseMachineDto;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huangdh
 * @since 2019-05-12
 */
@RestController
@RequestMapping(value="/base/baseMachine",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "【进口纸机】生产机械产能维护表", description = "【进口纸机】生产机械产能维护表")
public class BaseMachineController extends BaseController{
	
	@Autowired
	IBaseMachineService baseMachineService;
	
	
	@RequestMapping("/findAll")
	@ApiOperation(value = "查询所有记录", notes = "查询所有记录", httpMethod = "GET")
	public Response findAll() {
		return SuccessResponseData.newInstance(baseMachineService.findAll());
	}
	
	
	@RequestMapping("/save")
	@ApiOperation(value="新增数据",notes="新增数据",httpMethod="POST")
	public Response save(@RequestBody BaseMachineDto dto) {
		return SuccessResponseData.newInstance(baseMachineService.save(dto));
	}
	
	@RequestMapping("/update")
	@ApiOperation(value="修改数据",notes="修改数据",httpMethod="POST")
	public Response update(@RequestBody BaseMachineDto dto) {
		return SuccessResponseData.newInstance(baseMachineService.update(dto));
	}
	
	
	
	
	
	
	
	
}
