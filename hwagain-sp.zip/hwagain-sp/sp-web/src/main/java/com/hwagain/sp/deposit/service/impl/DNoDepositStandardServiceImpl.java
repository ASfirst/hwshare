package com.hwagain.sp.deposit.service.impl;

import com.hwagain.sp.deposit.entity.DNoDepositStandard;
import com.hwagain.sp.deposit.dto.DNoDepositStandardDto;
import com.hwagain.sp.deposit.mapper.DNoDepositStandardMapper;
import com.hwagain.sp.deposit.service.IDNoDepositStandardService;
import com.hwagain.sp.order.entity.ProductSet;
import com.hwagain.sp.order.service.IProductSetService;
import com.hwagain.sp.product.entity.ProductClass;

import com.hwagain.sp.product.service.IProductClassService;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.assertj.core.api.ListAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;


/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-08
 */
@Service("dNoDepositStandardService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DNoDepositStandardServiceImpl extends ServiceImpl<DNoDepositStandardMapper, DNoDepositStandard> implements IDNoDepositStandardService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	
	@Autowired IProductSetService productSetService;
	@Autowired IProductClassService productClassService;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(DNoDepositStandard.class, DNoDepositStandardDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(DNoDepositStandardDto.class, DNoDepositStandard.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	//初始化：获取产品品类以及企业套产品编号
//	@Override
//	public List<DNoDepositStandardDto> inputQueryProd(){
//		Date doDate = new Date();
//		String cUserid = UserUtils.getUserId();
//		//所有品类
//		Wrapper<ProductClass> wrapperClass=new CriterionWrapper<ProductClass>(ProductClass.class);
//		wrapperClass.eq("platform", "Import");
//		List<ProductClass> allClass=productClassService.selectList(wrapperClass);
//		
//		Wrapper<DNoDepositStandard> wrapperA=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
//		List<DNoDepositStandard> listA=super.selectList(wrapperA);
//		if(listA!=null&&listA.size()!=0){
//			for(int i=0;i<listA.size();i++){
//				if(listA.get(i).getEndTime()!=null){
//					SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
//					String end=simpleDateFormat.format(listA.get(i).getEndTime());
//					Date date1=null;
//					try{
//						date1=simpleDateFormat.parse(end);
//					}catch(ParseException e){
//						e.printStackTrace();
//					}
//					
//					Calendar c=Calendar.getInstance();
//					c.setTime(new Date());
//					c.add(Calendar.DAY_OF_MONTH, -1);
//					Date yesterday=c.getTime();
//					if(date1.before(yesterday)){
//						DNoDepositStandard depo=new DNoDepositStandard();
//						depo.setFdId(listA.get(i).getFdId());
//						depo.setIsHistory(1);
//						depo.setLastAlterId(cUserid);
//						depo.setLastAlterTime(doDate);
//						super.updateById(depo);
//					}else{
//						DNoDepositStandard depo=new DNoDepositStandard();
//						depo.setFdId(listA.get(i).getFdId());
//						depo.setIsHistory(0);
//						super.updateById(depo);
//					}
//				}
//			}
//		}
//		Wrapper<ProductSet> wrapperProd=new CriterionWrapper<ProductSet>(ProductSet.class);
//		wrapperProd.eq("kind_no", "b");
//		List<ProductSet> allProd=productSetService.selectList(wrapperProd);
////		System.err.println(allProd.size());
//		if(allProd!=null&&allProd.size()!=0){
//			for(int i=0;i<allProd.size();i++){
//				Wrapper<DNoDepositStandard> wrapper=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
//				wrapper.eq("is_history", 0);
//				wrapper.eq("class_no", allProd.get(i).getClassNo());
//				wrapper.eq("enterprise_set_no", allProd.get(i).getEnterpriseSetNo());
//				DNoDepositStandard list=super.selectFirst(wrapper);
////				System.err.println(list.size());
//				if(list==null){
//					
//					DNoDepositStandard depoStan=new DNoDepositStandard();
//					depoStan.setFdId(Long.valueOf(IdWorker.getId()));
//					depoStan.setClassNo(allProd.get(i).getClassNo());
//					depoStan.setEnterpriseSetNo(allProd.get(i).getEnterpriseSetNo());
//					depoStan.setCreaterId(cUserid);
//					depoStan.setCreateTime(doDate);
//					depoStan.setIsHistory(0);
//					super.insert(depoStan);
//				}
//			}
//		}
//		Wrapper<DNoDepositStandard> wrapper1=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
//		wrapper1.eq("is_history", 0);
//		List<DNoDepositStandard> list1=super.selectList(wrapper1);
//		if(list1!=null&&list1.size()!=0&&allClass!=null&&allClass.size()!=0){
//			
//			for(int i=0;i<list1.size();i++){
//				for(int j=0;j<allClass.size();j++){
//					if(list1.get(i).getClassNo().equals(allClass.get(j).getClassNo())){
//						list1.get(i).setClassNo(allClass.get(j).getName());
//					}
//				}
//			}
//		}
//		return entityToDtoMapper.mapAsList(list1, DNoDepositStandardDto.class);	
//	}
	
	//调整不收定金标准
//	@Override
//	public List<DNoDepositStandardDto> updatDepoStandards(List<DNoDepositStandardDto> dtos){
//		Date doDate = new Date();
//		String cUserid = UserUtils.getUserId();
//		Wrapper<ProductClass> wrapperClass=new CriterionWrapper<ProductClass>(ProductClass.class);
//		wrapperClass.eq("platform", "Import");
//		List<ProductClass> allClass=productClassService.selectList(wrapperClass);
//		
//		Wrapper<DNoDepositStandard> wrapper=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
//		wrapper.eq("is_history", 0);
//		List<DNoDepositStandard> list=super.selectList(wrapper);
//		if(list!=null&&list.size()!=0&&dtos!=null&&dtos.size()!=0){
//			for(int i=0;i<dtos.size();i++){
//				DNoDepositStandardDto dto=dtos.get(i);
//				if(dto!=null&&allClass!=null&&allClass.size()!=0){
//					for(int j=0;j<list.size();j++){
//						if(dto.getClassNo().equals(allClass.get(j).getName())){
//							dto.setClassNo(allClass.get(j).getClassNo());
//						}
//					}	
//				}
//				for(int j=0;j<list.size();j++){
//					if(dto.getClassNo().equals(list.get(j).getClassNo())&&
//							dto.getEnterpriseSetNo().equals(list.get(j).getEnterpriseSetNo())){
//						if(list.get(j).getStartTime()==null){
//							DNoDepositStandard depo=new DNoDepositStandard();
//							depo.setFdId(list.get(j).getFdId());
//							depo.setMonthDeliveryWeight(dto.getMonthDeliveryWeight());
//							depo.setMonthOrderWeight(dto.getMonthOrderWeight());
//							depo.setContinuousMonth(dto.getContinuousMonth());
//							depo.setStartTime(dto.getStartTime());
//							depo.setEndTime(dto.getEndTime());
//							depo.setLastAlterId(cUserid);
//							depo.setLastAlterTime(doDate);
//							super.updateById(depo);
//						}else{
//							DNoDepositStandard depo=new DNoDepositStandard();
//							depo.setFdId(Long.valueOf(IdWorker.getId()));
//							depo.setClassNo(list.get(j).getClassNo());
//							depo.setEnterpriseSetNo(list.get(j).getEnterpriseSetNo());
//							depo.setMonthDeliveryWeight(dto.getMonthDeliveryWeight());
//							depo.setMonthOrderWeight(dto.getMonthOrderWeight());
//							depo.setContinuousMonth(dto.getContinuousMonth());
//							depo.setStartTime(dto.getStartTime());
//							depo.setEndTime(dto.getEndTime());
//							depo.setIsHistory(0);
//							depo.setCreaterId(cUserid);
//							depo.setCreateTime(doDate);
//							super.insert(depo);
//							
//							DNoDepositStandard depo1=new DNoDepositStandard();
//							depo1.setFdId(list.get(j).getFdId());
//							depo1.setEndTime(dto.getStartTime());
//							depo1.setIsHistory(0);
//							depo1.setLastAlterId(cUserid);
//							depo1.setLastAlterTime(doDate);
//							super.updateById(depo1);
//						}
//					}
//				}
//			}
//		}
//		Wrapper<DNoDepositStandard> wrapper1=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
//		wrapper1.eq("is_history", 0);
//		List<DNoDepositStandard> list1=super.selectList(wrapper1);
//		return entityToDtoMapper.mapAsList(list1, DNoDepositStandardDto.class);	
//	}
//	
//	@Override
//	public List<DNoDepositStandardDto> updatDepoStandard(DNoDepositStandardDto dto){
//		Date doDate = new Date();
//		String cUserid = UserUtils.getUserId();
//		Wrapper<ProductClass> wrapperClass=new CriterionWrapper<ProductClass>(ProductClass.class);
//		wrapperClass.eq("platform", "Import");
//		List<ProductClass> allClass=productClassService.selectList(wrapperClass);
//		
//		Wrapper<DNoDepositStandard> wrapper=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
//		wrapper.eq("is_history", 0);
//		List<DNoDepositStandard> list=super.selectList(wrapper);
//		if(list!=null&&list.size()!=0&&dto!=null){
//			if(dto!=null&&allClass!=null&&allClass.size()!=0){
//				for(int j=0;j<allClass.size();j++){
//					if(dto.getClassNo().equals(allClass.get(j).getName())){
//						dto.setClassNo(allClass.get(j).getClassNo());
//					}
//				}	
//			}
//			for(int j=0;j<list.size();j++){
//				if(dto.getClassNo().equals(list.get(j).getClassNo())&&
//						dto.getEnterpriseSetNo().equals(list.get(j).getEnterpriseSetNo())){
//					if(list.get(j).getStartTime()==null){
//						DNoDepositStandard depo=new DNoDepositStandard();
//						depo.setFdId(list.get(j).getFdId());
//						depo.setMonthDeliveryWeight(dto.getMonthDeliveryWeight());
//						depo.setMonthOrderWeight(dto.getMonthOrderWeight());
//						depo.setContinuousMonth(dto.getContinuousMonth());
//						depo.setStartTime(dto.getStartTime());
//						depo.setEndTime(dto.getEndTime());
//						depo.setLastAlterId(cUserid);
//						depo.setLastAlterTime(doDate);
//						super.updateById(depo);
//					}else{
//						DNoDepositStandard depo=new DNoDepositStandard();
//						depo.setFdId(Long.valueOf(IdWorker.getId()));
//						depo.setClassNo(list.get(j).getClassNo());
//						depo.setEnterpriseSetNo(list.get(j).getEnterpriseSetNo());
//						depo.setMonthDeliveryWeight(dto.getMonthDeliveryWeight());
//						depo.setMonthOrderWeight(dto.getMonthOrderWeight());
//						depo.setContinuousMonth(dto.getContinuousMonth());
//						depo.setStartTime(dto.getStartTime());
//						depo.setEndTime(dto.getEndTime());
//						depo.setIsHistory(0);
//						depo.setCreaterId(cUserid);
//						depo.setCreateTime(doDate);
//						super.insert(depo);
//						
//						DNoDepositStandard depo1=new DNoDepositStandard();
//						depo1.setFdId(list.get(j).getFdId());
//						depo1.setEndTime(dto.getStartTime());
//						depo1.setIsHistory(0);
//						depo1.setLastAlterId(cUserid);
//						depo1.setLastAlterTime(doDate);
//						super.updateById(depo1);
//					}
//				}
//			}
//			
//		}
//		Wrapper<DNoDepositStandard> wrapper1=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
//		wrapper1.eq("is_history", 0);
//		List<DNoDepositStandard> list1=super.selectList(wrapper1);
//		return entityToDtoMapper.mapAsList(list1, DNoDepositStandardDto.class);	
//	}
//	
	@Override
	public List<DNoDepositStandardDto> findAllHistory(){

		Wrapper<DNoDepositStandard> wrapper=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
		wrapper.eq("is_history", 1);
		List<DNoDepositStandard> list=super.selectList(wrapper);
//		Wrapper<ProductClass> wrapperClass=new CriterionWrapper<ProductClass>(ProductClass.class);
//		wrapperClass.eq("platform", "Import");
//		List<ProductClass> allClass=productClassService.selectList(wrapperClass);
//		if(list!=null&&list.size()!=0&&allClass!=null&&allClass.size()!=0){
//			for(int i=0;i<list.size();i++){
//				for(int j=0;j<allClass.size();j++){
//					if(list.get(i).getClassNo().equals(allClass.get(j).getClassNo())){
//						list.get(i).setClassNo(allClass.get(j).getName());
//					}
//				}
//			}
//		}
		return entityToDtoMapper.mapAsList(list, DNoDepositStandardDto.class);
		
	}
	@Override
	public List<DNoDepositStandardDto> findEffectList(){
		Wrapper<DNoDepositStandard> wrapper=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
		wrapper.eq("is_history", 0);
		List<DNoDepositStandard> list=super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, DNoDepositStandardDto.class);
		
	}	
	@Override
	public List<DNoDepositStandardDto> findAllList(){
		Wrapper<DNoDepositStandard> wrapper=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
		wrapper.orderBy("create_time");
		List<DNoDepositStandard> list=super.selectList(wrapper);
		List<DNoDepositStandard> listA=new ArrayList();
		if(list.size()>0){
			for(int i=list.size()-1;i>=0;i--){
				listA.add(list.get(i));
			}
		}
		return entityToDtoMapper.mapAsList(listA, DNoDepositStandardDto.class);
		
	}
}
