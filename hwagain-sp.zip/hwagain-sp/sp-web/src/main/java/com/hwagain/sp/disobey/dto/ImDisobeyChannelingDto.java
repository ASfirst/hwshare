package com.hwagain.sp.disobey.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;


/**
 * <p>
 * 
 * </p>
 *
 * @author huanglf
 * @since 2018-11-29
 */
public class ImDisobeyChannelingDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 单据ID
     */
	private Long fdId;
    /**
     * 提货单号
     */
	private String pickupOrderId;
    /**
     * 客户ID
     */
	private Integer customerId;
    /**
     * 客户名称
     */
	private String customerName;
    /**
     * 发货日期
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date shipmentDate;
    /**
     * 承运物流公司
     */
	private String logisCompany;
    /**
     * 车牌号
     */
	private String carNo;
    /**
     * 客户经销区域
     */
	private String customerArea;
    /**
     * 窜货区域
     */
	private String channelingArea;
    /**
     * 翼讯定位情况
     */
	private String placePoint;
    /**
     * 窜货确认时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date channelingDate;
    /**
     * 窜货数量
     */
	private BigDecimal weight;
    /**
     * 规定扣款金额
     */
	private BigDecimal amount;
    /**
     * 申请扣款金额
     */
	private BigDecimal applyAmount;
    /**
     * 实际扣款金额
     */
	private BigDecimal deductAmount;
    /**
     * 扣款时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date deductDate;
    /**
     * 备注
     */
	private String remarks;
    /**
     * 状态
     */
	private Integer status;
    /**
     * OA流程状态
     */
	private Integer oaStatus;
    /**
     * OA单据编号
     */
	private String oaCode;
    /**
     * 创建人
     */
	private String createrId;
    /**
     * 创建时间
     */
	private Date createTime;
    /**
     * 最后修改人
     */
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getPickupOrderId() {
		return pickupOrderId;
	}

	public void setPickupOrderId(String pickupOrderId) {
		this.pickupOrderId = pickupOrderId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getShipmentDate() {
		return shipmentDate;
	}

	public void setShipmentDate(Date shipmentDate) {
		this.shipmentDate = shipmentDate;
	}

	public String getLogisCompany() {
		return logisCompany;
	}

	public void setLogisCompany(String logisCompany) {
		this.logisCompany = logisCompany;
	}

	public String getCarNo() {
		return carNo;
	}

	public void setCarNo(String carNo) {
		this.carNo = carNo;
	}

	public String getCustomerArea() {
		return customerArea;
	}

	public void setCustomerArea(String customerArea) {
		this.customerArea = customerArea;
	}

	public String getChannelingArea() {
		return channelingArea;
	}

	public void setChannelingArea(String channelingArea) {
		this.channelingArea = channelingArea;
	}

	public String getPlacePoint() {
		return placePoint;
	}

	public void setPlacePoint(String placePoint) {
		this.placePoint = placePoint;
	}

	public Date getChannelingDate() {
		return channelingDate;
	}

	public void setChannelingDate(Date channelingDate) {
		this.channelingDate = channelingDate;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getApplyAmount() {
		return applyAmount;
	}

	public void setApplyAmount(BigDecimal applyAmount) {
		this.applyAmount = applyAmount;
	}

	public BigDecimal getDeductAmount() {
		return deductAmount;
	}

	public void setDeductAmount(BigDecimal deductAmount) {
		this.deductAmount = deductAmount;
	}

	public Date getDeductDate() {
		return deductDate;
	}

	public void setDeductDate(Date deductDate) {
		this.deductDate = deductDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getOaStatus() {
		return oaStatus;
	}

	public void setOaStatus(Integer oaStatus) {
		this.oaStatus = oaStatus;
	}

	public String getOaCode() {
		return oaCode;
	}

	public void setOaCode(String oaCode) {
		this.oaCode = oaCode;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
