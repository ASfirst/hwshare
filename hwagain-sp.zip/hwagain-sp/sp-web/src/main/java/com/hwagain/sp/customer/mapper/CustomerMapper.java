package com.hwagain.sp.customer.mapper;

import com.hwagain.sp.customer.entity.Customer;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author linhl
 * @since 2018-10-30
 */
public interface CustomerMapper extends BaseMapper<Customer> {

}