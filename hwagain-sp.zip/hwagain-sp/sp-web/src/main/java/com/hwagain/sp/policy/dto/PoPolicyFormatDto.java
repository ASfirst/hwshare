package com.hwagain.sp.policy.dto;

import java.util.Date;

import java.io.Serializable;
import java.math.BigDecimal;


/**
 * <p>
 * 
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
public class PoPolicyFormatDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
	private Integer fdYear;
	private Integer fdMonth;
	private Date startDate;
	private Date endDate;
	private Boolean isImportWhite;
	private Boolean isImportColor;
	private Boolean is3900White;
	private Boolean is3900Color;
	private Boolean is1575White;
	private Boolean isAll;
	//上一期
	private Long detailId;
	private Integer lastBaseAmount;
	private Integer lastBaseAvgAmount;
	private Integer lastPromiseAmount;
	private Integer lastFbaseAmount;
	private Integer lastFbaseAvgAmount;
	private Integer lastFpromiseAmount;
	
	private Integer baseAmount;
	private Integer baseAvgAmount;
	private Integer promiseAmount;
	private Integer fbaseAmount;
	private Integer fbaseAvgAmount;
	private Integer fpromiseAmount;
	private String remark;
	private Integer status;
	private String createrId;
	private Date createTime;
	private String lastAlterId;
	private Date lastAlterTime;
	private String oaCode;
	
	private Integer level;
	//上一期
	private BigDecimal lastMinWeight;
	private BigDecimal lastMaxWeight;
	private BigDecimal lastAmount;
	private BigDecimal lastFminWeight;
	private BigDecimal lastFmaxWeight;
	private BigDecimal lastFamount;

	private BigDecimal minWeight;
	private BigDecimal maxWeight;
	private BigDecimal amount;
	private BigDecimal fminWeight;
	private BigDecimal fmaxWeight;
	private BigDecimal famount;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Integer getFdYear() {
		return fdYear;
	}

	public void setFdYear(Integer fdYear) {
		this.fdYear = fdYear;
	}

	public Integer getFdMonth() {
		return fdMonth;
	}

	public void setFdMonth(Integer fdMonth) {
		this.fdMonth = fdMonth;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Boolean isIsImportWhite() {
		return isImportWhite;
	}

	public void setIsImportWhite(Boolean isImportWhite) {
		this.isImportWhite = isImportWhite;
	}

	public Boolean isIsImportColor() {
		return isImportColor;
	}

	public void setIsImportColor(Boolean isImportColor) {
		this.isImportColor = isImportColor;
	}

	public Boolean isIs3900White() {
		return is3900White;
	}

	public void setIs3900White(Boolean is3900White) {
		this.is3900White = is3900White;
	}

	public Boolean isIs3900Color() {
		return is3900Color;
	}

	public void setIs3900Color(Boolean is3900Color) {
		this.is3900Color = is3900Color;
	}

	public Boolean isIs1575White() {
		return is1575White;
	}

	public void setIs1575White(Boolean is1575White) {
		this.is1575White = is1575White;
	}

	public Boolean isIsAll() {
		return isAll;
	}

	public void setIsAll(Boolean isAll) {
		this.isAll = isAll;
	}

	public Integer getBaseAmount() {
		return baseAmount;
	}

	public void setBaseAmount(Integer baseAmount) {
		this.baseAmount = baseAmount;
	}

	public Integer getBaseAvgAmount() {
		return baseAvgAmount;
	}

	public void setBaseAvgAmount(Integer baseAvgAmount) {
		this.baseAvgAmount = baseAvgAmount;
	}

	public Integer getPromiseAmount() {
		return promiseAmount;
	}

	public void setPromiseAmount(Integer promiseAmount) {
		this.promiseAmount = promiseAmount;
	}

	public Integer getFbaseAmount() {
		return fbaseAmount;
	}

	public void setFbaseAmount(Integer fbaseAmount) {
		this.fbaseAmount = fbaseAmount;
	}

	public Integer getFbaseAvgAmount() {
		return fbaseAvgAmount;
	}

	public void setFbaseAvgAmount(Integer fbaseAvgAmount) {
		this.fbaseAvgAmount = fbaseAvgAmount;
	}

	public Integer getFpromiseAmount() {
		return fpromiseAmount;
	}

	public void setFpromiseAmount(Integer fpromiseAmount) {
		this.fpromiseAmount = fpromiseAmount;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

	public String getOaCode() {
		return oaCode;
	}

	public void setOaCode(String oaCode) {
		this.oaCode = oaCode;
	}

	public Integer getLastBaseAmount() {
		return lastBaseAmount;
	}

	public void setLastBaseAmount(Integer lastBaseAmount) {
		this.lastBaseAmount = lastBaseAmount;
	}

	public Integer getLastBaseAvgAmount() {
		return lastBaseAvgAmount;
	}

	public void setLastBaseAvgAmount(Integer lastBaseAvgAmount) {
		this.lastBaseAvgAmount = lastBaseAvgAmount;
	}

	public Integer getLastPromiseAmount() {
		return lastPromiseAmount;
	}

	public void setLastPromiseAmount(Integer lastPromiseAmount) {
		this.lastPromiseAmount = lastPromiseAmount;
	}

	public Integer getLastFbaseAmount() {
		return lastFbaseAmount;
	}

	public void setLastFbaseAmount(Integer lastFbaseAmount) {
		this.lastFbaseAmount = lastFbaseAmount;
	}

	public Integer getLastFbaseAvgAmount() {
		return lastFbaseAvgAmount;
	}

	public void setLastFbaseAvgAmount(Integer lastFbaseAvgAmount) {
		this.lastFbaseAvgAmount = lastFbaseAvgAmount;
	}

	public Integer getLastFpromiseAmount() {
		return lastFpromiseAmount;
	}

	public void setLastFpromiseAmount(Integer lastFpromiseAmount) {
		this.lastFpromiseAmount = lastFpromiseAmount;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public BigDecimal getLastMinWeight() {
		return lastMinWeight;
	}

	public void setLastMinWeight(BigDecimal lastMinWeight) {
		this.lastMinWeight = lastMinWeight;
	}

	public BigDecimal getLastMaxWeight() {
		return lastMaxWeight;
	}

	public void setLastMaxWeight(BigDecimal lastMaxWeight) {
		this.lastMaxWeight = lastMaxWeight;
	}

	public BigDecimal getLastAmount() {
		return lastAmount;
	}

	public void setLastAmount(BigDecimal lastAmount) {
		this.lastAmount = lastAmount;
	}

	public BigDecimal getLastFminWeight() {
		return lastFminWeight;
	}

	public void setLastFminWeight(BigDecimal lastFminWeight) {
		this.lastFminWeight = lastFminWeight;
	}

	public BigDecimal getLastFmaxWeight() {
		return lastFmaxWeight;
	}

	public void setLastFmaxWeight(BigDecimal lastFmaxWeight) {
		this.lastFmaxWeight = lastFmaxWeight;
	}

	public BigDecimal getLastFamount() {
		return lastFamount;
	}

	public void setLastFamount(BigDecimal lastFamount) {
		this.lastFamount = lastFamount;
	}

	public BigDecimal getMinWeight() {
		return minWeight;
	}

	public void setMinWeight(BigDecimal minWeight) {
		this.minWeight = minWeight;
	}

	public BigDecimal getMaxWeight() {
		return maxWeight;
	}

	public void setMaxWeight(BigDecimal maxWeight) {
		this.maxWeight = maxWeight;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getFminWeight() {
		return fminWeight;
	}

	public void setFminWeight(BigDecimal fminWeight) {
		this.fminWeight = fminWeight;
	}

	public BigDecimal getFmaxWeight() {
		return fmaxWeight;
	}

	public void setFmaxWeight(BigDecimal fmaxWeight) {
		this.fmaxWeight = fmaxWeight;
	}

	public BigDecimal getFamount() {
		return famount;
	}

	public void setFamount(BigDecimal famount) {
		this.famount = famount;
	}

	public Long getDetailId() {
		return detailId;
	}

	public void setDetailId(Long detailId) {
		this.detailId = detailId;
	}
}
