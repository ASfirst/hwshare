package com.hwagain.sp.policy.web;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.policy.dto.PoDiscountDetailDto;
import com.hwagain.sp.policy.service.IPoDiscountDetailService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author linhl
 * @since 2018-11-02
 */
@RestController
@RequestMapping(value="/policy/poDiscountDetail",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "折扣计算单", description = "折扣计算单")
public class PoDiscountDetailController extends BaseController{
	
	@Autowired
	IPoDiscountDetailService poDiscountDetailService;
	
	@RequestMapping(value = "/save", method = { RequestMethod.POST })
	@ApiOperation(value = "新增记录", notes = "新增记录 ", httpMethod = "POST")
	public Response save(@RequestBody PoDiscountDetailDto dto) {
		return SuccessResponseData.newInstance(poDiscountDetailService.save(dto));
	}
	
	
	@RequestMapping(value = "/deleteByIds", method = { RequestMethod.POST })
	@ApiOperation(value = "删除记录（ID）", notes = "按ID删除多条记录（多条记录使用“,”分隔）", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "ids", value = "删除记录id,格式：1,2,3,4....", paramType = "query", required = true, dataType = "String") })
	public Response inputDeleteOne(String ids) {
		return SuccessResponseData.newInstance(poDiscountDetailService.deleteByIds(ids));
	}
	
	@RequestMapping(value = "/deleteByOrderNo", method = { RequestMethod.POST })
	@ApiOperation(value = "删除记录（订单号）", notes = "按订单号删除记录", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "orderNo", value = "删除记录订单号", paramType = "query", required = true, dataType = "String") })
	public Response DeleteByOrderNo(String orderNo) {
		return SuccessResponseData.newInstance(poDiscountDetailService.deleteByOrderNo(orderNo));
	}
	
	@RequestMapping("/findoneByfdId")
	@ApiOperation(value="查询单条",notes="按fdId查询单条记录",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="fdid",value="fdid",paramType="query",required=true,dataType="long")
	})
	public Response findOne(Long fdid){
		return SuccessResponseData.newInstance(poDiscountDetailService.findoneByfdid(fdid));
	}
	
	@RequestMapping("/findAll")
	@ApiOperation(value="查询全部",notes="录入订单号按订单号查询数据，如不录入条件，则查询全部",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="orderNo",value="订单号",paramType="query",required=false,dataType="String")
	})
	public Response findAll(String orderNo){
		return SuccessResponseData.newInstance(poDiscountDetailService.findAll(orderNo));
	}
}
