package com.hwagain.sp.price.service;

import com.hwagain.sp.price.dto.ImPriceAdjustDto;
import com.hwagain.sp.price.dto.ImPriceAdjustRptDto;
import com.hwagain.sp.price.dto.ImPriceRptDto;
import com.hwagain.sp.price.entity.ImPriceAdjust;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
public interface IImPriceAdjustService extends IService<ImPriceAdjust> {

	public List<ImPriceAdjustRptDto> adjustQueryList();

	public ImPriceAdjustDto adjustUpdateOne(String fdid, BigDecimal addPrice, Date startDate, String remark);
	
	public List<ImPriceAdjustDto> adjustUpdateSome(List<ImPriceAdjustDto> list);

	public List<ImPriceAdjustRptDto> adjustSentToOa();

	public List<ImPriceAdjustRptDto> adjustQueryByOaCode(String oaCode);

	public List<ImPriceAdjust> adjustOaAduitFlow(String oACode, Integer status, String nodeName, String empName,
			String empNo, String flowDjbh, String flowDjlsh);

	//============================================================================
	public ImPriceAdjustDto addOneEdit(ImPriceAdjustDto dto) throws CustomException;

//	public List<ImPriceDto> findNewHistory()throws CustomException;

	public List<ImPriceAdjustDto> matching(List<ImPriceAdjustDto> dtos)throws CustomException;

	public List<ImPriceAdjustRptDto> findNewHistory()throws CustomException;
}
