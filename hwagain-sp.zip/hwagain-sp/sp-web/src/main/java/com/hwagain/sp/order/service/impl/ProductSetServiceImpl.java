package com.hwagain.sp.order.service.impl;

import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;
import com.hwagain.sp.order.entity.ProductSet;
import com.hwagain.sp.order.dto.ProductSetDto;
import com.hwagain.sp.order.mapper.ProductSetMapper;
import com.hwagain.sp.order.service.IProductSetService;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

import java.util.Date;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@Service("productSetService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ProductSetServiceImpl extends ServiceImpl<ProductSetMapper, ProductSet> implements IProductSetService {
	
	// entity转dto
	public static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ProductSet.class, ProductSetDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ProductSetDto.class, ProductSet.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}


	@Override
	public ProductSetDto addOne(ProductSetDto dto) {
		Assert.notBlank(dto.getClassNo(), "品类编号不能为空");
		Assert.notBlank(dto.getKindNo(), "产品类别编号不能为空");
		Assert.notBlank(dto.getCutSpec(), "分切规格不能为空");
		Assert.notNull(dto.getTotalWidth(), "总幅宽不能为空");
		Wrapper<ProductSet> wrapper=new CriterionWrapper<>(ProductSet.class);
		wrapper.eq("class_no", dto.getClassNo());
		wrapper.eq("kind_no", dto.getKindNo());
		wrapper.eq("cut_spec", dto.getCutSpec());
		wrapper.eq("total_width", dto.getTotalWidth());
		ProductSet productSet=super.selectFirst(wrapper);
		if(productSet != null){
			Assert.throwException("[" + dto.getEnterpriseSetNo() + "]已存在该记录");
		}

		ProductSet newproductSet = dtoToEntityMapper.map(dto, ProductSet.class);
		newproductSet.setFdId(IdWorker.getId());
		newproductSet.setCreaterId(UserUtils.getUserCode());
		newproductSet.setCreateTime(new Date());
		super.insert(newproductSet);
		return entityToDtoMapper.map(super.selectById(newproductSet.getFdId()), ProductSetDto.class);

	}
}
