package com.hwagain.sp.deposit.api.impl;

import com.hwagain.sp.deposit.api.IDDepositStandardEditApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-06
 */
@Service("dDepositStandardEditApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DDepositStandardEditApiImpl implements IDDepositStandardEditApi {
	
}
