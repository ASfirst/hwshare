package com.hwagain.sp.process.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ImProductListDto {
	/**
     * 纸卷编号
     */
	private String paperNo;
	/**
     * 品类名称
     */
	private String className;
    /**
     * 品类
     */
	private String classNo;
    /**
     * 定量
     */
	private BigDecimal ration;
    /**
     * 起趋率
     */
	private BigDecimal wrinkleRate;
    /**
     * 层数
     */
	private Integer layer;
    /**
     * 单幅幅宽
     */
	private Integer width;
    /**
     * 直径
     */
	private Integer diameter;
    /**
     * 产品等级
     */
	private String grade;
    /**
     * 降级原因
     */
	private String reason;
    /**
     * 重量
     */
	private BigDecimal weight;
    /**
     * 生产日期
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date productDate;
	public String getPaperNo() {
		return paperNo;
	}
	public void setPaperNo(String paperNo) {
		this.paperNo = paperNo;
	}
	
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getClassNo() {
		return classNo;
	}
	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}
	public BigDecimal getRation() {
		return ration;
	}
	public void setRation(BigDecimal ration) {
		this.ration = ration;
	}
	public BigDecimal getWrinkleRate() {
		return wrinkleRate;
	}
	public void setWrinkleRate(BigDecimal wrinkleRate) {
		this.wrinkleRate = wrinkleRate;
	}
	public Integer getLayer() {
		return layer;
	}
	public void setLayer(Integer layer) {
		this.layer = layer;
	}
	
	public Integer getWidth() {
		return width;
	}
	public void setWidth(Integer width) {
		this.width = width;
	}
	
	public Integer getDiameter() {
		return diameter;
	}
	public void setDiameter(Integer diameter) {
		this.diameter = diameter;
	}
	public String getGrade() {
		return grade;
	}
	public void setGrade(String grade) {
		this.grade = grade;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public BigDecimal getWeight() {
		return weight;
	}
	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}
	public Date getProductDate() {
		return productDate;
	}
	public void setProductDate(Date productDate) {
		this.productDate = productDate;
	}
	
}
