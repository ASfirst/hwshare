package com.hwagain.sp.disobey.web;

import java.util.List;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.disobey.dto.ImDisobeyOverPeriodDto;
import com.hwagain.sp.disobey.service.IImDisobeyOverPeriodService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
@RestController
@RequestMapping(value="/disobey/imDisobeyOverPeriod",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "违约扣款-定制品超期未提货扣款", description = "违约扣款-定制品超期未提货扣款")
public class ImDisobeyOverPeriodController extends BaseController{
	
	@Autowired
	IImDisobeyOverPeriodService imDisobeyOverPeriodService;
	
	/**
	 * 定制品超期未提货扣款客户
	 * 
	 */
	
	@RequestMapping("/findOverPeriodCustList")
	@ApiOperation(value="定制品超期未提货客户",notes="定制品超期未提货客户",httpMethod="GET")
	public Response findOverPeriodCustList(){
		return SuccessResponseData.newInstance(imDisobeyOverPeriodService.queryOverPeriodCustomer());
	}
	
	/**
	 * 定制品超期未提货扣款客户
	 * 
	 */
	
	@RequestMapping("/findOverPeriodOrderByCustomerId")
	@ApiOperation(value="根据客户ID查找超期未提货订单信息",notes="根据客户ID查找超期未提货订单信息",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "customerId", value = "客户ID", paramType = "query", required = true, dataType = "String") })
	public Response findOverPeriodOrderByCustomerId(String customerId){
		return SuccessResponseData.newInstance(imDisobeyOverPeriodService.queryOverPeriodFromOrder(customerId));
	}
	
	/**
	 * 新增数据
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/save",method={RequestMethod.POST})
	@ApiOperation(value = "新增数据", notes = "新增数据",httpMethod="POST")
	public Response save(@RequestBody List<ImDisobeyOverPeriodDto> list){
		return SuccessResponseData.newInstance(imDisobeyOverPeriodService.saveMoreOverPeriod(list));
	}
	
	
	/**
	 * 提交OA
	 * 
	 */
	
	@RequestMapping(value = "/overPeriodSentToOa", method = { RequestMethod.POST })
	@ApiOperation(value = "提交OA【定制品超期未提货扣款】", notes = "提交OA【定制品超期未提货扣款】", httpMethod = "POST")
	public Response overPeriodSentToOa() {
		return SuccessResponseData.newInstance(imDisobeyOverPeriodService.overPeriodSentToOa());
	}
	
	/**
	 * 定制品超期未提货扣款申请
	 * 
	 */
	
	@RequestMapping("/findOverPeriodApplyList")
	@ApiOperation(value="定制品超期未提货扣款申请",notes="定制品超期未提货扣款申请",httpMethod="GET")
	public Response findOverPeriodApplyList(){
		return SuccessResponseData.newInstance(imDisobeyOverPeriodService.findOverPeriodApplyList());
	}
	
	/**
	 * 客户生活原纸定制品超期未提货扣款明细表
	 * 
	 */
	
	@RequestMapping("/findOverPeriodDetailList")
	@ApiOperation(value="客户生活原纸定制品超期未提货扣款明细表",notes="客户生活原纸定制品超期未提货扣款明细表",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "customerId", value = "客户ID", paramType = "query", required = true, dataType = "String") })
	public Response findOverPeriodDetailList(String customerId){
		return SuccessResponseData.newInstance(imDisobeyOverPeriodService.findOverPeriodDetailList(customerId));
	}
	
	/**
	 * 定制品超期未提货扣款明细查询
	 * 
	 */
	
	@RequestMapping("/findOverPeriodDeductList")
	@ApiOperation(value="定制品超期未提货扣款明细查询",notes="定制品超期未提货扣款明细查询",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "strDate", value = "查询月份(2018年12月),传入参数格式：2018-12-01", paramType = "query", required = false, dataType = "String") })
	public Response findOverPeriodDeductList(String strDate){
		return SuccessResponseData.newInstance(imDisobeyOverPeriodService.findOverPeriodDeductList(strDate));
	}
	
	/**
	 * 定制品超期未提货扣款明细查询
	 * 
	 */
	
	@RequestMapping("/findOverPeriodDeductDetailList")
	@ApiOperation(value="客户生活原纸定制品超期未提货扣款明细查询表",notes="客户生活原纸定制品超期未提货扣款明细查询表",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "customerId", value = "客户ID", paramType = "query", required = true, dataType = "String"),
		@ApiImplicitParam(name = "strDate", value = "查询月份(2018年12月),传入参数格式：2018-12-01", paramType = "query", required = false, dataType = "String")}
	)
	public Response findOverPeriodDeductDetailList(String customerId,String strDate){
		return SuccessResponseData.newInstance(imDisobeyOverPeriodService.findOverPeriodDeductDetailList(customerId,strDate));
	}
	
}
