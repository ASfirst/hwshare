package com.hwagain.sp.policy.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
@TableName("po_over")
public class PoOver implements Serializable {

    private static final long serialVersionUID = 1L;

	@TableId("fd_id")
	private Long fdId;
	@TableField("fd_year")
	private Integer fdYear;
	@TableField("fd_month")
	private Integer fdMonth;
	@TableField("start_date")
	private Date startDate;
	@TableField("end_date")
	private Date endDate;
	private String platform;
	@TableField("paper_type")
	private String paperType;
	@TableField("class_name")
	private String className;
	@TableField("is_promise")
	private Boolean isPromise;
	@TableField("base_condition")
	private String baseCondition;
	@TableField("base_amount")
	private BigDecimal baseAmount;
	@TableField("over_condition")
	private String overCondition;
	@TableField("over_amount")
	private BigDecimal overAmount;
	@TableField("other_condition")
	private String otherCondition;
	@TableField("other_amount")
	private BigDecimal otherAmount;
	private String remark;
	private Integer status;
	@TableField("creater_id")
	private String createrId;
	@TableField("create_time")
	private Date createTime;
	@TableField("last_alter_id")
	private String lastAlterId;
	@TableField("last_alter_time")
	private Date lastAlterTime;
	@TableField("oa_code")
	private String oaCode;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Integer getFdYear() {
		return fdYear;
	}

	public void setFdYear(Integer fdYear) {
		this.fdYear = fdYear;
	}

	public Integer getFdMonth() {
		return fdMonth;
	}

	public void setFdMonth(Integer fdMonth) {
		this.fdMonth = fdMonth;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getPlatform() {
		return platform;
	}

	public void setPlatform(String platform) {
		this.platform = platform;
	}

	public String getPaperType() {
		return paperType;
	}

	public void setPaperType(String paperType) {
		this.paperType = paperType;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Boolean isIsPromise() {
		return isPromise;
	}

	public void setIsPromise(Boolean isPromise) {
		this.isPromise = isPromise;
	}

	public String getBaseCondition() {
		return baseCondition;
	}

	public void setBaseCondition(String baseCondition) {
		this.baseCondition = baseCondition;
	}

	public BigDecimal getBaseAmount() {
		return baseAmount;
	}

	public void setBaseAmount(BigDecimal baseAmount) {
		this.baseAmount = baseAmount;
	}

	public String getOverCondition() {
		return overCondition;
	}

	public void setOverCondition(String overCondition) {
		this.overCondition = overCondition;
	}

	public BigDecimal getOverAmount() {
		return overAmount;
	}

	public void setOverAmount(BigDecimal overAmount) {
		this.overAmount = overAmount;
	}

	public String getOtherCondition() {
		return otherCondition;
	}

	public void setOtherCondition(String otherCondition) {
		this.otherCondition = otherCondition;
	}

	public BigDecimal getOtherAmount() {
		return otherAmount;
	}

	public void setOtherAmount(BigDecimal otherAmount) {
		this.otherAmount = otherAmount;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

	public String getOaCode() {
		return oaCode;
	}

	public void setOaCode(String oaCode) {
		this.oaCode = oaCode;
	}

}
