package com.hwagain.sp.price.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;
import com.hwagain.sp.price.dto.ImSpecialPriceAdjustExtDto;
import com.hwagain.sp.price.dto.ImSpecialPriceExtDto;
import com.hwagain.sp.price.entity.ImSpecialPrice;

public interface ImSpecialPriceExtMapper extends BaseMapper<ImSpecialPrice> {

	public List<ImSpecialPriceExtDto> queryImSpecialPriceList();
	
	public List<ImSpecialPriceAdjustExtDto> queryImSpecialAdjustList(@Param("curUserId") String curUserId);
	
	public List<ImSpecialPriceExtDto> queryImSpecialHistory1(@Param("batchId") String batchId);
}
