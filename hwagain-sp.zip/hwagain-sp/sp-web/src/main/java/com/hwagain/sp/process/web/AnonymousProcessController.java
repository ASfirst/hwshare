package com.hwagain.sp.process.web;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.sp.process.service.IImProcessService;

/**
 * <p>
 * 匿名访问-处理品销售
 * </p>
 *
 * @author huanglf
 * @since 2018-11-08
 */
@RestController
@RequestMapping(value = "/anonymous/process", method = { RequestMethod.GET, RequestMethod.POST })
@Api(value = "匿名接口-处理品销售", description = "匿名接口-处理品销售")
public class AnonymousProcessController {
	@Autowired
	IImProcessService imProcessService;
	
	
	@RequestMapping(value = "/queryProcessSaleList", method = { RequestMethod.GET })
	@ApiOperation(value = "处理品销售发布", notes = "处理品销售发布", httpMethod = "GET")
	public Response queryProcessSaleList() {
		return SuccessResponseData.newInstance(imProcessService.queryProcessSaleList());
	}
}
