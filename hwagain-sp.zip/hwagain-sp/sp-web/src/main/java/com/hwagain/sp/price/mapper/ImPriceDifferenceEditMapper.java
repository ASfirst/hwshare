package com.hwagain.sp.price.mapper;

import com.hwagain.sp.price.entity.ImPriceDifferenceEdit;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  * 副品及承兑汇票结算差价表 Mapper 接口
 * </p>
 *
 * @author xionglz
 * @since 2018-11-22
 */
public interface ImPriceDifferenceEditMapper extends BaseMapper<ImPriceDifferenceEdit> {

}