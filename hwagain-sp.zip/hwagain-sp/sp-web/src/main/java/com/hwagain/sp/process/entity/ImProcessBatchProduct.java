package com.hwagain.sp.process.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
@TableName("im_process_batch_product")
public class ImProcessBatchProduct implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	@TableId("fd_id")
	private Long fdId;
    /**
     * 处理品收集主表id
     */
	@TableField("im_process_id")
	private Long imProcessId;
    /**
     * 纸卷编号
     */
	@TableField("paper_no")
	private String paperNo;
    /**
     * 品类
     */
	@TableField("class_no")
	private String classNo;
    /**
     * 定量
     */
	private BigDecimal ration;
    /**
     * 起趋率
     */
	@TableField("wrinkle_rate")
	private BigDecimal wrinkleRate;
    /**
     * 层数
     */
	private Integer layer;
    /**
     * 单幅幅宽
     */
	private String width;
    /**
     * 直径
     */
	private BigDecimal diameter;
    /**
     * 产品等级
     */
	private String grade;
    /**
     * 降级原因
     */
	private String reason;
    /**
     * 重量
     */
	private BigDecimal weight;
    /**
     * 生产日期
     */
	@TableField("product_date")
	private Date productDate;
    /**
     * 处理品价格录入id
     */
	@TableField("im_process_price_id")
	private Long imProcessPriceId;
    /**
     * 是否属本批处理品
     */
	@TableField("is_this_batch")
	private Integer isThisBatch;
	/**
     * 状态
     */
	private Integer status;
    /**
     * 销售状态
     */
	@TableField("sale_status")
	private String saleStatus;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getImProcessId() {
		return imProcessId;
	}

	public void setImProcessId(Long imProcessId) {
		this.imProcessId = imProcessId;
	}

	public Long getImProcessPriceId() {
		return imProcessPriceId;
	}

	public void setImProcessPriceId(Long imProcessPriceId) {
		this.imProcessPriceId = imProcessPriceId;
	}

	public String getPaperNo() {
		return paperNo;
	}

	public void setPaperNo(String paperNo) {
		this.paperNo = paperNo;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public BigDecimal getRation() {
		return ration;
	}

	public void setRation(BigDecimal ration) {
		this.ration = ration;
	}

	public BigDecimal getWrinkleRate() {
		return wrinkleRate;
	}

	public void setWrinkleRate(BigDecimal wrinkleRate) {
		this.wrinkleRate = wrinkleRate;
	}

	public Integer getLayer() {
		return layer;
	}

	public void setLayer(Integer layer) {
		this.layer = layer;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public BigDecimal getDiameter() {
		return diameter;
	}

	public void setDiameter(BigDecimal diameter) {
		this.diameter = diameter;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public Date getProductDate() {
		return productDate;
	}

	public void setProductDate(Date productDate) {
		this.productDate = productDate;
	}

	public Integer getIsThisBatch() {
		return isThisBatch;
	}

	public void setIsThisBatch(Integer isThisBatch) {
		this.isThisBatch = isThisBatch;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getSaleStatus() {
		return saleStatus;
	}

	public void setSaleStatus(String saleStatus) {
		this.saleStatus = saleStatus;
	}

}
