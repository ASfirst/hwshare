package com.hwagain.sp.policy.dto;

import java.util.Date;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
public class PoPolicyDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
	private Integer fdYear;
	private Integer fdMonth;
	private Date startDate;
	private Date endDate;
	private Boolean isImportWhite;
	private Boolean isImportColor;
	private Boolean is3900White;
	private Boolean is3900Color;
	private Boolean is1575White;
	private Boolean isAll;
	private Integer baseAmount;
	private Integer baseAvgAmount;
	private Integer promiseAmount;
	private Integer fbaseAmount;
	private Integer fbaseAvgAmount;
	private Integer fpromiseAmount;
	private String remark;
	private Integer status;
	private String createrId;
	private Date createTime;
	private String lastAlterId;
	private Date lastAlterTime;
	private String oaCode;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Integer getFdYear() {
		return fdYear;
	}

	public void setFdYear(Integer fdYear) {
		this.fdYear = fdYear;
	}

	public Integer getFdMonth() {
		return fdMonth;
	}

	public void setFdMonth(Integer fdMonth) {
		this.fdMonth = fdMonth;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Boolean isIsImportWhite() {
		return isImportWhite;
	}

	public void setIsImportWhite(Boolean isImportWhite) {
		this.isImportWhite = isImportWhite;
	}

	public Boolean isIsImportColor() {
		return isImportColor;
	}

	public void setIsImportColor(Boolean isImportColor) {
		this.isImportColor = isImportColor;
	}

	public Boolean isIs3900White() {
		return is3900White;
	}

	public void setIs3900White(Boolean is3900White) {
		this.is3900White = is3900White;
	}

	public Boolean isIs3900Color() {
		return is3900Color;
	}

	public void setIs3900Color(Boolean is3900Color) {
		this.is3900Color = is3900Color;
	}

	public Boolean isIs1575White() {
		return is1575White;
	}

	public void setIs1575White(Boolean is1575White) {
		this.is1575White = is1575White;
	}

	public Boolean isIsAll() {
		return isAll;
	}

	public void setIsAll(Boolean isAll) {
		this.isAll = isAll;
	}

	public Integer getBaseAmount() {
		return baseAmount;
	}

	public void setBaseAmount(Integer baseAmount) {
		this.baseAmount = baseAmount;
	}

	public Integer getBaseAvgAmount() {
		return baseAvgAmount;
	}

	public void setBaseAvgAmount(Integer baseAvgAmount) {
		this.baseAvgAmount = baseAvgAmount;
	}

	public Integer getPromiseAmount() {
		return promiseAmount;
	}

	public void setPromiseAmount(Integer promiseAmount) {
		this.promiseAmount = promiseAmount;
	}

	public Integer getFbaseAmount() {
		return fbaseAmount;
	}

	public void setFbaseAmount(Integer fbaseAmount) {
		this.fbaseAmount = fbaseAmount;
	}

	public Integer getFbaseAvgAmount() {
		return fbaseAvgAmount;
	}

	public void setFbaseAvgAmount(Integer fbaseAvgAmount) {
		this.fbaseAvgAmount = fbaseAvgAmount;
	}

	public Integer getFpromiseAmount() {
		return fpromiseAmount;
	}

	public void setFpromiseAmount(Integer fpromiseAmount) {
		this.fpromiseAmount = fpromiseAmount;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

	public String getOaCode() {
		return oaCode;
	}

	public void setOaCode(String oaCode) {
		this.oaCode = oaCode;
	}

}
