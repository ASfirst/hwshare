package com.hwagain.sp.price.service.impl;

import com.hwagain.sp.price.entity.ImSpecialPrice;
import com.hwagain.sp.base.mapper.RptTempMapper;
import com.hwagain.sp.price.dto.ImPriceRptDto;
import com.hwagain.sp.price.dto.ImSpecialPriceDto;
import com.hwagain.sp.price.dto.ImSpecialPriceExtDto;
import com.hwagain.sp.price.mapper.ImSpecialPriceExtMapper;
import com.hwagain.sp.price.mapper.ImSpecialPriceMapper;
import com.hwagain.sp.price.service.IImSpecialPriceService;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author guoym
 * @since 2018-10-16
 */
@Service("imSpecialPriceService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImSpecialPriceServiceImpl extends ServiceImpl<ImSpecialPriceMapper, ImSpecialPrice>
		implements IImSpecialPriceService {

	// entity转dto
	static MapperFacade entityToDtoMapper;

	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImSpecialPrice.class, ImSpecialPriceDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();

		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImSpecialPriceDto.class, ImSpecialPrice.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

	@Autowired
	RptTempMapper rptTempMapper;
	@Autowired
	ImSpecialPriceExtMapper imSpecialPriceExtMapper;

	@Override
	public List<ImSpecialPriceExtDto> queryImSpecialPriceList() {
		List<ImSpecialPriceExtDto> list = imSpecialPriceExtMapper.queryImSpecialPriceList();
		return list;
	}
	
	@Override
	public List<ImSpecialPriceExtDto> queryHistoryByBatchId(String batchId) {
		List<ImSpecialPriceExtDto> list = imSpecialPriceExtMapper.queryImSpecialHistory1(batchId);
		return list;
	}

}
