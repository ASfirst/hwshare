package com.hwagain.sp.deposit.api;

/**
 * <p>
 * 客户当月定金对账主表 服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
public interface IDDepositMainApi {
	
}
