package com.hwagain.sp.disobey.web;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.sp.disobey.service.IImDisobeyChannelingService;

/**
 * <p>
 * 匿名访问-违约扣款
 * </p>
 *
 * @author huanglf
 * @since 2018-12-10
 */
@RestController
@RequestMapping(value = "/anonymous/disobey", method = { RequestMethod.GET, RequestMethod.POST })
@Api(value = "匿名接口-违约扣款", description = "匿名接口-违约扣款")
public class AnonymousDisobeyController {
	@Autowired
	IImDisobeyChannelingService imDisobeyChanngelingService;
	
	@RequestMapping(value = "/findChannelingListByOACode", method = { RequestMethod.GET })
	@ApiOperation(value = "根据OA单号查窜货明细", notes = "根据OA单号查窜货明细", httpMethod = "GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "oaCode", value = "oaCode", paramType = "query", required = true, dataType = "String") })
	public Response findChannelingListByOACode(String oaCode) {
		return SuccessResponseData.newInstance(imDisobeyChanngelingService.findByOACode(oaCode));
	}

}
