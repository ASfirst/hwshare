package com.hwagain.sp.process.dto;

import java.math.BigDecimal;
import java.util.Date;



/**
 * <p>
 * 
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public class ImProcessPriceListRptDto {

	private Long imPriceId;
	private Long imProcessId;
	/**
     * 是否享受政策
     */
	private Integer isPolicy;
	/**
     * 处理价格
     */
	private BigDecimal processPrice;
	public Long getImPriceId() {
		return imPriceId;
	}
	public void setImPriceId(Long imPriceId) {
		this.imPriceId = imPriceId;
	}
	public Long getImProcessId() {
		return imProcessId;
	}
	public void setImProcessId(Long imProcessId) {
		this.imProcessId = imProcessId;
	}
	public Integer getIsPolicy() {
		return isPolicy;
	}
	public void setIsPolicy(Integer isPolicy) {
		this.isPolicy = isPolicy;
	}
	public BigDecimal getProcessPrice() {
		return processPrice;
	}
	public void setProcessPrice(BigDecimal processPrice) {
		this.processPrice = processPrice;
	}
	

}
