package com.hwagain.sp.deposit.mapper;

import com.hwagain.sp.deposit.entity.DNoDepositStandard;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author xionglz
 * @since 2018-11-08
 */
public interface DNoDepositStandardMapper extends BaseMapper<DNoDepositStandard> {

}