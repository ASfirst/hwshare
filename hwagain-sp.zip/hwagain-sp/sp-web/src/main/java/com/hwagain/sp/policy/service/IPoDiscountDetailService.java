package com.hwagain.sp.policy.service;

import com.hwagain.sp.policy.dto.PoDiscountDetailDto;
import com.hwagain.sp.policy.entity.PoDiscountDetail;

import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author linhl
 * @since 2018-11-02
 */
public interface IPoDiscountDetailService extends IService<PoDiscountDetail> {
	public PoDiscountDetail findoneByfdid(Long fdid)throws CustomException;

	public List<PoDiscountDetail> findAll(String orderNo);
	
	public Double findSumAmountByParentID(long parentID);

	public PoDiscountDetailDto save(PoDiscountDetailDto dto);
	
	public Boolean deleteByOrderNo(String orderNo);
	
	public Boolean deleteByIds(String ids);

	
}
