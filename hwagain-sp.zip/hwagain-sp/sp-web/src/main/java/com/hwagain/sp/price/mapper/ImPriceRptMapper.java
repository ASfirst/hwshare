package com.hwagain.sp.price.mapper;

import com.hwagain.sp.price.dto.ImPriceAdjustRptDto;
import com.hwagain.sp.price.dto.ImPriceRptDto;
import com.hwagain.sp.price.entity.ImPrice;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

public interface ImPriceRptMapper extends BaseMapper<ImPrice> {

	public List<ImPriceRptDto> queryImPriceList();

	public List<ImPriceRptDto> queryInputList();

	public List<ImPriceRptDto> queryInputByOaCode(@Param("oACode") String oACode);

	public List<ImPriceAdjustRptDto> queryAdjustList(@Param("onlyChanged") Integer onlyChanged);

	public List<ImPriceAdjustRptDto> queryAdjustByOaCode(@Param("oACode") String oACode,
			@Param("onlyChanged") Integer onlyChanged);

	public List<ImPriceRptDto> queryHistoryPriceDetail(@Param("startDate") Date startDate,
			@Param("price") BigDecimal price, @Param("addPrice") BigDecimal addPrice);
	
	public List<ImPriceAdjustRptDto> findNewHistory(@Param("onlyChanged") Integer onlyChanged,@Param("createrId") String createrId);

	public List<ImPriceRptDto> findAllList();
}
