package com.hwagain.sp.policy.dto.params.area;

import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created on 2019/6/24 11:42
 * by @author WeiBoWen
 */
public class SavePoAreaDto implements Serializable {

    @NotNull(message = "客户id不能为空")
    private Long customerId;

    @NotNull(message = "补贴金额不能为空")
    private BigDecimal amount;

    @NotNull(message = "开始日期不能为空")
    private Date startDate;

    @NotNull(message = "客户id不能为空")
    private Integer status;

    @NotBlank(message = "为避免歧义，备注不能填写空字符串")
    private String remark;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
