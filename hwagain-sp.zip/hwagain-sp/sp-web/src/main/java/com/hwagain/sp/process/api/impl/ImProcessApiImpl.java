package com.hwagain.sp.process.api.impl;

import com.hwagain.sp.process.api.IImProcessApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
@Service("imProcessApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImProcessApiImpl implements IImProcessApi {
	
}
