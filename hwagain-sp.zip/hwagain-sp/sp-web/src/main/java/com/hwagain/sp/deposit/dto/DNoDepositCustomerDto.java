package com.hwagain.sp.deposit.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author xionglz
 * @since 2018-11-05
 */
public class DNoDepositCustomerDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
    /**
     * 产品品类
     */
	private String classNo;
    /**
     * 企业套产品编号
     */
	private String enterpriseSetNo;
    /**
     * 定量
     */
	private BigDecimal ration;
    /**
     * 起皱率
     */
	private String wrinkleRate;
    /**
     * 层数
     */
	private Integer layers;
    /**
     * 分切规格
     */
	private String cutSpec;
    /**
     * 直径
     */
	private BigDecimal diameter;
    /**
     * 月订单量
     */
	private BigDecimal monthOrderWeight;
    /**
     * 月出库量
     */
	private BigDecimal monthDeliveryWeight;
    /**
     * 连续月数
     */
	private Integer monthNumber;
    /**
     * 单幅幅宽
     */
	private String width;
    /**
     * 单幅产品名称
     */
	private String productName;
    /**
     * 年
     */
	private Integer year;
    /**
     * 月
     */
	private Integer month;
	/**
	 * 月份
	 */
	@JsonFormat(pattern="yyyy-MM",timezone="GMT+8")
	private Date monthDate;
    /**
     * X月订单量
     */
	private BigDecimal orderWeight;
	private BigDecimal totalOrderWeight;
    /**
     * X月出库量
     */
	private BigDecimal deliveryWeight;
	private BigDecimal totalDeliveryWeight;
    /**
     * Y月订单量
     */
	private BigDecimal orderWeight2;
	private BigDecimal totalOrderWeight2;
    /**
     * Y月出库量
     */
	private BigDecimal deliveryWeight2;
	private BigDecimal totalDeliveryWeight2;
    /**
     * 创建人
     */
	private String createrId;
    /**
     * 创建时间
     */
	private Date createTime;
    /**
     * 最后修改人
     */
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getEnterpriseSetNo() {
		return enterpriseSetNo;
	}

	public void setEnterpriseSetNo(String enterpriseSetNo) {
		this.enterpriseSetNo = enterpriseSetNo;
	}

	public BigDecimal getRation() {
		return ration;
	}

	public void setRation(BigDecimal ration) {
		this.ration = ration;
	}

	public String getWrinkleRate() {
		return wrinkleRate;
	}

	public void setWrinkleRate(String wrinkleRate) {
		this.wrinkleRate = wrinkleRate;
	}

	public Integer getLayers() {
		return layers;
	}

	public void setLayers(Integer layers) {
		this.layers = layers;
	}

	public String getCutSpec() {
		return cutSpec;
	}

	public void setCutSpec(String cutSpec) {
		this.cutSpec = cutSpec;
	}

	public BigDecimal getDiameter() {
		return diameter;
	}

	public void setDiameter(BigDecimal diameter) {
		this.diameter = diameter;
	}

	public BigDecimal getMonthOrderWeight() {
		return monthOrderWeight;
	}

	public void setMonthOrderWeight(BigDecimal monthOrderWeight) {
		this.monthOrderWeight = monthOrderWeight;
	}

	public BigDecimal getMonthDeliveryWeight() {
		return monthDeliveryWeight;
	}

	public void setMonthDeliveryWeight(BigDecimal monthDeliveryWeight) {
		this.monthDeliveryWeight = monthDeliveryWeight;
	}

	public Integer getMonthNumber() {
		return monthNumber;
	}

	public void setMonthNumber(Integer monthNumber) {
		this.monthNumber = monthNumber;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public Date getMonthDate() {
		return monthDate;
	}

	public void setMonthDate(Date monthDate) {
		this.monthDate = monthDate;
	}

	public BigDecimal getOrderWeight() {
		return orderWeight;
	}

	public void setOrderWeight(BigDecimal orderWeight) {
		this.orderWeight = orderWeight;
	}

	public BigDecimal getTotalOrderWeight() {
		return totalOrderWeight;
	}

	public void setTotalOrderWeight(BigDecimal totalOrderWeight) {
		this.totalOrderWeight = totalOrderWeight;
	}

	public BigDecimal getDeliveryWeight() {
		return deliveryWeight;
	}

	public void setDeliveryWeight(BigDecimal deliveryWeight) {
		this.deliveryWeight = deliveryWeight;
	}

	public BigDecimal getTotalDeliveryWeight() {
		return totalDeliveryWeight;
	}

	public void setTotalDeliveryWeight(BigDecimal totalDeliveryWeight) {
		this.totalDeliveryWeight = totalDeliveryWeight;
	}

	public BigDecimal getOrderWeight2() {
		return orderWeight2;
	}

	public void setOrderWeight2(BigDecimal orderWeight2) {
		this.orderWeight2 = orderWeight2;
	}

	public BigDecimal getTotalOrderWeight2() {
		return totalOrderWeight2;
	}

	public void setTotalOrderWeight2(BigDecimal totalOrderWeight2) {
		this.totalOrderWeight2 = totalOrderWeight2;
	}

	public BigDecimal getDeliveryWeight2() {
		return deliveryWeight2;
	}

	public void setDeliveryWeight2(BigDecimal deliveryWeight2) {
		this.deliveryWeight2 = deliveryWeight2;
	}

	public BigDecimal getTotalDeliveryWeight2() {
		return totalDeliveryWeight2;
	}

	public void setTotalDeliveryWeight2(BigDecimal totalDeliveryWeight2) {
		this.totalDeliveryWeight2 = totalDeliveryWeight2;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
