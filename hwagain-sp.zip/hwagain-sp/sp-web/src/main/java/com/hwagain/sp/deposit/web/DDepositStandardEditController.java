package com.hwagain.sp.deposit.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.deposit.service.IDDepositStandardEditService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xionglz
 * @since 2018-11-06
 */
@RestController
@RequestMapping(value="/deposit/dDepositStandardEdit",method={RequestMethod.GET,RequestMethod.POST})
public class DDepositStandardEditController extends BaseController{
	
	@Autowired
	IDDepositStandardEditService dDepositStandardEditService;
	
	
}
