package com.hwagain.sp.price.api.impl;

import com.hwagain.sp.price.api.IImPriceAddConditionEditApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 小幅宽产品加价表 服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-21
 */
@Service("imPriceAddConditionEditApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImPriceAddConditionEditApiImpl implements IImPriceAddConditionEditApi {
	
}
