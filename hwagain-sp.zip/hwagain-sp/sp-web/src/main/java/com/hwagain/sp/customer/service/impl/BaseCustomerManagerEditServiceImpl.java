package com.hwagain.sp.customer.service.impl;

import com.hwagain.sp.customer.entity.BaseCustomerManagerEdit;
import com.hwagain.sp.customer.dto.BaseCustomerManagerEditDto;
import com.hwagain.sp.customer.mapper.BaseCustomerManagerEditMapper;
import com.hwagain.sp.customer.service.IBaseCustomerManagerEditService;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-28
 */
@Service("baseCustomerManagerEditService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class BaseCustomerManagerEditServiceImpl extends ServiceImpl<BaseCustomerManagerEditMapper, BaseCustomerManagerEdit> implements IBaseCustomerManagerEditService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(BaseCustomerManagerEdit.class, BaseCustomerManagerEditDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(BaseCustomerManagerEditDto.class, BaseCustomerManagerEdit.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
}
