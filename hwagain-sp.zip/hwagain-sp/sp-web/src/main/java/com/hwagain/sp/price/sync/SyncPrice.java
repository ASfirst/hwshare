package com.hwagain.sp.price.sync;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import com.hwagain.sp.price.service.IImPriceService;

import ma.glasnost.orika.MapperFacade;

@Configurable
@EnableScheduling
@Component
public class SyncPrice {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	static boolean isSync = false;

	static MapperFacade entityToDtoMapper;
	
	@Autowired
	private IImPriceService imPriceService;
	
	protected static ExecutorService executorService = null;

	static {
		int processCount = 50;
		executorService = new ThreadPoolExecutor(processCount / 2 + 1, processCount * 2 + 1, 5L, TimeUnit.MINUTES,
				new LinkedBlockingQueue<Runnable>());
	}

	@Scheduled(cron = "0 0 2 ? * *") // 每天2点执行
	// @Scheduled(cron = "0/30 * * * * ?") // 5秒一次【 测试用】
	public void syncData() {
		if (isSync)
			return;

		isSync = true;

		//进口纸机-统一销售价格-过期状态
		imPriceService.outDateStatus();

		isSync = false;
	}


}
