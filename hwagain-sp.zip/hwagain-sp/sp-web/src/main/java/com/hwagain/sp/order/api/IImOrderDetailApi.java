package com.hwagain.sp.order.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
public interface IImOrderDetailApi {
	
}
