package com.hwagain.sp.policy.web;

import com.hwagain.sp.policy.dto.params.area.CheckPoAreaDto;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponse;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.validation.util.ValidationUtil;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.policy.dto.PoAreaDto;
import com.hwagain.sp.policy.service.IPoAreaService;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author weibw
 * @since 2019-06-24
 */
@RestController
@RequestMapping(value = "/policy/poArea", method = {RequestMethod.GET, RequestMethod.POST})
@Api(value = "【补贴金额】审核表管理", description = "【补贴金额】审核表管理")
public class PoAreaController extends BaseController {

    @Autowired
    IPoAreaService poAreaService;

    /**
     * 查询全部数据
     *
     * @return
     */
    @RequestMapping("/findAll")
    @ApiOperation(value = "查詢数据列表", notes = "查詢数据列表", httpMethod = "GET")
    public Response findAll() {
        return SuccessResponseData.newInstance(poAreaService.findAll(), null,
                this.getValidation(new PoAreaDto()), null);
    }

    /**
     * 获取当前资源下的用户权限
     *
     * @param dto
     * @return
     */
    public Map<String, Boolean> getValidation(PoAreaDto dto) {
        String contextPath = getRequest().getContextPath();
        Map<String, Boolean> validURIMaps = ValidationUtil.validModuleOperator(contextPath,
                "/policy/poArea", dto);
        return validURIMaps;
    }

    /**
     * 按ID查询数据
     *
     * @param dto
     * @return
     */
    @RequestMapping(value = "/findOne", method = {RequestMethod.GET})
    @ApiOperation(value = "按ID查询数据", notes = "按ID查询数据", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "fdId", value = "数据ID", paramType = "query",
                    required = false, dataType = "String")
    })
    public Response findOne(String fdId) {
        return SuccessResponseData.newInstance(poAreaService.findOne(fdId));
    }

    /**
     * 新增数据
     *
     * @param dto
     * @return
     */
    @RequestMapping(value = "/save", method = {RequestMethod.POST})
    @ApiOperation(value = "新增数据", notes = "新增数据", httpMethod = "POST")
    public Response save(@RequestBody PoAreaDto dto) {
        return SuccessResponseData.newInstance(poAreaService.save(dto));
    }

    /**
     * 修改数据
     *
     * @param dto
     * @return
     */
    @RequestMapping(value = "/update", method = {RequestMethod.POST})
    @ApiOperation(value = "修改数据", notes = "修改数据", httpMethod = "POST")
    public Response update(@RequestBody PoAreaDto dto) {
        return SuccessResponseData.newInstance(poAreaService.update(dto));
    }

    /**
     * 删除数据，可批量
     *
     * @param ids 格式：1;2;3;4....
     * @return
     */
    @RequestMapping(value = "/delete", method = {RequestMethod.GET})
    @ApiOperation(value = "删除数据", notes = "删除数据", httpMethod = "GET")
    @ApiImplicitParams({
            @ApiImplicitParam(name = "ids", value = "数据集,格式：1;2;3;4....", paramType = "query",
                    required = false, dataType = "String")
    })
    public Response delete(String ids) {
        Boolean isOk = poAreaService.deleteByIds(ids);
        return SuccessResponse.newInstance(isOk ? "删除成功！" : "删除失败！");
    }

    /**
     * 分页查询
     *
     * @param pageDto
     * @return
     *//*
	@RequestMapping(value="/findByPage",method={RequestMethod.GET})
	@ApiOperation(value = "分页查询数据", notes = "分页查询数据",httpMethod="GET")
	public Response findByPage(PoAreaDto dto,PageVO pageVo){
		return SuccessResponseData.newInstance(poAreaService.findByPage(dto,pageVo));
	}*/

    /**
     * 审核
     */
    @RequestMapping(value = "/check", method = {RequestMethod.POST})
    @ApiOperation(value = "审核数据", notes = "审核数据", httpMethod = "POST")
    public Response check(@RequestParam("fdId") Long fdId,
                          @RequestParam("status") Integer status,
                          @RequestParam(value = "checkedRemark", required = false)
                                  String checkedRemark) {
        CheckPoAreaDto checkPoAreaDto = new CheckPoAreaDto(fdId, status, checkedRemark);
        Boolean isOk = poAreaService.check(checkPoAreaDto);
        return SuccessResponse.newInstance(isOk ? "审核成功！" : "审核失败！");
    }
}
