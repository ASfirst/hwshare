package com.hwagain.sp.price.service;

import com.hwagain.sp.price.dto.ImSpecialPriceExtDto;
import com.hwagain.sp.price.entity.ImSpecialPrice;

import java.util.List;

import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author guoym
 * @since 2018-10-16
 */
public interface IImSpecialPriceService extends IService<ImSpecialPrice> {

    public List<ImSpecialPriceExtDto> queryImSpecialPriceList();

    public List<ImSpecialPriceExtDto> queryHistoryByBatchId(String batchId);
	
}
