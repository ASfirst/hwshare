package com.hwagain.sp.deposit.service.impl;

import com.alibaba.fastjson.JSONObject;
import com.hwagain.sp.deposit.entity.DDepositStandard;
import com.hwagain.sp.deposit.entity.DDepositStandardEdit;
import com.hwagain.sp.deposit.dto.DDepositStandardDto;
import com.hwagain.sp.deposit.dto.DDepositStandardEditDto;
import com.hwagain.sp.deposit.mapper.DDepositStandardEditMapper;
import com.hwagain.sp.deposit.service.IDDepositStandardEditService;
import com.hwagain.sp.deposit.service.IDDepositStandardService;
import com.hwagain.sp.product.entity.ProductKind;
import com.hwagain.sp.product.service.IProductKindService;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.core.util.StringUtil;
import com.hwagain.framework.mybatisplus.enums.SqlLike;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import oracle.net.aso.a;
import oracle.net.aso.e;
import oracle.net.aso.w;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-06
 */
@Service("dDepositStandardEditService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DDepositStandardEditServiceImpl extends ServiceImpl<DDepositStandardEditMapper, DDepositStandardEdit> implements IDDepositStandardEditService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	@Autowired IDDepositStandardService depositStandardService;
	@Autowired DDepositStandardServiceImpl dDepositStandardServiceImpl;
	@Autowired IProductKindService productKindService;
	
	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(DDepositStandardEdit.class, DDepositStandardEditDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(DDepositStandardEditDto.class, DDepositStandardEdit.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	//更新一条
	@Override
	public String updateOneDeposit(DDepositStandardEditDto dto){
//		System.err.println(dto.getProductNo());
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		
		//产品类型
		Wrapper<ProductKind> wrapperKind=new CriterionWrapper<ProductKind>(ProductKind.class);
		wrapperKind.eq("platform", "Import");
		List<ProductKind> allKind=productKindService.selectList(wrapperKind);
//	    System.err.println(dto.getKindNo());
		Wrapper<DDepositStandardEdit> wrapper=new CriterionWrapper<DDepositStandardEdit>(DDepositStandardEdit.class);
		wrapper.eq("status", 1);
		if(allKind!=null){
			for(int k=0;k<allKind.size();k++){
				if(allKind.get(k).getName().equals(dto.getKindNo())){
					wrapper.eq("kind_no", allKind.get(k).getKindNo());
				}
			}
		}
		
		wrapper.eq("product_no", dto.getProductNo());
		wrapper.eq("specification", dto.getSpecification());
		wrapper.eq("deposit", dto.getDeposit());
		wrapper.eq("start_time", dto.getStartTime());
		wrapper.eq("end_time", dto.getEndTime());
		wrapper.notIn("creater_id", cUserid);
		DDepositStandardEdit list=super.selectFirst(wrapper);
		
		DDepositStandardEdit depo=new DDepositStandardEdit();
		depo.setFdId(dto.getFdId());
		depo.setSpecification(dto.getSpecification());
		depo.setProductNo(dto.getProductNo());
		depo.setDeposit(dto.getDeposit());
		depo.setStartTime(dto.getStartTime());
		depo.setEndTime(dto.getEndTime());
		if(list!=null){
			depo.setStatus(10);
			DDepositStandardEdit depo1=new DDepositStandardEdit();
			depo1.setFdId(list.getFdId());
			depo1.setStatus(10);
			depo1.setLastAlterId(cUserid);
			depo1.setLastAlterTime(doDate);
			super.updateById(depo1);
			String str=JSONObject.toJSONString(depo);
			DDepositStandardDto ddto=JSONObject.parseObject(str,DDepositStandardDto.class);
			dDepositStandardServiceImpl.updateDeposits(ddto);
		}else{
			depo.setStatus(1);
		}
//		depo.setEdit(dto.getEdit()+cUserid);
		depo.setCreaterId(cUserid);
		depo.setCreateTime(doDate);
		depo.setIsHistory(0);
		super.updateById(depo);
		
		DDepositStandardEdit listF=super.selectById(depo.getFdId());
//		System.err.println(listF.getCreaterId());
		if(listF!=null&&listF.getStatus()==1){
			return "定金标准调整成功，未有相同数据匹配";
		}
		return "双人录入修改成功";
		
	}
	//批量更新
	@Override
	public List<DDepositStandardEditDto> updateDeposits(List<DDepositStandardEditDto> dtos){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		//产品类型
		Wrapper<ProductKind> wrapperKind=new CriterionWrapper<ProductKind>(ProductKind.class);
		wrapperKind.eq("platform", "Import");
		List<ProductKind> allKind=productKindService.selectList(wrapperKind);
//		System.err.println(dtos);
		for(int i=0;i<dtos.size();i++){
			DDepositStandardEditDto dto=dtos.get(i);
			
			Wrapper<DDepositStandardEdit> wrapper=new CriterionWrapper<DDepositStandardEdit>(DDepositStandardEdit.class);
			wrapper.eq("status", 1);
			if(allKind!=null){
				for(int k=0;k<allKind.size();k++){
					if(allKind.get(k).getName().equals(dto.getKindNo())){
						wrapper.eq("kind_no", allKind.get(k).getKindNo());
					}
				}
			}
			
			wrapper.eq("product_no", dto.getProductNo());
			wrapper.eq("specification", dto.getSpecification());
			wrapper.eq("deposit", dto.getDeposit());
			wrapper.eq("start_time", dto.getStartTime());
			wrapper.eq("end_time", dto.getEndTime());
			wrapper.notIn("creater_id", cUserid);
			DDepositStandardEdit list=super.selectFirst(wrapper);
			
			DDepositStandardEdit depo=new DDepositStandardEdit();
			depo.setFdId(Long.valueOf(IdWorker.getId()));
			if(allKind!=null){
				for(int k=0;k<allKind.size();k++){
					if(allKind.get(k).getName().equals(dto.getKindNo())){
						depo.setKindNo(allKind.get(k).getKindNo());
						if(allKind.get(k).getKindNo().equals("a")){
							depo.setProductNo(dto.getProductNo());
						}
						if(allKind.get(k).getKindNo().equals("c")){
							depo.setProductNo("全部");
						}else{
							depo.setProductNo(dto.getProductNo());
						}
					}
				}
			}
			
			depo.setSpecification(dto.getSpecification());
			depo.setDeposit(dto.getDeposit());
			depo.setStartTime(dto.getStartTime());
			depo.setEndTime(dto.getEndTime());
			if(list!=null){
				depo.setStatus(10);
				DDepositStandardEdit depo1=new DDepositStandardEdit();
				depo1.setFdId(list.getFdId());
				depo1.setStatus(10);
				super.updateById(depo1);
				String str=JSONObject.toJSONString(depo);
				DDepositStandardDto ddto=JSONObject.parseObject(str,DDepositStandardDto.class);
				dDepositStandardServiceImpl.updateDeposits(ddto);
			}else{
				depo.setStatus(1);
			}
			depo.setCreaterId(cUserid);
			depo.setCreateTime(doDate);
			depo.setIsHistory(0);
			super.insert(depo);
		}
		return dtos;
		
	}
	//
	//更新非常规品单幅产品编号
	@Override
	public List<DDepositStandardEditDto> updateBBase(String edit){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
		Wrapper<DDepositStandardEdit> wrapper=new CriterionWrapper<DDepositStandardEdit>(DDepositStandardEdit.class);
		wrapper.eq("is_history", 0);
		wrapper.eq("kind_no", "a");
		wrapper.eq("edit", edit);
		wrapper.orderBy("product_no");
		List<DDepositStandardEdit> listA=super.selectList(wrapper);
		ArrayList<String> productNo1=new ArrayList<>();
		String productNo2="";
		if(listA!=null){
			for(int i=0;i<listA.size();i++){
				productNo1.add(listA.get(i).getProductNo());
			}
		}
		productNo2=StringUtil.join(productNo1, "或");
//			System.err.println(productNo2);
		Wrapper<DDepositStandardEdit> wrpper1=new CriterionWrapper<DDepositStandardEdit>(DDepositStandardEdit.class);
		wrpper1.eq("kind_no", "b");
		List<DDepositStandardEdit> listB=super.selectList(wrpper1);
		if(listB!=null){
			for(int j=0;j<listB.size();j++){
				DDepositStandardEdit depo=new DDepositStandardEdit();
				depo.setFdId(listB.get(j).getFdId());
				depo.setSpecification("");
				depo.setProductNo("≠"+productNo2);
				depo.setLastAlterId(cUserid);
				depo.setLastAlterTime(doDate);
				super.updateById(depo);
			}
		}
		return null;
	}
	@Override
	public List<DDepositStandardEditDto> findAllEdit(String edit){
		updateBBase(edit);
		Wrapper<ProductKind> wrapperKind=new CriterionWrapper<ProductKind>(ProductKind.class);
		wrapperKind.eq("platform", "Import");
		List<ProductKind> allKind=productKindService.selectList(wrapperKind);
		if(StringUtil.isNull(edit)){
			edit="1";
		}
		Wrapper<DDepositStandardEdit> wrapper=new CriterionWrapper<DDepositStandardEdit>(DDepositStandardEdit.class);
		wrapper.like("edit", edit, SqlLike.DEFAULT);
//		wrapper.in("edit", "1,2");
		
		List<DDepositStandardEdit> list=super.selectList(wrapper);
		if(list!=null&&list.size()!=0){
			for(int i=0;i<list.size();i++){
				SimpleDateFormat simpleDateFormat = new SimpleDateFormat( "yyyy-MM-dd");
				if(list.get(i).getEndTime()!=null){
					String d=simpleDateFormat.format(list.get(i).getEndTime());
					Date date1 = null;
					try {
						date1 =  simpleDateFormat.parse(d);
					} catch (ParseException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Calendar c = Calendar.getInstance();
					c.setTime(new Date());
					c.add(Calendar.DAY_OF_MONTH, -1);
					Date yesterday = c.getTime();
					System.err.println(yesterday);
					if(date1.before(yesterday)){
					   DDepositStandardEdit depo=new DDepositStandardEdit();
					   depo.setFdId(list.get(i).getFdId());
					   depo.setIsHistory(1);
//					   depo.setLastAlterTime(doDate);
//					   depo.setLastAlterId(cUserid);
					   super.updateById(depo);
					}
				}
			}
		}
		Wrapper<DDepositStandardEdit> wrapper1=new CriterionWrapper<DDepositStandardEdit>(DDepositStandardEdit.class);
		wrapper1.like("edit", edit, SqlLike.DEFAULT);
		wrapper1.eq("is_history", 0);
		wrapper1.orderBy("kind_no");
		List<DDepositStandardEdit> list1=super.selectList(wrapper1);
		if(list1!=null&&list1.size()!=0){
			for(int i=0;i<list1.size();i++){
				if(list1.get(i).getEdit().equals("1")||list1.get(i).getEdit().equals("2")){
					list1.get(i).setEdit(edit+":未修改");
				}
				for(int k=0;k<allKind.size();k++){
					if(list1.get(i).getKindNo().equals(allKind.get(k).getKindNo())){
						list1.get(i).setKindNo(allKind.get(k).getName());
					}
				}
			}
		}
		return entityToDtoMapper.mapAsList(list1, DDepositStandardEditDto.class);
		
	}
	
	//查询当前用户历史修改记录
	@Override
	public List<DDepositStandardEditDto> findNewHistory(){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		Wrapper<ProductKind> wrapperKind=new CriterionWrapper<ProductKind>(ProductKind.class);
		wrapperKind.eq("platform", "Import");
		List<ProductKind> allKind=productKindService.selectList(wrapperKind);
		Wrapper<DDepositStandard> wrapperStandard=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
		wrapperStandard.eq("is_history", 0);
		wrapperStandard.orderBy("kind_no");
		wrapperStandard.orderBy("start_time");
		List<DDepositStandard> allStandard=depositStandardService.selectList(wrapperStandard);
		Wrapper<DDepositStandardEdit> wrapper=new CriterionWrapper<DDepositStandardEdit>(DDepositStandardEdit.class);
		wrapper.eq("creater_id", cUserid);
		wrapper.eq("status", 1);
//		wrapper.eq("is_history", 0);
		List<DDepositStandardEdit> list=super.selectList(wrapper);
		List<DDepositStandardEdit> listA=new ArrayList<>();
		if(allStandard.size()!=0){
			for(DDepositStandard dto:allStandard){
				String st=JSONObject.toJSONString(dto);
				DDepositStandardEdit standard=JSONObject.parseObject(st,DDepositStandardEdit.class);
				listA.add(standard);
			}
		}
		
		if(list!=null&&list.size()!=0){
			for(DDepositStandardEdit dto:list){
				int R=0;
				for(DDepositStandardEdit ddto:listA){
					R++;
					if(dto.getKindNo().equals(ddto.getKindNo())&&
							dto.getProductNo().equals(ddto.getProductNo())&&
							dto.getSpecification().equals(ddto.getSpecification())){
						ddto.setFdId(dto.getFdId());
						ddto.setDeposit(dto.getDeposit());
						ddto.setStartTime(dto.getStartTime());
						ddto.setCreaterId(dto.getCreaterId());
						ddto.setRole(dto.getRole());
						ddto.setStatus(dto.getStatus());
						ddto.setIsHistory(dto.getIsHistory());
						System.err.println(dto.getIsHistory());
						break;
					}
//					System.err.println(R);
					if(R==listA.size()){
						listA.add(dto);
						break;
					}
				}
			}
		}
		List<DDepositStandardEdit> listB=new ArrayList<>();
		for(DDepositStandardEdit dto:listA){
			for(ProductKind kind:allKind){
				if(dto.getKindNo().equals(kind.getKindNo())){
					dto.setKindNo(kind.getName());
				}
			}
			if(dto.getIsHistory()==0){
				listB.add(dto);
			}
		}
		return entityToDtoMapper.mapAsList(listB, DDepositStandardEditDto.class);
	}
	//新增
	@Override
	public DDepositStandardEditDto addOneEdit(DDepositStandardEditDto dto){
		if(dto.getStartTime()==null){
			Assert.throwException("开始执行时间为空");
		}
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		Wrapper<ProductKind> wrapperKind=new CriterionWrapper<ProductKind>(ProductKind.class);
		wrapperKind.eq("platform", "Import");
		List<ProductKind> allKind=productKindService.selectList(wrapperKind);
		for(ProductKind kind:allKind){
			if(kind.getName().equals(dto.getKindNo())){
				dto.setKindNo(kind.getKindNo());
			}
		}
		Wrapper<DDepositStandardEdit> wrapper=new CriterionWrapper<DDepositStandardEdit>(DDepositStandardEdit.class);
		wrapper.eq("kind_no", dto.getKindNo());
		wrapper.eq("product_no", dto.getProductNo());
		wrapper.eq("specification", dto.getSpecification());
		wrapper.eq("status", 1);
		wrapper.eq("creater_id", cUserid);
		DDepositStandardEdit standardEdit=super.selectFirst(wrapper);
		if(standardEdit!=null){
			dto.setFdId(standardEdit.getFdId());
			super.updateById(dtoToEntityMapper.map(dto, DDepositStandardEdit.class));
		}else{
			dto.setFdId(Long.valueOf(IdWorker.getId()));
			dto.setCreaterId(cUserid);
			dto.setRole(dept);
			dto.setCreateTime(doDate);
			dto.setStatus(1);
			dto.setIsHistory(0);
			super.insert(dtoToEntityMapper.map(dto, DDepositStandardEdit.class));
		}
		return entityToDtoMapper.map(super.selectById(dto.getFdId()), DDepositStandardEditDto.class);		
	}
	//删除
	@Override
	public List<DDepositStandardEditDto> delete(List<DDepositStandardEditDto> dtos) {
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		if(dtos==null){
			Assert.throwException("未选中需要删除数据，请重新选择");
		}else{
			for(DDepositStandardEditDto dto:dtos){
				Wrapper<ProductKind> wrapperKind=new CriterionWrapper<ProductKind>(ProductKind.class);
				wrapperKind.eq("platform", "Import");
				List<ProductKind> allKind=productKindService.selectList(wrapperKind);
				for(ProductKind kind:allKind){
					if(kind.getName().equals(dto.getKindNo())){
						dto.setKindNo(kind.getKindNo());
					}
				}
				Wrapper<DDepositStandardEdit> wrapper=new CriterionWrapper<DDepositStandardEdit>(DDepositStandardEdit.class);
				wrapper.eq("kind_no", dto.getKindNo());
				wrapper.eq("product_no", dto.getProductNo());
				wrapper.eq("specification", dto.getSpecification());
				wrapper.eq("status", 1);
				wrapper.eq("creater_id", cUserid);
				DDepositStandardEdit standardEdit=super.selectFirst(wrapper);
				if(standardEdit!=null){
					dto.setFdId(standardEdit.getFdId());
					dto.setIsHistory(1);
					super.updateById(dtoToEntityMapper.map(dto, DDepositStandardEdit.class));
				}else{
					dto.setFdId(Long.valueOf(IdWorker.getId()));
					dto.setCreaterId(cUserid);
					dto.setRole(dept);
					dto.setCreateTime(doDate);
					dto.setStatus(1);
					dto.setIsHistory(1);
					super.insert(dtoToEntityMapper.map(dto, DDepositStandardEdit.class));
				}
			}
		}
		return dtos;
	}
	//匹配
	@Override
	public List<DDepositStandardEditDto> matching(List<DDepositStandardEditDto> dtos){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		Wrapper<ProductKind> wrapperKind=new CriterionWrapper<ProductKind>(ProductKind.class);
		wrapperKind.eq("platform", "Import");
		List<ProductKind> allKind=productKindService.selectList(wrapperKind);
		if(dtos.size()==0){
			Assert.throwException("提交数据为空");
		}
		
		Wrapper<DDepositStandardEdit> wrapper0=new CriterionWrapper<DDepositStandardEdit>(DDepositStandardEdit.class);
		wrapper0.eq("status", 1);
		wrapper0.eq("creater_id", cUserid);
		List<DDepositStandardEdit> list0=super.selectList(wrapper0);
		if(list0.size()==0){
			Assert.throwException("没有要匹配的数据");
		}
		List<DDepositStandardEdit> listA=new ArrayList<>();
		List<DDepositStandardDto> listB=new ArrayList<>();
		int R=0;
		for(DDepositStandardEdit dto:list0){
//			System.err.println(dto.getStatus());
			for(ProductKind kind:allKind){
				if(dto.getKindNo().equals(kind.getName())){
					dto.setKindNo(kind.getKindNo());
				}
			}
			if(dto.getStatus()!=null&&dto.getStatus()==1){
				String st=JSONObject.toJSONString(dto);
//				System.err.println(dto.getStatus());
				DDepositStandardDto dsdto=JSONObject.parseObject(st, DDepositStandardDto.class);
				Wrapper<DDepositStandardEdit> wrapper1=new CriterionWrapper<DDepositStandardEdit>(DDepositStandardEdit.class);
				wrapper1.eq("kind_no", dto.getKindNo());
				wrapper1.eq("product_no", dto.getProductNo());
				wrapper1.eq("specification", dto.getSpecification());
				wrapper1.eq("deposit", dto.getDeposit());
				wrapper1.eq("is_history", dto.getIsHistory());
				wrapper1.eq("status", 1);
				wrapper1.notIn("creater_id", cUserid);
				wrapper1.notIn("role", dto.getRole());
				DDepositStandardEdit standardEdit=super.selectFirst(wrapper1);
				if(standardEdit==null){
					Assert.throwException("匹配失败");
				}else{
//					System.err.println(standardEdit.getIsHistory());
					listA.add(standardEdit);
					listA.add(entityToDtoMapper.map(dto, DDepositStandardEdit.class));
					listB.add(dsdto);
				}
			}
			
		}
//		System.err.println(listA.size());
		for(DDepositStandardEdit dto:listA){
//			System.err.println(dto.getDeposit());
			DDepositStandardEdit ds=new DDepositStandardEdit();
			ds.setFdId(dto.getFdId());
			ds.setStatus(10);
			super.updateById(ds);
		}
		for(DDepositStandardDto dto:listB){
			dDepositStandardServiceImpl.updateOneEdit(dto);
		}
		return dtos;
		
	}
}
