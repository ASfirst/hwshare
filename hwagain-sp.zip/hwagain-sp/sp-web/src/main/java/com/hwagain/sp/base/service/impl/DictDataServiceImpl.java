package com.hwagain.sp.base.service.impl;

import com.hwagain.sp.base.entity.DictData;
import com.hwagain.sp.base.dto.DictDataDto;
import com.hwagain.sp.base.mapper.DictDataMapper;
import com.hwagain.sp.base.service.IDictDataService;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.security.common.util.UserUtils;

import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
@Service("dictDataService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DictDataServiceImpl extends ServiceImpl<DictDataMapper, DictData> implements IDictDataService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(DictData.class, DictDataDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(DictDataDto.class, DictData.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	
	@Override
	public List<DictDataDto> findByType(String typename) {
		Wrapper<DictData> wrapper = new CriterionWrapper<DictData>(DictData.class);
		wrapper.eq("type_name",typename);
		wrapper.eq("is_delete", 0);
		wrapper.orderBy("orderby").orderBy("itemNo");
		List<DictData> list = super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, DictDataDto.class);
	}
	
	@Override
	public DictData findoneByfdid(Long fdid) {
		Wrapper<DictData> wrapper = new CriterionWrapper<DictData>(DictData.class);
		wrapper.eq("fd_id",fdid);
		return super.selectFirst(wrapper);
	}
	
	@Override
	public DictData findOaTemId(String itemName,String groupName) {
		Wrapper<DictData> wrapper = new CriterionWrapper<DictData>(DictData.class);
		wrapper.eq("itemName",itemName);
		wrapper.eq("groupName",groupName);
		wrapper.eq("is_delete", 0);
		wrapper.orderBy("orderby");
		return super.selectFirst(wrapper);
		
	}

	public void save(DictDataDto dto)  throws ClassNotFoundException, IllegalAccessException {
		// TODO Auto-generated method stub
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
	
		
		Wrapper<DictData> wrapper=new CriterionWrapper<DictData>(DictData.class);
		wrapper.eq("fd_id", dto.getFdId());
		DictData model=super.selectFirst(wrapper);
	
		model.setLastAlterId(cUserid);
		model.setLastAlterTime(doDate);
		String remark=dto.getRemark();
		model.setRemark(remark);
		super.updateById(model);
		return;
	}
}
