package com.hwagain.sp.order.mapper;

import com.hwagain.sp.order.entity.ImOrder;
import com.hwagain.sp.order.dto.ImOrderDto;

import java.math.BigInteger;

import org.apache.ibatis.annotations.Param;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;




/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
public interface ImOrderMapper extends BaseMapper<ImOrder> {

	public ImOrderDto findImOrderByFdId(@Param("fdId") BigInteger fdId);
	
	public ImOrderDto findImOrderByOrderNo(@Param("orderNo") String orderNo);
	
	
	
}