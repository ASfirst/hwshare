package com.hwagain.sp.disobey.service;

import java.util.List;

import com.hwagain.sp.disobey.dto.ImDisobeyOverPeriodDto;
import com.hwagain.sp.disobey.dto.ImDisobeyOverPeriodListDto;
import com.hwagain.sp.disobey.dto.ImDisobeyOverPeriodRptDto;
import com.hwagain.sp.disobey.entity.ImDisobeyOverPeriod;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
public interface IImDisobeyOverPeriodService extends IService<ImDisobeyOverPeriod> {
	public List<ImDisobeyOverPeriodListDto> queryOverPeriodCustomer() throws CustomException;
	public List<ImDisobeyOverPeriodListDto> queryOverPeriodFromOrder(String customerId) throws CustomException;
	public ImDisobeyOverPeriodDto saveOneOverPeriod(ImDisobeyOverPeriodDto dto) throws CustomException;
	public List<ImDisobeyOverPeriodDto> saveMoreOverPeriod(List<ImDisobeyOverPeriodDto> list) throws CustomException;
	public List<ImDisobeyOverPeriodListDto> findOverPeriodApplyList() throws CustomException;
	public List<ImDisobeyOverPeriodRptDto> findOverPeriodDetailList(String customerId) throws CustomException;
	public List<ImDisobeyOverPeriodListDto> overPeriodSentToOa();
	public List<ImDisobeyOverPeriodListDto> findOverPeriodDeductList(String strDate) throws CustomException;
	public List<ImDisobeyOverPeriodRptDto> findOverPeriodDeductDetailList(String customerId,String strDate) throws CustomException;
}
