package com.hwagain.sp.customer.mapper;

import com.hwagain.sp.customer.entity.BaseCustomerManagerEdit;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author xionglz
 * @since 2018-11-29
 */
public interface BaseCustomerManagerEditMapper extends BaseMapper<BaseCustomerManagerEdit> {

}