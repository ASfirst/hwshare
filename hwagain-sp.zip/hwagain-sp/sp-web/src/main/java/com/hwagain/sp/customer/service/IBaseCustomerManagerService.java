package com.hwagain.sp.customer.service;

import java.util.List;

import com.hwagain.framework.core.dto.PageVO;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;
import com.hwagain.sp.customer.dto.BaseCustomerManagerDto;
import com.hwagain.sp.customer.entity.BaseCustomerManager;
import com.hwagain.util.PageDto;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-28
 */
public interface IBaseCustomerManagerService extends IService<BaseCustomerManager> {

	public List<BaseCustomerManagerDto> findAll()throws CustomException;

	public BaseCustomerManagerDto editOne(BaseCustomerManagerDto dto)throws CustomException;

	public PageDto<BaseCustomerManagerDto> findAllByPage(PageVO pagevo);
	public BaseCustomerManagerDto editOneOnly(BaseCustomerManagerDto dto);
//	public List<BaseCustomerManagerDto> findFirstData()throws CustomException;

	public BaseCustomerManagerDto addOne(BaseCustomerManagerDto dto);
	
}
