package com.hwagain.sp.price.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.price.service.IImPriceAddConditionEditService;

/**
 * <p>
 * 小幅宽产品加价表 前端控制器
 * </p>
 *
 * @author xionglz
 * @since 2018-11-21
 */
@RestController
@RequestMapping(value="/price/imPriceAddConditionEdit",method={RequestMethod.GET,RequestMethod.POST})
public class ImPriceAddConditionEditController extends BaseController{
	
	@Autowired
	IImPriceAddConditionEditService imPriceAddConditionEditService;
	
}
