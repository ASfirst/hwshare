package com.hwagain.sp.customer.service;

import com.hwagain.sp.customer.entity.BaseCapacityEdit;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-29
 */
public interface IBaseCapacityEditService extends IService<BaseCapacityEdit> {
	
}
