package com.hwagain.sp.deposit.api.impl;

import com.hwagain.sp.deposit.api.IDDepositItemApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 客户当月定金对账明细表 服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
@Service("dDepositItemApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DDepositItemApiImpl implements IDDepositItemApi {
	
}
