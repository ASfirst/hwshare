package com.hwagain.sp.base.service;

import com.hwagain.sp.base.entity.BaseMachine;
import com.hwagain.sp.base.dto.BaseMachineDto;

import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huangdh
 * @since 2019-05-12
 */
public interface IBaseMachineService extends IService<BaseMachine> {

	//新增
	public BaseMachineDto save(BaseMachineDto dto)throws CustomException;
	//修改
	public BaseMachineDto update(BaseMachineDto dto)throws CustomException;
	
	
	//查找所有记录
	public List<BaseMachineDto> findAll()throws CustomException;
	
	
	public List<BaseMachineDto> findAllMachine()throws CustomException;
	
	
	
	
}
