package com.hwagain.sp.product.api.impl;

import com.hwagain.sp.product.api.IProductBaseEditApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-12-24
 */
@Service("productBaseEditApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ProductBaseEditApiImpl implements IProductBaseEditApi {
	
}
