package com.hwagain.sp.disobey.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
@TableName("base_disobey_edit")
public class BaseDisobeyEdit implements Serializable {

    private static final long serialVersionUID = 1L;

	@TableId("fd_id")
	private Long fdId;
    /**
     * 违约事项
     */
	@TableField("disobey_content")
	private String disobeyContent;
    /**
     * 计算单位
     */
	private String unit;
    /**
     * 扣款标准(元)
     */
	@TableField("penalty_standard")
	private BigDecimal penaltyStandard;
    /**
     * 生效时间
     */
	@TableField("start_time")
	private Date startTime;
    /**
     * 失效时间
     */
	@TableField("end_time")
	private Date endTime;
    /**
     * 备注
     */
	private String remark;
    /**
     * 创建人
     */
	@TableField("creater_id")
	private String createrId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
    /**
     * 最后修改人
     */
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;
	private String role;
	private Integer status;
	@TableField("status_text")
	private String statusText;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getDisobeyContent() {
		return disobeyContent;
	}

	public void setDisobeyContent(String disobeyContent) {
		this.disobeyContent = disobeyContent;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public BigDecimal getPenaltyStandard() {
		return penaltyStandard;
	}

	public void setPenaltyStandard(BigDecimal penaltyStandard) {
		this.penaltyStandard = penaltyStandard;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}
	
}
