package com.hwagain.sp.deposit.service.impl;

import com.hwagain.sp.deposit.entity.DDepositStandard;
import com.hwagain.sp.deposit.entity.DDepositStandardEdit;
import com.hwagain.sp.deposit.dto.DDepositStandardDto;
import com.hwagain.sp.deposit.mapper.DDepositStandardMapper;
import com.hwagain.sp.deposit.service.IDDepositStandardService;
import com.hwagain.sp.product.entity.ProductKind;
import com.hwagain.sp.product.service.IProductKindService;
import com.alibaba.dubbo.common.json.JSONObject;
import com.alibaba.fastjson.JSONArray;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.fasterxml.jackson.annotation.JsonTypeInfo.Id;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.core.util.StringUtil;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.WordUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import oracle.net.aso.e;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-05
 */
@Service("dDepositStandardService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DDepositStandardServiceImpl extends ServiceImpl<DDepositStandardMapper, DDepositStandard> implements IDDepositStandardService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	@Autowired IProductKindService productKindService;
	@Autowired DDepositStandardMapper dDepositStandardMapper;
	@Autowired DDepositStandardEditServiceImpl dDepositStandardEditServiceImpl;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(DDepositStandard.class, DDepositStandardDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(DDepositStandardDto.class, DDepositStandard.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	//查询生效产品定金标准
	@Override
	public List<DDepositStandardDto> findAll(){
		//产品类型
//		inputQueryDepo();
		Wrapper<ProductKind> wrapperKind=new CriterionWrapper<ProductKind>(ProductKind.class);
		wrapperKind.eq("platform", "Import");
		List<ProductKind> allKind=productKindService.selectList(wrapperKind);
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
		Wrapper<DDepositStandard> wrapper=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
		wrapper.eq("is_history", 0);
		wrapper.orderBy("kind_no");
		wrapper.orderBy("product_no");
		wrapper.orderBy("start_time");
		List<DDepositStandard> list=super.selectList(wrapper);
//		if(list!=null&&list.size()!=0){
//			for(int i=0;i<list.size();i++){
//				SimpleDateFormat simpleDateFormat = new SimpleDateFormat( "yyyy-MM-dd");
//				if(list.get(i).getEndTime()!=null){
//					String d=simpleDateFormat.format(list.get(i).getEndTime());
//					Date date1 = null;
//					try {
//						date1 =  simpleDateFormat.parse(d);
//					} catch (ParseException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//					Calendar c = Calendar.getInstance();
//					c.setTime(new Date());
//					c.add(Calendar.DAY_OF_MONTH, -1);
//					Date yesterday = c.getTime();
////					System.err.println(yesterday);
//					if(date1.before(yesterday)){
//					   DDepositStandard depo=new DDepositStandard();
//					   depo.setFdId(list.get(i).getFdId());
//					   depo.setIsHistory(1);
//					   depo.setLastAlterTime(doDate);
//					   depo.setLastAlterId(cUserid);
//					   super.updateById(depo);
//					}else{
//					   DDepositStandard depo=new DDepositStandard();
//					   depo.setFdId(list.get(i).getFdId());
//					   depo.setIsHistory(0);
//					   depo.setLastAlterTime(doDate);
//					   depo.setLastAlterId(cUserid);
//					   super.updateById(depo);
//					}
//				}
//			}		
//		}
//		updateBBase();
//		Wrapper<DDepositStandard> wrapper2=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
//		wrapper2.eq("is_history", 0);
//		wrapper2.orderBy("kind_no");
//		wrapper2.orderBy("start_time");
//		List<DDepositStandard> list2=super.selectList(wrapper2);
//		if(list2!=null&&list2.size()!=0){
//			for(int i=0;i<list2.size();i++){
//				for(int j=0;j<allKind.size();j++){
//					if(list2.get(i).getKindNo().equals(allKind.get(j).getKindNo())){
//						list2.get(i).setKindNo(allKind.get(j).getName());
//					}
//				}
//			}
//		}
		return entityToDtoMapper.mapAsList(list, DDepositStandardDto.class);
	}
	//查询所有历史记录
	@Override
	public List<DDepositStandardDto> findHistoryDeposit(){
		//产品类型
		Wrapper<ProductKind> wrapperKind=new CriterionWrapper<ProductKind>(ProductKind.class);
		wrapperKind.eq("platform", "Import");
		List<ProductKind> allKind=productKindService.selectList(wrapperKind);
		Wrapper<DDepositStandard> wrapper=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
		wrapper.eq("is_history", 1);
		wrapper.orderBy("kind_no");
		List<DDepositStandard> list=super.selectList(wrapper);
		if(list!=null&&list.size()!=0){
			for(int i=0;i<list.size();i++){
				for(int j=0;j<allKind.size();j++){
					if(list.get(i).getKindNo().equals(allKind.get(j).getKindNo())){
						list.get(i).setKindNo(allKind.get(j).getName());
					}
				}
			}
		}
		return entityToDtoMapper.mapAsList(list,DDepositStandardDto.class);
		
	}
	//增加一条定金标准
	@Override
	public DDepositStandardDto addOne(DDepositStandardDto ddto){
		Wrapper<DDepositStandard> wrapper=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
		wrapper.eq("kind_no", ddto.getKindNo());
		wrapper.eq("product_no", ddto.getProductNo());
		wrapper.eq("specification", ddto.getSpecification());
		DDepositStandard list=super.selectFirst(wrapper);
		Assert.isNull(list, "已存在产品型号为：["+ddto.getKindNo()+"],单幅产品编号为：["+ddto.getProductNo()+"],规格为：["+ddto.getSpecification()+"]的记录");
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
		DDepositStandard depo=new DDepositStandard();
		depo.setFdId(Long.valueOf(IdWorker.getId()));
		depo.setKindNo(ddto.getKindNo());
		depo.setProductNo(ddto.getProductNo());
		depo.setSpecification(ddto.getSpecification());
		depo.setDeposit(ddto.getDeposit());
		depo.setStartTime(ddto.getStartTime());
		depo.setEndTime(ddto.getEndTime());
		depo.setCreaterId(cUserid);
		depo.setCreateTime(doDate);
		depo.setIsHistory(0);
		super.insert(depo);
		updateBBase();
		return entityToDtoMapper.map(super.selectById(depo.getFdId()), DDepositStandardDto.class);
		
	}
	
	//更新一条记录
	@Override
	public DDepositStandardDto updateOne(Long fdId,String specification,BigDecimal deposit){
		Assert.notNull(fdId, "fdId 不能为空");
		Wrapper<DDepositStandard> wrapper=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
		wrapper.eq("fd_id", fdId);
		DDepositStandard list=super.selectFirst(wrapper);
		Wrapper<DDepositStandard> wrapper1=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
		wrapper1.eq("kind_no", list.getKindNo());
		wrapper1.eq("product_no", list.getProductNo());
		wrapper1.eq("specification", specification);
		wrapper1.eq("deposit", deposit);
		wrapper1.notIn("fd_id", fdId);
		DDepositStandard list1=super.selectFirst(wrapper1);
		Assert.isNull(list1, "已存在产品型号为：["+list.getKindNo()+"],单幅产品编号为：["+specification+"],规格为：["+list.getSpecification()+"],定金标准为：["+deposit+"]的记录");
		DDepositStandard depo=new DDepositStandard();
		depo.setFdId(fdId);
		depo.setSpecification(specification);
		depo.setDeposit(deposit);
		super.updateById(depo);
		updateBBase();
		return entityToDtoMapper.map(super.selectById(fdId), DDepositStandardDto.class);
		
	}
	//更新1条记录
	@Override
	public DDepositStandardDto updateDeposits(DDepositStandardDto ddto){
//		System.err.println("1"+ddto.getProductNo());
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
		Wrapper<DDepositStandard> wrapper=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
		wrapper.eq("kind_no", ddto.getKindNo());
		wrapper.eq("product_no", ddto.getProductNo());
		wrapper.eq("specification", ddto.getSpecification());
		wrapper.eq("is_history", 0);
		DDepositStandard list=super.selectFirst(wrapper);
		
		Assert.notNull(list, "不存在存在产品型号为：["+ddto.getKindNo()+"],单幅产品编号为：["+ddto.getSpecification()+"],规格为：["+ddto.getSpecification()+"]的记录");		
		if(list!=null&&list.getStartTime()==null){
			DDepositStandard depo=new DDepositStandard();
			depo.setFdId( list.getFdId());
//			depo.setSpecification(ddto.getSpecification());
			depo.setDeposit(ddto.getDeposit());
			depo.setStartTime(ddto.getStartTime());
			depo.setEndTime(ddto.getEndTime());
			super.updateById(depo);
		}
		if(list!=null&&list.getStartTime()!=null){
			DDepositStandard depo=new DDepositStandard();
			depo.setFdId(Long.valueOf(IdWorker.getId()));
			depo.setKindNo(list.getKindNo());
			depo.setProductNo(list.getProductNo());
			depo.setSpecification(ddto.getSpecification());
			depo.setDeposit(ddto.getDeposit());
			depo.setStartTime(ddto.getStartTime());
			depo.setEndTime(ddto.getEndTime());
			depo.setIsHistory(0);
			depo.setCreaterId(cUserid);
			depo.setCreateTime(doDate);
			super.insert(depo);
			DDepositStandard depo1=new DDepositStandard();
			depo1.setFdId(list.getFdId());
			depo1.setEndTime(ddto.getStartTime());
			super.updateById(depo1);
		}
		updateBBase();
		return entityToDtoMapper.map(super.selectById(ddto.getFdId()), DDepositStandardDto.class);
		
	}
	//更新非常规品单幅产品编号
	@Override
	public List<DDepositStandardDto> updateBBase(){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
		Wrapper<DDepositStandard> wrapper=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
		wrapper.eq("is_history", 0);
		wrapper.eq("kind_no", "a");
		wrapper.orderBy("product_no");
		List<DDepositStandard> listA=super.selectList(wrapper);
		ArrayList<String> productNo1=new ArrayList<>();
		String productNo2="";
		if(listA!=null){
			for(int i=0;i<listA.size();i++){
				productNo1.add(listA.get(i).getProductNo());
			}
		}
		productNo2=StringUtil.join(productNo1, "或");
//		System.err.println(productNo2);
		Wrapper<DDepositStandard> wrpper1=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
		wrpper1.eq("kind_no", "b");
		List<DDepositStandard> listB=super.selectList(wrpper1);
		if(listB!=null){
			for(int j=0;j<listB.size();j++){
				DDepositStandard depo=new DDepositStandard();
				depo.setFdId(listB.get(j).getFdId());
				depo.setSpecification("");
				depo.setProductNo("≠"+productNo2);
				depo.setLastAlterId(cUserid);
				depo.setLastAlterTime(doDate);
				super.updateById(depo);
			}
		}
		return null;
	}
	
	//产品定金标准是不在执行周期内
	@Override
	public List<DDepositStandardDto> isHistory(){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
		Wrapper<DDepositStandard> wrapper=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
		wrapper.eq("kind_no", "a");
		wrapper.orderBy("product_no");
		List<DDepositStandard> listA=super.selectList(wrapper);
		return null;
		
	}
	
	//初始化
	@Override
	public List<DDepositStandardDto> inputQueryDepo(){
//		BigDecimal de;
		List<DDepositStandard> list=dDepositStandardMapper.inputQueryDepo();
		List<DDepositStandard> listA=new ArrayList<>();
		if(list!=null&&list.size()!=0){
			for(int i=0;i<list.size();i++){
				DDepositStandard dto=list.get(i);
				Wrapper<DDepositStandard> wrapper=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
//				System.err.println(dto.getKindNo());
				if(dto.getKindNo().equals("a")){
					wrapper.eq("kind_no", dto.getKindNo());
					wrapper.eq("product_no", dto.getProductNo());
					wrapper.eq("specification", dto.getSpecification());
					wrapper.eq("is_history", 0);
					listA.add(dto);
				}
//				if(dto.getKindNo().equals("b")){
//					System.err.println(dto.getKindNo());
//					wrapper.eq("kind_no", dto.getKindNo());
//					wrapper.eq("specification", dto.getSpecification());
//					wrapper.eq("is_history", 0);
//				}
//				if(dto.getKindNo().equals("c")){
//					wrapper.eq("kind_no", dto.getKindNo());
//					wrapper.eq("product_no","全部");
//					wrapper.eq("specification", dto.getSpecification());
//					wrapper.eq("is_history", 0);
//				}
//				DDepositStandard listDepo=super.selectFirst(wrapper);
//				if(listDepo==null){
//					DDepositStandard depo=new DDepositStandard();
//					depo.setFdId(Long.valueOf(IdWorker.getId()));
//					depo.setKindNo(dto.getKindNo());
//					depo.setProductNo(dto.getProductNo());
//					depo.setStartTime(new Date());
//					depo.setDeposit(new BigDecimal(0));
//					depo.setSpecification(dto.getSpecification());
//					depo.setCreaterId(dto.getCreaterId());
//					depo.setCreateTime(dto.getCreateTime());
//					depo.setIsHistory(0);
//					super.insert(depo);
//					for(int e=1;e<3;e++){
//						String edit=String.valueOf(e);
//						DDepositStandardEdit depoE=new DDepositStandardEdit();
//						depoE.setFdId(Long.valueOf(IdWorker.getId()));
//						depoE.setKindNo(dto.getKindNo());
//						depoE.setProductNo(dto.getProductNo());
//						depoE.setDeposit(new BigDecimal(0));
//						depoE.setStartTime(new Date());
//						depoE.setSpecification(dto.getSpecification());
//						depoE.setCreaterId(dto.getCreaterId());
//						depoE.setCreateTime(dto.getCreateTime());
//						depoE.setIsHistory(0);
//						depoE.setEdit(edit);
//						depoE.setStatus(0);
//						dDepositStandardEditServiceImpl.insert(depoE);
//					}
//				}
			}
		}
		return entityToDtoMapper.mapAsList(listA, DDepositStandardDto.class);
		
	}
	
	//双人录入匹配成功，更新一条
	@Override
	public DDepositStandardDto updateOneEdit(DDepositStandardDto dto){
//		System.err.println(dto.getIsHistory());
		Wrapper<DDepositStandard> wrapper=new CriterionWrapper<DDepositStandard>(DDepositStandard.class);
		wrapper.eq("kind_no", dto.getKindNo());
		wrapper.eq("product_no", dto.getProductNo());
		wrapper.eq("is_history", 0);
		DDepositStandard list=super.selectFirst(wrapper);
//		Assert.notNull(list, "不存在存在产品型号为：["+dto.getKindNo()+"],单幅产品编号为：["+dto.getSpecification()+"]的记录");		
		if(list!=null){
			list.setDeposit(dto.getDeposit());
			list.setStartTime(dto.getStartTime());
			list.setLastAlterId(dto.getCreaterId());
			list.setIsHistory(dto.getIsHistory());
			list.setLastAlterTime(new Date());
			super.updateById(list);
		}else{
			dto.setFdId(Long.valueOf(IdWorker.getId()));
//			dto.setCreaterId(createrId);
//			dto.setIsHistory(0);
			super.insert(dtoToEntityMapper.map(dto, DDepositStandard.class));
		}
		updateBBase();
		return dto;
		
	}
	
	//求订单非常规品每吨要交多少订金？
	@Override
	public BigDecimal findOrderDepositByKindNo(String kindNo)
	{
		BigDecimal depositMoney=null;
		DDepositStandard model=dDepositStandardMapper.findOrderDepositByKindNo(kindNo);
		if (model!=null)
		{
			depositMoney=model.getDeposit();			
		}
		return depositMoney;
	}
	
	
	
	
	

}
