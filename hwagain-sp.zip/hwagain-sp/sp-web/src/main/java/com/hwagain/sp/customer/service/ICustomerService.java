package com.hwagain.sp.customer.service;

import com.hwagain.sp.customer.dto.CustomerBalanceDto;
import com.hwagain.sp.customer.dto.CustomerDto;
import com.hwagain.sp.customer.entity.Customer;
import com.hwagain.util.PageDto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.hwagain.framework.core.dto.PageVO;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author hanj
 * @since 2018-10-11
 */
public interface ICustomerService extends IService<Customer> {

//	public Customer findById(Integer id)throws CustomException;

	public List<CustomerDto> findCooperatingCustomer()throws CustomException;

	public List<CustomerDto> findByPage(String custName,String province,String city,String county,String custTypeName)throws CustomException;

	public CustomerDto findOne(Long fdId)throws CustomException;
	
	public boolean createDepositmove(int SourceID, String BillNo,Date sDate, String sCustName, BigDecimal DepositAmountTotal, String sCooperationCustomerName)throws CustomException;
	
	public List<CustomerBalanceDto> getGoodsBanlanceByCust(String custName,Integer year,Integer month)throws CustomException;

	public List<CustomerBalanceDto> getDepositBanlanceByCust(String custName, Integer year, Integer month)
			throws CustomException;

	public Customer findByCustName(String custName)throws CustomException;

	public List<CustomerDto> customerByUserId()throws CustomException;

	public PageDto<CustomerDto> findByPage(CustomerDto dto, PageVO pageVO);
	
}
