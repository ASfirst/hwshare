package com.hwagain.sp.price.service.impl;

import com.hwagain.sp.price.entity.ImPriceDifference;
import com.hwagain.sp.price.dto.ImPriceDifferenceDto;
import com.hwagain.sp.price.mapper.ImPriceDifferenceMapper;
import com.hwagain.sp.price.service.IImPriceDifferenceService;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 * 副品及承兑汇票结算差价表 服务实现类
 * </p>
 *
 * @author 
 * @since 2018-11-16
 */
@Service("imPriceDifferenceService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImPriceDifferenceServiceImpl extends ServiceImpl<ImPriceDifferenceMapper, ImPriceDifference> implements IImPriceDifferenceService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImPriceDifference.class, ImPriceDifferenceDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImPriceDifferenceDto.class, ImPriceDifference.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	//初始数据列表
	@Override
	public List<ImPriceDifferenceDto> findAll(){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
		Wrapper<ImPriceDifference> wrapper=new CriterionWrapper<ImPriceDifference>(ImPriceDifference.class);
		wrapper.eq("status", 1);
		List<ImPriceDifference> list=super.selectList(wrapper);
		if(list!=null&&list.size()!=0){
			for(int i=0;i<list.size();i++){
				SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
				ImPriceDifference impd=new ImPriceDifference();
				if(list.get(i).getEndDate()!=null){
					String d=simpleDateFormat.format(list.get(i).getEndDate());
					Date date1=null;
					try{
						date1=simpleDateFormat.parse(d);
					}catch(ParseException e){
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					Calendar c=Calendar.getInstance();
					c.setTime(new Date());
					c.add(Calendar.DAY_OF_MONTH, -1);
					Date yesterday=c.getTime();
					if(date1.before(yesterday)){
						impd.setFdId(list.get(i).getFdId());
						impd.setStatus(2);
						impd.setLastAlterId(cUserid);
						impd.setLastAlterTime(doDate);
						super.updateById(impd);
					}
				}
			}
		}
		Wrapper<ImPriceDifference> wrapperA=new CriterionWrapper<ImPriceDifference>(ImPriceDifference.class);
		wrapperA.eq("status", 1);
		List<ImPriceDifference> listA=super.selectList(wrapperA);
		return entityToDtoMapper.mapAsList(listA, ImPriceDifferenceDto.class);
		
	}
	//新增一条
	@Override
	public ImPriceDifferenceDto addOne(String itemName){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
		Assert.notBlank(itemName, "项目名称不能为空");
		Wrapper<ImPriceDifference> wrapper=new CriterionWrapper<ImPriceDifference>(ImPriceDifference.class);
		wrapper.eq("item_name", itemName);
//		wrapper.eq("status", 1);
		ImPriceDifference list=super.selectFirst(wrapper);
		ImPriceDifference impd=new ImPriceDifference();
		if(list!=null){
			Assert.throwException("已存在项目名称为："+itemName+"的记录");
		}else{
			
			impd.setFdId(Long.valueOf(IdWorker.getId()));
			impd.setItemName(itemName);
			impd.setIsPolicy(true);
			impd.setStatus(1);
			impd.setCreaterId(cUserid);
			impd.setCreateTime(doDate);
			super.insert(impd);
		}
		return entityToDtoMapper.map(super.selectById(impd.getFdId()), ImPriceDifferenceDto.class);
	}
	//调整更新一条
	@Override
	public ImPriceDifferenceDto updateOne(ImPriceDifferenceDto dto){
//		System.err.println("==="+dto.getIsPolicyText());
//		System.err.println(dto.isIsPolicy());
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
		Wrapper<ImPriceDifference> wrapper=new CriterionWrapper<ImPriceDifference>(ImPriceDifference.class);
		wrapper.eq("item_id", dto.getItemId());
		wrapper.eq("status", 1);
		ImPriceDifference list=super.selectFirst(wrapper);
		if(list!=null){
			dto.setFdId(list.getFdId());
			dto.setStatus(2);
			super.updateById(dtoToEntityMapper.map(dto, ImPriceDifference.class));
		}		
		dto.setFdId(Long.valueOf(IdWorker.getId()));
		dto.setStatus(1);
		super.insert(dtoToEntityMapper.map(dto, ImPriceDifference.class));
		return entityToDtoMapper.map(super.selectById(dto.getFdId()), ImPriceDifferenceDto.class);
		
	}
	//查询历史差价
	@Override
	public List<ImPriceDifferenceDto> findHistoryImPrice(String ItemName){
//		System.err.println(ItemName);
		Wrapper<ImPriceDifference> wrapper=new CriterionWrapper<ImPriceDifference>(ImPriceDifference.class);
		wrapper.eq("status", 2);
		wrapper.eq("item_name", ItemName);
		List<ImPriceDifference> list=super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, ImPriceDifferenceDto.class);
	}
	
	//查询一条
	@Override
	public List<ImPriceDifferenceDto> findOne(Long fdId){
		Wrapper<ImPriceDifference> wrapper=new CriterionWrapper<ImPriceDifference>(ImPriceDifference.class);
		wrapper.eq("fd_id", fdId);
		List<ImPriceDifference> list=super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, ImPriceDifferenceDto.class);
		
	}
}
