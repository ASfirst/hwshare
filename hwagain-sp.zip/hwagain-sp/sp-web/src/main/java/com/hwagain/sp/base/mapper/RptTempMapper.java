package com.hwagain.sp.base.mapper;

import java.util.List;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;
import com.hwagain.sp.base.entity.RptTempData;

public interface RptTempMapper extends BaseMapper<RptTempData> {

	public List<RptTempData> queryTempData(String sql);
}
