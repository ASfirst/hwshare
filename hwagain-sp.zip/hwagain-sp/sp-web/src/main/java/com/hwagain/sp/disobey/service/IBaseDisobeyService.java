package com.hwagain.sp.disobey.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.hwagain.sp.disobey.dto.BaseDisobeyDto;
import com.hwagain.sp.disobey.entity.BaseDisobey;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
public interface IBaseDisobeyService extends IService<BaseDisobey> {
	public List<BaseDisobey> findAll() throws CustomException;
	public Boolean deleteByIds(String ids) throws CustomException;
	public Boolean updateStatus(String id,String statusText) throws CustomException;
	public BigDecimal getPenaltyStandard(Date shipmentDate) throws CustomException;
	public BaseDisobeyDto updateOne(BaseDisobeyDto dto) throws CustomException;
	public BaseDisobeyDto getPenaltyStandard() throws CustomException;
}
