package com.hwagain.sp.policy.service.impl;

import com.hwagain.sp.policy.entity.PoDiscount;
import com.hwagain.sp.base.entity.DictData;
import com.hwagain.sp.base.service.IDictDataService;
import com.hwagain.sp.customer.dto.CustomerDto;
import com.hwagain.sp.customer.service.ICustomerService;
import com.hwagain.sp.policy.dto.PoDiscountDto;
import com.hwagain.sp.policy.mapper.PoDiscountMapper;
import com.hwagain.sp.policy.service.IPoDiscountService;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;
import com.hwagain.framework.util.judge.IsNotNullUtil;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author linhl
 * @since 2018-11-02
 */
@Service("poDiscountService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoDiscountServiceImpl extends ServiceImpl<PoDiscountMapper, PoDiscount> implements IPoDiscountService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	
	@Autowired
	IDictDataService dictDataService;
	
	@Autowired
	ICustomerService customerService;
	
	@Autowired
	PoDiscountMapper poDiscountMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(PoDiscount.class, PoDiscountDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(PoDiscountDto.class, PoDiscount.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

	@Override
	public PoDiscountDto findoneByfdid(Long fdid) throws CustomException {
		// TODO Auto-generated method stub
		Wrapper<PoDiscount> wrapper=new CriterionWrapper<PoDiscount>(PoDiscount.class);
		wrapper.eq("fd_id", fdid);
		PoDiscount entity=super.selectFirst(wrapper);
		return entityToDtoMapper.map(entity, PoDiscountDto.class);
	}

	

	@Override
	public PoDiscountDto save(PoDiscountDto dto) {
		// TODO Auto-generated method stub
		Date date=dto.getBusinessDate();
		if (date==null) 
		{
			Assert.throwException("日期不允许为空");
		}
		
		long policyID=Long.valueOf(dto.getPoPolicyId());
		Assert.notNull(policyID, "项目不允许为空");
		DictData d=dictDataService.findoneByfdid(policyID);
		if (d==null){Assert.throwException("项目ID不正确！");
		}
		
		long policyMethodId=Long.valueOf(dto.getPolicyMethodId());
		Assert.notNull(policyMethodId, "折扣方式ID不正确！");
		DictData m=dictDataService.findoneByfdid(policyID);
		if (m==null){Assert.throwException("折扣方式ID不正确！");
		}
		
		long customerid=dto.getCustomerId();
		Assert.notNull(customerid, "客户ID不允许为空");
		CustomerDto customerDto=customerService.findOne(Long.valueOf(customerid));
		if (customerDto==null){
			Assert.throwException("客户ID不正确！");
		}
		
		Assert.notNull(dto.getPrice(), "单价不允许为空");
		Assert.notNull(dto.getAmount(), "金额不允许为空");
		
		Date startDate=dto.getStartDate();
		if (startDate==null){
			Assert.throwException("开始日期不能为空");
		}
		
		Date endDate=dto.getEndDate();
		if (endDate==null) {
			Assert.throwException("结束日期不能为空");
		}
		
		if (startDate.getTime() > endDate.getTime()) {
             Assert.throwException("失效日期必需大于生效日期！");
        } 
		
		dto.setFdId(Long.valueOf(IdWorker.getId()));
		String createrId = UserUtils.getUserId();
		dto.setCreaterId(createrId);
		Date createTime = new Date();
		dto.setCreateTime(createTime);
		
		if (super.insert(dtoToEntityMapper.map(dto, PoDiscount.class)))
		{
		   	return dto;
		}
		else
		{
		 	return null;
		}
	}

	@Override
	public PoDiscountDto update(PoDiscountDto dto) {
		// TODO Auto-generated method stub
		PoDiscount entity=new PoDiscount();
		entity=super.selectById(dto.getFdId());
		
		if (entity==null) {
			Assert.throwException("查询不到指定ID的单据，不允许更改！");
		}
		
		BigDecimal commitAmount=entity.getCommitAmount();
		if (commitAmount.compareTo(new BigDecimal(0))==1) {
			 Assert.throwException("已经有关联单据，不允许更改！");
		}
		
		Date date=dto.getBusinessDate();
		if (date==null) 
		{
			Assert.throwException("日期不允许为空");
		}
		
		long policyID=Long.valueOf(dto.getPoPolicyId());
		Assert.notNull(policyID, "项目不允许为空");
		DictData d=dictDataService.findoneByfdid(policyID);
		if (d==null){Assert.throwException("项目ID不正确！");
		}
		
		long customerid=dto.getCustomerId();
		Assert.notNull(customerid, "客户ID不允许为空");
		CustomerDto customerDto=customerService.findOne(Long.valueOf(customerid));
		if (customerDto==null){
			Assert.throwException("客户ID不正确！");
		}
		
		Assert.notNull(dto.getPrice(), "单价不允许为空");
		Assert.notNull(dto.getAmount(), "金额不允许为空");
		
		Date startDate=dto.getStartDate();
		if (startDate==null){
			Assert.throwException("开始日期不能为空");
		}
		
		Date endDate=dto.getEndDate();
		if (endDate==null) {
			Assert.throwException("结束日期不能为空");
		}
		
		if (startDate.getTime() > endDate.getTime()) {
             Assert.throwException("失效日期必需大于生效日期！");
        } 
		
		
		String createrId = UserUtils.getUserId();
		dto.setCreaterId(createrId);
		Date createTime = new Date();
		dto.setCreateTime(createTime);
		if (super.insertOrUpdate(dtoToEntityMapper.map(dto, PoDiscount.class)))
		{
		   	return dto;
		}
		else
		{
		 	return null;
		}
	}

	@Override
	public Boolean deleteByIds(String ids) {
		// TODO Auto-generated method stub
		Assert.notBlank(ids, "请选择需要删除的纪录");
		String[] id = ids.split(",");
		Assert.isTrue(null != id && id.length > 0, "请选择需要删除的纪录");
		
		int i = 1;
		for (String s : id) {
			PoDiscount p = super.selectById(s);
			
			if (p.getStatus() == 1)
				Assert.throwException("第"+String.valueOf(i)+"记录已经审核,不允许删除！");
			
			BigDecimal commitamount=IsNotNullUtil.bigDecimalIsNotNull(p.getCommitAmount());
			if (commitamount.compareTo(new BigDecimal(0))==1)
				Assert.throwException("第"+String.valueOf(i)+"记录已经有关联单据,不允许删除！");

			i++;
		}
		return super.deleteBatchIds(Arrays.asList(id));
	}


	@Override
	public List<PoDiscount> findAll(Integer customerID, Date startDate, Date endDate) {
		// TODO Auto-generated method stub
		Wrapper<PoDiscount> wrapper=new CriterionWrapper<>(PoDiscount.class);
		if (customerID!=null)
		{
			wrapper.eq("CustomerID", customerID);
		}
		
		if (startDate!=null)
		{
			wrapper.gt("FDate", startDate);
		}
		
		if (endDate!=null)
		{
			wrapper.lt("FDate", endDate);
		}
		List<PoDiscount> list=super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, PoDiscount.class);
	}
	
	@Override
	public List<PoDiscountDto> queryList(Long customerId, String startDate, String endDate) {
		List<PoDiscountDto> list = poDiscountMapper.queryPoDiscountList(customerId, startDate, endDate);
		return list;
	}
}
