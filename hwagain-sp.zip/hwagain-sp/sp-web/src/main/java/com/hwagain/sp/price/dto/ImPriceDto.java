package com.hwagain.sp.price.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
public class ImPriceDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	private Long fdId;
    /**
     * 品类
     */
	private String classNo;
    /**
     * 颜色
     */
	private String color;
    /**
     * 产品类型
     */
	private String kindNo;
    /**
     * 定价单位
     */
	private String unit;
    /**
     * 定量
     */
	private String ration;
    /**
     * 最小定量
     */
	private BigDecimal minRation;
    /**
     * 最大定量
     */
	private BigDecimal maxRation;
    /**
     * 层数
     */
	private String layers;
    /**
     * 单幅幅宽
     */
	private String width;
    /**
     * 最小单幅幅宽
     */
	private BigDecimal minWidth;
    /**
     * 最大单幅幅宽
     */
	private BigDecimal maxWidth;
    /**
     * 总幅宽
     */
	private String totalWidth;
    /**
     * 最小总幅宽
     */
	private BigDecimal minTotalWidth;
    /**
     * 最大总幅宽
     */
	private BigDecimal maxTotalWidth;
    /**
     * 直径
     */
	private String diameter;
    /**
     * 最小直径
     */
	private BigDecimal minDiameter;
    /**
     * 最大直径
     */
	private BigDecimal maxDiameter;
    /**
     * 起趋率
     */
	private BigDecimal wrinkleRate;
    /**
     * 增加价格
     */
	private BigDecimal addPrice;
    /**
     * 执行价格
     */
	private BigDecimal price;
    /**
     * 开始时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date startDate;
    /**
     * 结束时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date endDate;
    /**
     * 是否享受政策
     */
	private Integer isPolicy;
    /**
     * 备注
     */
	private String remark;
    /**
     * 状态 (10：未提交(初始状态):可以选择/删除/修改保存/提交
     11：已提交到申请人工作台(或退回开始节点):可以选择/删除/修改保存
     20：审核中(申请人已经提交出去):不可操作
     30：已审批
     40：已过期)
     */
	private Integer status;
    /**
     * OACode
     */
	private String OACode;
    /**
     * 是否历史记录
     */
	private Integer isHistory;
    /**
     * 调整记录id
     */
	private Long adjustId;
    /**
     * 批次id
     */
	private Long batchId;
    /**
     * product_base id
     */
	private Long prodBaseId;
    /**
     * 是否删除
     */
	private Integer isDelete;
    /**
     * 创建人
     */
	private String createrId;
    /**
     * 创建时间
     */
	private Date createTime;
    /**
     * 最后修改人
     */
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getKindNo() {
		return kindNo;
	}

	public void setKindNo(String kindNo) {
		this.kindNo = kindNo;
	}

	public String getUnit() {
		return unit;
	}

	public void setUnit(String unit) {
		this.unit = unit;
	}

	public String getRation() {
		return ration;
	}

	public void setRation(String ration) {
		this.ration = ration;
	}

	public BigDecimal getMinRation() {
		return minRation;
	}

	public void setMinRation(BigDecimal minRation) {
		this.minRation = minRation;
	}

	public BigDecimal getMaxRation() {
		return maxRation;
	}

	public void setMaxRation(BigDecimal maxRation) {
		this.maxRation = maxRation;
	}

	public String getLayers() {
		return layers;
	}

	public void setLayers(String layers) {
		this.layers = layers;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public BigDecimal getMinWidth() {
		return minWidth;
	}

	public void setMinWidth(BigDecimal minWidth) {
		this.minWidth = minWidth;
	}

	public BigDecimal getMaxWidth() {
		return maxWidth;
	}

	public void setMaxWidth(BigDecimal maxWidth) {
		this.maxWidth = maxWidth;
	}

	public String getTotalWidth() {
		return totalWidth;
	}

	public void setTotalWidth(String totalWidth) {
		this.totalWidth = totalWidth;
	}

	public BigDecimal getMinTotalWidth() {
		return minTotalWidth;
	}

	public void setMinTotalWidth(BigDecimal minTotalWidth) {
		this.minTotalWidth = minTotalWidth;
	}

	public BigDecimal getMaxTotalWidth() {
		return maxTotalWidth;
	}

	public void setMaxTotalWidth(BigDecimal maxTotalWidth) {
		this.maxTotalWidth = maxTotalWidth;
	}

	public String getDiameter() {
		return diameter;
	}

	public void setDiameter(String diameter) {
		this.diameter = diameter;
	}

	public BigDecimal getMinDiameter() {
		return minDiameter;
	}

	public void setMinDiameter(BigDecimal minDiameter) {
		this.minDiameter = minDiameter;
	}

	public BigDecimal getMaxDiameter() {
		return maxDiameter;
	}

	public void setMaxDiameter(BigDecimal maxDiameter) {
		this.maxDiameter = maxDiameter;
	}

	public BigDecimal getWrinkleRate() {
		return wrinkleRate;
	}

	public void setWrinkleRate(BigDecimal wrinkleRate) {
		this.wrinkleRate = wrinkleRate;
	}

	public BigDecimal getAddPrice() {
		return addPrice;
	}

	public void setAddPrice(BigDecimal addPrice) {
		this.addPrice = addPrice;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getIsPolicy() {
		return isPolicy;
	}

	public void setIsPolicy(Integer isPolicy) {
		this.isPolicy = isPolicy;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getOACode() {
		return OACode;
	}

	public void setOACode(String OACode) {
		this.OACode = OACode;
	}

	public Integer getIsHistory() {
		return isHistory;
	}

	public void setIsHistory(Integer isHistory) {
		this.isHistory = isHistory;
	}

	public Long getAdjustId() {
		return adjustId;
	}

	public void setAdjustId(Long adjustId) {
		this.adjustId = adjustId;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public Long getProdBaseId() {
		return prodBaseId;
	}

	public void setProdBaseId(Long prodBaseId) {
		this.prodBaseId = prodBaseId;
	}

	public Integer getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
