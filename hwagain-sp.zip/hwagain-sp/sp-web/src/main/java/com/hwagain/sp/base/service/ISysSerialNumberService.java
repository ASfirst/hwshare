package com.hwagain.sp.base.service;

import com.hwagain.sp.base.entity.SysSerialNumber;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author guoym
 * @since 2018-11-05
 */
public interface ISysSerialNumberService extends IService<SysSerialNumber> {

 public	String getSerialNumber(String prefixChar, String remark);
	
}
