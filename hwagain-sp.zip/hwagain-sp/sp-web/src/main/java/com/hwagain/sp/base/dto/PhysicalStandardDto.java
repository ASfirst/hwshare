package com.hwagain.sp.base.dto;

import java.math.BigDecimal;
import java.util.Date;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author linhl
 * @since 2018-11-05
 */
public class PhysicalStandardDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
	private Long id;
    /**
     * 物料指标编号
     */
	private String physicalNo;
    /**
     * 定量
     */
	private BigDecimal ration;
    /**
     * 层数
     */
	private Integer layer;
    /**
     * 松紧度
     */
	private BigDecimal looseTighten;
    /**
     * 横向抗张强度
     */
	private BigDecimal horizontalResist;
    /**
     * 纵向抗张强度
     */
	private BigDecimal verticalResist;
    /**
     * 手感值
     */
	private BigDecimal handFeelValue;
    /**
     * 纤维柔软度
     */
	private BigDecimal fibreSoft;
    /**
     * 粗糙度
     */
	private BigDecimal crassitude;
    /**
     * 硬挺度
     */
	private BigDecimal rigidity;
    /**
     * 横向吸液高度
     */
	private BigDecimal horizontalSuck;
    /**
     * 白度
     */
	private BigDecimal white;
    /**
     * 单包片膜厚度
     */
	private BigDecimal unitFilm;
    /**
     * 中包包膜厚度
     */
	private BigDecimal middleFilm;
    /**
     * 纸箱层数
     */
	private Integer boxLayer;
    /**
     * 纸箱厚度
     */
	private BigDecimal boxDeep;
    /**
     * 备注
     */
	private String remarks;
    /**
     * 创建人
     */
	private String createdBy;
    /**
     * 创建时间
     */
	private Date createdDate;
    /**
     * 修改人
     */
	private String updatedBy;
    /**
     * 修改时间
     */
	private Date updatedDate;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPhysicalNo() {
		return physicalNo;
	}

	public void setPhysicalNo(String physicalNo) {
		this.physicalNo = physicalNo;
	}

	public BigDecimal getRation() {
		return ration;
	}

	public void setRation(BigDecimal ration) {
		this.ration = ration;
	}

	public Integer getLayer() {
		return layer;
	}

	public void setLayer(Integer layer) {
		this.layer = layer;
	}

	public BigDecimal getLooseTighten() {
		return looseTighten;
	}

	public void setLooseTighten(BigDecimal looseTighten) {
		this.looseTighten = looseTighten;
	}

	public BigDecimal getHorizontalResist() {
		return horizontalResist;
	}

	public void setHorizontalResist(BigDecimal horizontalResist) {
		this.horizontalResist = horizontalResist;
	}

	public BigDecimal getVerticalResist() {
		return verticalResist;
	}

	public void setVerticalResist(BigDecimal verticalResist) {
		this.verticalResist = verticalResist;
	}

	public BigDecimal getHandFeelValue() {
		return handFeelValue;
	}

	public void setHandFeelValue(BigDecimal handFeelValue) {
		this.handFeelValue = handFeelValue;
	}

	public BigDecimal getFibreSoft() {
		return fibreSoft;
	}

	public void setFibreSoft(BigDecimal fibreSoft) {
		this.fibreSoft = fibreSoft;
	}

	public BigDecimal getCrassitude() {
		return crassitude;
	}

	public void setCrassitude(BigDecimal crassitude) {
		this.crassitude = crassitude;
	}

	public BigDecimal getRigidity() {
		return rigidity;
	}

	public void setRigidity(BigDecimal rigidity) {
		this.rigidity = rigidity;
	}

	public BigDecimal getHorizontalSuck() {
		return horizontalSuck;
	}

	public void setHorizontalSuck(BigDecimal horizontalSuck) {
		this.horizontalSuck = horizontalSuck;
	}

	public BigDecimal getWhite() {
		return white;
	}

	public void setWhite(BigDecimal white) {
		this.white = white;
	}

	public BigDecimal getUnitFilm() {
		return unitFilm;
	}

	public void setUnitFilm(BigDecimal unitFilm) {
		this.unitFilm = unitFilm;
	}

	public BigDecimal getMiddleFilm() {
		return middleFilm;
	}

	public void setMiddleFilm(BigDecimal middleFilm) {
		this.middleFilm = middleFilm;
	}

	public Integer getBoxLayer() {
		return boxLayer;
	}

	public void setBoxLayer(Integer boxLayer) {
		this.boxLayer = boxLayer;
	}

	public BigDecimal getBoxDeep() {
		return boxDeep;
	}

	public void setBoxDeep(BigDecimal boxDeep) {
		this.boxDeep = boxDeep;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

}
