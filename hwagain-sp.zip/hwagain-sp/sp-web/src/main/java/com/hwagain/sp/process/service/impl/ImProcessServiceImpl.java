package com.hwagain.sp.process.service.impl;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.hwagain.sp.base.entity.RptTempData;
import com.hwagain.sp.process.entity.ImProcess;
import com.hwagain.sp.process.entity.ImProcessBatchProduct;
import com.hwagain.sp.process.entity.ImProcessPrice;
import com.hwagain.sp.process.dto.ImProcessBatchProductDto;
import com.hwagain.sp.process.dto.ImProcessDto;
import com.hwagain.sp.process.dto.ImProcessPriceDto;
import com.hwagain.sp.process.dto.ImProcessPriceListDto;
import com.hwagain.sp.process.dto.ImProcessPriceRptDto;
import com.hwagain.sp.process.dto.ImProcessProductFilterDto;
import com.hwagain.sp.process.dto.ImProcessProductRptDto;
import com.hwagain.sp.process.dto.ImProcessRptDto;
import com.hwagain.sp.process.dto.ImProcessSaleRptDto;
import com.hwagain.sp.process.dto.ImProductListDto;
import com.hwagain.sp.process.mapper.ImProcessBatchProductMapper;
import com.hwagain.sp.process.mapper.ImProcessMapper;
import com.hwagain.sp.process.mapper.ImProcessPriceMapper;
import com.hwagain.sp.process.mapper.ImProcessRptMapper;
import com.hwagain.sp.process.service.IImProcessBatchProductService;
import com.hwagain.sp.process.service.IImProcessPriceService;
import com.hwagain.sp.process.service.IImProcessService;
import com.hwagain.sp.process.service.ISysDataService;
import com.hwagain.sp.process.sync.DataUtil;
import com.hwagain.sp.process.sync.ProcessDateUtil;
import com.hwagain.sp.product.dto.ProductClassDto;
import com.hwagain.sp.product.service.IProductClassService;
import com.hwagain.sp.util.PublicUtils;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
@Service("imProcessService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImProcessServiceImpl extends ServiceImpl<ImProcessMapper, ImProcess> implements IImProcessService {
	@Autowired
	ISysDataService sysDataService;
	@Autowired
	IProductClassService productClassService;
	@Autowired
	IImProcessBatchProductService processBatchProductService;
	@Autowired
	IImProcessPriceService imProcessPriceService;
	@Autowired
	ImProcessRptMapper imProcessRptMapper;
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	
	@Autowired
	ImProcessMapper imProcessMapper;
	@Autowired
	ImProcessPriceMapper imProcessPriceMapper;
	@Autowired
	ImProcessBatchProductMapper imProcessBatchProductMapper;


	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImProcess.class, ImProcessDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImProcessDto.class, ImProcess.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	
	// 处理品收集表-处理品筛选
	@Override
	public List<ImProcessProductFilterDto> findProcessProduct(String className,
			String fmodel, String sDate, String eDate, String auxprod,
			String sfnumber, String efnumber) throws CustomException {
		Assert.notBlank(sDate, "请输入生产开始日期");
		Assert.notBlank(sDate, "请输入生产截止日期");
		List<ImProcessProductFilterDto> list= new ArrayList<ImProcessProductFilterDto>();
		List<Map> mapList=sysDataService.getProcessProductByFilter(className, fmodel, sDate, eDate, auxprod, sfnumber, efnumber);
		Assert.notNull(mapList,"查无数据！");
		if(mapList.size()>0)
		{
			for(int i=0;i<mapList.size();i++)
			{
				ImProcessProductFilterDto dto=new ImProcessProductFilterDto();
				String prodDate= (String) mapList.get(i).get("fkfdate");
				dto.setClassName((String) mapList.get(i).get("className"));
				dto.setPaperNo((String) mapList.get(i).get("fbatchno"));
				dto.setFmodel((String) mapList.get(i).get("fmodel"));
				dto.setFAuxProdName((String) mapList.get(i).get("auxProdName"));
				dto.setProductDate(ProcessDateUtil.strToUtilDate(prodDate, "yyyy-MM-dd"));
				dto.setWeight((BigDecimal) mapList.get(i).get("fqty"));
				list.add(dto);
			}
		}
		else
		{
			ImProcessProductFilterDto dto=new ImProcessProductFilterDto();
			list.add(dto);
		}
		return list;
	}

	/**
	 * 处理品收集-选择确认(保存处理品明细信息)
	 * 
	 * paperNos 纸卷编号 可传入多个并以","隔开
	 */
	@Override
	public List<ImProcessProductRptDto> saveProcessProduct(String paperNos, String platform)
			throws CustomException {
		List<ImProductListDto> productList=getProcessProductDetail(paperNos,platform);
		Assert.notNull(productList, "请选择处理品信息");
		//处理品批号
//		String batchNo=PublicUtils.getSerialCode("P", "【进口纸机】处理品销售批号");
//		Assert.notBlank("batchNo", "处理品批号产生错误");
//		Date doDate = new Date();
//		String curUserId = UserUtils.getUserId();
//		ImProcess entity=new ImProcess();
//		entity.setFdId(Long.valueOf(IdWorker.getId()));
//		entity.setBatchNo(batchNo);
//		entity.setStatus(0);
//		entity.setCreatorId(curUserId);
//		entity.setCreateDate(doDate);
//		//保存主表
//		super.insert(entity);
//		//获取主表fdId
//		Long imProcessId=entity.getFdId();
		List<ImProcessBatchProduct> list=new ArrayList<ImProcessBatchProduct>();
		//总数量
		BigDecimal totalWeight=new BigDecimal(0.0);
		for(ImProductListDto dto:productList)
		{
			totalWeight=totalWeight.add(dto.getWeight());
			ImProcessBatchProduct entity2=new ImProcessBatchProduct();
			entity2.setFdId(Long.valueOf(IdWorker.getId()));
			//entity2.setImProcessId(imProcessId);
			entity2.setPaperNo(dto.getPaperNo());
			entity2.setClassNo(dto.getClassNo());
			entity2.setRation(dto.getRation());
			entity2.setWrinkleRate(dto.getWrinkleRate());
			entity2.setLayer(dto.getLayer());
			entity2.setWidth(dto.getWidth().toString());
			entity2.setDiameter(new BigDecimal(dto.getDiameter().toString()));
			entity2.setGrade(dto.getGrade());
			entity2.setReason(dto.getReason());
			entity2.setWeight(dto.getWeight());
			entity2.setProductDate(dto.getProductDate());
			entity2.setStatus(0);
			list.add(entity2);
		}
		//Boolean isOK=false;
		//isOK=processBatchProductService.save(list);
		if(!processBatchProductService.save(list))
			Assert.throwException("生成处理品明细出错");
		
		List<ImProcessProductRptDto> list2=imProcessRptMapper.querpImProcessProductDetail();
		Integer seqNum = 1;
		for(ImProcessProductRptDto dto:list2)
		{
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list2;
	}


	private List<ImProductListDto> getProcessProductDetail(String paperNos, String platform)
	{
		Assert.notBlank(paperNos, "请选择纸卷");
		List<ImProductListDto> list=new ArrayList<ImProductListDto>();
		List<Map> mapList=sysDataService.getProductDetailByK3(paperNos, platform);
		String [] strPaperNoArr= paperNos.split(",");  
		Assert.notNull(mapList,"查无数据");
		if(mapList.size()>0)
		{
			for(int i=0;i<mapList.size();i++)
			{
				String className=(String) mapList.get(i).get("className");
				List<ProductClassDto> classList=productClassService.findByKey(className, platform);
				Assert.notNull(classList,"品类为"+className+"不存在");
				String classNo=productClassService.findByKey(className, platform).get(0).getClassNo();
				String prodDate=ProcessDateUtil.dateToStr((Date)mapList.get(i).get("ProduceDate"), "yyyy-MM-dd");
				String barcode=(String) mapList.get(i).get("Barcode");
				//double ration=(Double)mapList.get(i).get("FixedQuantity"); //下线系统为double
				String ration=(String)mapList.get(i).get("FixedQuantity");//K3 中间表为String
				//Integer width=(Integer) mapList.get(i).get("Specification");//下线系统为integer
				Integer width=(String) mapList.get(i).get("Specification")==null?0:Integer.valueOf((String) mapList.get(i).get("Specification"));  //K3 中间表为String
				double wrinkleRate=mapList.get(i).get("WrinkleRate")==null?0.0:Math.abs((Double) mapList.get(i).get("WrinkleRate"));
				Integer diameter=(String) mapList.get(i).get("Diameter")==null?0:Integer.valueOf((String) mapList.get(i).get("Diameter"));  //K3 中间表为String
				if(Arrays.asList(strPaperNoArr).contains(barcode))
				{
					ImProductListDto dto=new ImProductListDto();
					BigDecimal bigweight=(BigDecimal) mapList.get(i).get("Weight");
					BigDecimal divisor= new BigDecimal(1000);
					BigDecimal weight=bigweight.divide(divisor, 4, RoundingMode.HALF_UP);
					dto.setPaperNo(barcode);
					dto.setClassName((String) mapList.get(i).get("variety"));
					dto.setClassNo(classNo);
					dto.setRation(DataUtil.stringToBigDecimal(ration));
					dto.setWrinkleRate(DataUtil.doubleToBigDecimal(wrinkleRate));
					dto.setLayer((Integer)mapList.get(i).get("layers"));
					dto.setWidth(width);
					dto.setDiameter(diameter);
					dto.setGrade((String) mapList.get(i).get("grade"));
					dto.setReason((String) mapList.get(i).get("GradeBK"));
					dto.setWeight(weight);
					dto.setProductDate(ProcessDateUtil.strToUtilDate(prodDate, "yyyy-MM-dd"));
					list.add(dto);
				}
			}
		}
		else
		{
			ImProductListDto dto=new ImProductListDto();
			list.add(dto);
		}
		return list;
	}
	
	/**
	 * 处理品收集-选择确认
	 * 
	 * paperNos 纸卷编号 可传入多个并以","隔开
	 */
	@Override
	public List<ImProductListDto> getProductDetail(String paperNos, String platform) throws CustomException {
		//Assert.notBlank(sDate, "请输入生产开始日期");
		//Assert.notBlank(sDate, "请输入生产截止日期");
		Assert.notBlank(paperNos, "请选择纸卷");
		List<ImProductListDto> list=new ArrayList<ImProductListDto>();
		//List<Map> mapList=sysDataService.getProductDetail(sDate, eDate);
		List<Map> mapList=sysDataService.getProductDetailByK3(paperNos, platform);
		String [] strPaperNoArr= paperNos.split(",");  
		Assert.notNull(mapList,"查无数据");
		if(mapList.size()>0)
		{
			for(int i=0;i<mapList.size();i++)
			{
				String className=(String) mapList.get(i).get("className");
				List<ProductClassDto> classList=productClassService.findByKey(className, platform);
				Assert.notNull(classList,"品类为"+className+"不存在");
				String classNo=productClassService.findByKey(className, platform).get(0).getClassNo();
				String prodDate=ProcessDateUtil.dateToStr((Date)mapList.get(i).get("ProduceDate"), "yyyy-MM-dd");
				String barcode=(String) mapList.get(i).get("Barcode");
				//double ration=(Double)mapList.get(i).get("FixedQuantity"); //下线系统为double
				String ration=(String)mapList.get(i).get("FixedQuantity");//K3 中间表为String
				//Integer width=(Integer) mapList.get(i).get("Specification");//下线系统为integer
				Integer width=(String) mapList.get(i).get("Specification")==null?0:Integer.valueOf((String) mapList.get(i).get("Specification"));  //K3 中间表为String
				double wrinkleRate=mapList.get(i).get("WrinkleRate")==null?0.0:Math.abs((Double) mapList.get(i).get("WrinkleRate"));
				Integer diameter=(String) mapList.get(i).get("Diameter")==null?0:Integer.valueOf((String) mapList.get(i).get("Diameter"));  //K3 中间表为String
				if(Arrays.asList(strPaperNoArr).contains(barcode))
				{
					ImProductListDto dto=new ImProductListDto();
					BigDecimal bigweight=(BigDecimal) mapList.get(i).get("Weight");
					BigDecimal divisor= new BigDecimal(1000);
					BigDecimal weight=bigweight.divide(divisor, 4, RoundingMode.HALF_UP);
					dto.setPaperNo(barcode);
					dto.setClassName((String) mapList.get(i).get("variety"));
					dto.setClassNo(classNo);
					dto.setRation(DataUtil.stringToBigDecimal(ration));
					dto.setWrinkleRate(DataUtil.doubleToBigDecimal(wrinkleRate));
					dto.setLayer((Integer)mapList.get(i).get("layers"));
					dto.setWidth(width);
					dto.setDiameter(diameter);
					dto.setGrade((String) mapList.get(i).get("grade"));
					dto.setReason((String) mapList.get(i).get("GradeBK"));
					dto.setWeight(weight);
					dto.setProductDate(ProcessDateUtil.strToUtilDate(prodDate, "yyyy-MM-dd"));
					list.add(dto);
				}
			}
		}
		else
		{
			ImProductListDto dto=new ImProductListDto();
			list.add(dto);
		}
		return list;
	}

	// 处理品收集-查所有数据
	@Override
	public List<ImProcessDto> findAll() throws CustomException {
		Wrapper<ImProcess> wrapper = new CriterionWrapper<ImProcess>(ImProcess.class);
		//wrapper.eq("status", 1);
		List<ImProcess> list = super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, ImProcessDto.class);
	}

	// 处理品收集-查一条数据
	@Override
	public ImProcessDto findOne(Long fdId) throws CustomException {
		return entityToDtoMapper.map(super.selectById(fdId), ImProcessDto.class);
	}

	@Override
	public Boolean save(List<ImProductListDto> productList)
			throws CustomException {
		Assert.notNull(productList, "请选择处理品信息");
		//处理品批号
		//String batchNo=ruleService.makeNo("Import", "处理品收集");
		String batchNo=PublicUtils.getSerialCode("P", "【进口纸机】处理品销售批号");
		Assert.notBlank("batchNo", "处理品批号产生错误");
		Date doDate = new Date();
		String curUserId = UserUtils.getUserId();
		ImProcess entity=new ImProcess();
		entity.setFdId(Long.valueOf(IdWorker.getId()));
		entity.setBatchNo(batchNo);
		entity.setStatus(1);
		entity.setCreaterId(curUserId);
		entity.setCreateTime(doDate);
		//保存主表
		super.insert(entity);
		//获取主表fdId
		Long imProcessId=entity.getFdId();
		List<ImProcessBatchProduct> list=new ArrayList<ImProcessBatchProduct>();
		//总数量
		BigDecimal totalWeight=new BigDecimal(0.0);
		for(ImProductListDto dto:productList)
		{
			totalWeight=totalWeight.add(dto.getWeight());
			ImProcessBatchProduct entity2=new ImProcessBatchProduct();
			entity2.setFdId(Long.valueOf(IdWorker.getId()));
			entity2.setImProcessId(imProcessId);
			entity2.setPaperNo(dto.getPaperNo());
			entity2.setClassNo(dto.getClassNo());
			entity2.setRation(dto.getRation());
			entity2.setWrinkleRate(dto.getWrinkleRate());
			entity2.setLayer(dto.getLayer());
			entity2.setWidth(dto.getWidth().toString());
			entity2.setDiameter(new BigDecimal(dto.getDiameter().toString()));
			entity2.setGrade(dto.getGrade());
			entity2.setReason(dto.getReason());
			entity2.setWeight(dto.getWeight());
			entity2.setProductDate(dto.getProductDate());
			list.add(entity2);
		}
		Boolean isOK=false;
		isOK=processBatchProductService.save(list);
		Assert.isTrue(isOK, "生成处理品明细出错");
		//更新总重量
		entity.setTotalWeight(totalWeight);
		super.updateAllById(entity);
		List<ImProcessPriceListDto> priceList2=processBatchProductService.getCollectProduct(BigInteger.valueOf (imProcessId));
		for(ImProcessPriceListDto dto2:priceList2)
		{
			String stockAge="";
			String strNowDate=ProcessDateUtil.dateToStr(doDate,"yyyy-MM-dd");
			String minDate=ProcessDateUtil.dateToStr(dto2.getMinProductDate(), "yyyy-MM-dd");
			String maxDate=ProcessDateUtil.dateToStr(dto2.getMaxProductDate(), "yyyy-MM-dd");
			//计算库龄
			if(DateUtils.isSameDay(dto2.getMinProductDate(), dto2.getMaxProductDate()))
			{
				int monthSpace;
				try {
					monthSpace = ProcessDateUtil.getMonthSpace(minDate, strNowDate);
					stockAge=monthSpace+"个月";
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else	
			{
				try {
					int minMonth=ProcessDateUtil.getMonthSpace(maxDate, strNowDate);
					stockAge=minMonth+"-";
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				try {
					int maxMonth=ProcessDateUtil.getMonthSpace(minDate, strNowDate);
					stockAge=stockAge+maxMonth+"个月";
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
			
			ImProcessPrice entity3=new ImProcessPrice();
			entity3.setFdId(Long.valueOf(IdWorker.getId()));
			entity3.setImProcessId(imProcessId);
			entity3.setClassNo(dto2.getClassNo());
			entity3.setRation(dto2.getRation());
			entity3.setWrinkleRate(dto2.getWrinkleRate());
			entity3.setLayer(dto2.getLayer());
			entity3.setWidth(dto2.getWidth());
			entity3.setDiameter(dto2.getDiameter());
			entity3.setGrade(dto2.getGrade());
			entity3.setAge(stockAge);
			entity3.setWeight(dto2.getWeight());
			entity3.setStatus(0);//未审核
			entity3.setCreaterId(curUserId);
			entity3.setCreateTime(doDate);
			imProcessPriceService.insert(entity3);
			
			//获取处理品价格表fdId
			Long imProcessPriceId=entity3.getFdId();
			
			Wrapper<ImProcessBatchProduct> wrapper=new CriterionWrapper<ImProcessBatchProduct>(ImProcessBatchProduct.class);
			wrapper.eq("im_process_batch_id", imProcessId);
			wrapper.eq("class_no", dto2.getClassNo());
			wrapper.eq("ration", dto2.getRation());
			wrapper.eq("wrinkle_rate",dto2.getWrinkleRate());
			wrapper.eq("layer",dto2.getLayer());
			wrapper.eq("width",dto2.getWidth());
			wrapper.eq("diameter", dto2.getDiameter());
			wrapper.eq("grade",dto2.getGrade());
			List<ImProcessBatchProduct> list2=processBatchProductService.selectList(wrapper);
			for(ImProcessBatchProduct entity4:list2)
			{
				entity4.setImProcessPriceId(imProcessPriceId);
				processBatchProductService.updateAllById(entity4);
			}
		}
		
		return true;
	}

	@Override
	public ImProcessDto save(ImProcessDto dto,
			List<ImProcessPriceDto> priceList,
			List<ImProcessBatchProductDto> productList) throws CustomException {
		
		return null;
	}

	//删除处理品主表及明细表
	@Override
	@Transactional
	public Boolean delete(String fdId) throws CustomException {
		Boolean flag=false;
		//删除处理品明细表
		flag=imProcessMapper.delProduct(fdId);
		//删除处理品价格录入表
		flag=imProcessMapper.delPrice(fdId);
		//删除主表
		if(imProcessMapper.deleteById(fdId)>0)
			flag=true;
		return flag;
	}

	@Override
	public List<ImProcessSaleRptDto> queryProcessSaleList()
			throws CustomException {
		List<ImProcessSaleRptDto> list=imProcessRptMapper.queryImProcessSaleList();
		return list;
	}
	/**
	 * 在售处理品明细-终止销售
	 * 
	 */
	@Override
	public Boolean finishSale()
			throws CustomException {
		Boolean flag=false;
		Date doDate = new Date();
		String curUserId = UserUtils.getUserId();
		Wrapper<ImProcess> wrapper0=new CriterionWrapper<ImProcess>(ImProcess.class);
		wrapper0.eq("status", 3);
		ImProcess entity=super.selectFirst(wrapper0);
		Assert.notNull(entity, "没找到未终止的处理品记录！");
		entity.setEndDate(doDate);
		entity.setStatus(4); //终止销售
		entity.setLastAlterId(curUserId);
		entity.setLastAlterTime(doDate);
		imProcessMapper.updateAllById(entity);
		
		//处理品价格
		Wrapper<ImProcessPrice> wrapper=new CriterionWrapper<ImProcessPrice>(ImProcessPrice.class);
		wrapper.eq("im_process_id", entity.getFdId());
		List<ImProcessPrice> list=imProcessPriceService.selectList(wrapper);
		for(ImProcessPrice pp:list)
		{
			pp.setStatusText("终止销售");
			pp.setStatus(4);
			pp.setLastAlterId(curUserId);
			pp.setLastAlterTime(doDate);
			imProcessPriceService.updateAllById(pp);
		}
		
		//处理品明细
		Wrapper<ImProcessBatchProduct> wrapper2=new CriterionWrapper<ImProcessBatchProduct>(ImProcessBatchProduct.class);
		wrapper2.eq("im_process_id", entity.getFdId());
		List<ImProcessBatchProduct> list2=processBatchProductService.selectList(wrapper2);
		for(ImProcessBatchProduct pbp:list2)
		{
			pbp.setStatus(4);
			processBatchProductService.updateAllById(pbp);
		}
		
		flag=true;
		return flag;
	}

	
	@Override
	public List<ImProcessRptDto> queryProcessHistorySale() throws CustomException {
		List<ImProcessRptDto> list=imProcessRptMapper.queryImProcessHistorySale();
		Integer seqNum = 1;
		for(ImProcessRptDto dto:list)
		{
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list;
	}

	@Override
	public List<ImProcessSaleRptDto> queryProcessSaleByBatch(String batchNo)
			throws CustomException {
		List<ImProcessSaleRptDto> list=imProcessRptMapper.queryProcessSaleByBatch(batchNo);
		Integer seqNum = 1;
		for(ImProcessSaleRptDto dto:list)
		{
			String customer=sysDataService.getSaleCustomer(dto.getPaperNo());
			dto.setSeqNum(seqNum);
			dto.setCustomer(customer);
			seqNum++;
		}
		return list;
	}

	private BigDecimal getNormalPrice(String classNo,BigDecimal ration,BigDecimal wrinkleRate,Integer layers,Integer width,Integer diameter,Integer productKind )
	{
		List<RptTempData> list=null;
		String sql="";
		Date doDate = new Date();
		if(productKind.equals("A"))
		{
			sql="select price from im_price where class_no='"+classNo+"'and ration="+ration+" and layer="+layers+" and "
					+ ""+width+" between minTotalWidth and maxTotalWidth and "
							+ "stard_date>='"+ProcessDateUtil.dateToStr(doDate, "yyyy-MM-dd")+"' and end_date<='"+ProcessDateUtil.dateToStr(doDate, "yyyy-MM-dd")+"'";
		}
		else
		{
			sql="select top 1 price from im_special_price where class_no='"+classNo+"' and ration="+ration+" and layer="+layers+" and "
					+ ""+width+" between minTotalWidth and maxTotalWidth and "
							+ "stard_date>='"+ProcessDateUtil.dateToStr(doDate, "yyyy-MM-dd")+"' and end_date<='"+ProcessDateUtil.dateToStr(doDate, "yyyy-MM-dd")+"'";
		}
		return null;
	}
	/**
	 * 处理品收集明细
	 */
	@Override
	public List<ImProcessProductRptDto> findProcessProductDetail()
			throws CustomException {
		List<ImProcessProductRptDto> list=imProcessRptMapper.querpImProcessProductDetail();
		Integer seqNum = 1;
		for(ImProcessProductRptDto dto:list)
		{
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list;
	}
	
	
	
	@Override
	public List<ImProcessProductRptDto> getProcessProductDetailById(String ids)
			throws CustomException {
		String str[] = ids.split(",");
		List<String> strlist = new ArrayList<>();
		strlist = Arrays.asList(str);
		List<ImProcessProductRptDto> list=imProcessRptMapper.getImProcessProductDetailById(strlist);
		return list;
	}

	/**
	 * 处理品收集完成提交
	 * 
	 */
	@Override
	public Boolean collectFinish(String ids) throws CustomException {
		Wrapper<ImProcess> wrapper0=new CriterionWrapper<ImProcess>(ImProcess.class);
		wrapper0.lt("status", 4);
		List<ImProcess> list0=super.selectList(wrapper0);
		if(list0.size()!=0)
			Assert.throwException("还有未终止的处理品在售！");
		String batchNo=PublicUtils.getSerialCode("P", "【进口纸机】处理品销售批号");
		Assert.notBlank("batchNo", "处理品批号产生错误");
		Date doDate = new Date();
		String curUserId = UserUtils.getUserId();
		ImProcess entity=new ImProcess();
		entity.setFdId(Long.valueOf(IdWorker.getId()));
		entity.setBatchNo(batchNo);
		entity.setStatus(1);
		entity.setCreaterId(curUserId);
		entity.setCreateTime(doDate);
		//保存主表
		super.insert(entity);
		//获取主表fdId
		Long imProcessId=entity.getFdId();
		//总数量
				BigDecimal totalWeight=new BigDecimal(0.0);
		List<ImProcessProductRptDto> list=this.getProcessProductDetailById(ids);
		for(ImProcessProductRptDto p:list)
		{
			totalWeight=totalWeight.add(p.getWeight());
			ImProcessBatchProduct pbp=processBatchProductService.selectById(p);
			pbp.setImProcessId(imProcessId);
			pbp.setStatus(1);
			processBatchProductService.updateAllById(pbp);
		}
		//更新处理品主表总重量
		entity.setTotalWeight(totalWeight);
		super.updateAllById(entity);
		
		List<ImProcessPriceListDto> priceList2=processBatchProductService.getCollectProductById(ids);
		for(ImProcessPriceListDto dto2:priceList2)
		{
			String stockAge="";
			String strNowDate=ProcessDateUtil.dateToStr(doDate,"yyyy-MM-dd");
			String minDate=ProcessDateUtil.dateToStr(dto2.getMinProductDate(), "yyyy-MM-dd");
			String maxDate=ProcessDateUtil.dateToStr(dto2.getMaxProductDate(), "yyyy-MM-dd");
			//计算库龄
			if(DateUtils.isSameDay(dto2.getMinProductDate(), dto2.getMaxProductDate()))
			{
				int monthSpace;
				try {
					monthSpace = ProcessDateUtil.getMonthSpace(minDate, strNowDate);
					stockAge=monthSpace+"个月";
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else	
			{
				try {
					int minMonth=ProcessDateUtil.getMonthSpace(maxDate, strNowDate);
					stockAge=minMonth+"-";
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				try {
					int maxMonth=ProcessDateUtil.getMonthSpace(minDate, strNowDate);
					stockAge=stockAge+maxMonth+"个月";
				} catch (ParseException e) {
					e.printStackTrace();
				}
			}
			
			ImProcessPrice entity2=new ImProcessPrice();
			entity2.setFdId(Long.valueOf(IdWorker.getId()));
			entity2.setImProcessId(imProcessId);
			entity2.setClassNo(dto2.getClassNo());
			entity2.setRation(dto2.getRation());
			entity2.setWrinkleRate(dto2.getWrinkleRate());
			entity2.setLayer(dto2.getLayer());
			entity2.setWidth(dto2.getWidth());
			entity2.setDiameter(dto2.getDiameter());
			entity2.setGrade(dto2.getGrade());
			entity2.setAge(stockAge);
			entity2.setWeight(dto2.getWeight());
			entity2.setStatus(1);//未审核
			entity2.setCreaterId(curUserId);
			entity2.setCreateTime(doDate);
			imProcessPriceService.insert(entity2);
			
			//获取处理品价格表fdId
			Long imProcessPriceId=entity2.getFdId();
			
			Wrapper<ImProcessBatchProduct> wrapper=new CriterionWrapper<ImProcessBatchProduct>(ImProcessBatchProduct.class);
			wrapper.eq("im_process_id", imProcessId);
			wrapper.eq("class_no", dto2.getClassNo());
			wrapper.eq("ration", dto2.getRation());
			wrapper.eq("wrinkle_rate",dto2.getWrinkleRate());
			wrapper.eq("layer",dto2.getLayer());
			wrapper.eq("width",dto2.getWidth());
			wrapper.eq("diameter", dto2.getDiameter());
			wrapper.eq("grade",dto2.getGrade());
			List<ImProcessBatchProduct> list2=processBatchProductService.selectList(wrapper);
			for(ImProcessBatchProduct entity3:list2)
			{
				entity3.setImProcessPriceId(imProcessPriceId);
				processBatchProductService.updateAllById(entity3);
			}
		}
		return true;
	}

	//高速纸机处理品价格录入表
	@Override
	public List<ImProcessPriceRptDto> findProcessPriceList()
			throws CustomException {
		List<ImProcessPriceRptDto> list=imProcessRptMapper.queryImProcessPricetList();
		return list;
	}
	
}
