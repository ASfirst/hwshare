package com.hwagain.sp.order.dto;

import java.math.BigDecimal;
import java.util.Date;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author huangdh
 * @since 2018-11-16
 */
public class ImOrderDetailDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
    /**
     * 订单主表ID
     */
	private Long orderId;
    /**
     * 幅宽
     */
	private Integer width;
    /**
     * 数量
     */
	private Integer qty;
    /**
     * 重量
     */
	private BigDecimal weight;
    /**
     * 单价
     */
	private BigDecimal price;
    /**
     * 货款
     */
	private BigDecimal amount;
    /**
     * 每吨定金
     */
	private BigDecimal deposit;
    /**
     * 应缴定金
     */
	private BigDecimal paymentDeposit;
    /**
     * 完成量
     */
	private BigDecimal finishedWeight;
    /**
     * 库存量
     */
	private BigDecimal stockWeight;
    /**
     * 企业单幅产品编号
     */
	private String enterpriseWidthNo;
    /**
     * 客户单幅产品编号
     */
	private String customerWidthNo;
	private String creatorId;
    /**
     * 创建时间
     */
	private Date createTime;
	private String lastAlterId;
    /**
     * 更新时间
     */
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Integer getWidth() {
		return width;
	}

	public void setWidth(Integer width) {
		this.width = width;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getDeposit() {
		return deposit;
	}

	public void setDeposit(BigDecimal deposit) {
		this.deposit = deposit;
	}

	public BigDecimal getPaymentDeposit() {
		return paymentDeposit;
	}

	public void setPaymentDeposit(BigDecimal paymentDeposit) {
		this.paymentDeposit = paymentDeposit;
	}

	public BigDecimal getFinishedWeight() {
		return finishedWeight;
	}

	public void setFinishedWeight(BigDecimal finishedWeight) {
		this.finishedWeight = finishedWeight;
	}

	public BigDecimal getStockWeight() {
		return stockWeight;
	}

	public void setStockWeight(BigDecimal stockWeight) {
		this.stockWeight = stockWeight;
	}

	public String getEnterpriseWidthNo() {
		return enterpriseWidthNo;
	}

	public void setEnterpriseWidthNo(String enterpriseWidthNo) {
		this.enterpriseWidthNo = enterpriseWidthNo;
	}

	public String getCustomerWidthNo() {
		return customerWidthNo;
	}

	public void setCustomerWidthNo(String customerWidthNo) {
		this.customerWidthNo = customerWidthNo;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
