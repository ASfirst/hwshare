package com.hwagain.sp.order.entity;

import java.io.Serializable;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@TableName("product_set_detail")
public class ProductSetDetail implements Serializable {

    private static final long serialVersionUID = 1L;

	@TableId("fd_id")
	private Long fdId;
	@TableField("enterprise_set_no")
	private String enterpriseSetNo;
	private Integer width;
	private Integer qty;
	@TableField("enterprise_width_no")
	private String enterpriseWidthNo;
	@TableField("enterprise_width_name")
	private String enterpriseWidthName;
	@TableField("enterprise_index")
	private Integer enterpriseIndex;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getEnterpriseSetNo() {
		return enterpriseSetNo;
	}

	public void setEnterpriseSetNo(String enterpriseSetNo) {
		this.enterpriseSetNo = enterpriseSetNo;
	}

	public Integer getWidth() {
		return width;
	}

	public void setWidth(Integer width) {
		this.width = width;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public String getEnterpriseWidthNo() {
		return enterpriseWidthNo;
	}

	public void setEnterpriseWidthNo(String enterpriseWidthNo) {
		this.enterpriseWidthNo = enterpriseWidthNo;
	}

	public String getEnterpriseWidthName() {
		return enterpriseWidthName;
	}

	public void setEnterpriseWidthName(String enterpriseWidthName) {
		this.enterpriseWidthName = enterpriseWidthName;
	}

	public Integer getEnterpriseIndex() {
		return enterpriseIndex;
	}

	public void setEnterpriseIndex(Integer enterpriseIndex) {
		this.enterpriseIndex = enterpriseIndex;
	}

}
