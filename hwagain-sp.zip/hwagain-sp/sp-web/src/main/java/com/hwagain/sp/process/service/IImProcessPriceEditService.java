package com.hwagain.sp.process.service;

import java.math.BigDecimal;
import java.util.List;

import com.hwagain.sp.process.dto.ImProcessPriceEditDto;
import com.hwagain.sp.process.entity.ImProcessPriceEdit;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-12-20  class_no,ration,wrinkle_rate,layer,width,diameter,grade
 */
public interface IImProcessPriceEditService extends IService<ImProcessPriceEdit> {
	public ImProcessPriceEditDto addOneProcessEdit(Long fdId,Integer isPolicy,BigDecimal processPrice,String reason) throws CustomException;
	public List<ImProcessPriceEditDto> addSomeProcessEdit(List<ImProcessPriceEditDto> list) throws CustomException;
	public List<ImProcessPriceEditDto> findUserOrderHistory() throws CustomException;
	public Boolean submitCheck() throws CustomException;
	public List<ImProcessPriceEdit> getPriceEditRole() throws CustomException;
}
