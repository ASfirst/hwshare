package com.hwagain.sp.disobey.service.impl;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.hwagain.sp.disobey.entity.BaseDisobey;
import com.hwagain.sp.disobey.dto.BaseDisobeyDto;
import com.hwagain.sp.disobey.mapper.BaseDisobeyMapper;
import com.hwagain.sp.disobey.service.IBaseDisobeyEditService;
import com.hwagain.sp.disobey.service.IBaseDisobeyService;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
@Service("baseDisobeyService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class BaseDisobeyServiceImpl extends ServiceImpl<BaseDisobeyMapper, BaseDisobey> implements IBaseDisobeyService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	
	@Autowired
	IBaseDisobeyEditService baseDisobeyEditService;
	
	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(BaseDisobey.class, BaseDisobeyDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(BaseDisobeyDto.class, BaseDisobey.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

	@Override
	public List<BaseDisobey> findAll() throws CustomException {
		Wrapper<BaseDisobey> wrapper = new CriterionWrapper<BaseDisobey>(BaseDisobey.class);
		wrapper.orderBy("start_time", false);
		List<BaseDisobey> list = super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, BaseDisobey.class);
	}

	@Override
	public Boolean deleteByIds(String ids) throws CustomException {
		String[] id = ids.split(";");
		return baseDisobeyEditService.deleteBatchIds(Arrays.asList(id));
	}

	@Override
	public Boolean updateStatus(String id,String statusText) throws CustomException {
		BaseDisobey entity=super.selectById(id);
		Assert.notNull(entity, "修改的记录不存在！");
		if(statusText.equals("启用"))
		{
			entity.setStatus(0);
			super.updateAllById(entity);
		}
		else
		{
			entity.setStatus(1);
			super.updateAllById(entity);
		}
		return true;
	}

	@Override
	public BigDecimal getPenaltyStandard(Date shipmentDate) throws CustomException {
		Wrapper<BaseDisobey> wrapper=new CriterionWrapper<BaseDisobey>(BaseDisobey.class);
		wrapper.eq("disobey_content", "窜货");
		wrapper.eq("status", 1);
		wrapper.isNull("end_time");
		wrapper.le("start_time", shipmentDate);
		BaseDisobey disobey=super.selectFirst(wrapper);
		BigDecimal penaltyStandard=null;
		if(null != disobey)
		{
			if(disobey.getUnit().equals("车"))
				penaltyStandard=disobey.getPenaltyStandard();
		}
		return penaltyStandard;
	}

	@Override
	public BaseDisobeyDto getPenaltyStandard() throws CustomException {
		Date doDate = new Date();
		Wrapper<BaseDisobey> wrapper=new CriterionWrapper<BaseDisobey>(BaseDisobey.class);
		wrapper.eq("disobey_content", "窜货");
		wrapper.eq("status", 1);
		wrapper.le("start_time",doDate);
		BaseDisobey disobey=super.selectFirst(wrapper);
		return entityToDtoMapper.map(disobey, BaseDisobeyDto.class);
	}

	@Override
	public BaseDisobeyDto updateOne(BaseDisobeyDto dto) throws CustomException {
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
		Wrapper<BaseDisobey> wrapper=new CriterionWrapper<BaseDisobey>(BaseDisobey.class);
		wrapper.eq("disobey_content", dto.getDisobeyContent());
		wrapper.eq("unit", dto.getUnit());
		wrapper.eq("penalty_standard",dto.getPenaltyStandard());
		wrapper.eq("status", 1);
		BaseDisobey entity=super.selectFirst(wrapper);
		if(entity!=null)
		{
			BaseDisobey dis=new BaseDisobey();
			dis.setFdId(entity.getFdId());
			dis.setStatus(2);
			dis.setEndTime(dto.getStartTime());
			dis.setLastAlterId(cUserid);
			dis.setLastAlterTime(doDate);
			super.updateById(dis);
		}
		
		BaseDisobey dis1=new BaseDisobey();
		dis1.setFdId(Long.valueOf(IdWorker.getId()));
		dis1.setDisobeyContent(dto.getDisobeyContent());
		dis1.setUnit(dto.getUnit());
		dis1.setPenaltyStandard(dto.getPenaltyStandard());
		dis1.setStatus(1);
		dis1.setRemark(dto.getRemark());
		dis1.setStartTime(dto.getStartTime());
		dis1.setCreaterId(cUserid);
		dis1.setCreateTime(doDate);
		super.insert(dis1);
		return entityToDtoMapper.map(super.selectById(dis1.getFdId()), BaseDisobeyDto.class);
	}
	
	
}
