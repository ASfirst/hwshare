package com.hwagain.sp.policy.api.impl;

import com.hwagain.sp.policy.api.IPoOverApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
@Service("poOverApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoOverApiImpl implements IPoOverApi {
	
}
