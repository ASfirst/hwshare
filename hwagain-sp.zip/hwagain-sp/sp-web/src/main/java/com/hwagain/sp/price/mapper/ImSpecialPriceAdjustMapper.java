package com.hwagain.sp.price.mapper;

import com.hwagain.sp.price.entity.ImSpecialPriceAdjust;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author guoym
 * @since 2018-10-17
 */
public interface ImSpecialPriceAdjustMapper extends BaseMapper<ImSpecialPriceAdjust> {

}