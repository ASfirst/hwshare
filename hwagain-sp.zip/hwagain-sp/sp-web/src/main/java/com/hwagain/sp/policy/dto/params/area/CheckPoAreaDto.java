package com.hwagain.sp.policy.dto.params.area;

import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;

/**
 * Created on 2019/6/24 15:14
 * by @author WeiBoWen
 */
public class CheckPoAreaDto {

    @NotNull(message = "FdId参数不能为空")
    private Long fdId;

    @NotNull(message = "状态码参数不能为空")
    private Integer status;

    @NotBlank(message = "为避免歧义，该参数不能填写空字符")
    private String checkedRemark;

    public CheckPoAreaDto() {
    }

    public CheckPoAreaDto(
            @NotNull(message = "FdId参数不能为空") Long fdId,
            @NotNull(message = "状态码参数不能为空") Integer status, String checkedRemark) {
        this.fdId = fdId;
        this.status = status;
        this.checkedRemark = checkedRemark;
    }

    public Long getFdId() {
        return fdId;
    }

    public void setFdId(Long fdId) {
        this.fdId = fdId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCheckedRemark() {
        return checkedRemark;
    }

    public void setCheckedRemark(String checkedRemark) {
        this.checkedRemark = checkedRemark;
    }
}
