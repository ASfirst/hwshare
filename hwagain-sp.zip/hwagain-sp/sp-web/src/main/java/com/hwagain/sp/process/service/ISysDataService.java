package com.hwagain.sp.process.service;

import java.math.BigDecimal;
import java.sql.Connection;
import java.util.List;
import java.util.Map;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.sp.process.dto.ImProcessProductFilterDto;

public interface ISysDataService {
	public List<ImProcessProductFilterDto> getProcessDetailByKey(String className,String fmodel,String sDate,String eDate,String auxprod,String sfnumber,String efnumber) throws CustomException;
	public List<Map> getProcessProductByFilter(String className,String fmodel,String sDate,String eDate,String auxprod,String sfnumber,String efnumber) throws CustomException;
	public List<Map> getProductDetail(String sDate,String eDate) throws CustomException;
	public List<Map> getProductDetailByK3(String barcodes,String platform) throws CustomException;
	public String getSaleStatus(String batchno) throws CustomException;
	public String getSaleCustomer(String paperNo) throws CustomException;
	public BigDecimal getInQtyByOrderNo(String orderNo) throws CustomException;
	public BigDecimal getOutQtyByOrderNo(String orderNo) throws CustomException;
	public BigDecimal getStockQtyOrderNo(String orderNo) throws CustomException;
}
