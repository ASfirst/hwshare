package com.hwagain.sp.order.mapper;

import com.hwagain.sp.order.entity.ProductSet;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
public interface ProductSetMapper extends BaseMapper<ProductSet> {

}