package com.hwagain.sp.disobey.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
public interface IImDisobeyOverPeriodApi {
	
}
