package com.hwagain.sp.order.service.impl;


import com.hwagain.sp.order.entity.ImOrderDetail;
import com.hwagain.sp.order.dto.ImOrderDetailDto;
import com.hwagain.sp.order.mapper.ImOrderDetailMapper;
import com.hwagain.sp.order.service.IImOrderDetailService;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@Service("imOrderDetailService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImOrderDetailServiceImpl extends ServiceImpl<ImOrderDetailMapper, ImOrderDetail> implements IImOrderDetailService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	@Autowired
	private ImOrderDetailMapper imOrderDetailMapper;
	
	
	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImOrderDetail.class, ImOrderDetailDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImOrderDetailDto.class, ImOrderDetail.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	
	
	
	//新增一条记录
	@Override
	public ImOrderDetailDto save(ImOrderDetailDto dto) throws CustomException {
		ImOrderDetail entity = dtoToEntityMapper.map(dto, ImOrderDetail.class);
		Long fdId=Long.valueOf(IdWorker.getId());
		entity.setFdId(fdId);
		
		super.insert(entity);
		return dto;
	}	
	
	//通过im_order_id查询一张订单明细列表
	@Override
	public List<ImOrderDetailDto> findImOrderDetailListByOrderId(Long orderId) throws CustomException {
		return imOrderDetailMapper.findImOrderDetailListByOrderId(orderId);
	}

	
	//通过im_order_id删除订单明细
	@Override
	public Integer deleteImOrderDetailByOrderId(Long orderId) throws CustomException {
		return imOrderDetailMapper.deleteImOrderDetailByOrderId(orderId);
	}
	
	//当天下订单到第几张订单
	@Override
	public Integer findTodayOrderIndex() throws CustomException {
		ImOrderDetailDto obj=imOrderDetailMapper.findTodayOrderIndex();		
		Integer orderIndex= obj.getQty();
		return orderIndex;
	}
	
	
	
	
	
	
}
