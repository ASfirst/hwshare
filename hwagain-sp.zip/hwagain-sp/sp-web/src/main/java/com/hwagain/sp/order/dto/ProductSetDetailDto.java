package com.hwagain.sp.order.dto;


import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
public class ProductSetDetailDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
	private String enterpriseSetNo;
	private Integer width;
	private Integer qty;
	private String enterpriseWidthNo;
	private String enterpriseWidthName;
	private Integer enterpriseIndex;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getEnterpriseSetNo() {
		return enterpriseSetNo;
	}

	public void setEnterpriseSetNo(String enterpriseSetNo) {
		this.enterpriseSetNo = enterpriseSetNo;
	}

	public Integer getWidth() {
		return width;
	}

	public void setWidth(Integer width) {
		this.width = width;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public String getEnterpriseWidthNo() {
		return enterpriseWidthNo;
	}

	public void setEnterpriseWidthNo(String enterpriseWidthNo) {
		this.enterpriseWidthNo = enterpriseWidthNo;
	}

	public String getEnterpriseWidthName() {
		return enterpriseWidthName;
	}

	public void setEnterpriseWidthName(String enterpriseWidthName) {
		this.enterpriseWidthName = enterpriseWidthName;
	}

	public Integer getEnterpriseIndex() {
		return enterpriseIndex;
	}

	public void setEnterpriseIndex(Integer enterpriseIndex) {
		this.enterpriseIndex = enterpriseIndex;
	}

}
