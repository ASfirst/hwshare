package com.hwagain.sp.price.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ImPriceAdjustRptDto extends ImPriceRptDto {

	private static final long serialVersionUID = 1L;

	private Long adj_fdId;
	/**
	 * 统一销售价格id
	 */
	private Long importPriceId;
	/**
	 * 调整前价
	 */
	private BigDecimal adj_sourcePrice;
	/**
	 * 调整金额
	 */
	private BigDecimal adj_addPrice;
	/**
	 * 调整后价
	 */
	private BigDecimal adj_price;
	/**
	 * 开始日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date adj_startDate;
	/**
	 * 结束日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date adj_endDate;
	/**
	 * 备注
	 */
	private String adj_remark;
	 /**
     * 角色
     */
	private String adj_role;
	/**
	 * 创建人
	 */
	private String adj_createrId;
	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date adj_createTime;
	/**
	 * 最后修改人
	 */
	private String adj_lastAlterId;
	/**
	 * 最后修改时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date adj_lastAlterTime;
	/**
	 * 状态 (10：未提交(初始状态):可以选择/删除/修改保存/提交 11：已提交到申请人工作台(或退回开始节点):可以选择/删除/修改保存
	 * 20：审核中(申请人已经提交出去):不可操作 30：已审批 40：已过期)
	 */
	private Integer adj_status;
	
	/**
	 * OACode
	 */
	private String adj_OACode;
	/**
	 * 批次id
	 */
	private Long adj_batchId;
	/**
	 * 是否删除
	 */
	private Integer adj_isDelete;

	public Long getAdj_fdId() {
		return adj_fdId;
	}

	public void setAdj_fdId(Long adj_fdId) {
		this.adj_fdId = adj_fdId;
	}

	public Long getImportPriceId() {
		return importPriceId;
	}

	public void setImportPriceId(Long importPriceId) {
		this.importPriceId = importPriceId;
	}

	public BigDecimal getAdj_sourcePrice() {
		return adj_sourcePrice;
	}

	public void setAdj_sourcePrice(BigDecimal adj_sourcePrice) {
		this.adj_sourcePrice = adj_sourcePrice;
	}

	public BigDecimal getAdj_addPrice() {
		return adj_addPrice;
	}

	public void setAdj_addPrice(BigDecimal adj_addPrice) {
		this.adj_addPrice = adj_addPrice;
	}

	public BigDecimal getAdj_price() {
		return adj_price;
	}

	public void setAdj_price(BigDecimal adj_price) {
		this.adj_price = adj_price;
	}

	public Date getAdj_startDate() {
		return adj_startDate;
	}

	public void setAdj_startDate(Date adj_startDate) {
		this.adj_startDate = adj_startDate;
	}

	public Date getAdj_endDate() {
		return adj_endDate;
	}

	public void setAdj_endDate(Date adj_endDate) {
		this.adj_endDate = adj_endDate;
	}

	public String getAdj_remark() {
		return adj_remark;
	}

	public void setAdj_remark(String adj_remark) {
		this.adj_remark = adj_remark;
	}

	public String getAdj_role() {
		return adj_role;
	}

	public void setAdj_role(String adj_role) {
		this.adj_role = adj_role;
	}

	public String getAdj_createrId() {
		return adj_createrId;
	}

	public void setAdj_createrId(String adj_createrId) {
		this.adj_createrId = adj_createrId;
	}

	public Date getAdj_createTime() {
		return adj_createTime;
	}

	public void setAdj_createTime(Date adj_createTime) {
		this.adj_createTime = adj_createTime;
	}

	public String getAdj_lastAlterId() {
		return adj_lastAlterId;
	}

	public void setAdj_lastAlterId(String adj_lastAlterId) {
		this.adj_lastAlterId = adj_lastAlterId;
	}

	public Date getAdj_lastAlterTime() {
		return adj_lastAlterTime;
	}

	public void setAdj_lastAlterTime(Date adj_lastAlterTime) {
		this.adj_lastAlterTime = adj_lastAlterTime;
	}

	public Integer getAdj_status() {
		return adj_status;
	}

	public void setAdj_status(Integer adj_status) {
		this.adj_status = adj_status;
	}

	public String getAdj_OACode() {
		return adj_OACode;
	}

	public void setAdj_OACode(String adj_OACode) {
		this.adj_OACode = adj_OACode;
	}

	public Long getAdj_batchId() {
		return adj_batchId;
	}

	public void setAdj_batchId(Long adj_batchId) {
		this.adj_batchId = adj_batchId;
	}

	public Integer getAdj_isDelete() {
		return adj_isDelete;
	}

	public void setAdj_isDelete(Integer adj_isDelete) {
		this.adj_isDelete = adj_isDelete;
	}


}
