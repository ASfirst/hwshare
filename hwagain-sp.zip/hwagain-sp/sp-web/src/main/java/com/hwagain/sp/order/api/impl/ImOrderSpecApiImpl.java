package com.hwagain.sp.order.api.impl;

import com.hwagain.sp.order.api.IImOrderSpecApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@Service("imOrderSpecApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImOrderSpecApiImpl implements IImOrderSpecApi {
	
}
