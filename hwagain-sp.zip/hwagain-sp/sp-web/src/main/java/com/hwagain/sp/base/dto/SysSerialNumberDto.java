package com.hwagain.sp.base.dto;

import java.util.Date;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author guoym
 * @since 2018-11-05
 */
public class SysSerialNumberDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * fd_Id
     */
	private Long fdId;
    /**
     * 类型
     */
	private String typeName;
    /**
     * 前缀字母
     */
	private String prefixChar;
    /**
     * 年份
     */
	private Integer year;
    /**
     * 月份
     */
	private Integer month;
    /**
     * 流水号
     */
	private Integer number;
    /**
     * 说明
     */
	private String remark;
    /**
     * 创建人
     */
	private String createrId;
    /**
     * 创建时间
     */
	private Date createTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getTypeName() {
		return typeName;
	}

	public void setTypeName(String typeName) {
		this.typeName = typeName;
	}

	public String getPrefixChar() {
		return prefixChar;
	}

	public void setPrefixChar(String prefixChar) {
		this.prefixChar = prefixChar;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public Integer getNumber() {
		return number;
	}

	public void setNumber(Integer number) {
		this.number = number;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

}
