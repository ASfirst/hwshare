package com.hwagain.sp.process.mapper;

import org.apache.ibatis.annotations.Param;

import com.hwagain.sp.process.entity.ImProcessPrice;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public interface ImProcessPriceMapper extends BaseMapper<ImProcessPrice> {
	public Boolean delProductDetail(@Param("fdId") String fdId);
}