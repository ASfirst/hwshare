package com.hwagain.sp.process.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.hwagain.sp.price.dto.ImPriceAddConditionDto;
import com.hwagain.sp.price.dto.ImPriceAddConditionEditDto;
import com.hwagain.sp.price.entity.ImPriceAddConditionEdit;
import com.hwagain.sp.process.entity.ImProcess;
import com.hwagain.sp.process.entity.ImProcessBatchProduct;
import com.hwagain.sp.process.entity.ImProcessPrice;
import com.hwagain.sp.process.entity.ImProcessPriceEdit;
import com.hwagain.sp.process.dto.ImProcessPriceEditDto;
import com.hwagain.sp.process.dto.ImProcessPriceListRptDto;
import com.hwagain.sp.process.mapper.ImProcessPriceEditMapper;
import com.hwagain.sp.process.service.IImProcessBatchProductService;
import com.hwagain.sp.process.service.IImProcessPriceEditService;
import com.hwagain.sp.process.service.IImProcessPriceService;
import com.hwagain.sp.process.service.IImProcessService;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-12-20
 */
@Service("imProcessPriceEditService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImProcessPriceEditServiceImpl extends ServiceImpl<ImProcessPriceEditMapper, ImProcessPriceEdit> implements IImProcessPriceEditService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImProcessPriceEdit.class, ImProcessPriceEditDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImProcessPriceEditDto.class, ImProcessPriceEdit.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

	@Autowired
	IImProcessPriceService imProcessPriceService;
	@Autowired
	ImProcessPriceEditMapper imProcessPriceEditMapper;
	
	@Autowired
	IImProcessBatchProductService imProcessBatchProductService;
	
	@Autowired
	IImProcessService imProcessService;
	
	//新增一条处理品价格数据
	@Override
	public ImProcessPriceEditDto addOneProcessEdit(Long fdId,Integer isPolicy,BigDecimal processPrice,String reason) throws CustomException {
		Assert.notNull(fdId, "价格ID数据为空！");
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		ImProcessPrice pEntity=imProcessPriceService.selectById(fdId);
		Assert.notNull(pEntity,"处理品价格数据不存在！");
		if(pEntity.getStatus()==1)
			Assert.throwException("请先审核处理品明细！");
		Wrapper<ImProcessPriceEdit> wrapper=new CriterionWrapper<ImProcessPriceEdit>(ImProcessPriceEdit.class);
		wrapper.eq("creater_id", cUserid);
		wrapper.eq("im_price_id", pEntity.getFdId());
		wrapper.eq("status_edit", 1);
		ImProcessPriceEdit entity=super.selectFirst(wrapper);
		if(entity!=null)
		{
			entity.setIsPolicy(isPolicy);
			entity.setProcessPrice(processPrice);
			entity.setReason(reason);
			entity.setLastAlterId(cUserid);
			entity.setLastAlterTime(doDate);
			super.updateById(entity);
		}
		else
		{
			ImProcessPriceEdit pEdit=new ImProcessPriceEdit();
			pEdit.setFdId(Long.valueOf(IdWorker.getId()));
			pEdit.setImProcessId(pEntity.getImProcessId());
			pEdit.setImPriceId(fdId);
			pEdit.setIsPolicy(isPolicy);
			pEdit.setProcessPrice(processPrice);
			pEdit.setReason(reason);
			pEdit.setStatusEdit(1);
			pEdit.setRole(dept);
			pEdit.setCreaterId(cUserid);
			pEdit.setCreateTime(doDate);
			super.insert(pEdit);
		}
		return entityToDtoMapper.map(super.selectById(fdId), ImProcessPriceEditDto.class);
	}

	//新增多条处理品价格数据
	@Override
	public List<ImProcessPriceEditDto> addSomeProcessEdit(
			List<ImProcessPriceEditDto> list) throws CustomException {
		List<ImProcessPriceEditDto> list2 = new ArrayList<ImProcessPriceEditDto>();

		int i = 1;
		for (ImProcessPriceEditDto dto : list) {
			ImProcessPrice pp = imProcessPriceService.selectById(dto.getImPriceId());
			Assert.notNull(pp, "第" + String.valueOf(i) + "条纪录,没有找！");
			if (pp.getStatus() == 1)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,记录未审核，请先审核处理品明细！");
			if(pp.getStatus()==3)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,记录已检验完成！");
			if(pp.getStatus()==3)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,记录已终止销售！");
			i++;
		}

		for (ImProcessPriceEditDto dto : list) {
			list2.add(addOneProcessEdit(dto.getImPriceId(),dto.getIsPolicy(),dto.getProcessPrice(),dto.getReason()));
		}

		return list2;
	}

	@Override
	public List<ImProcessPriceEditDto> findUserOrderHistory() throws CustomException {
		String cUserid = UserUtils.getUserInfo().getName();
		List<ImProcessPriceEdit> listA=new ArrayList<>();
		Wrapper<ImProcessPrice> wrapper0=new CriterionWrapper<ImProcessPrice>(ImProcessPrice.class);
		wrapper0.eq("status", 1);
		List<ImProcessPrice> list0=imProcessPriceService.selectList(wrapper0);
		String st1=JSONObject.toJSONString(list0.get(0));
		ImProcessPriceEdit list00=JSONObject.parseObject(st1,ImProcessPriceEdit.class);
		if(list0.size()!=0)
		{
			listA.add(list00);
		}
		else
		{
			Wrapper<ImProcessPriceEdit> wrapper=new CriterionWrapper<ImProcessPriceEdit>(ImProcessPriceEdit.class);
			wrapper.eq("creater_id", cUserid);
			wrapper.eq("status_edit", 1);
			List<ImProcessPriceEdit> list=super.selectList(wrapper);
			Wrapper<ImProcessPrice> wrapper1=new CriterionWrapper<ImProcessPrice>(ImProcessPrice.class);
			wrapper.eq("status", 2);
			List<ImProcessPrice> list1=imProcessPriceService.selectList(wrapper1);
			String st=JSONObject.toJSONString(list1.get(0));
			ImProcessPriceEdit list11=JSONObject.parseObject(st,ImProcessPriceEdit.class);
			
			if(list.size()==0){
				listA.add(list11);
			}else{
				listA.addAll(list);
				
			}
		}
		return entityToDtoMapper.mapAsList(listA, ImProcessPriceEditDto.class);
	}

	@Override
	public List<ImProcessPriceEdit> getPriceEditRole()
			throws CustomException {
		List<ImProcessPriceEdit> list=imProcessPriceEditMapper.getPriceEditRole();
		return list;
	}
	
	@Override
	public Boolean submitCheck() throws CustomException {
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		List<ImProcessPriceEdit> list=imProcessPriceEditMapper.getPriceEditRole();
		
		if(list.size()==0)
		{
			Assert.throwException("处理品价格数据未录入！");
		}
		if(list.size()==1)
			Assert.throwException("只有一人录入处理品价格数据！");
		String[] arr=new String[list.size()];
		for(int i=0;i<arr.length;i++)
			arr[i]=list.get(i).getRole();
		
		Wrapper<ImProcessPriceEdit> wrapper=new CriterionWrapper<ImProcessPriceEdit>(ImProcessPriceEdit.class);
		wrapper.eq("role", arr[0].toString());
		wrapper.orderBy("im_price_id");
		List<ImProcessPriceEdit> listA=super.selectList(wrapper);
		List<ImProcessPriceListRptDto> listX=new ArrayList<>();
		for(ImProcessPriceEdit e1:listA)
		{
			ImProcessPriceListRptDto dto1=new ImProcessPriceListRptDto();
			dto1.setImPriceId(e1.getImPriceId());
			dto1.setImProcessId(e1.getImProcessId());
			dto1.setIsPolicy(e1.getIsPolicy());
			dto1.setProcessPrice(e1.getProcessPrice());
			listX.add(dto1);
			
		}
		
		Wrapper<ImProcessPriceEdit> wrapper2=new CriterionWrapper<ImProcessPriceEdit>(ImProcessPriceEdit.class);
		wrapper2.eq("role", arr[1].toString());
		wrapper2.orderBy("im_price_id");
		List<ImProcessPriceEdit> listB=super.selectList(wrapper2);
		List<ImProcessPriceListRptDto> listY=new ArrayList<>();
		for(ImProcessPriceEdit e2:listB)
		{
			ImProcessPriceListRptDto dto2=new ImProcessPriceListRptDto();
			dto2.setImPriceId(e2.getImPriceId());
			dto2.setImProcessId(e2.getImProcessId());
			dto2.setIsPolicy(e2.getIsPolicy());
			dto2.setProcessPrice(e2.getProcessPrice());
			listY.add(dto2);
			
		}
		
		if(listX.size()!=listY.size())
		{
			Assert.throwException("处理品价格校验失败！");
		}
		else
		{
			Integer nums=0;
			for(int i=0;i<listX.size();i++)
			{
				String a1=listX.get(i).getImPriceId().toString();
				String a2=listX.get(i).getImProcessId().toString();
				Integer a3=listX.get(i).getIsPolicy();
				BigDecimal a4=listX.get(i).getProcessPrice();
				
				String b1=listY.get(i).getImPriceId().toString();
				String b2=listY.get(i).getImProcessId().toString();
				Integer b3=listY.get(i).getIsPolicy();
				BigDecimal b4=listY.get(i).getProcessPrice();
				if(a4==null || b4==null)
					Assert.throwException("第"+String.valueOf(i)+"条处理价格未录入！");
				if(a1.equals(b1) && a2.equals(b2) && a3.equals(b3) && a4.compareTo(b4)==0)
				{
					nums++;
				}
				else
				{
					Assert.throwException("第"+String.valueOf(i)+"条处理品价格校验失败！");
					
				}
			}
			if(nums==listX.size())
			{
				Wrapper<ImProcessPriceEdit> w1=new CriterionWrapper<ImProcessPriceEdit>(ImProcessPriceEdit.class);
				w1.eq("im_process_id", listX.get(0).getImProcessId());
				List<ImProcessPriceEdit> pList1=super.selectList(w1);
				for(ImProcessPriceEdit e1:pList1)
				{
					e1.setStatus(3);
					e1.setStatusText("校验成功");
					e1.setStatusEdit(10);
					super.updateAllById(e1);
				}
				Wrapper<ImProcessPrice> w2=new CriterionWrapper<ImProcessPrice>(ImProcessPrice.class);
				w2.eq("im_process_id", listX.get(0).getImProcessId());
				List<ImProcessPrice> pList2=imProcessPriceService.selectList(w2);
				for(ImProcessPrice e2:pList2)
				{
					e2.setStatus(3);
					e2.setStatusText("校验成功");
					e2.setLastAlterId(cUserid);
					e2.setLastAlterTime(doDate);
					imProcessPriceService.updateAllById(e2);
				}
				Wrapper<ImProcessBatchProduct> w3=new CriterionWrapper<ImProcessBatchProduct>(ImProcessBatchProduct.class);
				w3.eq("im_process_id", listX.get(0).getImProcessId());
				List<ImProcessBatchProduct> pList3=imProcessBatchProductService.selectList(w3);
				for(ImProcessBatchProduct e3:pList3)
				{
					e3.setStatus(3);
					imProcessBatchProductService.updateAllById(e3);
				}
				Wrapper<ImProcess> w4=new CriterionWrapper<ImProcess>(ImProcess.class);
				w4.eq("fd_id", listX.get(0).getImProcessId());
				List<ImProcess> pList4=imProcessService.selectList(w4);
				for(ImProcess e4:pList4)
				{
					e4.setStardDate(doDate);
					e4.setStatus(3);
					e4.setLastAlterId(cUserid);
					e4.setLastAlterTime(doDate);
					imProcessService.updateAllById(e4);
				}
			}
		}
		
		
		return null;
	}

}
