package com.hwagain.sp.deposit.service;

import com.hwagain.sp.deposit.dto.DDepositStandardEditDto;
import com.hwagain.sp.deposit.entity.DDepositStandardEdit;

import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-06
 */
public interface IDDepositStandardEditService extends IService<DDepositStandardEdit> {

//	public DDepositStandardEditDto addOne(DDepositStandardEditDto dto)throws CustomException;

	public List<DDepositStandardEditDto> updateDeposits(List<DDepositStandardEditDto> dtos)throws CustomException;

	public String updateOneDeposit(DDepositStandardEditDto dto)throws CustomException;

	public List<DDepositStandardEditDto> findAllEdit(String edit)throws CustomException;

	public List<DDepositStandardEditDto> updateBBase(String edit)throws CustomException;

	public List<DDepositStandardEditDto> findNewHistory()throws CustomException;

	public DDepositStandardEditDto addOneEdit(DDepositStandardEditDto dto)throws CustomException;

	public List<DDepositStandardEditDto> matching(List<DDepositStandardEditDto> dtos)throws CustomException;

	public List<DDepositStandardEditDto> delete(List<DDepositStandardEditDto> dtos)throws CustomException;


	
	
}
