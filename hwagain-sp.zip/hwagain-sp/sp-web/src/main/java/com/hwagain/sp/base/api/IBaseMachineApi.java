package com.hwagain.sp.base.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huangdh
 * @since 2019-05-12
 */
public interface IBaseMachineApi {
	
}
