package com.hwagain.sp.order.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.framework.validation.util.ValidationUtil;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.List;
import java.util.Map;
import java.math.BigInteger;

import com.hwagain.sp.order.service.IImOrderService;
import com.hwagain.sp.order.entity.ImOrder;
import com.hwagain.sp.order.entity.ImOrderDetail;
import com.hwagain.sp.order.dto.ImOrderDto;
import com.hwagain.sp.deposit.service.IDDepositStandardService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@RestController
@RequestMapping(value="/order/imOrder",method={RequestMethod.GET,RequestMethod.POST})
@Api(value="【进口纸机】订单主表",description="【进口纸机】订单主表")
public class ImOrderController extends BaseController{
	
	@Autowired
	IImOrderService imOrderService;
	@Autowired
	IDDepositStandardService dDepositStandardService;
	

	/**
	 * 查询全部数据
	 * 
	 * @return
	 */
	@RequestMapping("/findAll")
	@ApiOperation(value = "查詢订单列表", notes = "查詢订单列表",httpMethod="GET")
	public Response findAll(){
		return SuccessResponseData.newInstance(imOrderService.findAll(),null,this.getValidation(new ImOrderDto()),null);
	}
	
	/**
	 * 获取当前资源下的用户权限
	 * 
	 * @param dto
	 * @return
	 */
	public Map<String, Boolean> getValidation(ImOrderDto dto) {
		String contextPath = getRequest().getContextPath();
		Map<String, Boolean> validURIMaps = ValidationUtil.validModuleOperator(contextPath, "/order/imOrder", dto);
		return validURIMaps;
	}
	/**
	 * 按ID查询数据
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/findOne",method={RequestMethod.GET})
	@ApiOperation(value = "按fdId查询数据", notes = "按fdId查询数据",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "fdId", value = "主键fdId", paramType = "query", required = false, dataType = "BigInteger")
	})
	public Response findOne(Long fdId){
		return SuccessResponseData.newInstance(imOrderService.findOne(fdId));
	}
	
	/**
	 * 新增订单，主表和明细表同时插入
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/save",method={RequestMethod.POST})
	@ApiOperation(value = "新增订单，主表和明细表同时插入", notes = "新增订单，主表和明细表同时插入",httpMethod="POST")
	public Response save(@RequestBody ImOrderDto dto){
		return SuccessResponseData.newInstance(imOrderService.save(dto));

	}
	
	/**
	 * 修改订单，更新主表、明细表
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/update",method={RequestMethod.POST})
	@ApiOperation(value = "修改订单，更新主表、明细表", notes = "修改订单，更新主表、明细表",httpMethod="POST")
	public Response update(@RequestBody ImOrderDto dto){
		return SuccessResponseData.newInstance(imOrderService.update(dto));
	}
	
	
	
	
	
	
	/**
	 * 通过orderNo查询一条记录
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/findImOrderByOrderNo",method={RequestMethod.GET})
	@ApiOperation(value = "按orderNo查询数据", notes = "按orderNo查询数据",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "orderNo", value = "订单号orderNo", paramType = "query", required = false, dataType = "String")
	})
	public Response findImOrderByOrderNo(String orderNo){
		return SuccessResponseData.newInstance(imOrderService.findImOrderByOrderNo(orderNo));
	}
	
	/**
	 * 订单非常规品定金（每吨定金）
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/findOrderDeposit",method={RequestMethod.GET})
	@ApiOperation(value = "订单非常规品定金（每吨定金）", notes = "订单非常规品定金（每吨定金）",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "kindNo", value = "产品类型（常规a/非常规b/特规c）", paramType = "query", required = false, dataType = "String")
	})
	public Response findOrderDepositByKindNo(String kindNo){
		return SuccessResponseData.newInstance(dDepositStandardService.findOrderDepositByKindNo(kindNo));
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
