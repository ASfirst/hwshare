package com.hwagain.sp.customer.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-29
 */
public interface IBaseCustomerManagerApi {
	
}
