package com.hwagain.sp.price.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ImSpecialPriceAdjustExtDto extends ImSpecialPriceExtDto {
	private static final long serialVersionUID = 1L;

	/**
	 * 主键id
	 */
	private Long adj_fdId;
	/**
	 * 特规品价格id
	 */
	private Long imSpecialPriceId;
	/**
	 * 对应常规价格
	 */
	private BigDecimal adj_normalPrice;
	/**
	 * 调整前加价
	 */
	private BigDecimal sourceAddPrice;
	/**
	 * 调整后加价
	 */
	private BigDecimal adjustAddPrice;
	/**
	 * 调整前执行价
	 */
	private BigDecimal sourceExecPrice;
	/**
	 * 调整后执行价
	 */
	private BigDecimal adjustExecPrice;
	/**
	 * 生效日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date adj_startDate;
	/**
	 * 失效日期
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date adj_endDate;
	/**
	 * 备注
	 */
	private String adj_remark;
	/**
	 * 状态 (0:未生效 1:已生效)
	 */
	private Integer adj_status;
	/**
	 * 状态描述
	 */
	private String adj_statusText;
	/**
     * 是否享受政策
     */
	private Integer adj_isPolicy;
	/**
	 * 是否删除
	 */
	private Integer adj_isDelete;
	/**
	 * 创建人姓名
	 */
	private String adj_createrName;
	/**
	 * 创建人
	 */
	private String adj_createrId;
	/**
	 * 创建时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date adj_createTime;
	/**
	 * 最后修改人
	 */
	private String adj_lastAlterId;
	/**
	 * 最后修改时间
	 */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date adj_lastAlterTime;
	
	private String adj_isPolicyText;

	public Long getAdj_fdId() {
		return adj_fdId;
	}

	public void setAdj_fdId(Long adj_fdId) {
		this.adj_fdId = adj_fdId;
	}

	public BigDecimal getAdj_NormalPrice() {
		return adj_normalPrice;
	}

	public void setAdj_NormalPrice(BigDecimal adj_normalPrice) {
		this.adj_normalPrice = adj_normalPrice;
	}

	public BigDecimal getSourceAddPrice() {
		return sourceAddPrice;
	}

	public void setSourceAddPrice(BigDecimal sourceAddPrice) {
		this.sourceAddPrice = sourceAddPrice;
	}

	public BigDecimal getSourceExecPrice() {
		return sourceExecPrice;
	}

	public void setSourceExecPrice(BigDecimal sourceExecPrice) {
		this.sourceExecPrice = sourceExecPrice;
	}

	public Long getImSpecialPriceId() {
		return imSpecialPriceId;
	}

	public void setImSpecialPriceId(Long imSpecialPriceId) {
		this.imSpecialPriceId = imSpecialPriceId;
	}

	public BigDecimal getAdjustAddPrice() {
		return adjustAddPrice;
	}

	public void setAdjustAddPrice(BigDecimal adjustAddPrice) {
		this.adjustAddPrice = adjustAddPrice;
	}

	public BigDecimal getAdjustExecPrice() {
		return adjustExecPrice;
	}

	public void setAdjustExecPrice(BigDecimal adjustExecPrice) {
		this.adjustExecPrice = adjustExecPrice;
	}

	public Date getAdj_startDate() {
		return adj_startDate;
	}

	public void setAdj_startDate(Date adj_startDate) {
		this.adj_startDate = adj_startDate;
	}

	public Date getAdj_endDate() {
		return adj_endDate;
	}

	public void setAdj_endDate(Date adj_endDate) {
		this.adj_endDate = adj_endDate;
	}

	public String getAdj_remark() {
		return adj_remark;
	}

	public void setAdj_remark(String adj_remark) {
		this.adj_remark = adj_remark;
	}

	public Integer getAdj_status() {
		return adj_status;
	}

	public void setAdj_status(Integer adj_status) {
		this.adj_status = adj_status;
	}

	public String getAdj_statusText() {
		return adj_statusText;
	}

	public void setAdj_statusText(String adj_statusText) {
		this.adj_statusText = adj_statusText;
	}

	public Integer getAdj_isDelete() {
		return adj_isDelete;
	}

	public void setAdj_isDelete(Integer adj_isDelete) {
		this.adj_isDelete = adj_isDelete;
	}

	public String getAdj_createrName() {
		return adj_createrName;
	}

	public void setAdj_createrName(String adj_createrName) {
		this.adj_createrName = adj_createrName;
	}

	public String getAdj_createrId() {
		return adj_createrId;
	}

	public void setAdj_createrId(String adj_createrId) {
		this.adj_createrId = adj_createrId;
	}

	public Date getAdj_createTime() {
		return adj_createTime;
	}

	public void setAdj_createTime(Date adj_createTime) {
		this.adj_createTime = adj_createTime;
	}

	public String getAdj_lastAlterId() {
		return adj_lastAlterId;
	}

	public void setAdj_lastAlterId(String adj_lastAlterId) {
		this.adj_lastAlterId = adj_lastAlterId;
	}

	public Date getAdj_lastAlterTime() {
		return adj_lastAlterTime;
	}

	public void setAdj_lastAlterTime(Date adj_lastAlterTime) {
		this.adj_lastAlterTime = adj_lastAlterTime;
	}

	public BigDecimal getAdj_normalPrice() {
		return adj_normalPrice;
	}

	public void setAdj_normalPrice(BigDecimal adj_normalPrice) {
		this.adj_normalPrice = adj_normalPrice;
	}

	public Integer getAdj_isPolicy() {
		return adj_isPolicy;
	}

	public void setAdj_isPolicy(Integer adj_isPolicy) {
		this.adj_isPolicy = adj_isPolicy;
	}

	public String getAdj_isPolicyText() {
		if (null != this.getAdj_isPolicy()) {
			if (this.getAdj_isPolicy() == 1)
				adj_isPolicyText = "是";
			else
				adj_isPolicyText = "否";
		}
		return adj_isPolicyText;
	}

	public void setAdj_isPolicyText(String adj_isPolicyText) {
		this.adj_isPolicyText = adj_isPolicyText;
	}

}
