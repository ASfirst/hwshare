package com.hwagain.sp.process.service.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.core.util.SpringBeanUtil;
import com.hwagain.framework.core.util.date.DateUtil;
import com.hwagain.framework.mybatisplus.enums.SqlLike;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.sp.process.dto.ImProcessProductFilterDto;
import com.hwagain.sp.process.dto.ImProductListDto;
import com.hwagain.sp.process.service.ISysDataService;
import com.hwagain.sp.product.entity.ProductClass;
import com.hwagain.sp.product.mapper.ProductClassMapper;
import com.hwagain.sp.product.service.IProductClassService;
import com.hwagain.sp.util.JDBCConfig;
@Service("SysDataServiceImpl")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class SysDataServiceImpl implements ISysDataService {
	private final static Logger logger = LoggerFactory.getLogger(SysDataServiceImpl.class);
	@Autowired
	ProductClassMapper productClassMapper;
	
	private static Connection getK3Conn()
	{
		JDBCConfig jDBCConfig=SpringBeanUtil.getBean(JDBCConfig.class);
		String url = jDBCConfig.getK3Url();// 127.0.0.1是本机地址，XE是精简版Oracle的默认数据库名
		String username = jDBCConfig.getK3Username();// 用户名,系统默认的账户名
		String password = jDBCConfig.getK3Password();// 你安装时选设置的密码
		Connection con = null;// 创建一个数据库连接
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");// 加载sql驱动程序
			logger.info("开始尝试连接K3纸品账套数据库...");
			logger.info(url);
			logger.info(username);
			logger.info(password);
			con = DriverManager.getConnection(url, username, password);// 获取连接
			logger.info("K3纸品账套连接成功...");
			

		} catch (Exception e) {
			e.printStackTrace();
			con=null;
		} 
		return con;
	}
	
	private static Connection getPOMConn()
	{
		JDBCConfig jDBCConfig=SpringBeanUtil.getBean(JDBCConfig.class);
		String url = jDBCConfig.getPOMUrl();// 127.0.0.1是本机地址，XE是精简版Oracle的默认数据库名
		String username = jDBCConfig.getPOMUsername();// 用户名,系统默认的账户名
		String password = jDBCConfig.getPOMPassword();// 你安装时选设置的密码
		Connection con = null;// 创建一个数据库连接
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");// 加载sql驱动程序
			logger.info("开始尝试连接生产下线系统数据库...");
			logger.info(url);
			logger.info(username);
			logger.info(password);
			con = DriverManager.getConnection(url, username, password);// 获取连接
			logger.info("生产下线系统数据库连接成功...");
			

		} catch (Exception e) {
			e.printStackTrace();
			con=null;
		} 
		return con;
	}
	
	@Override
	public List<ImProcessProductFilterDto> getProcessDetailByKey(String className, String fmodel,
			String sDate, String eDate, String auxprod, String sfnumber,
			String efnumber) throws CustomException {
		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		List<ImProcessProductFilterDto> list= new ArrayList<ImProcessProductFilterDto>();
		String wStr="where round(i.fqty,4)>0 ";
		if(!"".equals(className) && className!=null)
		{
			wStr=wStr+" and t.fname like '"+className+"'";
		}
		if(!"".equals(fmodel) && fmodel!=null)
		{
			wStr=wStr+" and t.fmodel like '%"+fmodel+"%'";
		}
		if(!"".equals(sDate) && sDate!=null)
		{
			wStr=wStr+" and convert(varchar(10),fkfdate,21)>='"+sDate+"'";
		}
		if(!"".equals(eDate) && eDate!=null)
		{
			wStr=wStr+" and convert(varchar(10),fkfdate,21)<='"+eDate+"'";
		}
		if(!"".equals(auxprod) && auxprod!=null)
		{
			wStr=wStr+" and a.fname like '%"+auxprod+"%'";
		}
		if(!"".equals(sfnumber) && sfnumber!=null)
		{
			wStr=wStr+" and t.fnumber>='"+sfnumber+"'";
		}
		if(!"".equals(efnumber) && efnumber!=null)
		{
			wStr=wStr+" and t.fnumber<='"+efnumber+"'";
		}
		String sql="select t.fnumber,t.fname className,t.fmodel,fbatchno,a.fname auxProdName,fkfdate,fqty,m.fname" 
				+" from DB241.赣州纸品.dbo.ICInventory i" 
				+" inner join DB241.赣州纸品.dbo.t_icitem t on i.fitemid=t.fitemid" 
				+" inner join DB241.赣州纸品.dbo.t_AuxItem a on i.fauxpropid=a.fitemid" 
				+" inner join DB241.赣州纸品.dbo.t_MeasureUnit m on t.fstoreunitid=m.fmeasureunitid "+wStr;
		try{
			con=getK3Conn();
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result = pre.executeQuery();// 执行查询，注意括号中不需要再加参数
			ResultSetMetaData md = pre.getMetaData();
			int columnCount = md.getColumnCount();
			while (result.next()) {
				Map<String, Object> map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++)
					map.put(md.getColumnName(i).toString(), result.getObject(i));
				String prodDate= (String)map.get("fkfdate");
				ImProcessProductFilterDto dto=new ImProcessProductFilterDto();
				dto.setClassName((String)map.get("className"));
				dto.setPaperNo((String) map.get("fbatchno"));
				dto.setFmodel((String) map.get("fmodel"));
				dto.setFAuxProdName((String) map.get("auxProdName"));
				dto.setProductDate(DateUtil.stringToDate(prodDate, "yyyy-MM-dd"));
				dto.setWeight((BigDecimal) map.get("fqty"));
				list.add(dto);
			}
			//查询不到数据负空值
			if (list.size()==0) {
				ImProcessProductFilterDto dto=new ImProcessProductFilterDto();
				list.add(dto);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}
	
	private static List<ImProductListDto> getProductList(String date1,String date2,String fbatchnos)
	{
		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		List<ImProductListDto> list=new ArrayList<ImProductListDto>();
		
		try {
			con=getPOMConn();

			String sql = "exec GetReportData 2,'"+date1+"','"+date2+"','所有','所有' ";
			
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result=pre.executeQuery();
			ResultSetMetaData md = pre.getMetaData();
			int columnCount = md.getColumnCount();
			while (result.next()) {
				Map<String, Object> map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++)
					map.put(md.getColumnName(i).toString(), result.getObject(i));
				String prodDate= (String)map.get("fkfdate");
				//List<ProductClassDto> classDto=productClassService.
				String classNo=(String)map.get("variety");
				ImProductListDto dto=new ImProductListDto();
				//dto.setClassNo(classNo);
				list.add(dto);
			}
			//查询不到数据负空值
			if (list.size()==0) {
				ImProductListDto dto=new ImProductListDto();
				list.add(dto);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	@Override
	public List<Map> getProcessProductByFilter(String className, String fmodel,
			String sDate, String eDate, String auxprod, String sfnumber,
			String efnumber) throws CustomException {
		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		List<Map> list=new ArrayList<Map>();
		String wStr="where round(i.fqty,4)>0 ";
		if(!"".equals(className) && className!=null)
		{
			wStr=wStr+" and t.fname like '%"+className+"%'";
		}
		if(!"".equals(fmodel) && fmodel!=null)
		{
			wStr=wStr+" and t.fmodel like '%"+fmodel+"%'";
		}
		if(!"".equals(sDate) && sDate!=null)
		{
			wStr=wStr+" and convert(varchar(10),fkfdate,21)>='"+sDate+"'";
		}
		if(!"".equals(eDate) && eDate!=null)
		{
			wStr=wStr+" and convert(varchar(10),fkfdate,21)<='"+eDate+"'";
		}
		if(!"".equals(auxprod) && auxprod!=null)
		{
			wStr=wStr+" and a.fname like '%"+auxprod+"%'";
		}
		if(!"".equals(sfnumber) && sfnumber!=null)
		{
			wStr=wStr+" and t.fnumber>='"+sfnumber+"'";
		}
		if(!"".equals(efnumber) && efnumber!=null)
		{
			wStr=wStr+" and t.fnumber<='"+efnumber+"'";
		}
		String sql="select t.fnumber,t.fname className,t.fmodel,fbatchno,a.fname auxProdName,fkfdate,fqty,m.fname" 
				+" from DB241.赣州纸品.dbo.ICInventory i" 
				+" inner join DB241.赣州纸品.dbo.t_icitem t on i.fitemid=t.fitemid" 
				+" inner join DB241.赣州纸品.dbo.t_AuxItem a on i.fauxpropid=a.fitemid" 
				+" inner join DB241.赣州纸品.dbo.t_MeasureUnit m on t.fstoreunitid=m.fmeasureunitid "+wStr;
		try{
			con=getK3Conn();
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result = pre.executeQuery();// 执行查询，注意括号中不需要再加参数
			ResultSetMetaData md = pre.getMetaData();
			int columnCount = md.getColumnCount();
			while (result.next()) {
				Map<String, Object> map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++)
					map.put(md.getColumnName(i).toString(), result.getObject(i));
				
				list.add(map);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public List<Map> getProductDetail(String sDate, String eDate)
			throws CustomException {
		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		List<Map> list=new ArrayList<Map>();
		try {
			con=getPOMConn();

			String sql = "exec GetReportData 2,'"+sDate+"','"+eDate+"','所有','所有' ";
			
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result=pre.executeQuery();
			ResultSetMetaData md = pre.getMetaData();
			int columnCount = md.getColumnCount();
			while (result.next()) {
				Map<String, Object> map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++)
					map.put(md.getColumnName(i).toString(), result.getObject(i));
				list.add(map);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public List<Map> getProductDetailByK3(String barcodes,
			String platform) throws CustomException {
		Assert.notBlank(barcodes, "请选择纸卷");
		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		List<Map> list=new ArrayList<Map>();
		try {
			con=getK3Conn();
			String strBarcodes=barcodes.replace(",", "','");
			String sql="select NO Barcode,PinMing variety,ration FixedQuantity,GG Specification,Weight,grade,ProduceDate,层数 layers,Diameter,GradeBK,WrinkleRate from [DB241].[赣州华劲_赣州华劲纸业有限公司（总财、物料）].dbo.chaint_K3 where no in('"+strBarcodes+"')";
			
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result=pre.executeQuery();
			ResultSetMetaData md = pre.getMetaData();
			int columnCount = md.getColumnCount();
			while (result.next()) {
				Map<String, Object> map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++)
					map.put(md.getColumnName(i).toString(), result.getObject(i));
				list.add(map);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return list;
	}

	@Override
	public String getSaleStatus(String batchno) throws CustomException {
		Assert.notBlank(batchno, "纸卷编号不能为空");
		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		String saleStatus="";
		try {
			con=getK3Conn();
			String sql="select isnull(sum(isnull(fqty,0)),0) fqty from [DB241].[赣州纸品].dbo.icstockbill t1 inner join [DB241].[赣州纸品].dbo.icstockbillentry t2 on t1.finterid=t2.finterid " 
                    +"where t1.ftrantype=21 and t2.fbatchno='"+batchno+"'";
			
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result=pre.executeQuery();
			while (result.next()) {
				if(result.getDouble("fqty")>0)
				{
					saleStatus="已售";
				}
				else
				{
					saleStatus="未售";
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return saleStatus;
	}

	@Override
	public String getSaleCustomer(String paperNo) throws CustomException {
		Assert.notBlank(paperNo, "纸卷编号不能为空");
		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		String customer="";
		try {
			con=getK3Conn();
			String sql="select t.fname from icstockbillentry a "
						+"inner join icstockbill b on a.finterid=b.finterid " 
						+"left join t_Organization t on b.FSupplyID=t.FItemid "
						+"where ftrantype=21 and fbatchno='"+paperNo+"' and fcheckerId>0";
			
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result=pre.executeQuery();
			while (result.next()) {
				customer=result.getString("fname");
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return customer;
	}

	@Override
	public BigDecimal getInQtyByOrderNo(String orderNo) throws CustomException {
		Assert.notBlank(orderNo, "订单编号不能为空");
		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		BigDecimal inQty=new BigDecimal(0);
		String sql="select isnull(sum(fqty),0) fqty from icstockbill v1 inner join icstockbillentry u1 on v1.finterid=u1.finterid "+
				"inner join (select distinct no from [赣州华劲_赣州华劲纸业有限公司（总财、物料）].dbo.chaint_K3 "
				+ "where 特规纸客户采购订单号='"+orderNo+"' and isSelect=1) as t "+
				"on u1.fbatchno=t.no "+
				"where v1.ftrantype=2";
		try {
			con=getK3Conn();
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result=pre.executeQuery();
			while (result.next()) {
				inQty=result.getBigDecimal("fqty");
			}
			return inQty;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public BigDecimal getOutQtyByOrderNo(String orderNo) throws CustomException {
		Assert.notBlank(orderNo, "订单编号不能为空");
		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		BigDecimal outQty=new BigDecimal(0);
		String sql="select isnull(sum(fqty),0) fqty from icstockbill v1 inner join icstockbillentry u1 on v1.finterid=u1.finterid "+
				"inner join (select distinct no from [赣州华劲_赣州华劲纸业有限公司（总财、物料）].dbo.chaint_K3 "
				+ "where 特规纸客户采购订单号='"+orderNo+"' and isSelect=1) as t "+
				"on u1.fbatchno=t.no "+
				"where v1.ftrantype=21";
		try {
			con=getK3Conn();
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result=pre.executeQuery();
			while (result.next()) {
				outQty=result.getBigDecimal("fqty");
			}
			return outQty;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	@Override
	public BigDecimal getStockQtyOrderNo(String orderNo) throws CustomException {
		Assert.notBlank(orderNo, "订单编号不能为空");
		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		BigDecimal stockQty=new BigDecimal(0);
		String sql="select isnull(sum(fqty),0) fqty from icinventory i inner join "
				+ "(select distinct no from [赣州华劲_赣州华劲纸业有限公司（总财、物料）].dbo.chaint_K3 "
				+ "where 特规纸客户采购订单号='"+orderNo+"' and isSelect=1) as t on i.fbatchno=t.no";
		try {
			con=getK3Conn();
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result=pre.executeQuery();
			while (result.next()) {
				stockQty=result.getBigDecimal("fqty");
			}
			return stockQty;
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
}
