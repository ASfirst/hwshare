package com.hwagain.sp.base.service.impl;

import com.hwagain.sp.base.entity.BaseMachine;
import com.hwagain.sp.base.dto.BaseMachineDto;
import com.hwagain.sp.base.mapper.BaseMachineMapper;
import com.hwagain.sp.base.service.IBaseMachineService;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

import java.util.List;
import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huangdh
 * @since 2019-05-12
 */
@Service("baseMachineService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class BaseMachineServiceImpl extends ServiceImpl<BaseMachineMapper, BaseMachine> implements IBaseMachineService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(BaseMachine.class, BaseMachineDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(BaseMachineDto.class, BaseMachine.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	//新增
	@Override
	public BaseMachineDto save(BaseMachineDto dto) {
		BaseMachine entity=dtoToEntityMapper.map(dto,BaseMachine.class);
		super.insert(entity);
		return dto;
		
	}

	//修改
	@Override
	public BaseMachineDto update(BaseMachineDto dto) {
		BaseMachine entity=dtoToEntityMapper.map(dto,BaseMachine.class);
		super.updateById(entity);
		return dto;
		
	}


	
	
	
	@Override
	public List<BaseMachineDto> findAll(){
//		Wrapper<BaseMachine> wrapper = new CriterionWrapper<BaseMachine>(BaseMachine.class);
//		List<BaseMachine> list = super.selectList(wrapper);
//		return entityToDtoMapper.mapAsList(list, BaseMachineDto.class);

		
		
		Wrapper<BaseMachine> wrapper=new CriterionWrapper<BaseMachine>(BaseMachine.class);
		wrapper.eq("end_time", "2035-11-30");
		wrapper.orderBy("machine_type");
		wrapper.orderBy("machine_no");
		List<BaseMachine> list=super.selectList(wrapper);
//		int i=0;
		System.err.println(list.size());
		int a=1;
		int capacity=0;
		int totalCapacity=0;
		BaseMachine base=new BaseMachine();
		if(list.size()==1){
			capacity=list.get(0).getSingleCapacity();
			base.setFdId(list.get(0).getFdId());
			base.setTotalCapacity(capacity);
			super.updateById(base);
		}
		if(list.size()>1){	
			capacity=list.get(0).getSingleCapacity();
			for(int i=1;i<list.size();i++){
//				System.err.println(capacity);
				if(list.get(i).getMachineType().equals(list.get(i-1).getMachineType())){
//					System.err.println(capacity+"+"+list.get(i).getSingleCapacity());
					capacity+=list.get(i).getSingleCapacity();
					a++;
//					System.err.println(capacity);
					for(int j=0;j<a;j++){
						base.setFdId(list.get(i-j).getFdId());
						base.setTotalCapacity(capacity);
						super.updateById(base);
					}
	//				break;
				}
				if(!list.get(i).getMachineType().equals(list.get(i-1).getMachineType())){
					totalCapacity=capacity;
					for(int j=0;j<a;j++){
						base.setFdId(list.get(i-j).getFdId());
						base.setTotalCapacity(totalCapacity);
						super.updateById(base);
					}
					capacity=list.get(i).getSingleCapacity();
					a=1;
	//				break;
				}
			}
		}
		return entityToDtoMapper.mapAsList(list, BaseMachineDto.class);
		
	}
	
	
	@Override
	public List<BaseMachineDto> findAllMachine(){
		Wrapper<BaseMachine> wrapper=new CriterionWrapper<BaseMachine>(BaseMachine.class);
		wrapper.eq("end_time", "2035-11-30");
		wrapper.orderBy("machine_type");
		wrapper.orderBy("machine_no");
		List<BaseMachine> list=super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, BaseMachineDto.class);	
	}

	
	
	
	
	
	
	
	
	
	
}
