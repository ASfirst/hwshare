package com.hwagain.sp.customer.dto;

import java.io.Serializable;
import java.math.BigDecimal;


/**
 * <p>
 * 
 * </p>
 *
 * @author linhl
 * @since 2018-10-18
 */
public class CustomerBalanceDto implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
     * 客户ID
     */
	private Integer FCustID;
    /**
     * 客户编号
     */
	private String FCustNumber;
    /**
     * 客户名称
     */
	private String FCustName;
    /**
     * 合作经销商ID
     */
	private Integer FCooperationCustID;
    /**
     * 合作经销商编号
     */
	private String FCooperationCustNumber;
    /**
     * 合作经销商名称
     */
	private String FCooperationCustName;
    /**
     * 客户余额
     */
	//private BigDecimal FTotalAmount;
    /**
     * 订金
     */
	//private BigDecimal FDownPayment;
    /**
     * 可用余额
     */
	private BigDecimal FBanlance;
	public Integer getFCustID() {
		return FCustID;
	}
	public void setFCustID(Integer fCustID) {
		FCustID = fCustID;
	}
	public String getFCustNumber() {
		return FCustNumber;
	}
	public void setFCustNumber(String fCustNumber) {
		FCustNumber = fCustNumber;
	}
	public String getFCustName() {
		return FCustName;
	}
	public void setFCustName(String fCustName) {
		FCustName = fCustName;
	}
	public Integer getFCooperationCustID() {
		return FCooperationCustID;
	}
	public void setFCooperationCustID(Integer fCooperationCustID) {
		FCooperationCustID = fCooperationCustID;
	}
	public String getFCooperationCustNumber() {
		return FCooperationCustNumber;
	}
	public void setFCooperationCustNumber(String fCooperationCustNumber) {
		FCooperationCustNumber = fCooperationCustNumber;
	}
	public String getFCooperationCustName() {
		return FCooperationCustName;
	}
	public void setFCooperationCustName(String fCooperationCustName) {
		FCooperationCustName = fCooperationCustName;
	}
	public BigDecimal getFBanlance() {
		return FBanlance;
	}
	public void setFBanlance(BigDecimal fBanlance) {
		FBanlance = fBanlance;
	}
    



}
