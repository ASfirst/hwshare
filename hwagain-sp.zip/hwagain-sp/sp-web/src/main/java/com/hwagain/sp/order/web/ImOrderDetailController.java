package com.hwagain.sp.order.web;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.web.common.controller.BaseController;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.List;
import java.math.BigInteger;

import com.hwagain.sp.order.dto.ImOrderDetailDto;
import com.hwagain.sp.order.service.IImOrderDetailService;



/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@RestController
@RequestMapping(value="/order/imOrderDetail",method={RequestMethod.GET,RequestMethod.POST})
@Api(value="【进口纸机】订单明细表",description="【进口纸机】订单明细表")
public class ImOrderDetailController extends BaseController{
	
	@Autowired
	IImOrderDetailService imOrderDetailService;

	
	
	/**
	 * 按OrderId查询一张订单明细列表
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/findImOrderDetailListByOrderId",method={RequestMethod.GET})
	@ApiOperation(value = "按imOrderId查询一张订单明细列表", notes = "按imOrderId查询一张订单明细列表",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "orderId", value = "订单主表fdId", paramType = "query", required = false, dataType = "Long")
	})
	public Response findImOrderDetailListByOrderId(Long orderId){
		List<ImOrderDetailDto> list=imOrderDetailService.findImOrderDetailListByOrderId(orderId);
		return SuccessResponseData.newInstance(list);	

	}
	
	
	/**
	 * 查询当前生成第几张订单
	 */
	@RequestMapping("/findTodayOrderIndex")
	@ApiOperation(value = "查询当前生成第几张订单", notes = "查询当前生成第几张订单",httpMethod="GET")
	public Response findTodayOrderIndex(){
		return SuccessResponseData.newInstance(imOrderDetailService.findTodayOrderIndex());
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
