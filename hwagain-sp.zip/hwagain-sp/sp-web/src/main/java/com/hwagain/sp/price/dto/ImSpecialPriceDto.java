package com.hwagain.sp.price.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author guoym
 * @since 2018-10-17
 */
public class ImSpecialPriceDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	private Long fdId;
    /**
     * 品类
     */
	private String classNo;
    /**
     * 定量
     */
	private BigDecimal ration;
    /**
     * 起趋率
     */
	private BigDecimal wrinkleRate;
    /**
     * 层数
     */
	private String layer;
    /**
     * 分切幅宽合计
     */
	private String totalWidth;
    /**
     * 最小总幅宽
     */
	private BigDecimal minTotalWidth;
    /**
     * 最大总幅宽
     */
	private BigDecimal maxTotalWidth;
    /**
     * 直径
     */
	private BigDecimal diameter;
    /**
     * 最小直径
     */
	private BigDecimal minDiameter;
    /**
     * 最大直径
     */
	private BigDecimal maxDiameter;
    /**
     * 对应常规价格
     */
	private BigDecimal normalPrice;
    /**
     * 增加价格
     */
	private BigDecimal addPrice;
    /**
     * 执行价格
     */
	private BigDecimal price;
    /**
     * 开始时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date startDate;
    /**
     * 结束时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date endDate;
    /**
     * 是否享受政策
     */
	private Integer isPolicy;
    /**
     * 物理指标号
     */
	private String physicalNo;
    /**
     * 订单编号
     */
	private String orderNo;
    /**
     * 备注
     */
	private String remark;
    /**
     * 状态 (30：生效中
     40：已过期)
     */
	private Integer status;
    /**
     * 是否历史记录
     */
	private Integer isHistory;
    /**
     * 调整记录id
     */
	private Long adjustId;
    /**
     * 批次id
     */
	private Long batchId;
    /**
     * 是否删除
     */
	private Integer isDelete;
    /**
     * 创建人
     */
	private String createrId;
    /**
     * 创建时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date createTime;
    /**
     * 最后修改人
     */
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public BigDecimal getRation() {
		return ration;
	}

	public void setRation(BigDecimal ration) {
		this.ration = ration;
	}

	public BigDecimal getWrinkleRate() {
		return wrinkleRate;
	}

	public void setWrinkleRate(BigDecimal wrinkleRate) {
		this.wrinkleRate = wrinkleRate;
	}

	public String getLayer() {
		return layer;
	}

	public void setLayer(String layer) {
		this.layer = layer;
	}

	public String getTotalWidth() {
		return totalWidth;
	}

	public void setTotalWidth(String totalWidth) {
		this.totalWidth = totalWidth;
	}

	public BigDecimal getMinTotalWidth() {
		return minTotalWidth;
	}

	public void setMinTotalWidth(BigDecimal minTotalWidth) {
		this.minTotalWidth = minTotalWidth;
	}

	public BigDecimal getMaxTotalWidth() {
		return maxTotalWidth;
	}

	public void setMaxTotalWidth(BigDecimal maxTotalWidth) {
		this.maxTotalWidth = maxTotalWidth;
	}

	public BigDecimal getDiameter() {
		return diameter;
	}

	public void setDiameter(BigDecimal diameter) {
		this.diameter = diameter;
	}

	public BigDecimal getMinDiameter() {
		return minDiameter;
	}

	public void setMinDiameter(BigDecimal minDiameter) {
		this.minDiameter = minDiameter;
	}

	public BigDecimal getMaxDiameter() {
		return maxDiameter;
	}

	public void setMaxDiameter(BigDecimal maxDiameter) {
		this.maxDiameter = maxDiameter;
	}

	public BigDecimal getNormalPrice() {
		return normalPrice;
	}

	public void setNormalPrice(BigDecimal normalPrice) {
		this.normalPrice = normalPrice;
	}

	public BigDecimal getAddPrice() {
		return addPrice;
	}

	public void setAddPrice(BigDecimal addPrice) {
		this.addPrice = addPrice;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getIsPolicy() {
		return isPolicy;
	}

	public void setIsPolicy(Integer isPolicy) {
		this.isPolicy = isPolicy;
	}

	public String getPhysicalNo() {
		return physicalNo;
	}

	public void setPhysicalNo(String physicalNo) {
		this.physicalNo = physicalNo;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getIsHistory() {
		return isHistory;
	}

	public void setIsHistory(Integer isHistory) {
		this.isHistory = isHistory;
	}

	public Long getAdjustId() {
		return adjustId;
	}

	public void setAdjustId(Long adjustId) {
		this.adjustId = adjustId;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public Integer getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
