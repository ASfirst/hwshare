package com.hwagain.sp.price.api;

/**
 * <p>
 * 副品及承兑汇票结算差价表 服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-22
 */
public interface IImPriceDifferenceEditApi {
	
}
