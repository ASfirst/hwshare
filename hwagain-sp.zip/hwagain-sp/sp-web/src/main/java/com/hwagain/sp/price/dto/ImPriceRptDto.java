package com.hwagain.sp.price.dto;

import java.math.BigDecimal;
import java.util.Date;

import java.io.Serializable;

public class ImPriceRptDto extends ImPriceDto {

	private static final long serialVersionUID = 1L;

	private String classText;

	private String kindText;

	private String statusText;

	private Integer seqNum;

	private Integer rowSpan1;

	private Integer rowSpan2;

	private String isPolicyText;

	public Integer getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}

	public String getClassText() {
		return classText;
	}

	public void setClassText(String classText) {
		this.classText = classText;
	}

	public String getKindText() {
		return kindText;
	}

	public void setKindText(String kindText) {
		this.kindText = kindText;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	public Integer getRowSpan1() {
		return rowSpan1;
	}

	public void setRowSpan1(Integer rowSpan1) {
		this.rowSpan1 = rowSpan1;
	}

	public Integer getRowSpan2() {
		return rowSpan2;
	}

	public void setRowSpan2(Integer rowSpan2) {
		this.rowSpan2 = rowSpan2;
	}

	public String getIsPolicyText() {
		if (null != this.getIsPolicy()) {
			if (this.getIsPolicy() == 1)
				isPolicyText = "是";
			else
				isPolicyText = "否";
		}
		return isPolicyText;
	}

	public void setIsPolicyText(String isPolicyText) {
		this.isPolicyText = isPolicyText;
	}

}
