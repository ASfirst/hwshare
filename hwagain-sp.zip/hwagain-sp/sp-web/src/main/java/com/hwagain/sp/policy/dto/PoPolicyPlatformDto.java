package com.hwagain.sp.policy.dto;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
public class PoPolicyPlatformDto implements Serializable {

    private static final long serialVersionUID = 1L;
	private Boolean isImportWhite;
	private Boolean isImportColor;
	private Boolean is3900White;
	private Boolean is3900Color;
	private Boolean is1575White;
	private Boolean isAll;
	
	public PoPolicyPlatformDto() {
		// TODO Auto-generated constructor stub
	}
	
	public PoPolicyPlatformDto(Boolean isImportWhite, Boolean isImportColor, Boolean is3900White, Boolean is3900Color,
			Boolean is1575White, Boolean isAll) {
		super();
		this.isImportWhite = isImportWhite;
		this.isImportColor = isImportColor;
		this.is3900White = is3900White;
		this.is3900Color = is3900Color;
		this.is1575White = is1575White;
		this.isAll = isAll;
	}

	public Boolean getIsImportWhite() {
		return isImportWhite;
	}
	public void setIsImportWhite(Boolean isImportWhite) {
		this.isImportWhite = isImportWhite;
	}
	public Boolean getIsImportColor() {
		return isImportColor;
	}
	public void setIsImportColor(Boolean isImportColor) {
		this.isImportColor = isImportColor;
	}
	public Boolean getIs3900White() {
		return is3900White;
	}
	public void setIs3900White(Boolean is3900White) {
		this.is3900White = is3900White;
	}
	public Boolean getIs3900Color() {
		return is3900Color;
	}
	public void setIs3900Color(Boolean is3900Color) {
		this.is3900Color = is3900Color;
	}
	public Boolean getIs1575White() {
		return is1575White;
	}
	public void setIs1575White(Boolean is1575White) {
		this.is1575White = is1575White;
	}
	public Boolean getIsAll() {
		return isAll;
	}
	public void setIsAll(Boolean isAll) {
		this.isAll = isAll;
	}
	@Override
	public boolean equals(Object obj) {
        if(obj == this)  
            return true;  
        if(!(obj instanceof PoPolicyPlatformDto))  
            return false;  
          
        PoPolicyPlatformDto o = (PoPolicyPlatformDto)obj; 
        
        return (((boolean)o.is1575White == (boolean) is1575White)
				&& ((boolean)o.is3900Color == (boolean) is3900Color)
				&& ((boolean)o.is3900White == (boolean) is3900White)
				&& ((boolean)o.isImportColor == (boolean) isImportColor)
				&& ((boolean)o.isImportWhite == (boolean) isImportWhite)
				&& ((boolean) o.isAll == (boolean) isAll)
				);
	}
	@Override
	public int hashCode() {
		int result = 17;  
        result = result * 31 + isImportWhite.hashCode();  
        result = result * 31 + isImportColor.hashCode();  
        result = result * 31 + is3900Color.hashCode();
        result = result * 31 + is3900White.hashCode();
        result = result * 31 + is1575White.hashCode();
        result = result * 31 + isAll.hashCode();
        return result;  
	}
}
