package com.hwagain.sp.policy.api.impl;

import com.hwagain.sp.policy.api.IPoTransportApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author weibw
 * @since 2019-06-20
 */
@Service("poTransportApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoTransportApiImpl implements IPoTransportApi {
	
}
