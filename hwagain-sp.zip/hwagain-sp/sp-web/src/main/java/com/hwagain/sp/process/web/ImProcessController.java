package com.hwagain.sp.process.web;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import java.util.List;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponse;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.process.dto.ImProcessBatchProductDto;
import com.hwagain.sp.process.dto.ImProcessPriceEditDto;
import com.hwagain.sp.process.dto.ImProcessProductFilterDto;
import com.hwagain.sp.process.dto.ImProcessProductRptDto;
import com.hwagain.sp.process.dto.ImProductListDto;
import com.hwagain.sp.process.service.IImProcessBatchProductService;
import com.hwagain.sp.process.service.IImProcessPriceEditService;
import com.hwagain.sp.process.service.IImProcessService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
@RestController
@RequestMapping(value="/process/imProcess",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "【进口纸机】处理品收集", description = "【进口纸机】处理品收集")
public class ImProcessController extends BaseController{
	
	@Autowired
	IImProcessService imProcessService;
	@Autowired
	IImProcessBatchProductService imBatchProductService;
	@Autowired
	IImProcessPriceEditService imProcessPriceEditService;
	
	@RequestMapping("/processQueryList")
	@ApiOperation(value = "【处理品】查询列表", notes = "【处理品】查询列表", httpMethod = "GET")
	public Response processQueryList() {
		return SuccessResponseData.newInstance(imProcessService.findAll());
	}
	
	/**
	 * 按条件筛选处理品
	 * 
	 * @return
	 */
	@RequestMapping("/findProcessProduct")
	@ApiOperation(value = "查询处理品数据列表", notes = "查询处理品数据列表",httpMethod="GET")
	@ApiImplicitParams(
		{
			@ApiImplicitParam(name = "className", value = "品类", paramType = "query", required = true, dataType = "String") 
			,@ApiImplicitParam(name = "fmodel", value = "规格型号", paramType = "query", required = false, dataType = "String")
			,@ApiImplicitParam(name = "sDate", value = "生产开始日期", paramType = "query", required = true, dataType = "String")
			,@ApiImplicitParam(name = "eDate", value = "生产截止日期", paramType = "query", required = true, dataType = "String")
			,@ApiImplicitParam(name = "auxprod", value = "辅助属性", paramType = "query", required = false, dataType = "String")
			,@ApiImplicitParam(name = "sfnumber", value = "起始物料代码", paramType = "query", required = false, dataType = "String")
			,@ApiImplicitParam(name = "efnumber", value = "截止物料代码", paramType = "query", required = false, dataType = "String")
		}
	)
	public Response findProcessProduct(String className,String fmodel,String sDate,String eDate,String auxprod,String sfnumber,String efnumber){
		List<ImProcessProductFilterDto> list=imProcessService.findProcessProduct(className, fmodel, sDate, eDate, auxprod, sfnumber, efnumber);
		return SuccessResponseData.newInstance(list);
	}
	
	/**
	 * 确认获取处理品收集明细
	 * 
	 * @return
	 */
	@RequestMapping("/findProductList")
	@ApiOperation(value = "查询处理品数据列表", notes = "查询处理品数据列表",httpMethod="GET")
	@ApiImplicitParams(
		{
			@ApiImplicitParam(name = "paperNos", value = "纸卷编号,多个以逗号隔开", paramType = "query", required = true, dataType = "String")
			,@ApiImplicitParam(name = "platform", value = "平台类型", paramType = "query", required = true, dataType = "String")
		}
	)
	public Response findProductList(String paperNos,String platform){
		List<ImProductListDto> list=imProcessService.getProductDetail(paperNos, platform);
		return SuccessResponseData.newInstance(list);
	}
	
	/**
	 * 处理品收集-新增确认
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/confirmProcess",method={RequestMethod.POST})
	@ApiOperation(value = "处理品收集-新增确认", notes = "处理品收集-新增确认",httpMethod="POST")
	@ApiImplicitParams(
			{
				@ApiImplicitParam(name = "paperNos", value = "纸卷编号,多个以逗号隔开", paramType = "query", required = true, dataType = "String")
				,@ApiImplicitParam(name = "platform", value = "平台类型", paramType = "query", required = true, dataType = "String")
			}
		)
	public Response confirmProcess(String paperNos,String platform){
		return SuccessResponseData.newInstance(imProcessService.saveProcessProduct(paperNos, platform));
	}
	
	/**
	 * 处理品收集明细
	 * 
	 * @return
	 */
	@RequestMapping("/findProcessProductDetail")
	@ApiOperation(value = "处理品收集明细", notes = "处理品收集明细",httpMethod="GET")
	
	public Response findProcessProductDetail(){
		List<ImProcessProductRptDto> list=imProcessService.findProcessProductDetail();
		return SuccessResponseData.newInstance(list);
	}
	
	/**
	 * 新增处理品，主表和明细表同时插入
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/save",method={RequestMethod.POST})
	@ApiOperation(value = "新增处理品，主表和明细表同时插入", notes = "新增处理品，主表和明细表同时插入",httpMethod="POST")
	public Response save(@RequestBody List<ImProductListDto> productList){
		return SuccessResponseData.newInstance(imProcessService.save(productList));
	}
	
	/**
	 * 新增处理品，主表和明细表同时插入
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/collectFinish",method={RequestMethod.POST})
	@ApiOperation(value = "处理品收集-收集完成提交", notes = "处理品收集-收集完成提交",httpMethod="POST")
	@ApiImplicitParams(
		{
			@ApiImplicitParam(name = "ids", value = "处理品收集明细ID,多个以逗号(,)分割", paramType = "query", required = true, dataType = "String")
		}
	)
	public Response collectFinish(String ids){
		Boolean isOk = imProcessService.collectFinish(ids);
		return SuccessResponse.newInstance(isOk?"收集完成提交成功！":"收集完成提交失败！");
	}
	
	/**
	 * 删除处理品，主表和明细表同时删除
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/delete",method={RequestMethod.POST})
	@ApiOperation(value = "删除处理品，主表和明细表同时删除", notes = "删除处理品，主表和明细表同时删除",httpMethod="POST")
	@ApiImplicitParams(
			{
				@ApiImplicitParam(name = "fdId", value = "处理品主表ID", paramType = "query", required = true, dataType = "String")
			}
		)
	public Response delete(String fdId){
		Boolean isOk = imProcessService.delete(fdId);
		return SuccessResponse.newInstance(isOk?"删除成功！":"删除失败！");
	}
	
	/**
	 * 删除处理品明细
	 * 
	 * @param String ids
	 * @return
	 */
	@RequestMapping(value="/delProcessProductDetail",method={RequestMethod.POST})
	@ApiOperation(value = "处理品明细-删除", notes = "处理品明细-删除",httpMethod="POST")
	@ApiImplicitParams(
			{
				@ApiImplicitParam(name = "ids", value = "处理品收集明细ID,多个以逗号(,)分割", paramType = "query", required = true, dataType = "String")
			}
		)
	public Response delProcessProductDetail(String ids){
		Boolean isOk = imBatchProductService.deleteByIds(ids);
		return SuccessResponse.newInstance(isOk?"删除成功！":"删除失败！");
	}
	
	@RequestMapping(value = "/findProcessSaleList", method = { RequestMethod.GET })
	@ApiOperation(value = "高速纸机在售处理品明细", notes = "高速纸机在售处理品明细", httpMethod = "GET")
	public Response findProcessSaleList() {
		return SuccessResponseData.newInstance(imProcessService.queryProcessSaleList());
	}
	
	/**
	 * 在售处理品明细-终止销售
	 * 
	 * 
	 * @return
	 */
	@RequestMapping(value = "/finishProcessSale", method = { RequestMethod.POST})
	@ApiOperation(value = "处理品-终止销售", notes = "处理品-终止销售", httpMethod = "POST")
	public Response finishProcessSale() {
		Boolean isOk = imProcessService.finishSale();
		return SuccessResponse.newInstance(isOk?"处理品终止销售成功！":"处理品终止销售失败！");
	}
	
	/**
	 * 历次处理品销售明细
	 * 
	 */
	@RequestMapping("/queryProcessHistorySale")
	@ApiOperation(value = "历次处理品销售明细", notes = "历次处理品销售明细", httpMethod = "GET")
	public Response queryProcessHistorySale() {
		return SuccessResponseData.newInstance(imProcessService.queryProcessHistorySale());
	}
	
	/**
	 * 处理品销售明细表
	 * 
	 */
	@RequestMapping("/queryProcessSaleByBatch")
	@ApiOperation(value = "处理品销售明细表", notes = "处理品销售明细表", httpMethod = "GET")
	@ApiImplicitParams(
			{
				@ApiImplicitParam(name = "batchNo", value = "处理品批号", paramType = "query", required = true, dataType = "String")
			}
		)
	public Response queryProcessSaleByBatch(String batchNo) {
		return SuccessResponseData.newInstance(imProcessService.queryProcessSaleByBatch(batchNo));
	}
	
	/**
	 * 
	 * 高速纸机处理品价格录入表
	 * 
	 * @return
	 */
	@RequestMapping(value="/findProcessPriceList")
	@ApiOperation(value = "查询高速纸机处理品价格录入表", notes = "查询高速纸机处理品价格录入表",httpMethod="GET")
	public Response findProcessPriceList(){
		//return SuccessResponseData.newInstance(imProcessService.findProcessPriceList());
		return SuccessResponseData.newInstance(imProcessPriceEditService.findUserOrderHistory());
	}
	
	/**
	 * 高速纸机处理品价格录入表-处理品明细审核表
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/findByPriceId")
	@ApiOperation(value = "高速纸机处理品价格录入表-处理品明细审核表", notes = "高速纸机处理品价格录入表-处理品明细审核表",httpMethod="GET")
	@ApiImplicitParams(
		{
			@ApiImplicitParam(name = "priceId", value = "处理品价格表ID", paramType = "query", required = true, dataType = "String")
		}
	)
	public Response findByPriceId(String priceId){
		return SuccessResponseData.newInstance(imBatchProductService.findByPriceId(priceId));
	}
	
	/**
	 * 
	 * 高速纸机处理品价格录入表-审核
	 * 
	 * @return
	 */
	@RequestMapping(value = "/aduitProcessProduct", method = { RequestMethod.POST})
	@ApiOperation(value = "高速纸机处理品价格录入表-审核", notes = "高速纸机处理品价格录入表-审核", httpMethod = "POST")
	public Response aduitProcessProduct(@RequestBody List<ImProcessBatchProductDto> list) {
		Boolean isOk = imBatchProductService.audit(list);
		return SuccessResponse.newInstance(isOk?"处理品明细审核成功！":"处理品明细审核失败！");
	}
	
	/**
	 * 
	 * 高速纸机处理品价格录入表
	 * 
	 * @return
	 */
	@RequestMapping(value = "/saveProcessPrice", method = { RequestMethod.POST})
	@ApiOperation(value = "高速纸机处理品价格录入表-保存", notes = "高速纸机处理品价格录入表-保存", httpMethod = "POST")
	public Response saveProcessPrice(@RequestBody List<ImProcessPriceEditDto> list) {
		List<ImProcessPriceEditDto> list2=imProcessPriceEditService.addSomeProcessEdit(list);
		return SuccessResponseData.newInstance(list2);
	}
	
	/**
	 * 
	 * 高速纸机处理品价格录入表
	 * 
	 * @return
	 */
	@RequestMapping(value = "/submitCheck", method = { RequestMethod.POST})
	@ApiOperation(value = "高速纸机处理品价格录入表-提交校验", notes = "高速纸机处理品价格录入表-提交校验", httpMethod = "POST")
	public Response submitCheck() {
		Boolean isOk = imProcessPriceEditService.submitCheck();
		return SuccessResponse.newInstance(isOk?"处理品价格校验成功！":"处理品价格校验失败！");
	}
}
