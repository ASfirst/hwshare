package com.hwagain.sp.order.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author huangdh
 * @since 2018-11-16
 */
@TableName("im_pickup_order_detail_k3")
public class ImPickupOrderDetailK3 implements Serializable {

    private static final long serialVersionUID = 1L;

	@TableId("fd_id")
	private Long fdId;
    /**
     * 提货规格ID
     */
	@TableField("pickup_order_detail_id")
	private Long pickupOrderDetailId;
	@TableField("customer_id")
	private Long customerId;
	@TableField("order_no")
	private String orderNo;
    /**
     * 物料代码
     */
	@TableField("material_code")
	private String materialCode;
    /**
     * 物料名称
     */
	@TableField("material_name")
	private String materialName;
    /**
     * 规格名称，如：13.5克/1390mm/3层
     */
	private String spec;
    /**
     * 销量
     */
	@TableField("sale_weight")
	private BigDecimal saleWeight;
    /**
     * 库存
     */
	private BigDecimal stock;
    /**
     * 入库日期
     */
	@TableField("business_date")
	private Date businessDate;
	@TableField("creator_id")
	private String creatorId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 更新时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getPickupOrderDetailId() {
		return pickupOrderDetailId;
	}

	public void setPickupOrderDetailId(Long pickupOrderDetailId) {
		this.pickupOrderDetailId = pickupOrderDetailId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getMaterialCode() {
		return materialCode;
	}

	public void setMaterialCode(String materialCode) {
		this.materialCode = materialCode;
	}

	public String getMaterialName() {
		return materialName;
	}

	public void setMaterialName(String materialName) {
		this.materialName = materialName;
	}

	public String getSpec() {
		return spec;
	}

	public void setSpec(String spec) {
		this.spec = spec;
	}

	public BigDecimal getSaleWeight() {
		return saleWeight;
	}

	public void setSaleWeight(BigDecimal saleWeight) {
		this.saleWeight = saleWeight;
	}

	public BigDecimal getStock() {
		return stock;
	}

	public void setStock(BigDecimal stock) {
		this.stock = stock;
	}

	public Date getBusinessDate() {
		return businessDate;
	}

	public void setBusinessDate(Date businessDate) {
		this.businessDate = businessDate;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
