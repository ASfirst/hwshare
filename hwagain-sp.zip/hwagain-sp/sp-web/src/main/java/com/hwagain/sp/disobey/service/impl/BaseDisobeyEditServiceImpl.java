package com.hwagain.sp.disobey.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.alibaba.fastjson.JSONObject;
import com.hwagain.sp.base.mapper.RptTempMapper;
import com.hwagain.sp.disobey.entity.BaseDisobey;
import com.hwagain.sp.disobey.entity.BaseDisobeyEdit;
import com.hwagain.sp.disobey.dto.BaseDisobeyDto;
import com.hwagain.sp.disobey.dto.BaseDisobeyEditDto;
import com.hwagain.sp.disobey.mapper.BaseDisobeyEditMapper;
import com.hwagain.sp.disobey.service.IBaseDisobeyEditService;
import com.hwagain.sp.disobey.service.IBaseDisobeyService;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
@Service("baseDisobeyEditService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class BaseDisobeyEditServiceImpl extends ServiceImpl<BaseDisobeyEditMapper, BaseDisobeyEdit> implements IBaseDisobeyEditService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(BaseDisobeyEdit.class, BaseDisobeyEditDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(BaseDisobeyEditDto.class, BaseDisobeyEdit.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	@Autowired
	RptTempMapper rptTempMapper;
	@Autowired
	BaseDisobeyEditMapper baseDisobeyEditMapper;
	@Autowired
	IBaseDisobeyService baseDisobeyService;

//	@Override
//	public String getUserOrder() throws CustomException {
//		String cUserid = UserUtils.getUserId();
//		// 判断当前是否已经有2个人在录入
//		String sql = "select count(distinct  j.creater_id) c1 from base_disobey_edit j where `status`=0 "
//				+ "  and j.creater_id !='" + cUserid + "' ";
//		List<RptTempData> tmL1 = rptTempMapper.queryTempData(sql);
//		if (null != tmL1 && !tmL1.isEmpty()) {
//			if (Integer.valueOf(tmL1.get(0).getC1()) >= 2) {
//				Assert.throwException("当前已经有2个人正在录入");
//			}
//		}
//
//		String sql2 = " select distinct creater_id c1 from (  "
//				+ "	select creater_id from base_disobey_edit j where `status`=0   "
//				+ "	order by j.create_time ) t ";
//
//		List<RptTempData> tmL2 = rptTempMapper.queryTempData(sql2);
//		if (null == tmL2 || tmL2.isEmpty())
//			return "第一人";
//		else {
//			if (tmL2.get(0).getC1().equals(cUserid))
//				return "第一人";
//			else
//				return "第二人";
//		}
//	}
	//新增一条
	@Override
	public BaseDisobeyEditDto insert(BaseDisobeyEditDto dto) throws CustomException {
		Assert.notNull(dto, "没找到记录！");
		String cUserid = UserUtils.getUserId();
		Date doDate = new Date();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		Wrapper<BaseDisobeyEdit> wrapper=new CriterionWrapper<BaseDisobeyEdit>(BaseDisobeyEdit.class);
		wrapper.eq("disobey_content", dto.getDisobeyContent());
		wrapper.eq("unit", dto.getUnit());
		wrapper.eq("penalty_standard", dto.getPenaltyStandard());
		wrapper.eq("start_time", dto.getStartTime());
		wrapper.eq("status", 1);
		wrapper.eq("creater_id", cUserid);
		BaseDisobeyEdit obj=super.selectFirst(wrapper);
		if(obj!=null)
			super.updateById(dtoToEntityMapper.map(dto, BaseDisobeyEdit.class));
		else
		{
			dto.setFdId(IdWorker.getId());
			dto.setRemark(dto.getRemark());
			dto.setCreaterId(cUserid);
			dto.setCreateTime(doDate);
			dto.setRole(dept);
			dto.setStatus(1);
			super.insert(dtoToEntityMapper.map(dto, BaseDisobeyEdit.class));
		}
		return entityToDtoMapper.map(super.selectById(dto.getFdId()), BaseDisobeyEditDto.class);
	}

	@Override
	public List<BaseDisobeyEditDto> queryDisobeyEdit(String curUserId)
			throws CustomException {
		List<BaseDisobeyEditDto> list=baseDisobeyEditMapper.queryEditList(curUserId);
		return list;
	}

	@Override
	public List<BaseDisobeyEditDto> findDisobeyList(String disobeyContent,
			String unit, BigDecimal penaltyStandard) throws CustomException {
		String cUserid = UserUtils.getUserInfo().getName();
		Wrapper<BaseDisobeyEdit> wrapper=new CriterionWrapper<BaseDisobeyEdit>(BaseDisobeyEdit.class);
		wrapper.eq("creater_id", cUserid);
		wrapper.eq("disobey_content", disobeyContent);
		wrapper.eq("unit", unit);
		wrapper.eq("penalty_standard",penaltyStandard);
		wrapper.eq("status", 1);
		List<BaseDisobeyEdit> list=super.selectList(wrapper);
		Wrapper<BaseDisobey> wrapper1=new CriterionWrapper<BaseDisobey>(BaseDisobey.class);
		wrapper1.eq("disobey_content", disobeyContent);
		wrapper1.eq("unit", unit);
		wrapper1.eq("penalty_standard",penaltyStandard);
		wrapper1.eq("status", 1);
		List<BaseDisobey> list1=baseDisobeyService.selectList(wrapper1);
		String st=JSONObject.toJSONString(list1.get(0));
		BaseDisobeyEdit list11=JSONObject.parseObject(st,BaseDisobeyEdit.class);
		List<BaseDisobeyEdit> listA=new ArrayList<>();
		if(list.size()==0){
			listA.add(list11);
		}else{
			listA.addAll(list);
			
		}
		return entityToDtoMapper.mapAsList(listA, BaseDisobeyEditDto.class);
	}

	@Override
	public List<BaseDisobeyEditDto> matching(List<BaseDisobeyEditDto> list)
			throws CustomException {
		Wrapper<BaseDisobeyEdit> wrapper0=new CriterionWrapper<BaseDisobeyEdit>(BaseDisobeyEdit.class);
		wrapper0.eq("status",1);		
		List<BaseDisobeyEdit> list0=super.selectList(wrapper0);
		if(list0.size()==0){
			Assert.throwException("数据未调整");
		}
		if(list!=null && list.size()==0){
			Assert.throwException("提交数据为空");
		}
		List<BaseDisobeyEdit> listA=new ArrayList<>();
		List<BaseDisobeyDto> listB=new ArrayList<>();
		for(BaseDisobeyEditDto dto:list){
			//原始数据
			Wrapper<BaseDisobeyEdit> wrapper1=new CriterionWrapper<BaseDisobeyEdit>(BaseDisobeyEdit.class);
			wrapper1.eq("fd_id", dto.getFdId());		
			BaseDisobeyEdit list1=super.selectFirst(wrapper1);
			String st=JSONObject.toJSONString(list1);
			BaseDisobeyDto bddto=JSONObject.parseObject(st,BaseDisobeyDto.class);
			Wrapper<BaseDisobeyEdit> wrapper=new CriterionWrapper<BaseDisobeyEdit>(BaseDisobeyEdit.class);
			wrapper.eq("disobey_content", dto.getDisobeyContent());
			wrapper.eq("unit", dto.getUnit());
			wrapper.eq("penalty_standard",dto.getPenaltyStandard());
			wrapper.eq("status", 1);
			wrapper.eq("start_time", dto.getStartTime());
			wrapper.notIn("creater_id", dto.getCreaterId());
			wrapper.notIn("role",dto.getRole());
			BaseDisobeyEdit list2=super.selectFirst(wrapper);
			if(list==null){
				Assert.throwException("匹配失败");
			}else{
				listA.add(list2);
				listA.add(list1);
				listB.add(bddto);
			}
		}
		for(BaseDisobeyEdit dto:listA){
			BaseDisobeyEdit impe=new BaseDisobeyEdit();
			impe.setFdId(dto.getFdId());
			impe.setStatus(10);
			super.updateById(impe);
		}
		for(BaseDisobeyDto dto:listB){
			baseDisobeyService.updateOne(dto);
		}
		return list;
	}

	@Override
	public BaseDisobeyEditDto updateOneDisobey(String fdId,String disobeyContent,String unit,BigDecimal penaltyStandard,Date startDate,String remark)
			throws CustomException {
		Assert.notBlank(fdId, "修改记录id不能为空");
		Assert.notBlank(disobeyContent, "违约事项不能为空");
		Assert.notBlank(unit, "计算单位不能为空");
		Assert.notNull(penaltyStandard, "扣款标准不能为空");
		Assert.notNull(startDate, "开始日期不能为空");
		BaseDisobeyEdit bde=super.selectById(fdId);
		Assert.notNull(bde, "没有找到需要修改的记录");
		if (bde.getStatus() == 1)
			Assert.throwException("记录已经生效,不允许修改");
		Date doDate = new Date();
		String cUsaerid = UserUtils.getUserId();

		bde.setDisobeyContent(disobeyContent);
		bde.setUnit(unit);
		bde.setPenaltyStandard(penaltyStandard);
		bde.setStartTime(startDate);
		bde.setRemark(remark);
		bde.setLastAlterTime(doDate);
		bde.setLastAlterId(cUsaerid);

		Wrapper<BaseDisobeyEdit> wrapper = new CriterionWrapper<BaseDisobeyEdit>(BaseDisobeyEdit.class);
		wrapper.eq("disobey_content", disobeyContent);
		wrapper.eq("unit", unit);
		//wrapper.eq("penalty_standard", penaltyStandard);
		//wrapper.eq("start_time", startDate);
		wrapper.eq("status", 0);
		wrapper.ne("creater_id", cUsaerid);
		BaseDisobeyEdit obj = super.selectFirst(wrapper);

		if (null != obj && null != obj.getDisobeyContent() && null != obj.getUnit()) {
			Boolean b1 = penaltyStandard.compareTo(obj.getPenaltyStandard()) == 0;
			Boolean b2 = startDate.compareTo(obj.getStartTime()) == 0;

			if (b1 && b2) {
				bde.setStatusText("校验通过");
				bde.setStatus(1);
				super.updateAllById(bde);

				obj.setStatusText("校验通过");
				obj.setStatus(1);
				obj.setLastAlterTime(doDate);
				obj.setLastAlterId(cUsaerid);
				super.updateAllById(obj);
				
				//更新违约扣款标准终止日期
				Wrapper<BaseDisobey> b=new CriterionWrapper<BaseDisobey>(BaseDisobey.class);
				b.eq("disobey_content", obj.getDisobeyContent());
				b.eq("unit", obj.getUnit());
				//b.eq("penalty_standard", obj.getPenaltyStandard());
				//b.eq("start_time", obj.getStartTime());
				b.isNull("end_time");
				BaseDisobey bd=baseDisobeyService.selectOne(b);
				if(null != bd)
				{
					bd.setLastAlterId(cUsaerid);
					bd.setLastAlterTime(doDate);
					bd.setEndTime(obj.getStartTime());
					bd.setStatus(2);//历史
					baseDisobeyService.updateAllById(bd);
				}
				

				// 插入违约扣款标准表
				BaseDisobey bdObj = new BaseDisobey();
				bdObj.setFdId(IdWorker.getId());
				bdObj.setDisobeyContent(disobeyContent);
				bdObj.setUnit(unit);
				bdObj.setPenaltyStandard(penaltyStandard);
				bdObj.setStartTime(startDate);
				bdObj.setRemark(remark);
				bdObj.setCreaterId(cUsaerid);
				bdObj.setCreateTime(doDate);
				baseDisobeyService.insert(bdObj);
				
			} else {
				bde.setStatusText("校验未通过,请核对录入信息");
				super.updateAllById(bde);
			}
		} else {
			bde.setStatusText("等待校验");
			super.updateAllById(bde);
		}

		return entityToDtoMapper.map(bde, BaseDisobeyEditDto.class);
	}

	@Override
	public List<BaseDisobeyEditDto> updateMoreDisobey(
			List<BaseDisobeyEditDto> list) throws CustomException {
		List<BaseDisobeyEditDto> list2 = new ArrayList<BaseDisobeyEditDto>();

		int i = 1;
		for (BaseDisobeyEditDto dto : list) {
			BaseDisobeyEdit p = super.selectById(String.valueOf(dto.getFdId()));
			Assert.notNull(p, "第" + String.valueOf(i) + "条纪录,没有找到");
			if (p.getStatus() == 1)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,已经生效,不允许修改");
			Assert.notNull(dto.getFdId(), "第" + String.valueOf(i) + "条纪录,修改记录id不能为空");
			Assert.notBlank(dto.getUnit(), "计量单位不能为空");
			Assert.notBlank(dto.getDisobeyContent(), "违约事项不能为空");
			Assert.notNull(dto.getPenaltyStandard(), "第" + String.valueOf(i) + "条纪录,扣款标准不能为空");
			Assert.notNull(dto.getStartTime(), "第" + String.valueOf(i) + "条纪录,开始日期不能为空");

			i++;
		}

		for (BaseDisobeyEditDto dto : list) {
			list2.add(updateOneDisobey(String.valueOf(dto.getFdId()), dto.getDisobeyContent(), dto.getUnit(),
					dto.getPenaltyStandard(),dto.getStartTime(), dto.getRemark()));
		}

		return list2;
	}

	@Override
	public Boolean deleteByIds(String ids) throws CustomException {
		String[] id = ids.split(";");
		return super.deleteBatchIds(Arrays.asList(id));
	}

	
	
	
}
