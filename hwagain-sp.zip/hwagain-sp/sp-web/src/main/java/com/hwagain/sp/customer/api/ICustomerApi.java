package com.hwagain.sp.customer.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author hanj
 * @since 2018-10-11
 */
public interface ICustomerApi {
	
}
