package com.hwagain.sp.deposit.service.impl;

import com.hwagain.sp.deposit.entity.DDepositStandard;
import com.hwagain.sp.deposit.entity.DDepositStandardEdit;
import com.hwagain.sp.deposit.entity.DNoDepositCustomer;
import com.hwagain.sp.deposit.entity.DNoDepositStandard;
import com.hwagain.sp.deposit.dto.DDepositStandardDto;
import com.hwagain.sp.deposit.dto.DDepositStandardEditDto;
import com.hwagain.sp.deposit.dto.DNoDepositCustomerDto;
import com.hwagain.sp.deposit.mapper.DNoDepositCustomerMapper;
import com.hwagain.sp.deposit.service.IDNoDepositCustomerService;
import com.hwagain.sp.deposit.service.IDNoDepositStandardService;
import com.hwagain.sp.product.dto.ProductOutStockDto;
import com.hwagain.sp.product.entity.ProductClass;
import com.hwagain.sp.product.service.IProductClassService;
import com.hwagain.sp.product.service.impl.ProductServiceImpl;
import com.hwagain.sp.product.web.ProductController;
import com.hwagain.sp.util.JDBCConfig;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.core.util.SpringBeanUtil;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.crypto.Data;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-05
 */
@Service("dNoDepositCustomerService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DNoDepositCustomerServiceImpl extends ServiceImpl<DNoDepositCustomerMapper, DNoDepositCustomer> implements IDNoDepositCustomerService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	@Autowired DNoDepositCustomerMapper dNodepositcustomerMapper;
	@Autowired IProductClassService productClassService;
	@Autowired ProductServiceImpl productServiceImpl;
	@Autowired ProductController productController;
    @Autowired DNoDepositStandardServiceImpl depositStandardServiceImpl;
    @Autowired IDNoDepositStandardService dNoDepositStandardService;
	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(DNoDepositCustomer.class, DNoDepositCustomerDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(DNoDepositCustomerDto.class, DNoDepositCustomer.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	@Override
	public List<DNoDepositCustomerDto> findAll(Date queryTime){
	
		System.err.println("测试");
		String custName="南昌星晨纸业有限公司";
		String itemNumber="";
		String auxNumber=""; 
		String startDate="2018-11-01"; 
		String endDate="2018-11-30"; 
		Integer iType=2;
		List<ProductOutStockDto> prodOSList=productServiceImpl.GetProductOutStock(custName, itemNumber, auxNumber, startDate, endDate, iType);
//		System.err.println(prodOSList.size());
		BigDecimal qty=new BigDecimal(0);
		for(ProductOutStockDto dto:prodOSList){
			qty=qty.add(dto.getqty());
		}
		System.err.println(qty);
		return null;
		
	}
	@Override
	public List<DNoDepositCustomerDto> inputQueryNoDepoProd(int year,int month){
		//
		Date monthDate=null;
		Date monthDate1=null;
		Date monthDate2=null;
		String a="-";
		String monthTime=year+a+(month-1)+"-01";
		String monthTime1=year+a+(month)+"-02";
		String startTime="2018-11-01";
//		System.err.println(monthTime1);
		Date startDate=null; 
		try {
//			startDate = new SimpleDateFormat("yyyy-MM-dd").parse(startTime);
			monthDate=new SimpleDateFormat("yyyy-MM").parse(monthTime);
			monthDate1=new SimpleDateFormat("yyyy-MM").parse(monthTime1);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<DNoDepositCustomer> list=new ArrayList<>();
		Wrapper<DNoDepositStandard> wrapperSt=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
		wrapperSt.eq("is_history", 1);
		wrapperSt.orderBy("create_time");
		List<DNoDepositStandard> standardList=dNoDepositStandardService.selectList(wrapperSt);
		int t=0;
		for(DNoDepositStandard dto:standardList){
			t++;
			if(monthDate.before(dto.getEndTime())){
				list=dNodepositcustomerMapper.inputQueryNoDepoProdHistory(monthDate);
				break;
			}
		}
		if(list.size()==0){
			list=dNodepositcustomerMapper.inputQueryNoDepoProd(monthDate);
		}
		Wrapper<ProductClass> wrapperClass=new CriterionWrapper<ProductClass>(ProductClass.class);
		wrapperClass.eq("platform", "Import");
		List<ProductClass> allClass=productClassService.selectList(wrapperClass);
		if(list!=null&&list.size()!=0&&allClass!=null&&allClass.size()!=0){
			for(int i=0;i<list.size();i++){
				for(int j=0;j<allClass.size();j++){
					if(list.get(i).getClassNo().equals(allClass.get(j).getClassNo())){
						list.get(i).setClassNo(allClass.get(j).getName());
					}
				}
			}
			for(int i=0;i<list.size();i++){
				BigDecimal  weight=list.get(i).getOrderWeight();  
				for(int j=i+1;j<list.size();j++){					
					if(list.get(i).getEnterpriseSetNo().equals(list.get(j).getEnterpriseSetNo())&&
							list.get(i).getWidth().equals(list.get(j).getWidth())){
						weight=weight.add(list.get(j).getOrderWeight());
						list.get(i).setOrderWeight(weight);
						list.remove(j);
					}
				}
			}
			for(DNoDepositCustomer dto:list){
				Wrapper<DNoDepositCustomer> wrapper=new CriterionWrapper<DNoDepositCustomer>(DNoDepositCustomer.class);
				wrapper.eq("month_date", monthDate1);
				wrapper.eq("enterprise_set_no", dto.getEnterpriseSetNo());
				wrapper.eq("width", dto.getWidth());
				List<DNoDepositCustomer> listA=super.selectList(wrapper);
				System.err.println(listA.size());
				if(listA.size()==0){
					
					dto.setFdId(Long.valueOf(IdWorker.getId()));
					dto.setDeliveryWeight(new BigDecimal("0"));
					dto.setDeliveryWeight2(new BigDecimal("0"));
					dto.setYear(year);
					dto.setMonth(month-1);
					dto.setMonthDate(monthDate1);
					dto.setCreateTime(new Date());
					super.insert(dto);
				}
				
			}
		}
		Wrapper<DNoDepositCustomer> wrapper1=new CriterionWrapper<DNoDepositCustomer>(DNoDepositCustomer.class);
		wrapper1.eq("month_date", monthDate1);
		List<DNoDepositCustomer> list1=super.selectList(wrapper1);
		BigDecimal weight=new BigDecimal("0");
		
		Wrapper<DNoDepositCustomer> wrapper2=new CriterionWrapper<DNoDepositCustomer>(DNoDepositCustomer.class);
		wrapper2.eq("month_date", monthDate);
		List<DNoDepositCustomer> list2=super.selectList(wrapper2);
		System.err.println(list2.size());
		for(DNoDepositCustomer dto1:list1){
			for(DNoDepositCustomer dto2:list2){
				if(dto1.getEnterpriseSetNo().equals(dto2.getEnterpriseSetNo())&&dto1.getWidth().equals(dto2.getWidth())){
					dto1.setOrderWeight2(dto2.getOrderWeight());
					super.updateById(dto1);
				}
			}
				
		}
		return entityToDtoMapper.mapAsList(list, DNoDepositCustomerDto.class);		
	}
	@Override
	public List<DNoDepositCustomerDto> findNoDepositStandardList(Date monthDate){
//		System.err.println(monthDate);
		if(monthDate== null){
			monthDate=new Date();
		}
		Date monthDate1=null;
//		Date monthDate2=null;
		DateFormat df = new SimpleDateFormat("yyyy-MM");
		String monthTime = df.format(monthDate);
		try {
			monthDate1 = df.parse(monthTime);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		List<DNoDepositCustomer> listA=new ArrayList<>();
		List<DNoDepositCustomer> listB=new ArrayList<>();
		List<DNoDepositCustomer> listA1=new ArrayList<>();
		Wrapper<DNoDepositCustomer> wrapper1=new CriterionWrapper<DNoDepositCustomer>(DNoDepositCustomer.class);
		wrapper1.eq("month_date", monthDate1);
		List<DNoDepositCustomer> list1=super.selectList(wrapper1);
//		listA.addAll(list1);
		System.err.println(list1.size());
		
		for(int i=0;i<list1.size();i++){
			BigDecimal oweight1=new BigDecimal("0");
			BigDecimal oweight2=new BigDecimal("0");
			BigDecimal dweight1=new BigDecimal("0");
			BigDecimal dweight2=new BigDecimal("0");
			oweight1=list1.get(i).getOrderWeight();
			oweight2=list1.get(i).getOrderWeight2();
			dweight1=list1.get(i).getDeliveryWeight();
			dweight2=list1.get(i).getDeliveryWeight2();
			for(int j=i+1;j<list1.size();j++){
				if(list1.get(j).getEnterpriseSetNo().equals(list1.get(i).getEnterpriseSetNo())){
					oweight1=oweight1.add(list1.get(j).getOrderWeight());
					oweight2=oweight2.add(list1.get(j).getOrderWeight2());
					dweight1=dweight1.add(list1.get(j).getDeliveryWeight());
					dweight2=dweight2.add(list1.get(j).getDeliveryWeight2());
					list1.remove(j);
				}
				
			}
			if(oweight1.compareTo(list1.get(i).getMonthOrderWeight())>=0&&
					oweight2.compareTo(list1.get(i).getMonthOrderWeight())>=0&&
					dweight1.compareTo(list1.get(i).getMonthDeliveryWeight())>=0&&
					dweight2.compareTo(list1.get(i).getMonthDeliveryWeight())>=0){
				list1.get(i).setOrderWeight(oweight1);
				list1.get(i).setOrderWeight2(oweight2);
				list1.get(i).setDeliveryWeight(dweight1);
				list1.get(i).setDeliveryWeight2(dweight2);
				list1.get(i).setWidth("小计");
				list1.get(i).setProductName("小计");
				listB.add(list1.get(i));
				listA.add(list1.get(i));
			}
		}
		System.err.println(listB.size());
		int t=-1;
		for(DNoDepositCustomer dto:listB){
			t++;
			System.err.println(dto.getEnterpriseSetNo());
			Wrapper<DNoDepositCustomer> wrapperB=new CriterionWrapper<DNoDepositCustomer>(DNoDepositCustomer.class);
			wrapperB.eq("month_date", monthDate1);
			wrapperB.eq("enterprise_set_no", dto.getEnterpriseSetNo());
			List<DNoDepositCustomer> listB1=super.selectList(wrapperB);
			listA1.addAll(listB1);
			listA1.add(listA.get(t));
		}
		
		return entityToDtoMapper.mapAsList(listA1, DNoDepositCustomerDto.class);
		
	}
	//查询所有当月不收定金企业套产品
	@Override
	public List<DNoDepositCustomerDto> findAllNoDepositProd(){
		Date monthDate=new Date();
		List<DNoDepositCustomerDto> list=findNoDepositStandardList(monthDate);
		if(list.size()>0){
			for(int i=0;i<list.size();i++){
				for(int j=i+1;j<list.size();j++){
					if(list.get(i).getEnterpriseSetNo().equals(list.get(j).getEnterpriseSetNo())){
						list.remove(j);
					}
				}
			}
		}
		return entityToDtoMapper.mapAsList(list, DNoDepositCustomerDto.class);
		
	}
}
