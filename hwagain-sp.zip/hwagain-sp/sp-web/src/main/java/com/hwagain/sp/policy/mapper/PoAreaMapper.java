package com.hwagain.sp.policy.mapper;

import com.hwagain.sp.policy.entity.PoArea;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;
import com.hwagain.sp.product.dto.ProductBaseExtDto;

import java.util.List;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author weibw
 * @since 2019-06-24
 */
public interface PoAreaMapper extends BaseMapper<PoArea> {


    public List<ProductBaseExtDto> listAreaAndCustomer();

}