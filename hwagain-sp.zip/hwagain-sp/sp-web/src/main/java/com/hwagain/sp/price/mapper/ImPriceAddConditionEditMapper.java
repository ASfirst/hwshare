package com.hwagain.sp.price.mapper;

import com.hwagain.sp.price.entity.ImPriceAddConditionEdit;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  * 小幅宽产品加价表 Mapper 接口
 * </p>
 *
 * @author xionglz
 * @since 2018-11-21
 */
public interface ImPriceAddConditionEditMapper extends BaseMapper<ImPriceAddConditionEdit> {

}