package com.hwagain.sp.process.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.process.service.IImProcessPriceEditService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huanglf
 * @since 2018-12-20
 */
@RestController
@RequestMapping(value="/process/imProcessPriceEdit",method={RequestMethod.GET,RequestMethod.POST})
public class ImProcessPriceEditController extends BaseController{
	
	@Autowired
	IImProcessPriceEditService imProcessPriceEditService;
	
}
