package com.hwagain.sp.deposit.mapper;

import com.hwagain.sp.deposit.dto.DNoDepositCustomerDto;
import com.hwagain.sp.deposit.entity.DNoDepositCustomer;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author xionglz
 * @since 2018-11-05
 */
public interface DNoDepositCustomerMapper extends BaseMapper<DNoDepositCustomer> {
	public List<DNoDepositCustomer> inputQueryNoDepoProd(@Param("monthDate")Date monthDate);
	public List<DNoDepositCustomer> inputQueryNoDepoProdHistory(@Param("monthDate")Date monthDate);

}