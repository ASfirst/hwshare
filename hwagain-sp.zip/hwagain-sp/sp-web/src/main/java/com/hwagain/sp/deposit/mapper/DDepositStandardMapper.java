package com.hwagain.sp.deposit.mapper;

import com.hwagain.sp.deposit.dto.DDepositStandardDto;
import com.hwagain.sp.deposit.entity.DDepositStandard;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author xionglz
 * @since 2018-11-05
 */
public interface DDepositStandardMapper extends BaseMapper<DDepositStandard> {
	public List<DDepositStandard> inputQueryDepo();

	//求订单非常规品每吨要交多少订金？
	public DDepositStandard findOrderDepositByKindNo(@Param("kindNo") String kindNo);
	
}