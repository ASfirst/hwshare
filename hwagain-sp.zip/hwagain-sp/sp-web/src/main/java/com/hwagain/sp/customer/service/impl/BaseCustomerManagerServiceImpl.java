package com.hwagain.sp.customer.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hwagain.framework.core.dto.PageVO;
import com.hwagain.framework.core.util.ArraysUtil;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.plugins.Page;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;
import com.hwagain.sp.customer.dto.BaseCustomerManagerDto;
import com.hwagain.sp.customer.dto.CustomerDto;
import com.hwagain.sp.customer.entity.BaseCustomerManager;
import com.hwagain.sp.customer.mapper.BaseCustomerManagerMapper;
import com.hwagain.sp.customer.service.IBaseCustomerManagerService;
import com.hwagain.sp.customer.service.ICustomerService;
import com.hwagain.util.PageDto;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-28
 */
@Service("baseCustomerManagerService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class BaseCustomerManagerServiceImpl extends ServiceImpl<BaseCustomerManagerMapper, BaseCustomerManager> implements IBaseCustomerManagerService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	@Autowired ICustomerService customerService;
	@Autowired CustomerServiceImpl customerServiceImpl;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(BaseCustomerManager.class, BaseCustomerManagerDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(BaseCustomerManagerDto.class, BaseCustomerManager.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	//初始化客户数据
	@Override
	public List<BaseCustomerManagerDto> findAll(){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String curUserId = UserUtils.getUserId();
		String endTimea="2035-11-30";
		Date endTime = null;
		try {
			endTime = new SimpleDateFormat("yyyy-MM-dd").parse(endTimea);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		List<CustomerDto> allCustomer=customerServiceImpl.findCooperatingCustomer();
		Wrapper<BaseCustomerManager> wrapper=new CriterionWrapper<BaseCustomerManager>(BaseCustomerManager.class);
		wrapper.eq("end_time", "2035-11-30");
		List<BaseCustomerManager> list=super.selectList(wrapper);
//		System.err.println(list);
		if(list!=null&&list.size()==0){
			for(CustomerDto dto:allCustomer){
				BaseCustomerManager bcust=new BaseCustomerManager();
				bcust.setFdId(Long.valueOf(IdWorker.getId()));
				bcust.setCustomerId(dto.getFdId());
				bcust.setCustomerName(dto.getCustName());
				bcust.setCustomerType(dto.getCustTypeName());
				bcust.setCity(dto.getCity());
				bcust.setProvince(dto.getProvince());
				bcust.setCreaterId(curUserId);
				bcust.setCreateTime(doDate);
				bcust.setEndTime(endTime);
				super.insert(bcust);
			}
		}else{
			for(CustomerDto dto:allCustomer){
				int i=0;
				for(BaseCustomerManager bdto:list){
					i++;
					if(dto.getFdId().equals(bdto.getCustomerId())){
						bdto.setFdId(bdto.getFdId());
						bdto.setCustomerName(dto.getCustName());
						bdto.setProvince(dto.getProvince());
						bdto.setCity(dto.getCity());
						bdto.setCustomerType(dto.getCustTypeName());
						super.updateById(bdto);
						break;
					}
					if(i==list.size()){
						bdto.setFdId(Long.valueOf(IdWorker.getId()));
						bdto.setCustomerId(dto.getFdId());
						bdto.setCustomerName(dto.getCustName());
						bdto.setCustomerType(dto.getCustTypeName());
						bdto.setCity(dto.getCity());
						bdto.setProvince(dto.getProvince());
						bdto.setCreaterId(curUserId);
						bdto.setCreateTime(doDate);
						bdto.setEndTime(endTime);
						super.insert(bdto);
					}
				}
			}
		}
		Wrapper<BaseCustomerManager> wrapper1=new CriterionWrapper<BaseCustomerManager>(BaseCustomerManager.class);
		wrapper1.eq("end_time", "2035-11-30");
		wrapper1.orderBy("province");
		wrapper1.orderBy("city");
		
		List<BaseCustomerManager> list1=super.selectList(wrapper1);
		return entityToDtoMapper.mapAsList(list1, BaseCustomerManagerDto.class);
	}
	@Override
	public BaseCustomerManagerDto editOne(BaseCustomerManagerDto dto){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String curUserId = UserUtils.getUserId();
		String endTimea="2035-11-30";
		Date endTime = null;
		try {
			endTime = new SimpleDateFormat("yyyy-MM-dd").parse(endTimea);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Wrapper<BaseCustomerManager> wrapper=new CriterionWrapper<BaseCustomerManager>(BaseCustomerManager.class);
		wrapper.eq("customer_id", dto.getCustomerId());
		wrapper.eq("end_time", endTimea);
		BaseCustomerManager list=super.selectFirst(wrapper);
		if(list.getEndTime()==endTime){
			dto.setFdId(list.getFdId());
			dto.setOperator(cUserid);
			dto.setStartTime(doDate);
			super.updateById(dtoToEntityMapper.map(dto, BaseCustomerManager.class));
		}else{
			BaseCustomerManager bacu=new BaseCustomerManager();
			bacu.setFdId(list.getFdId());
			bacu.setEndTime(doDate);
			bacu.setLastAlterId(curUserId);
			bacu.setLastAlterTime(doDate);
			super.updateById(bacu);
			dto.setFdId(Long.valueOf(IdWorker.getId()));
			dto.setOperator(cUserid);
			dto.setStartTime(doDate);
			super.insert(dtoToEntityMapper.map(dto, BaseCustomerManager.class));
		}
		return entityToDtoMapper.map(list.getFdId(), BaseCustomerManagerDto.class);
	}
	
	@Override
	public PageDto<BaseCustomerManagerDto> findAllByPage(PageVO page){
		Wrapper<BaseCustomerManager> wrapper=new CriterionWrapper<BaseCustomerManager>(BaseCustomerManager.class);
		//wrapper.eq("end_time", "2035-11-30");
		wrapper.orderBy("province");
		wrapper.orderBy("city");
		PageDto<BaseCustomerManagerDto> result = new PageDto<>();
		Page<BaseCustomerManager> page2 = super.selectPage(new Page<BaseCustomerManager>(page.getPage()+1, page.getPageSize()), wrapper);
		if (ArraysUtil.notEmpty(page2.getRecords())) {
			result.setList(entityToDtoMapper.mapAsList(page2.getRecords(), BaseCustomerManagerDto.class));
		}
		result.setPage(page.getPage());
		result.setPageSize(page.getPageSize());
		result.setRowCount(page2.getTotal());
		return result;
	}
	
	@Override
	public BaseCustomerManagerDto editOneOnly(BaseCustomerManagerDto dto){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String curUserId = UserUtils.getUserId();
		
		Wrapper<BaseCustomerManager> wrapper=new CriterionWrapper<BaseCustomerManager>(BaseCustomerManager.class);
		wrapper.eq("CUSTOMER_ID", dto.getCustomerId());
		wrapper.eq("FD_ID", dto.getFdId());
		super.selectOne(wrapper);
		BaseCustomerManager entity=super.selectFirst(wrapper);
		entity.setBillOperator(dto.getBillOperator());
		entity.setSaleManager(dto.getSaleManager());
		entity.setRunningMan(dto.getRunningMan());
		entity.setOperator(cUserid);
		entity.setLastAlterId(curUserId);
		entity.setLastAlterTime(doDate);
		super.updateById(entity);
		
		return entityToDtoMapper.map(entity, BaseCustomerManagerDto.class);
	}
	@Override
	public BaseCustomerManagerDto addOne(BaseCustomerManagerDto dto) {
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String curUserId = UserUtils.getUserId();
		dto.setLastAlterId(curUserId);
		dto.setOperator(cUserid);
		dto.setLastAlterTime(doDate);
		BaseCustomerManager entity = dtoToEntityMapper.map(dto, BaseCustomerManager.class);
		super.insert(entity);
		return dto;
	}
}
