package com.hwagain.sp.policy.web;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.policy.dto.PoOverDto;
import com.hwagain.sp.policy.service.IPoOverService;

import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
@RestController
@RequestMapping(value="/policy/poOver",method={RequestMethod.GET,RequestMethod.POST})
public class PoOverController extends BaseController{
	private static Logger logger = LoggerFactory.getLogger(PoPolicyController.class);
	
	@Autowired
	IPoOverService poOverService;
	
	@RequestMapping("/findPolicyMaintainOver")
	@ApiOperation(value="当月生活原纸【超量奖】维护奖励标准维护表查询",notes="当月生活原纸【超量奖】维护奖励标准维护表查询",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="fdYear",value="当月年份",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="fdMonth",value="当月月份",paramType = "query", required = false, dataType = "String"),
	})
	public Response findPolicyMaintainOver(String fdYear, String fdMonth){
		logger.info("findCurrentPolicyMaintain: fdYear="+fdYear+", fdMonth="+fdMonth);
		Map<String, Object> params = new HashMap<>();
		params.put("fdYear", fdYear);
		params.put("fdMonth", fdMonth);
		return SuccessResponseData.newInstance(poOverService.findListByParams(params));
	}
	

	@RequestMapping("/addPolicyMaintainOver")
	@ApiOperation(value="当月生活原纸【超量奖】维护奖励标准维护表添加",notes="当月生活原纸【超量奖】维护奖励标准维护表添加",httpMethod="POST")
	public Response addPolicyMaintainOver(@RequestBody PoOverDto dto){
		logger.info("findCurrentPolicyMaintain: fdYear="+dto.getFdYear()+", fdMonth="+dto.getFdMonth());
		return SuccessResponseData.newInstance(poOverService.saveOne(dto));
	}
	
	@RequestMapping("/deletePolicyMaintainOver")
	@ApiOperation(value="当月生活原纸【超量奖】维护奖励标准维护表删除",notes="当月生活原纸【超量奖】维护奖励标准维护表删除",httpMethod="POST")
	@ApiImplicitParams({
		@ApiImplicitParam(name="fdId",value="记录ID",paramType = "query", required = false, dataType = "String"),
	})
	public Response addPolicyMaintainOver(String fdId){
		logger.info("deleteCurrentPolicyMaintain: fdId="+fdId);
		return SuccessResponseData.newInstance(poOverService.deleteOne(fdId));
	}
}
