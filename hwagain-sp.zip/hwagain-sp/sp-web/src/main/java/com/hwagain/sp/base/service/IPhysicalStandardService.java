package com.hwagain.sp.base.service;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;
import com.hwagain.sp.base.entity.PhysicalStandard;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author linhl
 * @since 2018-11-05
 */
public interface IPhysicalStandardService extends IService<PhysicalStandard> {
	public boolean syncData () throws CustomException;;
}
