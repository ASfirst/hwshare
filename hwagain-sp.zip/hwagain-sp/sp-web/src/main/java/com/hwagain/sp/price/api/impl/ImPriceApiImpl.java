package com.hwagain.sp.price.api.impl;

import com.hwagain.sp.price.api.IImPriceApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 * 常规、非常规产品统一销售价格表 服务实现类
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
@Service("imPriceApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImPriceApiImpl implements IImPriceApi {
	
}
