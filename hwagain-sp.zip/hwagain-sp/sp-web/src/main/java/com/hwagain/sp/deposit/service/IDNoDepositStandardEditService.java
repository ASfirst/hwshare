package com.hwagain.sp.deposit.service;

import com.hwagain.sp.deposit.dto.DNoDepositStandardEditDto;
import com.hwagain.sp.deposit.entity.DNoDepositStandardEdit;

import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
public interface IDNoDepositStandardEditService extends IService<DNoDepositStandardEdit> {

	public List<DNoDepositStandardEditDto> findNewHistory()throws CustomException;

	public DNoDepositStandardEditDto addOneEdit(DNoDepositStandardEditDto dto)throws CustomException;

	public DNoDepositStandardEditDto matching(DNoDepositStandardEditDto dto)throws CustomException;
	
}
