package com.hwagain.sp.process.mapper;

import java.math.BigInteger;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hwagain.sp.process.dto.ImProcessPriceListDto;
import com.hwagain.sp.process.entity.ImProcessBatchProduct;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public interface ImProcessBatchProductMapper extends BaseMapper<ImProcessBatchProduct> {
	public Boolean insertProcessProductBatch(@Param("productList") List<ImProcessBatchProduct> productList);
	public List<ImProcessPriceListDto> getCollectProduct(@Param("fdId") BigInteger fdId);
	public List<ImProcessPriceListDto> getCollectProductById(@Param("list")List<String> list);
}