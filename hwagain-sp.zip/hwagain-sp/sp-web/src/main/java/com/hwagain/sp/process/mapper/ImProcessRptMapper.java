package com.hwagain.sp.process.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;
import com.hwagain.sp.process.dto.ImProcessPriceRptDto;
import com.hwagain.sp.process.dto.ImProcessProductRptDto;
import com.hwagain.sp.process.dto.ImProcessRptDto;
import com.hwagain.sp.process.dto.ImProcessSaleRptDto;
import com.hwagain.sp.process.entity.ImProcess;

public interface ImProcessRptMapper extends BaseMapper<ImProcess> {
	public List<ImProcessProductRptDto> queryImProductList(@Param("priceId") String priceId);
	//public List<ImProcessPriceRptDto> queryImProcessPricetList(@Param("processId") String processId);
	public List<ImProcessPriceRptDto> queryImPricetFirstList();
	public List<ImProcessPriceRptDto> queryImPricetSecondList();
	public List<ImProcessSaleRptDto> queryImProcessSaleList();
	public List<ImProcessRptDto> queryImProcessHistorySale();
	public List<ImProcessSaleRptDto> queryProcessSaleByBatch(@Param("batchNo") String batchNo);
	
	public List<ImProcessProductRptDto> querpImProcessProductDetail();
	
	public List<ImProcessProductRptDto> getImProcessProductDetailById(@Param("list")List<String> list);
	
	//高速纸机处理品价格录入表
	public List<ImProcessPriceRptDto> queryImProcessPricetList();
	
	
}
