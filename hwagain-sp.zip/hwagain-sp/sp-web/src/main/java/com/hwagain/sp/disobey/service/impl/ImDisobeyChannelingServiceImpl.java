package com.hwagain.sp.disobey.service.impl;

import com.hwagain.sp.base.dto.OaAduitDetailDto;
import com.hwagain.sp.base.entity.DictData;
import com.hwagain.sp.base.entity.OaAduit;
import com.hwagain.sp.base.entity.OaAduitDetail;
import com.hwagain.sp.base.service.IDictDataService;
import com.hwagain.sp.base.service.IOaAduitDetailService;
import com.hwagain.sp.base.service.IOaAduitService;
import com.hwagain.sp.disobey.entity.ImDisobeyChanneling;
import com.hwagain.sp.disobey.dto.BaseDisobeyDto;
import com.hwagain.sp.disobey.dto.ImDisobeyChannelingDto;
import com.hwagain.sp.disobey.dto.ImDisobeyChannelingRptDto;
import com.hwagain.sp.disobey.mapper.ImDisobeyChannelingMapper;
import com.hwagain.sp.disobey.mapper.ImDisobeyChannelingRptMapper;
import com.hwagain.sp.disobey.service.IBaseDisobeyService;
import com.hwagain.sp.disobey.service.IImDisobeyChannelingService;
import com.hwagain.sp.disobey.sync.DisobeyUtils;
import com.hwagain.sp.util.JDBCConfig;
import com.hwagain.sp.util.PublicUtils;
import com.hwagain.sp.util.SqlDbUtils;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.core.util.SpringBeanUtil;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
@Service("imDisobeyChannelingService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImDisobeyChannelingServiceImpl extends ServiceImpl<ImDisobeyChannelingMapper, ImDisobeyChanneling> implements IImDisobeyChannelingService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	@Autowired
	ImDisobeyChannelingRptMapper channelingRptMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImDisobeyChanneling.class, ImDisobeyChannelingDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImDisobeyChannelingDto.class, ImDisobeyChanneling.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	@Autowired
	IBaseDisobeyService baseDisobeyService;
	
	@Autowired
	IDictDataService dictDataService;
	@Autowired
	IOaAduitService oaAduitService;
	@Autowired
	IOaAduitDetailService oaAduitDetailService;
	
	//根据提货订单号获取“客户ID”，“客户名称”，“发货日期”，“承运物流公司”，“车牌号”，“客户经销区域”，“翼迅定位情况”，“窜货数量”
	@Override
	public List<ImDisobeyChannelingDto> getDriverByOrder(String orderNo)
			throws CustomException {
		// TODO Auto-generated method stub
		JDBCConfig jDBCConfig=SpringBeanUtil.getBean(JDBCConfig.class);
		List<ImDisobeyChannelingDto> list= new ArrayList<ImDisobeyChannelingDto>();
		String url = jDBCConfig.getK3Url();// 127.0.0.1是本机地址，XE是精简版Oracle的默认数据库名
		String username = jDBCConfig.getK3Username();// 用户名,系统默认的账户名
		String password = jDBCConfig.getK3Password();// 你安装时选设置的密码

		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");// 加载sql驱动程序
			con = DriverManager.getConnection(url, username, password);// 获取连接
			
			String sql = "exec 物流管理系统.dbo.GetDriverByOrderNo '"+orderNo.toString()+"'";// 预编译语句，“？”代表参数
			System.out.println(sql);
			pre = con.prepareStatement(sql);// 实例化预编译语句
			result = pre.executeQuery();// 执行查询，注意括号中不需要再加参数
			ResultSetMetaData md = pre.getMetaData();
			int columnCount = md.getColumnCount();
			while (result.next()) {
				Map<String, Object> map = new HashMap<>();
				for (int i = 1; i <= columnCount; i++)
					map.put(md.getColumnName(i).toString(), result.getObject(i));
				ImDisobeyChannelingDto dto=new ImDisobeyChannelingDto();
				
				dto=driverAdd(map);
				list.add(dto);
			}
			
			//查询不到数据负空值
			if (list.size()==0) {
				ImDisobeyChannelingDto dto=new ImDisobeyChannelingDto();
				list.add(dto);
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return entityToDtoMapper.mapAsList(list, ImDisobeyChannelingDto.class);
	}	
	
	private ImDisobeyChannelingDto driverAdd(Map<String, Object> obj) {
		ImDisobeyChannelingDto dto=new ImDisobeyChannelingDto();
		String pickupOrderId=(String) obj.get("orderno");
		Integer customerId=(Integer) obj.get("customer_id");
		Date shipmentDate=(Date) obj.get("shipment_date");
		String customerName=(String) obj.get("customer_name");
		String logisCompany=(String) obj.get("logis_company");
		String carNo=(String) obj.get("car_no");
		String customerArea=(String) obj.get("customer_area");
		String placePoint=(String) obj.get("place_point");
		BigDecimal weight=(BigDecimal) obj.get("weight");
		BigDecimal amount=getKoKuanAmount(weight);
		
		dto.setPickupOrderId(pickupOrderId);
		dto.setCustomerId(customerId);
		dto.setCustomerName(customerName);
		dto.setShipmentDate(shipmentDate);
		dto.setLogisCompany(logisCompany);
		dto.setCarNo(carNo);
		dto.setCustomerArea(customerArea);
		dto.setPlacePoint(placePoint);
		dto.setWeight(weight);
		dto.setAmount(amount);
		return dto;
	}

	@Override
	public ImDisobeyChannelingDto save(ImDisobeyChannelingDto dto)
			throws CustomException {
		dto.setStatus(10);  //新增时将OA状态设为10;
		ImDisobeyChanneling entity=dtoToEntityMapper.map(dto, ImDisobeyChanneling.class);
		super.insert(entity);
		return dto;
	}

	@Override
	public ImDisobeyChannelingDto update(ImDisobeyChannelingDto dto)
			throws CustomException {
		Assert.isTrue(dto.getOaStatus()<=10, "数据已经提交OA，不能修改！");
		dto.setLastAlterId(UserUtils.getUserId());
		dto.setLastAlterTime(new Date());
		ImDisobeyChanneling entity=dtoToEntityMapper.map(dto, ImDisobeyChanneling.class);
		super.updateById(entity);
		return dto;
	}

	@Override
	public Boolean deleteByIds(String ids) throws CustomException {
		String[] id = ids.split(";");
		ImDisobeyChanneling entity=super.selectById(id);
		Assert.notNull(entity, "没有找到需要删除的记录！");
		Assert.isTrue(entity.getOaStatus()<=10, "数据已经提交OA，不能删除！");
		return super.deleteBatchIds(Arrays.asList(id));
	}

	@Override
	public List<ImDisobeyChannelingRptDto> findByOACode(String oaCode)
			throws CustomException {
		List<ImDisobeyChannelingRptDto> list=channelingRptMapper.queryChannelingByOACode(oaCode);
		int seqNum=1;
		for(ImDisobeyChannelingRptDto dto:list)
		{
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list;
	}

	@Override
	public List<ImDisobeyChannelingRptDto> disobeySentToOa() {
		List<ImDisobeyChannelingRptDto> list = channelingRptMapper.queryChannelingSendOAList();

		Assert.notNull(list, "没有找到需要推送OA的生活原纸客户窜货扣款记录");
		Assert.isTrue(!list.isEmpty(), "没有找到需要推送OA的生活原纸客户窜货扣款记录");

		int i = 1;
		for (ImDisobeyChannelingRptDto dto : list) {
			if (dto.getStatus() != 10)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,不是未提交状态,无法提交OA");
			if (null != dto.getOaCode() && !dto.getOaCode().isEmpty())
				Assert.throwException("第" + String.valueOf(i) + "条纪录,OACode不为空,无法提交OA");
			if (null == dto.getPickupOrderId())
				Assert.throwException("第" + String.valueOf(i) + "条纪录,提货订单号不能为空");
			if (null == dto.getDeductDate())
				Assert.throwException("第" + String.valueOf(i) + "条纪录,窜货确认日期不能为空");

			i++;
		}

		Date doDate = new Date();
		String oACode = String.valueOf(IdWorker.getId());

		String flowName = DisobeyUtils.const_OaFlowName_ImDisobeyChanneling;
		String platform = PublicUtils.const_Platform_Import;

		DictData dic = findOaTemId(flowName, platform);
		Assert.notNull(dic, "没有找到[" + flowName + "]的OA流程配置信息");
		Assert.notBlank(dic.getCode(), "没有找到[" + flowName + "]的OA流程配置信息");

		String temid = dic.getCode();
		String title = dic.getText();
		String userEmpNo = UserUtils.getUserInfo().getFdEmployeeNumber();
		String userName = UserUtils.getUserInfo().getName();
		Integer iresult = SqlDbUtils.sentOaFlow(temid, oACode, title, userEmpNo, userName, platform + ";" + flowName);
		Assert.isTrue(iresult == 1, "提交OA失败");

		// 记录日志
		OaAduit oa = new OaAduit();
		oa.setFdId(IdWorker.getId());
		oa.setOaCode(oACode);
		oa.setPlatform(platform);
		oa.setTableName("im_disobey_channeling");
		oa.setFlowName(flowName);
		oa.setNodeName("提交OA");
		oa.setEmpName(userName);
		oa.setEmpNo(userEmpNo);
		oa.setStatus(11);
		oa.setCreaterId(UserUtils.getUserId());
		oa.setCreateTime(doDate);
		oaAduitService.insert(oa);

		OaAduitDetailDto oaDetailDto = entityToDtoMapper.map(oa, OaAduitDetailDto.class);

		for (ImDisobeyChannelingRptDto dto : list) {
			dto.setOaCode(oACode);
			dto.setStatus(11);
			dto.setStatusText("已提交");

			ImDisobeyChanneling d = dtoToEntityMapper.map(dto, ImDisobeyChanneling.class);
			d.setLastAlterTime(doDate);
			d.setLastAlterId(UserUtils.getUserId());

			super.updateById(d);

			OaAduitDetail oaDetail = dtoToEntityMapper.map(oaDetailDto, OaAduitDetail.class);
			oaDetail.setFdId(IdWorker.getId());
			oaDetail.setRecFdId(d.getFdId());
			oaAduitDetailService.insert(oaDetail);
		}

		return list;
	}

	@Override
	public List<ImDisobeyChannelingRptDto> findDisobeyChannelingList()
			throws CustomException {
		List<ImDisobeyChannelingRptDto> list=channelingRptMapper.queryImChannelingList();
		int seqNum=1;
		for(ImDisobeyChannelingRptDto dto:list)
		{
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list;
	}
	
	@Override
	public List<ImDisobeyChannelingRptDto> findChannelingApplyList()
			throws CustomException {
		List<ImDisobeyChannelingRptDto> list=channelingRptMapper.queryChannelingApplyList();
		int seqNum=1;
		for(ImDisobeyChannelingRptDto dto:list)
		{
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list;
	}
		
	@Override
	public DictData findOaTemId(String itemName, String groupName)
			throws CustomException {
		Wrapper<DictData> wrapper = new CriterionWrapper<DictData>(DictData.class);
		wrapper.eq("item_name",itemName);
		wrapper.eq("group_name",groupName);
		wrapper.eq("is_delete", 0);
		return dictDataService.selectFirst(wrapper);
	}

	private BigDecimal getKoKuanAmount(BigDecimal qty)
	{
		BigDecimal amount=null;
		BaseDisobeyDto dto=baseDisobeyService.getPenaltyStandard();
		if(null!=dto)
		{
			if(dto.getUnit().equals("车"))
			{
				amount=dto.getPenaltyStandard();
			}
			else
			{
				amount=dto.getPenaltyStandard().multiply(qty);
			}
		}
		return amount;
	}

	
	
}
