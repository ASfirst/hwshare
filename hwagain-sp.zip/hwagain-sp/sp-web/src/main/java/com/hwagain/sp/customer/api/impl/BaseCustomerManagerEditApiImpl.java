package com.hwagain.sp.customer.api.impl;

import com.hwagain.sp.customer.api.IBaseCustomerManagerEditApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-29
 */
@Service("baseCustomerManagerEditApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class BaseCustomerManagerEditApiImpl implements IBaseCustomerManagerEditApi {
	
}
