package com.hwagain.sp.customer.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hwagain.framework.core.dto.PageVO;
import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.customer.dto.BaseCustomerManagerDto;
import com.hwagain.sp.customer.service.IBaseCustomerManagerService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xionglz
 * @since 2018-11-28
 */
@RestController
@RequestMapping(value="/customer/baseCustomerManager",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "【进口纸机】客户分管责任人维护表", description = "【进口纸机】客户分管责任人维护表")
public class BaseCustomerManagerController extends BaseController{
	private static Logger logger = LoggerFactory.getLogger(BaseCustomerManagerController.class);
	
	@Autowired
	IBaseCustomerManagerService baseCustomerManagerService;
	
	@RequestMapping("/findAll")
	@ApiOperation(value = "初始数据", notes = "初始数据", httpMethod = "GET")
	public Response findCooperatingCustomer() {
		return SuccessResponseData.newInstance(baseCustomerManagerService.findAll());
	}
	/**
	 * 重写获取客户分管责任人分页列表
	 * @param page
	 * @param pageSize
	 * @return
	 */
	@RequestMapping("/findAllByPage")
	@ApiOperation(value = "初始数据", notes = "初始数据", httpMethod = "GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="page",value="当前页",paramType = "query", required = false, dataType = "int"),
		@ApiImplicitParam(name="pageSize",value="每页显示数",paramType = "query", required = false, dataType = "int")
	})
	public Response findCooperatingCustomerByPage(Integer page, Integer pageSize) {
		PageVO pagevo = new PageVO();
		pagevo.setPage(page);
		pagevo.setPageSize(pageSize);
		logger.info("请求参数: page>>" + page + ",pageSize=" +pageSize);
		return SuccessResponseData.newInstance(baseCustomerManagerService.findAllByPage(pagevo));
	}
	@RequestMapping("/editOne")
	@ApiOperation(value="录入一条",notes="录入一条",httpMethod="POST")
	public Response editOne(@RequestBody BaseCustomerManagerDto dto){
//		return SuccessResponseData.newInstance(baseCustomerManagerService.editOne(dto));
		return SuccessResponseData.newInstance(baseCustomerManagerService.editOneOnly(dto));
	}
	@RequestMapping("/addOne")
	@ApiOperation(value="录入一条",notes="录入一条",httpMethod="POST")
	public Response addOne(@RequestBody BaseCustomerManagerDto dto){
//		return SuccessResponseData.newInstance(baseCustomerManagerService.editOne(dto));
		return SuccessResponseData.newInstance(baseCustomerManagerService.addOne(dto));
	}
}
