package com.hwagain.sp.base.service.impl;

import com.hwagain.sp.base.entity.DictData;
import com.hwagain.sp.base.entity.SysSerialNumber;
import com.hwagain.sp.base.dto.DictDataDto;
import com.hwagain.sp.base.dto.SysSerialNumberDto;
import com.hwagain.sp.base.mapper.SysSerialNumberMapper;
import com.hwagain.sp.base.service.ISysSerialNumberService;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.security.common.util.UserUtils;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author guoym
 * @since 2018-11-05
 */
@Service("sysSerialNumberService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class SysSerialNumberServiceImpl extends ServiceImpl<SysSerialNumberMapper, SysSerialNumber> implements ISysSerialNumberService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(SysSerialNumber.class, SysSerialNumberDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(SysSerialNumberDto.class, SysSerialNumber.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	@Override
	public String getSerialNumber(String prefixChar,String remark) {
		Assert.notBlank(prefixChar, "前缀字母不能为空");
		
		Calendar cale = null;  
        cale = Calendar.getInstance();  
        int year = cale.get(Calendar.YEAR);  
        int month = cale.get(Calendar.MONTH) + 1;  
        int curNbr=1;
		
		Wrapper<SysSerialNumber> wrapper = new CriterionWrapper<SysSerialNumber>(SysSerialNumber.class);
		wrapper.eq("prefix_char",prefixChar);
		wrapper.eq("year",year);
		wrapper.eq("month",month);
		wrapper.orderBy("number", false);
		SysSerialNumber obj = super.selectFirst(wrapper);
		
		if(null!=obj)
			curNbr = obj.getNumber()+1;
		
		SysSerialNumber newObj =new SysSerialNumber();
		newObj.setPrefixChar(prefixChar);
		newObj.setYear(year);
		newObj.setMonth(month);
		newObj.setNumber(curNbr);
		newObj.setRemark(remark);
		newObj.setCreateTime(new Date());
		newObj.setCreaterId(UserUtils.getUserId());
		super.insert(newObj);
		
		Integer ibig = 100000+curNbr;
		String snbr=String.valueOf(ibig);
		if(ibig>9999)
			snbr = snbr.substring(2, 6);
		else
			snbr = snbr.substring(3, 6);
		
		String sCode= prefixChar + String.valueOf(year)+
				( month <10 ? "0" : "" ) +  String.valueOf(month)
				+ snbr;	
				
		return sCode;
	}
	
}
