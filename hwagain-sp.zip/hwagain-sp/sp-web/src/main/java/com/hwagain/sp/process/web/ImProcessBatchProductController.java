package com.hwagain.sp.process.web;

import io.swagger.annotations.Api;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.hwagain.framework.web.common.controller.BaseController;


/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
@RestController
@RequestMapping(value="/process/imProcessBatchProduct",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "【进口纸机】处理品收集", description = "【进口纸机】处理品收集")
public class ImProcessBatchProductController extends BaseController{
	
}
