package com.hwagain.sp.policy.web;

import com.hwagain.framework.core.response.Response;
import com.hwagain.sp.policy.component.response.ResponseData;
import com.hwagain.sp.policy.dto.params.transport.AddSubsidyDto;
import com.hwagain.sp.policy.dto.params.transport.CheckDto;
import com.hwagain.sp.policy.dto.params.transport.UpdateSubsidyDto;
import com.jeramtough.jtlog.with.WithLogger;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.springframework.web.bind.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.policy.service.IPoTransportService;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author weibw
 * @since 2019-06-20
 */
@RestController
@RequestMapping(value = "/policy/poTransport",
        method = {RequestMethod.GET, RequestMethod.POST})
@Api(value = "【运输补贴】", description = "【运输补贴】调用接口")
public class PoTransportController extends BaseController implements WithLogger {

    @Autowired
    IPoTransportService poTransportService;


    @RequestMapping(value = "/save", method = RequestMethod.POST)
    @ApiOperation(value = "新增【运输补贴】数据", notes = "新增一条数据到po_transport表", httpMethod = "POST")
    @ResponseBody
    public Response addSubsidy(@RequestBody AddSubsidyDto addSubsidyDto) {
        getLogger().info("开始执行新增【运输补贴】API接口");
        return ResponseData.newInstance(poTransportService.addSubsidy(addSubsidyDto));
    }

    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ApiOperation(value = "更新【运输补贴】数据", notes = "更新一条数据到po_transport表", httpMethod = "POST")
    public Response updateSubsidy(@RequestBody UpdateSubsidyDto updateSubsidyDto) {
        getLogger().info("开始执行更新【运输补贴】API接口");
        return ResponseData.newInstance(poTransportService.updateSubsidy(updateSubsidyDto));
    }

    @RequestMapping(value = "/findAll", method = RequestMethod.GET)
    @ApiOperation(value = "获取【运输补贴】数据", notes = "获取全部数据从po_transport表", httpMethod = "GET")
    @ResponseBody
    public Response findAllSubsidys() {
        getLogger().info("开始执行获取【运输补贴】API接口");
        return ResponseData.newInstance(poTransportService.findAllSubsidys());
    }


    @RequestMapping(value = "/deleteById", method = {RequestMethod.POST,
            RequestMethod.GET})
    @ApiOperation(value = "删除【运输补贴】数据", notes = "删除一条数据从po_transport表", httpMethod = "POST")
    @ResponseBody
    public Response deleteSubsidyById(@RequestParam Long fdId) {
        getLogger().info("开始执行删除【运输补贴】API接口");
        return ResponseData.newInstance(poTransportService.deleteSubsidyByFdId(fdId));
    }

    @RequestMapping(value = "/check", method = {RequestMethod.POST,
            RequestMethod.GET})
    @ApiOperation(value = "审核【运输补贴】数据", notes = "审核【运输补贴】数据", httpMethod = "POST")
    @ResponseBody
    public Response check(@RequestBody CheckDto checkDto) {
        getLogger().info("开始执行删除【运输补贴】API接口");
        return ResponseData.newInstance(poTransportService.check(checkDto));
    }


}
