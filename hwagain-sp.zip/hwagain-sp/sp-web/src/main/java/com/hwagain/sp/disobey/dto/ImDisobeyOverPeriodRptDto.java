package com.hwagain.sp.disobey.dto;


public class ImDisobeyOverPeriodRptDto extends ImDisobeyOverPeriodDto {
	private static final long serialVersionUID = 1L;
	private String orderNo;
	private String statusText;
	private String isDedectText;
	private String kindName;
	private String className;
	private Integer seqNum;

	private Integer rowSpan1;

	private Integer rowSpan2;
	

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	public String getKindName() {
		return kindName;
	}

	public void setKindName(String kindName) {
		this.kindName = kindName;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Integer getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}

	public Integer getRowSpan1() {
		return rowSpan1;
	}

	public void setRowSpan1(Integer rowSpan1) {
		this.rowSpan1 = rowSpan1;
	}

	public Integer getRowSpan2() {
		return rowSpan2;
	}

	public void setRowSpan2(Integer rowSpan2) {
		this.rowSpan2 = rowSpan2;
	}

	public String getIsDedectText() {
		if (this.getIsDedect())
			isDedectText = "免责";
		else
			isDedectText = "";

		return isDedectText;
	}

	public void setIsDedectText(String isDedectText) {
		this.isDedectText = isDedectText;
	}
	
}
