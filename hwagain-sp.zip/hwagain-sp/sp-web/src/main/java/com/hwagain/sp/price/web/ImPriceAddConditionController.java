package com.hwagain.sp.price.web;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.List;

import org.apache.velocity.app.event.ReferenceInsertionEventHandler.referenceInsertExecutor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jca.cci.RecordTypeNotSupportedException;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.price.dto.ImPriceAddConditionDto;
import com.hwagain.sp.price.dto.ImPriceAddConditionEditDto;
import com.hwagain.sp.price.service.IImPriceAddConditionEditService;
import com.hwagain.sp.price.service.IImPriceAddConditionService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 小幅宽产品加价表 前端控制器
 * </p>
 *
 * @author
 * @since 2018-11-16
 */
@RestController
@RequestMapping(value="/price/imPriceAddCondition",method={RequestMethod.GET,RequestMethod.POST})
@Api(value="【进口纸机】小幅产品加价表",description="【进口纸机】小幅产品加价表")
public class ImPriceAddConditionController extends BaseController{
	
	@Autowired
	IImPriceAddConditionService imPriceAddConditionService;
	@Autowired
	IImPriceAddConditionEditService imPriceAddConditionEditService;
	
	@RequestMapping("/findAll")
	@ApiOperation(value="初始列表",notes="findAll",httpMethod="GET")
	public Response findAll(){
		return SuccessResponseData.newInstance(imPriceAddConditionService.findAll());
	}
	
	@RequestMapping("/update")
	@ApiOperation(value="调整",notes="update",httpMethod="POST")
	public Response updateOne(@RequestBody ImPriceAddConditionDto dto){
		return SuccessResponseData.newInstance(imPriceAddConditionService.updateOne(dto));
	}
	
	@RequestMapping("/findHistory")
	@ApiOperation(value="历史价差",notes="findHistory",httpMethod="GET")
	public Response findHistory(){
		return SuccessResponseData.newInstance(imPriceAddConditionService.findHistory());
	}
	
	@RequestMapping("/findAllSpecialSetPrice")
	@ApiOperation(value="特规套产品销售价格明细表",notes="findHistory",httpMethod="GET")
	public Response findAllSpecialSetPrice(){
		return SuccessResponseData.newInstance(imPriceAddConditionService.findAllSpecialSetPrice());
	}
	
	@RequestMapping("/findHistorySpecialSetPrice")
	@ApiOperation(value="特规套产品销售价格历史价格",notes="findHistorySpecialSetPrice",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="ration",value="定量",paramType="query",required=true,dataType="BigDecimal"),
		@ApiImplicitParam(name="wrinkleRate",value="起皱率",paramType="query",required=true,dataType="BigDecimal"),
		@ApiImplicitParam(name="physicalNo",value="物理指标",paramType="query",required=true,dataType="String")
	})
	public Response findHistorySpecialSetPrice(BigDecimal ration, BigDecimal wrinkleRate, String physicalNo){
		return SuccessResponseData.newInstance(imPriceAddConditionService.findHistorySpecialSetPrice(ration, wrinkleRate, physicalNo));
	}
	
	//双人录入
	@RequestMapping("/addOneEdit")
	@ApiOperation(value="双人录入",notes="双人录入",httpMethod="POST")
	public Response addOneEdit(@RequestBody ImPriceAddConditionEditDto dto){
		return SuccessResponseData.newInstance(imPriceAddConditionEditService.addOneEdit(dto));
	}
	
	@RequestMapping("/findNewHistory")
	@ApiOperation(value="当前用户历史",notes="findNewHistory",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="width",value="幅宽",paramType="query",required=true,dataType="int"),
		@ApiImplicitParam(name="qty",value="幅数",paramType="query",required=true,dataType="int")
	})
	public Response findNewHistory(int width,int qty){
		return SuccessResponseData.newInstance(imPriceAddConditionEditService.findNewHistory(width, qty));
	}
	
	@RequestMapping("/matching")
	@ApiOperation(value="双人录入数据匹配",notes="双人录入数据匹配",httpMethod="POST")
	public Response matching(@RequestBody List<ImPriceAddConditionEditDto> dtos){
		return SuccessResponseData.newInstance(imPriceAddConditionEditService.matching(dtos));
	}
}
