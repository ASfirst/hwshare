package com.hwagain.sp.policy.service;

import com.hwagain.sp.policy.dto.params.AddSubsidyDto;
import com.hwagain.sp.policy.entity.PoTransport;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author weibw
 * @since 2019-06-20
 */
public interface IPoTransportService extends IService<PoTransport> {

    Boolean addSubsidy(AddSubsidyDto addSubsidyDto);
}
