package com.hwagain.sp.policy.service;

import com.hwagain.framework.mybatisplus.service.IService;
import com.hwagain.sp.policy.dto.params.transport.AddSubsidyDto;
import com.hwagain.sp.policy.dto.params.transport.CheckDto;
import com.hwagain.sp.policy.dto.params.transport.UpdateSubsidyDto;
import com.hwagain.sp.policy.entity.PoTransport;
import com.jeramtough.jtcomponent.task.response.TaskResponse;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author weibw
 * @since 2019-06-20
 */
public interface IPoTransportService extends IService<PoTransport> {

    TaskResponse addSubsidy(AddSubsidyDto addSubsidyDto);

    TaskResponse updateSubsidy(UpdateSubsidyDto updateSubsidyDto);

    TaskResponse deleteSubsidyByFdId(Long fdId);

    TaskResponse findAllSubsidys();

    TaskResponse findSubsidyByFdId(Long fdId);

    TaskResponse check(CheckDto checkDto);
}
