package com.hwagain.sp.price.api;

/**
 * <p>
 * 小幅宽产品加价表 服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-21
 */
public interface IImPriceAddConditionEditApi {
	
}
