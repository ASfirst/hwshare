package com.hwagain.sp.customer.service;

import com.hwagain.sp.customer.dto.BaseCapacityDto;
import com.hwagain.sp.customer.entity.BaseCapacity;

import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-29
 */
public interface IBaseCapacityService extends IService<BaseCapacity> {

	public List<BaseCapacityDto> findAll()throws CustomException;

	public BaseCapacityDto addOne(BaseCapacityDto dto)throws Exception;

	public List<BaseCapacityDto> findAllCapacity()throws CustomException;
	
}
