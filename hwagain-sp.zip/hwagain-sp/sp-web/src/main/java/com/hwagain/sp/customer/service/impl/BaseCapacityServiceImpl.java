package com.hwagain.sp.customer.service.impl;

import com.hwagain.sp.customer.entity.BaseCapacity;
import com.hwagain.sp.customer.dto.BaseCapacityDto;
import com.hwagain.sp.customer.mapper.BaseCapacityMapper;
import com.hwagain.sp.customer.service.IBaseCapacityService;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import oracle.net.aso.c;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-29
 */
@Service("baseCapacityService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class BaseCapacityServiceImpl extends ServiceImpl<BaseCapacityMapper, BaseCapacity> implements IBaseCapacityService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(BaseCapacity.class, BaseCapacityDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(BaseCapacityDto.class, BaseCapacity.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	@Override
	public List<BaseCapacityDto> findAllCapacity(){
		Wrapper<BaseCapacity> wrapper=new CriterionWrapper<BaseCapacity>(BaseCapacity.class);
		wrapper.eq("end_time", "2035-11-30");
		wrapper.orderBy("machine_type");
		wrapper.orderBy("machine_no");
		List<BaseCapacity> list=super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, BaseCapacityDto.class);	
	}
	@Override
	public List<BaseCapacityDto> findAll(){
		Wrapper<BaseCapacity> wrapper=new CriterionWrapper<BaseCapacity>(BaseCapacity.class);
		wrapper.eq("end_time", "2035-11-30");
		wrapper.orderBy("machine_type");
		wrapper.orderBy("machine_no");
		List<BaseCapacity> list=super.selectList(wrapper);
//		int i=0;
		System.err.println(list.size());
		int a=1;
		int capacity=0;
		int totalCapacity=0;
		BaseCapacity base=new BaseCapacity();
		if(list.size()==1){
			capacity=list.get(0).getSingleCapacity();
			base.setFdId(list.get(0).getFdId());
			base.setTotalCapacity(capacity);
			super.updateById(base);
		}
		if(list.size()>1){	
			capacity=list.get(0).getSingleCapacity();
			for(int i=1;i<list.size();i++){
//				System.err.println(capacity);
				if(list.get(i).getMachineType().equals(list.get(i-1).getMachineType())){
//					System.err.println(capacity+"+"+list.get(i).getSingleCapacity());
					capacity+=list.get(i).getSingleCapacity();
					a++;
//					System.err.println(capacity);
					for(int j=0;j<a;j++){
						base.setFdId(list.get(i-j).getFdId());
						base.setTotalCapacity(capacity);
						super.updateById(base);
					}
	//				break;
				}
				if(!list.get(i).getMachineType().equals(list.get(i-1).getMachineType())){
					totalCapacity=capacity;
					for(int j=0;j<a;j++){
						base.setFdId(list.get(i-j).getFdId());
						base.setTotalCapacity(totalCapacity);
						super.updateById(base);
					}
					capacity=list.get(i).getSingleCapacity();
					a=1;
	//				break;
				}
			}
		}
		return entityToDtoMapper.mapAsList(list, BaseCapacityDto.class);
		
	}
	
	@Override
	public BaseCapacityDto addOne(BaseCapacityDto dto) throws Exception{
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
//		String curUserId = UserUtils.getUserId();
		String endData1="2035-11-30";
		Date endData=new SimpleDateFormat("yyyy-MM-dd").parse(endData1);

		Wrapper<BaseCapacity> wrapper=new CriterionWrapper<BaseCapacity>(BaseCapacity.class);
		wrapper.eq("end_time", null);
		wrapper.eq("machine_type", dto.getMachineType());
		wrapper.eq("machine_no", dto.getMachineNo());
		BaseCapacity list=super.selectFirst(wrapper);
		System.err.println(list);
		if(list==null){
			dto.setFdId(Long.valueOf(IdWorker.getId()));
//			dto.setTotalCapacity(dto.getSingleCapacity());
			dto.setStartTime(doDate);
			dto.setEndTime(endData);
			dto.setCreaterId(cUserid);
			dto.setCreateTime(doDate);
			dto.setTotalCapacity(dto.getSingleCapacity());
			super.insert(dtoToEntityMapper.map(dto, BaseCapacity.class));
		}else{
			BaseCapacity baca=new BaseCapacity();
			baca.setFdId(list.getFdId());
			baca.setEndTime(doDate);
			baca.setLastAlterId(cUserid);
			baca.setLastAlterTime(doDate);
			super.updateById(baca);
			dto.setFdId(Long.valueOf(IdWorker.getId()));
			dto.setStartTime(doDate);
			dto.setEndTime(endData);
			dto.setCreaterId(cUserid);
			dto.setCreateTime(doDate);
			dto.setTotalCapacity(dto.getSingleCapacity());
			super.insert(dtoToEntityMapper.map(dto, BaseCapacity.class));
		}
		findAll();
		findAll();
		return dto;
		
	}
}
