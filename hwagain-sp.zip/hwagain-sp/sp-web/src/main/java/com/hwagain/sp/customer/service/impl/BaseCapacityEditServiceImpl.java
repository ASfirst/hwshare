package com.hwagain.sp.customer.service.impl;

import com.hwagain.sp.customer.entity.BaseCapacityEdit;
import com.hwagain.sp.customer.dto.BaseCapacityEditDto;
import com.hwagain.sp.customer.mapper.BaseCapacityEditMapper;
import com.hwagain.sp.customer.service.IBaseCapacityEditService;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-29
 */
@Service("baseCapacityEditService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class BaseCapacityEditServiceImpl extends ServiceImpl<BaseCapacityEditMapper, BaseCapacityEdit> implements IBaseCapacityEditService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(BaseCapacityEdit.class, BaseCapacityEditDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(BaseCapacityEditDto.class, BaseCapacityEdit.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
}
