package com.hwagain.sp.deposit.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 客户当月定金对账明细表
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
@TableName("d_deposit_item")
public class DDepositItem implements Serializable {

    private static final long serialVersionUID = 1L;

	@TableId("fd_id")
	private Long fdId;
    /**
     * 客户当月定金对账主表ID
     */
	@TableField("deposit_main_id")
	private Long depositMainId;
    /**
     * 日期
     */
	@TableField("happen_date")
	private Date happenDate;
    /**
     * 项目
     */
	private String project;
    /**
     * 单据类别
     */
	private String category;
    /**
     * 单据编号
     */
	private String number;
    /**
     * 汇入定金
     */
	@TableField("add_deposit")
	private BigDecimal addDeposit;
    /**
     * 转出定金
     */
	@TableField("reduce_deposit")
	private BigDecimal reduceDeposit;
    /**
     * 冻结定金
     */
	@TableField("frozen_deposit")
	private BigDecimal frozenDeposit;
    /**
     * 解冻定金
     */
	@TableField("thaw_deposit")
	private BigDecimal thawDeposit;
    /**
     * 可用定金
     */
	@TableField("available_deposit")
	private BigDecimal availableDeposit;
    /**
     * 账户总冻结定金
     */
	@TableField("total_frozen_deposit")
	private BigDecimal totalFrozenDeposit;
    /**
     * 定金总额
     */
	@TableField("total_deposit")
	private BigDecimal totalDeposit;
    /**
     * 创建人
     */
	@TableField("creater_id")
	private String createrId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
    /**
     * 最后修改人
     */
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getDepositMainId() {
		return depositMainId;
	}

	public void setDepositMainId(Long depositMainId) {
		this.depositMainId = depositMainId;
	}

	public Date getHappenDate() {
		return happenDate;
	}

	public void setHappenDate(Date happenDate) {
		this.happenDate = happenDate;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public BigDecimal getAddDeposit() {
		return addDeposit;
	}

	public void setAddDeposit(BigDecimal addDeposit) {
		this.addDeposit = addDeposit;
	}

	public BigDecimal getReduceDeposit() {
		return reduceDeposit;
	}

	public void setReduceDeposit(BigDecimal reduceDeposit) {
		this.reduceDeposit = reduceDeposit;
	}

	public BigDecimal getFrozenDeposit() {
		return frozenDeposit;
	}

	public void setFrozenDeposit(BigDecimal frozenDeposit) {
		this.frozenDeposit = frozenDeposit;
	}

	public BigDecimal getThawDeposit() {
		return thawDeposit;
	}

	public void setThawDeposit(BigDecimal thawDeposit) {
		this.thawDeposit = thawDeposit;
	}

	public BigDecimal getAvailableDeposit() {
		return availableDeposit;
	}

	public void setAvailableDeposit(BigDecimal availableDeposit) {
		this.availableDeposit = availableDeposit;
	}

	public BigDecimal getTotalFrozenDeposit() {
		return totalFrozenDeposit;
	}

	public void setTotalFrozenDeposit(BigDecimal totalFrozenDeposit) {
		this.totalFrozenDeposit = totalFrozenDeposit;
	}

	public BigDecimal getTotalDeposit() {
		return totalDeposit;
	}

	public void setTotalDeposit(BigDecimal totalDeposit) {
		this.totalDeposit = totalDeposit;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
