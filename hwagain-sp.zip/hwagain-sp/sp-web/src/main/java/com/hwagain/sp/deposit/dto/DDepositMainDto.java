package com.hwagain.sp.deposit.dto;

import java.util.Date;

import java.io.Serializable;


/**
 * <p>
 * 客户当月定金对账主表
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
public class DDepositMainDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
    /**
     * 客户ID
     */
	private Long customerId;
    /**
     * 客户名称
     */
	private String customerName;
    /**
     * 客户类型
     */
	private String customerType;
    /**
     * 定金账户
     */
	private String depositAccount;
    /**
     * 审核人
     */
	private String auditor;
    /**
     * 审核时间
     */
	private Date auditTime;
    /**
     * 客户确认状态
     */
	private String confirmStatus;
    /**
     * 客户确认时间
     */
	private Date confirmTime;
    /**
     * 客户确认意见
     */
	private String confirmOpinion;
    /**
     * 年
     */
	private Integer year;
    /**
     * 月
     */
	private Integer month;
    /**
     * 创建人
     */
	private String createrId;
    /**
     * 创建时间
     */
	private Date createTime;
    /**
     * 最后修改人
     */
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getDepositAccount() {
		return depositAccount;
	}

	public void setDepositAccount(String depositAccount) {
		this.depositAccount = depositAccount;
	}

	public String getAuditor() {
		return auditor;
	}

	public void setAuditor(String auditor) {
		this.auditor = auditor;
	}

	public Date getAuditTime() {
		return auditTime;
	}

	public void setAuditTime(Date auditTime) {
		this.auditTime = auditTime;
	}

	public String getConfirmStatus() {
		return confirmStatus;
	}

	public void setConfirmStatus(String confirmStatus) {
		this.confirmStatus = confirmStatus;
	}

	public Date getConfirmTime() {
		return confirmTime;
	}

	public void setConfirmTime(Date confirmTime) {
		this.confirmTime = confirmTime;
	}

	public String getConfirmOpinion() {
		return confirmOpinion;
	}

	public void setConfirmOpinion(String confirmOpinion) {
		this.confirmOpinion = confirmOpinion;
	}

	public Integer getYear() {
		return year;
	}

	public void setYear(Integer year) {
		this.year = year;
	}

	public Integer getMonth() {
		return month;
	}

	public void setMonth(Integer month) {
		this.month = month;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
