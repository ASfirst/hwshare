package com.hwagain.sp.deposit.web;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.deposit.dto.DNoDepositStandardDto;
import com.hwagain.sp.deposit.dto.DNoDepositStandardEditDto;
import com.hwagain.sp.deposit.service.IDNoDepositStandardEditService;
import com.hwagain.sp.deposit.service.IDNoDepositStandardService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import oracle.net.aso.d;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xionglz
 * @since 2018-11-08
 */
@RestController
@RequestMapping(value="/deposit/dNoDepositStandard",method={RequestMethod.GET,RequestMethod.POST})
@Api(value="【进口纸机】不收定金标准",description="【进口纸机】不收定金标准")
public class DNoDepositStandardController extends BaseController{
	
	@Autowired
	IDNoDepositStandardService dNoDepositStandardService;
	@Autowired IDNoDepositStandardEditService dNoDepositStandardEditService;
//	@RequestMapping("/inputQueryProd")
//	@ApiOperation(value="获取所有产品型号",notes="获取所有产品型号",httpMethod="GET")
//	public Response inputQueryProd(){
//		return SuccessResponseData.newInstance(dNoDepositStandardService.inputQueryProd());
//	}
//	
//	@RequestMapping("/updatDepoStandards")
//	@ApiOperation(value="批量调整不收定金标准",notes="批量调整不收定金标准",httpMethod="POST")
//	public Response updatDepoStandards(@RequestBody List<DNoDepositStandardDto> dtos){
//		return SuccessResponseData.newInstance(dNoDepositStandardService.updatDepoStandards(dtos));
//	}
//	
//	@RequestMapping("/updatDepoStandard")
//	@ApiOperation(value="调整不收定金标准",notes="调整不收定金标准",httpMethod="POST")
//	public Response updatDepoStandard(@RequestBody DNoDepositStandardDto dto){
//		return SuccessResponseData.newInstance(dNoDepositStandardService.updatDepoStandard(dto));
//	}
//	
	@RequestMapping("/findAllHistory")
	@ApiOperation(value="历史不收定金标准",notes="历史不收定金标准",httpMethod="GET")
	public Response findAllHistory(){
		return SuccessResponseData.newInstance(dNoDepositStandardService.findAllHistory());
	}
	
	@RequestMapping("/findEffectList")
	@ApiOperation(value="不收定金标准生效列表",notes="不收定金标准生效列表",httpMethod="GET")
	public Response findEffectList(){
		return SuccessResponseData.newInstance(dNoDepositStandardService.findEffectList());
	}
	
	@RequestMapping("/findAllList")
	@ApiOperation(value="不收定金生效列表",notes="不收定金生效列表",httpMethod="GET")
	public Response findAllList(){
		return SuccessResponseData.newInstance(dNoDepositStandardService.findAllList());
	}
	
	@RequestMapping("/findNewHistory")
	@ApiOperation(value="获取当前用户双人录入修改记录",notes="获取当前用户双人录入修改记录",httpMethod="GET")
	public Response findNewHistory(){
		return SuccessResponseData.newInstance(dNoDepositStandardEditService.findNewHistory());
	}
	
	@RequestMapping("/addOneEdit")
	@ApiOperation(value="调整-双人录入",notes="调整-双人录入",httpMethod="POST")
	public Response addOneEdit(@RequestBody DNoDepositStandardEditDto dto){
		return SuccessResponseData.newInstance(dNoDepositStandardEditService.addOneEdit(dto));
	}
	
	@RequestMapping("/matching")
	@ApiOperation(value="匹配-双人录入",notes="匹配-双人录入",httpMethod="POST")
	public Response matching(@RequestBody DNoDepositStandardEditDto dto){
		return SuccessResponseData.newInstance(dNoDepositStandardEditService.matching(dto));
	}
}
