package com.hwagain.sp.process.service;

import java.math.BigDecimal;
import java.util.List;

import com.hwagain.sp.process.dto.ImProcessPriceDto;
import com.hwagain.sp.process.dto.ImProcessPriceRptDto;
import com.hwagain.sp.process.entity.ImProcessPrice;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public interface IImProcessPriceService extends IService<ImProcessPrice> {
	//public List<ImProcessPriceRptDto> findPriceByFdId(String processId) throws CustomException;
	public Boolean delete(String fdId) throws CustomException; 
	public Boolean isAuditComplate(String priceId) throws CustomException;
	public String getUserOrder();
	public List<ImProcessPriceRptDto> queryPriceFirstList() throws CustomException;
	public List<ImProcessPriceRptDto> queryPriceSecondList() throws CustomException;
	public ImProcessPriceDto updateProcessPriceOne(String fdId,String userOrder,Integer isPolicy,BigDecimal normalPrice,BigDecimal processPrice,String remark) throws CustomException;
	public List<ImProcessPriceDto> updateProcessPriceSome(List<ImProcessPriceDto> list,String userOrder) throws CustomException;
}
