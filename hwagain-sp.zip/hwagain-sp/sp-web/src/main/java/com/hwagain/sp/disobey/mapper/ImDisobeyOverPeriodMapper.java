package com.hwagain.sp.disobey.mapper;

import com.hwagain.sp.disobey.entity.ImDisobeyOverPeriod;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
public interface ImDisobeyOverPeriodMapper extends BaseMapper<ImDisobeyOverPeriod> {

}