package com.hwagain.sp.policy.service.impl;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;
import com.hwagain.sp.policy.dto.PoPolicyDto;
import com.hwagain.sp.policy.dto.PoPolicyFormatDto;
import com.hwagain.sp.policy.dto.PoPolicyPlatformDto;
import com.hwagain.sp.policy.entity.PoPolicy;
import com.hwagain.sp.policy.entity.PoPolicyDetails;
import com.hwagain.sp.policy.mapper.PoPolicyMapper;
import com.hwagain.sp.policy.service.IPoPolicyDetailsService;
import com.hwagain.sp.policy.service.IPoPolicyService;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
@Service("poPolicyService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoPolicyServiceImpl extends ServiceImpl<PoPolicyMapper, PoPolicy> implements IPoPolicyService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	@Autowired
	IPoPolicyDetailsService policyDetailsService; 
	@Autowired
	PoPolicyMapper poPolicyMapper;
	
	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(PoPolicy.class, PoPolicyDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(PoPolicyDto.class, PoPolicy.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	private void union(List<PoPolicy> list, Set<PoPolicyPlatformDto> set){
		for(PoPolicy entity : list){
			set.add(new PoPolicyPlatformDto(entity.isIsImportWhite(), entity.isIsImportColor(), entity.isIs3900White(), entity.isIs3900Color(), entity.isIs1575White(), entity.isIsAll()));
		}
	}
	@Override
	public List<PoPolicyFormatDto> findPolicyCurrentMonth(String fdYear, String fdMonth) {
		List<PoPolicy> policys = poPolicyMapper.findAllList(fdYear, fdMonth);
		Map<String, String> last = getLastMonth(fdYear, fdMonth);
		List<PoPolicy> lastpolicys = poPolicyMapper.findAllList(last.get("year"), last.get("month"));
		if((policys == null || policys.size() == 0) && (lastpolicys != null && lastpolicys.size() > 0)){//当月还没有优惠政策, 从上个月导入
			for(PoPolicy policy : lastpolicys){
				PoPolicy entity = new PoPolicy();
				entity.setBaseAmount(policy.getBaseAmount());
				entity.setBaseAvgAmount(policy.getBaseAvgAmount());
				entity.setPromiseAmount(policy.getPromiseAmount());
				entity.setFbaseAmount(policy.getFbaseAmount());
				entity.setFbaseAvgAmount(policy.getFbaseAvgAmount());
				entity.setFpromiseAmount(policy.getFpromiseAmount());
				entity.setIs1575White(policy.isIs1575White());
				entity.setIs3900Color(policy.isIs3900Color());
				entity.setIs3900White(policy.isIs3900White());
				entity.setIsImportColor(policy.isIsImportColor());
				entity.setIsImportWhite(policy.isIsImportWhite());
				entity.setIsAll(policy.isIsAll());
				Calendar cal=Calendar.getInstance();
				cal.add(Calendar.MONTH, 0);
				cal.set(Calendar.DAY_OF_MONTH,1);
				entity.setFdYear(cal.get(Calendar.YEAR));
				entity.setFdMonth(cal.get(Calendar.MONTH) + 1);
				entity.setStartDate(new Date(cal.getTimeInMillis()));
				cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
				entity.setEndDate(new Date(cal.getTimeInMillis()));
				entity.setFdId(IdWorker.getId());
				entity.setCreaterId(UserUtils.getUserCode());
				entity.setCreateTime(new Date());
				entity.setStatus(30);
				super.insertOrUpdate(entity);//头信息保存
				List<PoPolicyDetails> detailsForShow = new ArrayList<>();
				List<PoPolicyDetails> details = policy.getDetails();
				if(details != null && details.size() > 0){
					for(PoPolicyDetails detail : details){
						PoPolicyDetails entityDetail = new PoPolicyDetails();
						entityDetail.setLevel(detail.getLevel());
						entityDetail.setFminWeight(detail.getFminWeight());
						entityDetail.setFmaxWeight(detail.getFmaxWeight());
						entityDetail.setMinWeight(detail.getMinWeight());
						entityDetail.setMaxWeight(detail.getMaxWeight());
						entityDetail.setAmount(detail.getAmount());
						entityDetail.setFamount(detail.getFamount());
						entityDetail.setPoPolicyId(entity.getFdId());
						entityDetail.setFdId(IdWorker.getId());
						policyDetailsService.insert(entityDetail);
						detailsForShow.add(entityDetail);
					}
					entity.setDetails(detailsForShow);
				}
				policys.add(entity);
			}
		}else if((policys == null || policys.size() == 0) && (lastpolicys == null || lastpolicys.size() == 0)){
			Assert.throwException("当月和上个月的优惠政策都未维护。");
		}
		
		//查询处理
		//长度计算 
		Set<PoPolicyPlatformDto> set = new LinkedHashSet<PoPolicyPlatformDto>();
		if(policys != null){
			union(policys, set);
		}
		if(lastpolicys != null){
			union(lastpolicys, set);
		}
		Iterator<PoPolicyPlatformDto> it = set.iterator();
		List<PoPolicyFormatDto> list = new ArrayList<>();
		while (it.hasNext()) {
			PoPolicyPlatformDto platformDto = it.next();
			PoPolicy policy = getPolicy(policys, platformDto);
			PoPolicy lastPolicy = getPolicy(lastpolicys, platformDto);
			
			List<PoPolicyDetails> details = null;;
			List<PoPolicyDetails> lastdetails = null;
			if(lastPolicy != null){
				lastdetails = lastPolicy.getDetails();
			}
			if(policy != null){
				details = policy.getDetails();
			}
			
			int size = 0;
			if(lastdetails != null){
				size = lastdetails.get(lastdetails.size()-1).getLevel();
			}
			if(details != null && details.get(details.size()-1).getLevel() > size){
				size = details.get(details.size()-1).getLevel();
			}
			for(int j = 1 ; j <= size; j ++){//当月机型纸种
				PoPolicyDetails detail = getPoPolicyDetail(details, j);
				PoPolicyDetails lastdetail = getPoPolicyDetail(lastdetails,j);
				list.add(setPoPolicyFormateDto(policy, detail, lastPolicy, lastdetail));
			}
		}
//		
//		int length = 0;
//		if(policys != null){
//			length =  policys.size();
//		}
//		if(lastpolicys != null && lastpolicys.size() > length){
//			length = lastpolicys.size();
//		}
//		List<PoPolicyFormatDto> list = new ArrayList<>();
//		for(int i = 0; i < length; i++){//机型纸种
//			if(i < policys.size()){//当月机型纸种
//				PoPolicy policy = policys.get(i);
//				PoPolicy lastPolicy = getPolicy(lastpolicys, policy);
//				List<PoPolicyDetails> details = policy.getDetails();
//				List<PoPolicyDetails> lastdetails = null;
//				if(lastPolicy != null){
//					lastdetails = lastPolicy.getDetails();
//				}
//				
//				int size = 0;
//				if(lastdetails != null){
//					size = lastdetails.get(lastdetails.size()-1).getLevel();
//				}
//				if(details != null && details.get(details.size()-1).getLevel() > size){
//					size = details.get(details.size()-1).getLevel();
//				}
//				for(int j = 1 ; j <= size; j ++){//当月机型纸种
//					PoPolicyDetails detail = getPoPolicyDetail(details, j);
//					PoPolicyDetails lastdetail = getPoPolicyDetail(lastdetails,j);
//					list.add(setPoPolicyFormateDto(policy, detail, lastPolicy, lastdetail));
//				}
//			}else{//上个月机型纸种,当月不存在的
//				PoPolicy lastPolicy = lastpolicys.get(i);
//				List<PoPolicyDetails> details = lastPolicy.getDetails();
//				for(PoPolicyDetails lastdetail : details){
//					list.add(setPoPolicyFormateDto(null, null, lastPolicy, lastdetail));
//				}
//			}
//		}
		return list;
	}
	
	private PoPolicyFormatDto setPoPolicyFormateDto(PoPolicy policy, PoPolicyDetails detail, PoPolicy lastPolicy, PoPolicyDetails lastdetal){
		PoPolicyFormatDto dto = new PoPolicyFormatDto();
		if(lastPolicy != null){//设置当月主表
			dto.setLastBaseAmount(lastPolicy.getBaseAmount());
			dto.setLastBaseAvgAmount(lastPolicy.getBaseAvgAmount());
			dto.setLastPromiseAmount(lastPolicy.getPromiseAmount());
			dto.setLastFbaseAmount(lastPolicy.getFbaseAmount());
			dto.setLastFbaseAvgAmount(lastPolicy.getFbaseAvgAmount());
			dto.setLastFpromiseAmount(lastPolicy.getFpromiseAmount());
			dto.setIs1575White(lastPolicy.isIs1575White());
			dto.setIs3900Color(lastPolicy.isIs3900Color());
			dto.setIs3900White(lastPolicy.isIs3900White());
			dto.setIsImportColor(lastPolicy.isIsImportColor());
			dto.setIsImportWhite(lastPolicy.isIsImportWhite());
			dto.setIsAll(lastPolicy.isIsAll());
		}
		if(policy != null){//设置当月主表
			dto.setBaseAmount(policy.getBaseAmount());
			dto.setBaseAvgAmount(policy.getBaseAvgAmount());
			dto.setPromiseAmount(policy.getPromiseAmount());
			dto.setFbaseAmount(policy.getFbaseAmount());
			dto.setFbaseAvgAmount(policy.getFbaseAvgAmount());
			dto.setFpromiseAmount(policy.getFpromiseAmount());
			dto.setIs1575White(policy.isIs1575White());
			dto.setIs3900Color(policy.isIs3900Color());
			dto.setIs3900White(policy.isIs3900White());
			dto.setIsImportColor(policy.isIsImportColor());
			dto.setIsImportWhite(policy.isIsImportWhite());
			dto.setIsAll(policy.isIsAll());
			dto.setFdYear(policy.getFdYear());
			dto.setFdMonth(policy.getFdMonth());
			dto.setStartDate(policy.getStartDate());
			dto.setEndDate(policy.getEndDate());
		}
		if(lastdetal != null){
			dto.setLevel(lastdetal.getLevel());
			dto.setLastFminWeight(lastdetal.getFminWeight());
			dto.setLastFmaxWeight(lastdetal.getFmaxWeight());
			dto.setLastMinWeight(lastdetal.getMinWeight());
			dto.setLastMaxWeight(lastdetal.getMaxWeight());
			dto.setLastAmount(lastdetal.getAmount());
			dto.setLastFamount(lastdetal.getFamount());
		}
		if(detail != null){
			dto.setLevel(detail.getLevel());
			dto.setFminWeight(detail.getFminWeight());
			dto.setFmaxWeight(detail.getFmaxWeight());
			dto.setMinWeight(detail.getMinWeight());
			dto.setMaxWeight(detail.getMaxWeight());
			dto.setAmount(detail.getAmount());
			dto.setFamount(detail.getFamount());
			dto.setDetailId(detail.getFdId());
		}
		return dto;
		
	}
	private PoPolicyDetails getPoPolicyDetail(List<PoPolicyDetails> list, int level){
		PoPolicyDetails result = null;
		if(list == null){
			return result;
		}
		for(PoPolicyDetails entity : list){
			if(entity.getLevel() == level){
				result = entity;
				break;
			}
		}
		return result;
	}
	private PoPolicy getPolicy(List<PoPolicy> list, PoPolicy policy){
		PoPolicy result = null;
		for(PoPolicy entity : list){
			if(((boolean)entity.isIs1575White() == (boolean) policy.isIs1575White())
					&& ((boolean)entity.isIs3900Color() == (boolean) policy.isIs3900Color())
					&& ((boolean)entity.isIs3900White() == (boolean) policy.isIs3900White())
					&& ((boolean)entity.isIsImportColor() == (boolean) policy.isIsImportColor())
					&& ((boolean)entity.isIsImportWhite() == (boolean) policy.isIsImportWhite())
					&& ((boolean) entity.isIsAll() == (boolean) policy.isIsAll())
					){
				result = entity;
				break;
			}
		}
		return result;
	}
	private PoPolicy getPolicy(List<PoPolicy> list, PoPolicyPlatformDto policy){
		PoPolicy result = null;
		for(PoPolicy entity : list){
			if(((boolean)entity.isIs1575White() == (boolean) policy.getIs1575White())
					&& ((boolean)entity.isIs3900Color() == (boolean) policy.getIs3900Color())
					&& ((boolean)entity.isIs3900White() == (boolean) policy.getIs3900White())
					&& ((boolean)entity.isIsImportColor() == (boolean) policy.getIsImportColor())
					&& ((boolean)entity.isIsImportWhite() == (boolean) policy.getIsImportWhite())
					&& ((boolean) entity.isIsAll() == (boolean) policy.getIsAll())
					){
				result = entity;
				break;
			}
		}
		return result;
	}
	private Map<String, String> getLastMonth(String year, String month){
		if(Integer.valueOf(month) < 10){
			month = "0"+Integer.valueOf(month);
		}
		String rq = year + "-" + month;
		DateFormat format2 =  new SimpleDateFormat("yyyy-MM");
		Date date = new Date();
		try{
		    date = format2.parse(rq);
		}catch(Exception e){
		    e.printStackTrace();
		}
		Calendar c = Calendar.getInstance();
		c.setTime(date);
		c.add(Calendar.MONTH, -1);
		
		 int lastyear = c.get(Calendar.YEAR); 
		 int lastmonth = c.get(Calendar.MONTH) + 1;
		
		Map<String, String> map = new HashMap<>();
		map.put("year", lastyear+"");
		map.put("month", lastmonth+"");
		
		return map;
	}
	
	@Override
	public PoPolicyFormatDto saveOne(PoPolicyFormatDto dto) {
		if(!dto.isIs1575White()&&dto.isIs3900Color()
				&& dto.isIs3900White()&&dto.isIsImportWhite()
				&& dto.isIsImportColor()&&dto.isIsAll()){
			Assert.throwException("机型纸种不能为空");
		}
		Assert.notNull(dto.getLevel(), "级别不能为空");
		
		Wrapper<PoPolicy> wrapper = new CriterionWrapper<>(PoPolicy.class);
		wrapper.eq("fd_year", dto.getFdYear());
		wrapper.eq("fd_month", dto.getFdMonth());
		wrapper.eq("is_all", dto.isIsAll());
		wrapper.eq("is_1575_white", dto.isIs1575White());
		wrapper.eq("is_3900_white", dto.isIs3900White());
		wrapper.eq("is_3900_color", dto.isIs3900Color());
		wrapper.eq("is_import_white", dto.isIsImportWhite());
		wrapper.eq("is_import_color", dto.isIsImportColor());
		
		PoPolicy policyForCheck = super.selectFirst(wrapper);
		if(policyForCheck != null){
			Wrapper<PoPolicyDetails> detailWrapper = new CriterionWrapper<>(PoPolicyDetails.class);
			detailWrapper.eq("po_policy_id", policyForCheck.getFdId());
			detailWrapper.eq("level", dto.getLevel());
			PoPolicyDetails detail = policyDetailsService.selectFirst(detailWrapper);
			if (detail != null && dto.getDetailId() == null) {
				Assert.throwException("该机型纸种的级别已经存在记录");
			}
		}
		if (policyForCheck == null){
			PoPolicy policy = dtoToEntityMapper.map(dto, PoPolicy.class);
			policy.setFdId(IdWorker.getId());
			policy.setCreaterId(UserUtils.getUserCode());
			policy.setCreateTime(new Date());
			policy.setStatus(30);
			super.insertOrUpdate(policy);
			dto.setFdId(policy.getFdId());
		}else{
			policyForCheck.setLastAlterId(UserUtils.getUserCode());
			policyForCheck.setLastAlterTime(new Date());
			super.updateAllById(policyForCheck);
			dto.setFdId(policyForCheck.getFdId());
		}
		policyDetailsService.saveDetails(dto);
		return dto;
	}
	@Override
	public boolean deleteOne(String detailId) {
		PoPolicyDetails detail = policyDetailsService.selectById(detailId);
		PoPolicy policy = super.selectById(detail.getPoPolicyId());
		
		Wrapper<PoPolicyDetails> detailWrapper = new CriterionWrapper<>(PoPolicyDetails.class);
		detailWrapper.eq("po_policy_id", policy.getFdId());
		List<PoPolicyDetails> details = policyDetailsService.selectList(detailWrapper);
		policyDetailsService.deleteById(detail.getFdId());
		if(details != null && details.size() == 1){
			super.deleteById(policy.getFdId());
		}
		return true;
	}
}
