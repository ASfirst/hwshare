package com.hwagain.sp.price.api;

/**
 * <p>
 * 进口纸机特规品价格调整【双人录入】 服务类
 * </p>
 *
 * @author guoym
 * @since 2018-10-16
 */
public interface IImSpecialPriceAdjustApi {
	
}
