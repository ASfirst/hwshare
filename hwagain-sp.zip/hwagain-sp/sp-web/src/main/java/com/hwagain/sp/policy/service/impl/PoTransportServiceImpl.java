package com.hwagain.sp.policy.service.impl;

import com.hwagain.sp.policy.component.factory.PoTransportDtoFactory;
import com.hwagain.sp.policy.dto.params.AddSubsidyDto;
import com.hwagain.sp.policy.entity.PoTransport;
import com.hwagain.sp.policy.dto.PoTransportDto;
import com.hwagain.sp.policy.mapper.PoTransportMapper;
import com.hwagain.sp.policy.service.IPoTransportService;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.Set;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author weibw
 * @since 2019-06-20
 */
@Service("poTransportService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoTransportServiceImpl extends ServiceImpl<PoTransportMapper, PoTransport>
        implements IPoTransportService {

    // entity转dto
    static MapperFacade entityToDtoMapper;

    // dto转entity
    static MapperFacade dtoToEntityMapper;

    private final PoTransportMapper poTransportMapper;

    static {
        MapperFactory factory = new DefaultMapperFactory.Builder().build();
        factory.classMap(PoTransport.class, PoTransportDto.class).byDefault().register();
        entityToDtoMapper = factory.getMapperFacade();

        MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
        factorytwo.classMap(PoTransportDto.class, PoTransport.class).byDefault().register();
        dtoToEntityMapper = factorytwo.getMapperFacade();
    }

    @Autowired
    public PoTransportServiceImpl(
            PoTransportMapper poTransportMapper) {
        this.poTransportMapper = poTransportMapper;
    }

    @Override
    public Boolean addSubsidy(AddSubsidyDto addSubsidyDto) {

        //表单数据合法性校验
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<AddSubsidyDto>> constraintViolations =
                validator.validate(addSubsidyDto);
        if (constraintViolations.size() > 0) {
            for (ConstraintViolation<AddSubsidyDto> constraintViolation : constraintViolations) {

            }
            return false;
        }

        PoTransportDto poTransportDto =
                PoTransportDtoFactory.getPoTransportDto(addSubsidyDto);
        PoTransport poTransport = dtoToEntityMapper.map(poTransportDto, PoTransport.class);
        poTransportMapper.insertPoTransportEntity(poTransport);
        return true;
    }
}
