package com.hwagain.sp.policy.service.impl;

import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.sp.policy.component.factory.PoTransportDtoFactory;
import com.hwagain.sp.policy.component.factory.PoTransportFactory;
import com.hwagain.sp.policy.dto.PoSubsidizedTransportDto;
import com.hwagain.sp.policy.dto.PoTransportDto;
import com.hwagain.sp.policy.dto.params.transport.AddSubsidyDto;
import com.hwagain.sp.policy.dto.params.transport.CheckDto;
import com.hwagain.sp.policy.dto.params.transport.UpdateSubsidyDto;
import com.hwagain.sp.policy.entity.PoSubsidizedTransport;
import com.hwagain.sp.policy.entity.PoTransport;
import com.hwagain.sp.policy.mapper.PoTransportJavaMapper;
import com.hwagain.sp.policy.mapper.PoTransportMapper;
import com.hwagain.sp.policy.service.IPoTransportService;
import com.jeramtough.jtcomponent.task.bean.no.TaskResult;
import com.jeramtough.jtcomponent.task.response.TaskResponse;
import com.jeramtough.jtcomponent.task.response.TaskResponseBuilder;
import com.jeramtough.jtlog.with.WithLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;
import java.util.Set;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author weibw
 * @since 2019-06-20
 */
@Service("poTransportService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoTransportServiceImpl extends ServiceImpl<PoTransportMapper, PoTransport>
        implements IPoTransportService, WithLogger {

    private final PoTransportJavaMapper poTransportJavaMapper;
    private final PoTransportFactory poTransportFactory;
    private final PoTransportDtoFactory poTransportDtoFactory;


    @Autowired
    public PoTransportServiceImpl(
            PoTransportJavaMapper poTransportJavaMapper,
            PoTransportFactory poTransportFactory,
            PoTransportDtoFactory poTransportDtoFactory) {
        this.poTransportJavaMapper = poTransportJavaMapper;
        this.poTransportFactory = poTransportFactory;
        this.poTransportDtoFactory = poTransportDtoFactory;
    }

    @Override
    public TaskResponse addSubsidy(AddSubsidyDto addSubsidyDto) {
        return TaskResponseBuilder.doing((TaskResult taskResult) -> {

            //校验客户端提交的表单数据的合法性
            boolean isPassed = verifyParamsDTO(addSubsidyDto, taskResult);

            if (isPassed) {
                //DTO转Entiiy
                PoTransport poTransport = poTransportFactory.getPoTransport(addSubsidyDto);
                //插入数据
                int count = poTransportJavaMapper.insert(poTransport);
                if (count > 0) {
                    getLogger().info("成功插入[%d]条数据进【交通补贴】表", count);
                    return true;
                }
                else {
                    getLogger().warn("失败插入数据进【交通补贴】表，请检查数据库是否异常");
                    return false;
                }
            }
            else {
                return false;
            }
        });
    }

    @Override
    public TaskResponse updateSubsidy(UpdateSubsidyDto updateSubsidyDto) {
        return TaskResponseBuilder.doing((TaskResult taskResult) -> {

            //校验客户端提交的表单数据的合法性
            boolean isPassed = verifyParamsDTO(updateSubsidyDto, taskResult);

            if (isPassed) {
                //DTO转Entiiy
                PoTransport poTransport = poTransportFactory.getPoTransport(updateSubsidyDto);
                //更新数据
                int count = poTransportJavaMapper.updateByPrimaryKeySelective(poTransport);
                if (count > 0) {
                    getLogger().info("成功更新[%d]条数据进【交通补贴】表", count);
                    return true;
                }
                else {
                    String failedMessage = "失败更新数据进【交通补贴】表，请检查fdId是否存在";
                    taskResult.setMessage(failedMessage);
                    getLogger().warn(failedMessage);
                    return false;
                }
            }
            else {
                return false;
            }
        });
    }

    @Override
    public TaskResponse deleteSubsidyByFdId(Long fdId) {
        return TaskResponseBuilder.doing((TaskResult taskResult) -> {
            //删除数据
            int count = poTransportJavaMapper.deleteByPrimaryKey(fdId);
            if (count > 0) {
                getLogger().info("成功删除[%d]条数据从【交通补贴】表", count);
                return true;
            }
            else {
                String failedMessage = "失败删除数据从【交通补贴】表，请检查数据库是否异常或则该FdId不存在";
                taskResult.setMessage(failedMessage);
                getLogger().warn(failedMessage);
                return false;
            }
        });
    }

    @Override
    public TaskResponse findAllSubsidys() {
        return TaskResponseBuilder.doing((TaskResult taskResult) -> {
            PoSubsidizedTransport[] poSubsidizedTransports = poTransportJavaMapper.selectAllPoSubsidizedTransport();
            if (poSubsidizedTransports != null) {
                PoSubsidizedTransportDto[] poSubsidizedTransportDtos =
                        poTransportDtoFactory.getPoTransportDtos(poSubsidizedTransports);
                taskResult.putPayload("data", poSubsidizedTransportDtos);
                getLogger().info("成功查询[%d]条数据从【交通补贴】表", poSubsidizedTransportDtos.length);
                return true;
            }
            else {
                String failedMessage = "数据库异常";
                taskResult.setMessage(failedMessage);
                getLogger().warn(failedMessage);
                return false;
            }
        });
    }

    @Override
    public TaskResponse findSubsidyByFdId(Long fdId) {
        return TaskResponseBuilder.doing((TaskResult taskResult) -> {
            //查询数据
            PoTransport poTransport = poTransportJavaMapper.selectByPrimaryKey(fdId);
            if (poTransport != null) {
                getLogger().info("成功查询fdid为[%d]的数据从【交通补贴】表", fdId);
                PoTransportDto poTransportDto =
                        poTransportDtoFactory.getPoTransportDto(poTransport);
                taskResult.putPayload("data", poTransportDto);
                return true;
            }
            else {
                String failedMessage = "失败查询fdid为[%d]的数据从【交通补贴】表，" +
                        "请检查数据库是否异常或则该FdId不存在";
                failedMessage = String.format(failedMessage, fdId);
                taskResult.setMessage(failedMessage);
                getLogger().warn(failedMessage);
                return false;
            }
        });
    }

    @Override
    public TaskResponse check(CheckDto checkDto) {
        return TaskResponseBuilder.doing(taskResult -> {
            //校验客户端提交的表单数据的合法性
            boolean isPassed = verifyParamsDTO(checkDto, taskResult);

            if (isPassed) {
                //DTO转Entiiy
                PoTransport poTransport = poTransportFactory.getPoTransport(checkDto);
                //更新数据
                int count = poTransportJavaMapper.updateByPrimaryKeySelective(poTransport);
                if (count > 0) {
                    getLogger().info("成功审核完成[%d]条数据", count);
                    return true;
                }
                else {
                    String failedMessage = "失败审核数据，请检查fdId是否存在";
                    taskResult.setMessage(failedMessage);
                    getLogger().warn(failedMessage);
                    return false;
                }
            }
            else {
                return false;
            }
        });
    }

    //********************

    private boolean verifyParamsDTO(Object paramsDTO, TaskResult taskResult) {
        //表单数据合法性校验
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory();
        Validator validator = factory.getValidator();
        Set<ConstraintViolation<Object>> constraintViolations =
                validator.validate(paramsDTO);
        for (ConstraintViolation<Object> constraintViolation : constraintViolations) {
            //拿到数据校验信息
            taskResult.setMessage(constraintViolation.getMessage());
            getLogger().error("参数校验失败--%s", constraintViolation.getMessage());
            return false;
        }

        return true;

    }
}
