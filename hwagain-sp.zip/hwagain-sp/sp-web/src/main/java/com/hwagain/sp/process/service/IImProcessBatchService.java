package com.hwagain.sp.process.service;

import com.hwagain.sp.process.entity.ImProcessBatch;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public interface IImProcessBatchService extends IService<ImProcessBatch> {
	
}
