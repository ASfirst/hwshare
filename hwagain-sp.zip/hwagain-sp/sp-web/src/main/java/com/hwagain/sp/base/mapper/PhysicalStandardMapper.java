package com.hwagain.sp.base.mapper;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;
import com.hwagain.sp.base.entity.PhysicalStandard;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author linhl
 * @since 2018-11-05
 */
public interface PhysicalStandardMapper extends BaseMapper<PhysicalStandard> {

}