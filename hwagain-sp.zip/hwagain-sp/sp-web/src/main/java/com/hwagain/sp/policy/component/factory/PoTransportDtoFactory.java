package com.hwagain.sp.policy.component.factory;

import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.sp.policy.dto.PoTransportDto;
import com.hwagain.sp.policy.dto.params.AddSubsidyDto;
import com.hwagain.sp.policy.entity.PoPolicyDetails;

import java.util.Date;

/**
 * Created on 2019/6/20 17:02
 * by @author WeiBoWen
 */
public class PoTransportDtoFactory {

    public static PoTransportDto getPoTransportDto(AddSubsidyDto addSubsidyDto) {

        PoTransportDto poTransportDto = new PoTransportDto();
        poTransportDto.setFdId(IdWorker.getId());
        poTransportDto.setAddPrice(addSubsidyDto.getAddPrice());
        poTransportDto.setCheckedBy(addSubsidyDto.getCheckedBy());
        poTransportDto.setCheckedDate(addSubsidyDto.getCheckedDate());
        poTransportDto.setCheckedRemark(addSubsidyDto.getCheckedRemark());
        poTransportDto.setCreaterId(addSubsidyDto.getCreaterId());
        poTransportDto.setCreateTime(new Date());
        poTransportDto.setCustomerId(addSubsidyDto.getCustomerId());
        poTransportDto.setEndDate(addSubsidyDto.getEndDate());
        poTransportDto.setStartDate(addSubsidyDto.getStartDate());
        poTransportDto.setLastAlterId(null);
        poTransportDto.setLastAlterTime(new Date());
        poTransportDto.setMethod(addSubsidyDto.getMethod());
        poTransportDto.setPrice(addSubsidyDto.getPrice());
        poTransportDto.setRemark(addSubsidyDto.getRemark());
        poTransportDto.setStatus(11);
        return poTransportDto;
    }

}
