package com.hwagain.sp.policy.component.factory;

import com.hwagain.sp.policy.dto.PoSubsidizedTransportDto;
import com.hwagain.sp.policy.dto.PoTransportDto;
import com.hwagain.sp.policy.entity.PoSubsidizedTransport;
import com.hwagain.sp.policy.entity.PoTransport;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.springframework.stereotype.Component;

/**
 * Created on 2019-06-21 01:23
 * by @author JeramTough
 */
@Component
public class PoTransportDtoFactory {

    private MapperFacade mapperFacade1;
    private MapperFacade mapperFacade2;

    public PoTransportDtoFactory() {
        MapperFactory factory = new DefaultMapperFactory.Builder().build();

        factory.classMap(PoTransportDto.class, PoTransport.class).byDefault().register();
        mapperFacade1 = factory.getMapperFacade();

        factory.classMap(PoSubsidizedTransportDto.class,
                PoSubsidizedTransport.class).byDefault().register();
        mapperFacade2 = factory.getMapperFacade();
    }

    public PoTransportDto[] getPoTransportDtos(PoTransport[] poTransports) {
        PoTransportDto[] poTransportDtos = new PoTransportDto[poTransports.length];
        for (int i = 0; i < poTransportDtos.length; i++) {
            poTransportDtos[i] = getPoTransportDto(poTransports[i]);
        }
        return poTransportDtos;
    }

    public PoTransportDto getPoTransportDto(PoTransport poTransport) {
        PoTransportDto poTransportDto = mapperFacade1.map(poTransport,
                PoTransportDto.class);
        return poTransportDto;
    }

    public PoSubsidizedTransportDto getPoSubsidizedTransportDto(
            PoSubsidizedTransport poSubsidizedTransport) {
        PoSubsidizedTransportDto poSubsidizedTransportDto = mapperFacade1.map(
                poSubsidizedTransport,
                PoSubsidizedTransportDto.class);
        return poSubsidizedTransportDto;
    }

    public PoSubsidizedTransportDto[] getPoTransportDtos(
            PoSubsidizedTransport[] poSubsidizedTransports) {

        PoSubsidizedTransportDto[] poSubsidizedTransportDtos =
                new PoSubsidizedTransportDto[poSubsidizedTransports.length];
        for (int i = 0; i < poSubsidizedTransportDtos.length; i++) {
            poSubsidizedTransportDtos[i] =
                    getPoSubsidizedTransportDto(poSubsidizedTransports[i]);
        }
        return poSubsidizedTransportDtos;
    }
}
