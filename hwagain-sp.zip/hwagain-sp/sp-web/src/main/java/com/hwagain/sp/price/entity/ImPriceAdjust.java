package com.hwagain.sp.price.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
@TableName("im_price_adjust")
public class ImPriceAdjust implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	@TableId("fd_id")
	private Long fdId;
    /**
     * 统一销售价格id
     */
	@TableField("import_price_id")
	private Long importPriceId;
    /**
     * 调整前价 
     */
	@TableField("source_price")
	private BigDecimal sourcePrice;
    /**
     * 调整金额
     */
	@TableField("add_price")
	private BigDecimal addPrice;
    /**
     * 调整后价
     */
	private BigDecimal price;
    /**
     * 开始日期
     */
	@TableField("start_date")
	private Date startDate;
    /**
     * 结束日期
     */
	@TableField("end_date")
	private Date endDate;
    /**
     * 备注
     */
	private String remark;
	 /**
     * 角色
     */
	private String role;
    /**
     * 创建人
     */
	@TableField("creater_id")
	private String createrId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
    /**
     * 最后修改人
     */
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;
    /**
     * 状态 (10：未提交(初始状态):可以选择/删除/修改保存/提交
     11：已提交到申请人工作台(或退回开始节点):可以选择/删除/修改保存
     20：审核中(申请人已经提交出去):不可操作
     30：已审批
     40：已过期)
     */
	private Integer status;
    /**
     * OACode
     */
	private String OACode;
    /**
     * 批次id
     */
	@TableField("batch_id")
	private Long batchId;
    /**
     * 是否删除
     */
	@TableField("is_delete")
	private Integer isDelete;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getImportPriceId() {
		return importPriceId;
	}

	public void setImportPriceId(Long importPriceId) {
		this.importPriceId = importPriceId;
	}

	public BigDecimal getSourcePrice() {
		return sourcePrice;
	}

	public void setSourcePrice(BigDecimal sourcePrice) {
		this.sourcePrice = sourcePrice;
	}

	public BigDecimal getAddPrice() {
		return addPrice;
	}

	public void setAddPrice(BigDecimal addPrice) {
		this.addPrice = addPrice;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getOACode() {
		return OACode;
	}

	public void setOACode(String OACode) {
		this.OACode = OACode;
	}

	public Long getBatchId() {
		return batchId;
	}

	public void setBatchId(Long batchId) {
		this.batchId = batchId;
	}

	public Integer getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}

}
