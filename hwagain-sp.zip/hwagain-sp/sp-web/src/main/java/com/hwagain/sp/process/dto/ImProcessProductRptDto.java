package com.hwagain.sp.process.dto;

import java.util.Date;

public class ImProcessProductRptDto extends ImProcessBatchProductDto {
	private static final long serialVersionUID = 1L;
	private String batchNo;
	private Date stardDate;
	private Date endDate;
	private String className;
	private Integer seqNum;

	private Integer rowSpan1;

	private Integer rowSpan2;

	private String isThisBatchText;

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public Integer getSeqNum() {
		return seqNum;
	}

	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}

	public Integer getRowSpan1() {
		return rowSpan1;
	}

	public void setRowSpan1(Integer rowSpan1) {
		this.rowSpan1 = rowSpan1;
	}

	public Integer getRowSpan2() {
		return rowSpan2;
	}

	public void setRowSpan2(Integer rowSpan2) {
		this.rowSpan2 = rowSpan2;
	}

	public String getIsThisBatchText() {
		if (null != this.getIsThisBatch()) {
			if (this.getIsThisBatch() == 1)
				isThisBatchText = "是";
			else
				isThisBatchText = "否";
		}
		return isThisBatchText;
	}

	public void setIsThisBatchText(String isThisBatchText) {
		this.isThisBatchText = isThisBatchText;
	}

	public Date getStardDate() {
		return stardDate;
	}

	public void setStardDate(Date stardDate) {
		this.stardDate = stardDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
}
