package com.hwagain.sp.price.web;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.price.dto.ImPriceAddConditionEditDto;
import com.hwagain.sp.price.dto.ImPriceDifferenceDto;
import com.hwagain.sp.price.dto.ImPriceDifferenceEditDto;
import com.hwagain.sp.price.service.IImPriceAddConditionEditService;
import com.hwagain.sp.price.service.IImPriceDifferenceEditService;
import com.hwagain.sp.price.service.IImPriceDifferenceService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 副品及承兑汇票结算差价表 前端控制器
 * </p>
 *
 * @author
 * @since 2018-11-16
 */
@RestController
@RequestMapping(value="/price/imPriceDifference",method={RequestMethod.GET,RequestMethod.POST})
@Api(value="【进口纸机】副品及承兑汇票结算差价表",description="【进口纸机】副品及承兑汇票结算差价表")
public class ImPriceDifferenceController extends BaseController{
	
	@Autowired
	IImPriceDifferenceService imPriceDifferenceService;
	@Autowired
	IImPriceDifferenceEditService imPriceDifferenceEditService;
	
	@RequestMapping("/addOne")
	@ApiOperation(value="新增",notes="新增",httpMethod="POST")
	@ApiImplicitParams({
		@ApiImplicitParam(name="itemName",value="项目名称",paramType="query",required=true,dataType="String")
	})
	public Response addOne(String itemName){
		return SuccessResponseData.newInstance(imPriceDifferenceService.addOne(itemName));
	}
	
	@RequestMapping("/updateOne")
	@ApiOperation(value="调整",notes="调整",httpMethod="POST")
	public Response updateOne(@RequestBody ImPriceDifferenceDto dto){
		return SuccessResponseData.newInstance(imPriceDifferenceService.updateOne(dto));
	}
	
	@RequestMapping("/findAll")
	@ApiOperation(value="初始列表",notes="初始列表",httpMethod="GET")
	public Response findAll(){
		return SuccessResponseData.newInstance(imPriceDifferenceService.findAll());
	}
	
	@RequestMapping("/findHistoryImPrice")
	@ApiOperation(value="历史差价查询",notes="历史差价查询",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="ItemName",value="项目名称",paramType="query",required=true,dataType="String")
	})
	public Response findHistoryImPrice(String ItemName){
		return SuccessResponseData.newInstance(imPriceDifferenceService.findHistoryImPrice(ItemName));
	}
	
	@RequestMapping("/findOne")
	@ApiOperation(value="根据fdI的查询",notes="根据fdI的查询",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="fdId",value="fdId",paramType="query",required=true,dataType="Long")
	})
	public Response findOne(Long fdId){
		return SuccessResponseData.newInstance(imPriceDifferenceService.findOne(fdId));
	}
	
	//双人录入
	@RequestMapping("/addOneEdit")
	@ApiOperation(value="双人录入",notes="双人录入",httpMethod="POST")
	public Response addOneEdit(@RequestBody ImPriceDifferenceEditDto dto){
		return SuccessResponseData.newInstance(imPriceDifferenceEditService.addOneEdit(dto));
	}
	
	@RequestMapping("/findNewHistory")
	@ApiOperation(value="当前用户历史",notes="当前用户历史",httpMethod="GET")
	public Response findNewHistory(){
		return SuccessResponseData.newInstance(imPriceDifferenceEditService.findNewHistory());
	}
	
	@RequestMapping("/matching")
	@ApiOperation(value="双人录入数据匹配",notes="双人录入数据匹配",httpMethod="POST")
	public Response matching(@RequestBody List<ImPriceDifferenceEditDto> dtos){
		return SuccessResponseData.newInstance(imPriceDifferenceEditService.matching(dtos));
	}
}
