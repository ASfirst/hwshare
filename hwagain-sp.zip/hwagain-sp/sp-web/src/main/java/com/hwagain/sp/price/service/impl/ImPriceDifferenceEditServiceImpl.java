package com.hwagain.sp.price.service.impl;

import com.hwagain.sp.price.entity.ImPriceAddConditionEdit;
import com.hwagain.sp.price.entity.ImPriceDifference;
import com.hwagain.sp.price.entity.ImPriceDifferenceEdit;
import com.hwagain.sp.price.dto.ImPriceAddConditionDto;
import com.hwagain.sp.price.dto.ImPriceDifferenceDto;
import com.hwagain.sp.price.dto.ImPriceDifferenceEditDto;
import com.hwagain.sp.price.mapper.ImPriceDifferenceEditMapper;
import com.hwagain.sp.price.service.IImPriceDifferenceEditService;
import com.hwagain.sp.price.service.IImPriceDifferenceService;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 * 副品及承兑汇票结算差价表 服务实现类
 * </p>
 *
 * @author 
 * @since 2018-11-22
 */
@Service("imPriceDifferenceEditService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImPriceDifferenceEditServiceImpl extends ServiceImpl<ImPriceDifferenceEditMapper, ImPriceDifferenceEdit> implements IImPriceDifferenceEditService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	
	@Autowired IImPriceDifferenceService iImPriceDifferenceService;
	@Autowired ImPriceDifferenceServiceImpl imPriceDifferenceServiceImpl;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImPriceDifferenceEdit.class, ImPriceDifferenceEditDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImPriceDifferenceEditDto.class, ImPriceDifferenceEdit.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	//新增
	@Override
	public ImPriceDifferenceEditDto addOneEdit(ImPriceDifferenceEditDto dto){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		Wrapper<ImPriceDifferenceEdit> wrapper=new CriterionWrapper<ImPriceDifferenceEdit>(ImPriceDifferenceEdit.class);
		wrapper.eq("item_id", dto.getItemId());
		wrapper.eq("status", 1);
		wrapper.eq("creater_id", cUserid);
		ImPriceDifferenceEdit list=super.selectFirst(wrapper);
		if(list!=null){
			super.updateById(dtoToEntityMapper.map(dto, ImPriceDifferenceEdit.class));
		}else{
			dto.setFdId(Long.valueOf(IdWorker.getId()));
			dto.setRole(dept);
			dto.setCreaterId(cUserid);
			dto.setCreateTime(doDate);
			dto.setStatus(1);
//			dto.setIsPolicy(true);
			super.insert(dtoToEntityMapper.map(dto, ImPriceDifferenceEdit.class));
		}
		return entityToDtoMapper.map(super.selectById(dto.getFdId()), ImPriceDifferenceEditDto.class);
	}
	
	//当前用户历史修改记录
	@Override
	public List<ImPriceDifferenceEditDto> findNewHistory(){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		Wrapper<ImPriceDifferenceEdit> wrapper=new CriterionWrapper<ImPriceDifferenceEdit>(ImPriceDifferenceEdit.class);
		wrapper.eq("creater_id", cUserid);
		wrapper.eq("status", 1);
		List<ImPriceDifferenceEdit> list=super.selectList(wrapper);
		Wrapper<ImPriceDifference> wrapper1=new CriterionWrapper<ImPriceDifference>(ImPriceDifference.class);
//		wrapper1.eq("creater_id", cUserid);
		wrapper1.eq("status", 1);
		List<ImPriceDifference> list1=iImPriceDifferenceService.selectList(wrapper1);
		List<ImPriceDifferenceEdit> listA=new ArrayList<>();
		if(list1!=null&&list1.size()!=0){
			for(ImPriceDifference dto:list1){
				String st=JSONObject.toJSONString(dto);
				ImPriceDifferenceEdit list11=JSONObject.parseObject(st, ImPriceDifferenceEdit.class);
				listA.add(list11);
			}
		}
		
		if(list!=null&&list.size()!=0){
			for(ImPriceDifferenceEdit dto:list){
				for(ImPriceDifferenceEdit ddto:listA){
					if(dto.getItemId().equals(ddto.getItemId())){
						ddto.setFdId(dto.getFdId());
						ddto.setItemName(dto.getItemName());
						ddto.setDiffPrice(dto.getDiffPrice());
						ddto.setStartDate(dto.getStartDate());
						ddto.setIsPolicy(dto.isIsPolicy());
						ddto.setCreaterId(dto.getCreaterId());
						ddto.setRole(dto.getRole());
					}
				}
			}
		}
		return entityToDtoMapper.mapAsList(listA,ImPriceDifferenceEditDto.class);
		
	}
	
	//匹配
	@Override
	public List<ImPriceDifferenceEditDto> matching(List<ImPriceDifferenceEditDto> dtos){
//		Date doDate = new Date();
//		String cUserid = UserUtils.getUserInfo().getName();
//		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		if(dtos.size()==0){
			Assert.throwException("提交数据为空");
		}
		Wrapper<ImPriceDifferenceEdit> wrapper0=new CriterionWrapper<ImPriceDifferenceEdit>(ImPriceDifferenceEdit.class);
		wrapper0.eq("status",1);		
		List<ImPriceDifferenceEdit> list0=super.selectList(wrapper0);
		if(list0.size()==0){
			Assert.throwException("数据未调整");
		}
		List<ImPriceDifferenceEdit> listA=new ArrayList<>();
		List<ImPriceDifferenceDto> listB=new ArrayList<>();
		int R=0;
		for(ImPriceDifferenceEditDto dto:dtos){
			R++;
			if(StringUtils.isBlank(dto.getRole())){
				Assert.throwException("第("+R+")条数据未进行修改，无法匹配,请取消选择该数据后再提交");
			}
			Wrapper<ImPriceDifferenceEdit> wrapper1=new CriterionWrapper<ImPriceDifferenceEdit>(ImPriceDifferenceEdit.class);
			wrapper1.eq("fd_id", dto.getFdId());
			ImPriceDifferenceEdit list1=super.selectFirst(wrapper1);
			System.err.println(list1.getItemName());
			String st=JSONObject.toJSONString(list1);
			ImPriceDifferenceDto adto=JSONObject.parseObject(st, ImPriceDifferenceDto.class);
			Wrapper<ImPriceDifferenceEdit> wrapper=new CriterionWrapper<ImPriceDifferenceEdit>(ImPriceDifferenceEdit.class);
			wrapper.eq("item_id", dto.getItemId());
			wrapper.eq("item_name", dto.getItemName());
			wrapper.eq("start_date", dto.getStartDate());
			wrapper.eq("diff_price", dto.getDiffPrice());
			wrapper.eq("status", 1);
			wrapper.eq("is_policy", dto.isIsPolicy());
			wrapper.notIn("creater_id", dto.getCreaterId());
//			wrapper.notIn("role", dto.getRole());
			ImPriceDifferenceEdit list=super.selectFirst(wrapper);
//			System.err.println(list.getDiffPrice());
//			System.err.println(list.getCreaterId());
			if(list==null){
				Assert.throwException("匹配失败");
			}else{
				listA.add(list);
				listA.add(list1);
				listB.add(adto);
			}
		}
		for(ImPriceDifferenceEdit dto:listA){
			ImPriceDifferenceEdit impe=new ImPriceDifferenceEdit();
			impe.setFdId(dto.getFdId());
			impe.setStatus(10);
			super.updateById(impe);
		}
		for(ImPriceDifferenceDto dto:listB){
			imPriceDifferenceServiceImpl.updateOne(dto);
		}
		return dtos;
		
	}
}
