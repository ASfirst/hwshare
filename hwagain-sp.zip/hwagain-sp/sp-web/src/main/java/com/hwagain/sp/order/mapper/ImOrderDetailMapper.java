package com.hwagain.sp.order.mapper;

import com.hwagain.sp.order.entity.ImOrderDetail;
import com.hwagain.sp.order.dto.ImOrderDetailDto;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.math.BigInteger;
import org.apache.ibatis.annotations.Param;



/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
public interface ImOrderDetailMapper extends BaseMapper<ImOrderDetail> {

	//通过im_order_id查询一张订单明细列表
	public List<ImOrderDetailDto> findImOrderDetailListByOrderId(@Param("orderId") Long orderId);
	
	//通过im_order_id删除订单明细
	public Integer deleteImOrderDetailByOrderId(@Param("orderId") Long orderId);
		
	//当天下订单到第几张订单
	public ImOrderDetailDto findTodayOrderIndex();

	
	
}