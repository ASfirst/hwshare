package com.hwagain.sp.price.service;

import com.hwagain.sp.price.dto.ImSpecialPriceAdjustDto;
import com.hwagain.sp.price.dto.ImSpecialPriceAdjustExtDto;
import com.hwagain.sp.price.entity.ImSpecialPriceAdjust;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 * 进口纸机特规品价格调整【双人录入】 服务类
 * </p>
 *
 * @author guoym
 * @since 2018-10-16
 */
public interface IImSpecialPriceAdjustService extends IService<ImSpecialPriceAdjust> {

	public String getUserOrder();

	public List<ImSpecialPriceAdjustExtDto> queryAdjustList();

	public List<ImSpecialPriceAdjustExtDto> selectSpecialPrice(String specialPriceIds);

	public List<ImSpecialPriceAdjust> deleteAdjustRecord(String specialPriceIds);

	public ImSpecialPriceAdjustDto updateAdjustOne(String fdid, BigDecimal adjustAddPrice, Date startDate, Integer isPolicy,
			String remark);

	public List<ImSpecialPriceAdjustDto> updateAdjustSome(List<ImSpecialPriceAdjustDto> list);
	
}
