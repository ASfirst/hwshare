package com.hwagain.sp.jdbc;

public enum SourceEnum {

    K3,
    OA,
    PD;

}
