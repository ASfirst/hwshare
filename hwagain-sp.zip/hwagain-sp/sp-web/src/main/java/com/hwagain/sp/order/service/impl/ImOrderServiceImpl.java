package com.hwagain.sp.order.service.impl;

import com.hwagain.sp.order.entity.ImOrder;
import com.hwagain.sp.order.entity.ImOrderDetail;
import com.hwagain.sp.product.entity.Product;


import com.hwagain.sp.order.dto.ImOrderDto;
import com.hwagain.sp.order.dto.ImOrderDetailDto;
import com.hwagain.sp.order.mapper.ImOrderMapper;
import com.hwagain.sp.order.service.IImOrderService;
import com.hwagain.sp.order.service.IImOrderDetailService;
import com.hwagain.sp.product.service.IProductService;


import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;



/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@Service("imOrderService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImOrderServiceImpl extends ServiceImpl<ImOrderMapper, ImOrder> implements IImOrderService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	@Autowired
	private	ImOrderMapper imOrderMapper;
	@Autowired
	private	IImOrderDetailService imOrderDetailService;
	
	@Autowired
	private	IProductService productService;
	

	
	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImOrder.class, ImOrderDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImOrderDto.class, ImOrder.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	

	@Override
	public List<ImOrderDto> findAll() {
		Wrapper<ImOrder> wrapper = new CriterionWrapper<ImOrder>(ImOrder.class);
		List<ImOrder> list = super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, ImOrderDto.class);
	}

	@Override
	public ImOrderDto findOne(Long fdId) {
		return entityToDtoMapper.map(super.selectById(fdId), ImOrderDto.class);
	}

	
	
	//保存订单，同时保存明细表 
	@Override
	public ImOrderDto save(ImOrderDto dto) {
		ImOrder entity = dtoToEntityMapper.map(dto, ImOrder.class);
		Assert.notNull(entity.getMachineType(), "纸机类型不能为空");
		Assert.notNull(entity.getClass(), "品类不能为空");
		Assert.notNull(entity.getKindNo(), "品种不能为空");
		Assert.notNull(entity.getRation(), "定量不能为空");
		Assert.notNull(entity.getColor(), "颜色不能为空");
		Assert.notNull(entity.getCustomerName(), "客户名称不能为空");
		Assert.notNull(entity.getOrderUser(), "收货人不能为空");
		Assert.notNull(entity.getOrderTel(), "收货人电话不能为空");
		
		//主表唯一主键
		Long orderId=Long.valueOf(IdWorker.getId());

		//查询订单号order_no
		String orderNo="";
		Integer orderIndex=imOrderDetailService.findTodayOrderIndex();
		String SerialNo="000"+orderIndex.toString();
		SerialNo=SerialNo.substring(SerialNo.length()-4);		
		//获取年月日
		Date d = new Date();  
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");  
        String yearMonthDay = sdf.format(d).substring(2);          
		if (entity.getKindNo().equals("a"))
		{
			orderNo="YZ"+yearMonthDay+SerialNo;			
		}
		else if (entity.getKindNo().equals("b"))
		{
			orderNo="YF"+yearMonthDay+SerialNo;			
		}
		else 
		{
			orderNo="YT"+yearMonthDay+SerialNo;			
		}			
		//主表产品product_id
		Long productId =getProductId(entity);
		Date actionDate=new Date(); 
		String actionUserId=UserUtils.getUserId();   //当前操作用户Id
		
		//重新赋值
		entity.setFdId(orderId);
		entity.setProductId(productId);
		entity.setOrderNo(orderNo);		
		entity.setCreatorId(actionUserId);
		entity.setCreateTime(actionDate);
		//保存主表
		super.insert(entity);
		
		
		//插入保存明细表
		List<ImOrderDetailDto> detailsList=dto.getDetailsList();	
		for (ImOrderDetailDto item:detailsList)
		{
			ImOrderDetailDto objDetail = item;
			objDetail.setFdId(Long.valueOf(IdWorker.getId()));  //主键fdId
			objDetail.setOrderId(orderId);  //给明细表赋值主表imOrderId
			objDetail.setCreatorId(actionUserId);
			objDetail.setCreateTime(actionDate);			
			
			imOrderDetailService.save(objDetail);			
		}		
		return dto;
	}
	
	//查询订单的product_id
	private Long getProductId(ImOrder entity)
	{
		String machineType=entity.getMachineType();
		String classNo=entity.getClassNo();
		String kindNo=entity.getKindNo();
		String ration=entity.getRation();
		String layer=entity.getLayer();
		String wrinkleRate=entity.getWrinkleRate();
		
		Long productId = null;
		Product model=productService.findProductByOrder(machineType, classNo, kindNo, ration, layer, wrinkleRate);
		if (model!=null)
		{
			productId=model.getFdId();			
		}		
		return productId;
	}

	
	//修改保存。先删除订单明细，再插入数据
	@Override
	public ImOrderDto update(ImOrderDto dto) {
		ImOrder entity = dtoToEntityMapper.map(dto, ImOrder.class);
		Date actionDate=new Date(); 
		String actionUserId=UserUtils.getUserId();   //当前操作用户Id
		//主表产品product_id
		Long productId =getProductId(entity);
		
		entity.setProductId(productId);
		entity.setLastAlterId(actionUserId);
		entity.setLastAlterTime(actionDate);
		super.updateById(entity);
		
		
		//获取主表fdId
		Long orderId=entity.getFdId();		
		//删除原来明细数据
		imOrderDetailService.deleteImOrderDetailByOrderId(orderId);			
		//插入保存明细表
		List<ImOrderDetailDto> detailsList=dto.getDetailsList();	
		for (ImOrderDetailDto item:detailsList)
		{
			ImOrderDetailDto objDetail =item;
			objDetail.setFdId(Long.valueOf(IdWorker.getId()));  //主键fdId
			objDetail.setOrderId(orderId);  //给明细表赋值主表imOrderId
			objDetail.setCreatorId(actionUserId);
			objDetail.setCreateTime(actionDate);	
			
			imOrderDetailService.save(objDetail);			
		}	
		return dto;
	}
	
	
	//通过order_no查询一条记录
	@Override
	public ImOrderDto findImOrderByOrderNo(String orderNo) {
		//订单主表
		ImOrderDto dto=imOrderMapper.findImOrderByOrderNo(orderNo);		
		//订单明细表
		Long orderId=dto.getFdId();		
		List<ImOrderDetailDto> detailsList=imOrderDetailService.findImOrderDetailListByOrderId(orderId);	
		dto.setDetailsList(detailsList);	
				
		return dto;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
