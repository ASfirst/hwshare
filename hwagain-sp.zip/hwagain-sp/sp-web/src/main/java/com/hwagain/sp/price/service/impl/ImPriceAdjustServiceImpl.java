package com.hwagain.sp.price.service.impl;

import com.hwagain.sp.price.entity.ImPrice;
import com.hwagain.sp.price.entity.ImPriceAdjust;
import com.hwagain.sp.base.dto.OaAduitDetailDto;
import com.hwagain.sp.base.entity.DictData;
import com.hwagain.sp.base.entity.OaAduit;
import com.hwagain.sp.base.entity.OaAduitDetail;
import com.hwagain.sp.base.mapper.RptTempMapper;
import com.hwagain.sp.base.service.IDictDataService;
import com.hwagain.sp.base.service.IOaAduitDetailService;
import com.hwagain.sp.base.service.IOaAduitService;
import com.hwagain.sp.price.dto.ImPriceAdjustDto;
import com.hwagain.sp.price.dto.ImPriceAdjustRptDto;
import com.hwagain.sp.price.dto.ImPriceDto;
import com.hwagain.sp.price.dto.ImPriceRptDto;
import com.hwagain.sp.price.mapper.ImPriceAdjustMapper;
import com.hwagain.sp.price.mapper.ImPriceRptMapper;
import com.hwagain.sp.price.service.IImPriceAdjustService;
import com.hwagain.sp.price.service.IImPriceService;
import com.hwagain.sp.price.sync.PriceUtils;
import com.hwagain.sp.product.dto.ProductClassDto;
import com.hwagain.sp.product.dto.ProductKindDto;
import com.hwagain.sp.product.entity.ProductClass;
import com.hwagain.sp.product.entity.ProductKind;
import com.hwagain.sp.product.service.IProductClassService;
import com.hwagain.sp.product.service.IProductKindService;
import com.hwagain.sp.util.PublicUtils;
import com.hwagain.sp.util.SqlDbUtils;
import com.alibaba.fastjson.JSONObject;
import com.fasterxml.jackson.annotation.JsonTypeInfo.As;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import oracle.net.aso.w;

/**
 * <p>
 * 服务实现类
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
@Service("imPriceAdjustService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImPriceAdjustServiceImpl extends ServiceImpl<ImPriceAdjustMapper, ImPriceAdjust>
		implements IImPriceAdjustService {

	// entity转dto
	static MapperFacade entityToDtoMapper;

	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImPriceAdjust.class, ImPriceAdjustDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();

		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImPriceAdjustDto.class, ImPriceAdjust.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

	@Autowired
	RptTempMapper rptTempMapper;
	@Autowired
	ImPriceRptMapper imPriceRptMapper;
	@Autowired
	IImPriceService imPriceService;
	@Autowired IProductClassService productClassService;
	@Autowired IProductKindService productKindService;

	// 价格调整-查询列表
	@Override
	public List<ImPriceAdjustRptDto> adjustQueryList() {

		// 判断是否需要初始化
		Wrapper<ImPriceAdjust> wrapper = new CriterionWrapper<ImPriceAdjust>(ImPriceAdjust.class);
		wrapper.ne("status", 30);
		wrapper.eq("is_delete", 0);
		List<ImPriceAdjust> list1 = super.selectList(wrapper);
		if (null == list1 || list1.isEmpty()) {
			Wrapper<ImPrice> wrapper2 = new CriterionWrapper<ImPrice>(ImPrice.class);
			wrapper2.eq("status", 30);
			wrapper2.eq("is_history", 0);
			wrapper2.eq("is_delete", 0);
			List<ImPrice> list2 = imPriceService.selectList(wrapper2);
			if (null == list2 || list2.isEmpty())
				Assert.throwException("没有已审批的价格纪录，无法进行调整");

			Date doDate = new Date();
			String curUserId = UserUtils.getUserId();

			for (ImPrice p : list2) {
				ImPriceAdjust j = new ImPriceAdjust();
				j.setFdId(IdWorker.getId());
				j.setImportPriceId(p.getFdId());
				j.setSourcePrice(p.getPrice());
				j.setStatus(10);
				j.setIsDelete(0);
				j.setCreaterId(curUserId);
				j.setCreateTime(doDate);
				super.insert(j);
			}
		}

		List<ImPriceAdjustRptDto> list = imPriceRptMapper.queryAdjustList(0);

		Integer seqNum = 1;
		for (ImPriceAdjustRptDto dto : list) {
			dto.setSeqNum(seqNum);
			seqNum++;
		}

		return list;
	}

	// 价格调整-更新一条
	@Override
	public ImPriceAdjustDto adjustUpdateOne(String fdid, BigDecimal addPrice, Date startDate, String remark) {
		Assert.notBlank(fdid, "修改记录id不能为空");

		ImPriceAdjust j = super.selectById(fdid);
		Assert.notNull(j, "没有找到需要修改的记录");
		if (j.getStatus() == 20)
			Assert.throwException("记录正在OA流程审核中,不允许修改");
		if (j.getStatus() == 30)
			Assert.throwException("记录已经审批,不允许修改");

		j.setAddPrice(addPrice);
		if (null != addPrice)
			j.setPrice(j.getSourcePrice().add(addPrice));
		else
			j.setPrice(null);
		j.setStartDate(startDate);
		//if (null != startDate)
		//	j.setEndDate(PriceUtils.getQuarterEndDate(startDate));
		//else
		//	j.setEndDate(null);
		j.setRemark(remark);
		j.setLastAlterTime(new Date());
		j.setLastAlterId(UserUtils.getUserId());

		super.updateAllById(j);

		return entityToDtoMapper.map(j, ImPriceAdjustDto.class);
	}

	// 价格调整-更新多条
	@Override
	public List<ImPriceAdjustDto> adjustUpdateSome(List<ImPriceAdjustDto> list) {
		List<ImPriceAdjustDto> list2 = new ArrayList<ImPriceAdjustDto>();

		int i = 1;
		for (ImPriceAdjustDto dto : list) {
			ImPriceAdjust j = super.selectById(String.valueOf(dto.getFdId()));
			Assert.notNull(j, "第" + String.valueOf(i) + "条纪录,没有找到需要修改的记录");
			if (j.getStatus() == 20)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,记录正在OA流程审核中,不允许修改");
			if (j.getStatus() == 30)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,记录已经审批,不允许修改");
			i++;
		}

		for (ImPriceAdjustDto dto : list) {
			list2.add(adjustUpdateOne(String.valueOf(dto.getFdId()), dto.getAddPrice(), dto.getStartDate(),
					dto.getRemark()));
		}

		return list2;
	}

	@Autowired
	IDictDataService dictDataService;
	@Autowired
	IOaAduitService oaAduitService;
	@Autowired
	IOaAduitDetailService oaAduitDetailService;

	// 价格调整-提交OA
	@Override
	public List<ImPriceAdjustRptDto> adjustSentToOa() {

		List<ImPriceAdjustRptDto> list = imPriceRptMapper.queryAdjustList(0);

		Assert.notNull(list, "没有找到需要推送OA的价格调整记录");
		Assert.isTrue(!list.isEmpty(), "没有找到需要推送OA的价格调整记录");

		int i = 1;
		int icount = 0;
		for (ImPriceAdjustRptDto dto : list) {
			if (dto.getAdj_status() != 10)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,不是未提交状态,无法提交OA");
			if (null != dto.getAdj_OACode() && !dto.getAdj_OACode().isEmpty())
				Assert.throwException("第" + String.valueOf(i) + "条纪录,OACode不为空,无法提交OA");

			if (null != dto.getAdj_startDate() && null != dto.getAdj_price())
				icount++;
			i++;
		}

		if (icount <= 0)
			Assert.throwException("必须至少输入一条记录的调整价格和开始日期");

		Date doDate = new Date();
		String oACode = String.valueOf(IdWorker.getId());

		String flowName = PriceUtils.const_OaFlowName_ImPriceAdjust;
		String platform = PublicUtils.const_Platform_Import;

		DictData dic = dictDataService.findOaTemId(flowName, platform);
		Assert.notNull(dic, "没有找到[" + flowName + "]的OA流程配置信息");
		Assert.notBlank(dic.getCode(), "没有找到[" + flowName + "]的OA流程配置信息");

		String temid = dic.getCode();
		String title = dic.getText();
		String userEmpNo = UserUtils.getUserInfo().getFdEmployeeNumber();
		String userName = UserUtils.getUserInfo().getName();
		Integer iresult = SqlDbUtils.sentOaFlow(temid, oACode, title, userEmpNo, userName, platform + ";" + flowName);
		Assert.isTrue(iresult == 1, "提交OA失败");

		// 记录日志
		OaAduit oa = new OaAduit();
		oa.setFdId(IdWorker.getId());
		oa.setOaCode(oACode);
		oa.setPlatform(platform);
		oa.setTableName("im_price_adjust");
		oa.setFlowName(flowName);
		oa.setNodeName("提交OA");
		oa.setEmpName(userName);
		oa.setEmpNo(userEmpNo);
		oa.setStatus(11);
		oa.setCreaterId(UserUtils.getUserId());
		oa.setCreateTime(doDate);
		oaAduitService.insert(oa);

		OaAduitDetailDto oaDetailDto = entityToDtoMapper.map(oa, OaAduitDetailDto.class);

		for (ImPriceAdjustRptDto dto : list) {
			dto.setAdj_OACode(oACode);
			dto.setAdj_status(11);
			dto.setStatusText("已提交");

			ImPriceAdjust j = super.selectById(dto.getAdj_fdId());
			j.setOACode(oACode);
			j.setStatus(11);
			j.setLastAlterTime(doDate);
			j.setLastAlterId(UserUtils.getUserId());

			super.updateById(j);

			OaAduitDetail oaDetail = dtoToEntityMapper.map(oaDetailDto, OaAduitDetail.class);
			oaDetail.setFdId(IdWorker.getId());
			oaDetail.setRecFdId(j.getFdId());
			oaAduitDetailService.insert(oaDetail);
		}

		return list;
	}

	// 价格调整-OA查询列表
	@Override
	public List<ImPriceAdjustRptDto> adjustQueryByOaCode(String oaCode) {
		List<ImPriceAdjustRptDto> list = imPriceRptMapper.queryAdjustByOaCode(oaCode, 1);

		Integer seqNum = 1;
		for (ImPriceAdjustRptDto dto : list) {
			dto.setSeqNum(seqNum);
			seqNum++;
		}

		return list;
	}

	// 价格调整-OA审批过程
	@Override
	public List<ImPriceAdjust> adjustOaAduitFlow(String oACode, Integer status, String nodeName, String empName,
			String empNo, String flowDjbh, String flowDjlsh) {

		Assert.isTrue(status == 11 || status == 20 || status == 30, "状态无效（只能是11或20或30）");

		// 0:查询所有的记录-包括不调整的
		// List<ImPriceAdjustRptDto> list =
		// imPriceRptMapper.queryAdjustByOaCode(oACode, 0);

		Wrapper<ImPriceAdjust> wrapper = new CriterionWrapper<ImPriceAdjust>(ImPriceAdjust.class);
		wrapper.eq("OACode", oACode);
		wrapper.eq("is_delete", 0);
		List<ImPriceAdjust> list = super.selectList(wrapper);

		Assert.notNull(list, "没有找到oACode对应的价格录入记录");
		Assert.isTrue(!list.isEmpty(), "没有找到oACode对应的价格录入记录");

		for (ImPriceAdjust j : list) {
			if (j.getStatus() == 30)
				Assert.throwException("部分记录已经审批");
		}

		Date doDate = new Date();
		String flowName = PriceUtils.const_OaFlowName_ImPriceAdjust;
		String platform = PublicUtils.const_Platform_Import;

		// 记录日志
		OaAduit oa = new OaAduit();
		oa.setFdId(IdWorker.getId());
		oa.setOaCode(oACode);
		oa.setPlatform(platform);
		oa.setTableName("im_price_adjust");
		oa.setFlowName(flowName);
		oa.setNodeName(nodeName);
		oa.setEmpName(empName);
		oa.setEmpNo(empNo);
		oa.setFlowDjbh(flowDjbh);
		oa.setFlowDjlsh(flowDjlsh);
		oa.setStatus(status);
		// oa.setCreaterId(UserUtils.getUserId());
		oa.setCreateTime(doDate);
		oaAduitService.insert(oa);

		OaAduitDetailDto oaDetailDto = entityToDtoMapper.map(oa, OaAduitDetailDto.class);

		for (ImPriceAdjust j : list) {

			if (status == 30 && null != j.getAddPrice()) {
				// 审批完成
				// 旧的价格记录
				ImPrice op = imPriceService.selectById(j.getImportPriceId());

				// 复制一条新的价格记录
				ImPriceDto opDto = entityToDtoMapper.map(op, ImPriceDto.class);
				ImPrice np = dtoToEntityMapper.map(opDto, ImPrice.class);
				np.setFdId(IdWorker.getId());
				np.setAddPrice(j.getAddPrice());
				np.setPrice(j.getPrice());
				np.setStartDate(j.getStartDate());
				np.setEndDate(j.getEndDate());
				np.setRemark(j.getRemark());
				np.setStatus(30);
				np.setOACode(j.getOACode());
				np.setIsHistory(0);
				np.setAdjustId(j.getFdId());
				np.setIsDelete(0);
				np.setCreaterId(j.getCreaterId());
				np.setCreateTime(doDate);
				// 插入新的价格记录
				imPriceService.insert(np);

				// 旧的价格记录更新为历史
				op.setIsHistory(1);
				op.setLastAlterId(j.getCreaterId());
				op.setLastAlterTime(doDate);
				imPriceService.updateById(op);
			}

			// 调整记录更新状态
			j.setStatus(status);
			j.setLastAlterTime(doDate);
			super.updateById(j);

			OaAduitDetail oaDetail = dtoToEntityMapper.map(oaDetailDto, OaAduitDetail.class);
			oaDetail.setFdId(IdWorker.getId());
			oaDetail.setRecFdId(j.getFdId());
			oaAduitDetailService.insert(oaDetail);
		}

		return list;
	}
	
	//========================================================================
	//价格录入（双人录入）
	@Override
	public ImPriceAdjustDto addOneEdit(ImPriceAdjustDto dto){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String curUserId = UserUtils.getUserId();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		Wrapper<ImPriceAdjust> wrapper=new CriterionWrapper<ImPriceAdjust>(ImPriceAdjust.class);
		wrapper.eq("creater_id", curUserId);
		wrapper.eq("status", 1);
		wrapper.eq("import_price_id", dto.getImportPriceId());
		ImPriceAdjust list=super.selectFirst(wrapper);
		if(list!=null){
			dto.setFdId(list.getFdId());
			dto.setStatus(1);
			dto.setCreaterId(curUserId);
			dto.setPrice(dto.getAddPrice().add(dto.getSourcePrice()));
			super.updateById(dtoToEntityMapper.map(dto, ImPriceAdjust.class));
		}else{
			dto.setFdId(Long.valueOf(IdWorker.getId()));
			dto.setCreaterId(curUserId);
			dto.setCreateTime(doDate);
			dto.setStatus(1);
			System.err.println(dto.getAddPrice()+":"+dto.getSourcePrice());
			dto.setPrice(dto.getAddPrice().add(dto.getSourcePrice()));
			dto.setRole(dept);
			super.insert(dtoToEntityMapper.map(dto, ImPriceAdjust.class));
		}
		return entityToDtoMapper.map(super.selectById(dto.getFdId()), ImPriceAdjustDto.class);
		
	}
	
	//查看当前录入者历史录入记录
	@Override
	public List<ImPriceAdjustRptDto> findNewHistory(){
		
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String curUserId = UserUtils.getUserId();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		Wrapper<ProductClass> wrapperPC=new CriterionWrapper<ProductClass>(ProductClass.class);
		wrapperPC.eq("platform", "Import");
		wrapperPC.eq("is_delete", 0);
		wrapperPC.eq("enabled", 2);
		wrapperPC.orderBy("class_no");
		List<ProductClass> listPC=productClassService.selectList(wrapperPC);
		
		Wrapper<ProductKind> wrapperPK=new CriterionWrapper<ProductKind>(ProductKind.class);
		wrapperPK.eq("platform", "Import");
		wrapperPK.eq("is_delete", 0);
		wrapperPK.eq("enabled", 2);
		wrapperPK.orderBy("kind_no");
		List<ProductKind> listPK=productKindService.selectList(wrapperPK);

//		Wrapper<ImPriceAdjust> wrapper =new CriterionWrapper<ImPriceAdjust>(ImPriceAdjust.class);
////		wrapper.eq("import_price_id", importPriceId);
//		wrapper.eq("creater_id", curUserId);
//		wrapper.eq("status", 1);
//		List<ImPriceAdjust> list=super.selectList(wrapper);
		List<ImPriceAdjustRptDto> listC=imPriceRptMapper.findNewHistory(0,curUserId);
		System.err.println(curUserId);
		Wrapper<ImPrice> wrapperIP =new CriterionWrapper<ImPrice>(ImPrice.class);
		wrapperIP.eq("status", 1);
		List<ImPrice> list1=imPriceService.selectList(wrapperIP);
		List<ImPriceAdjustRptDto> listA=new ArrayList<>();
		
		if(list1!=null&&list1.size()!=0){
			for(ImPrice dto:list1){
				BigDecimal a=new BigDecimal(0);
				String st=JSONObject.toJSONString(dto);
				ImPriceAdjustRptDto dtoA=JSONObject.parseObject(st, ImPriceAdjustRptDto.class);
				dtoA.setImportPriceId(dto.getFdId());
				dtoA.setAddPrice(a);
//				dtoA.setAdj_addPrice(dto.getAddPrice());
				dtoA.setAdj_sourcePrice(dto.getPrice());
				dtoA.setAdj_startDate(dto.getStartDate());
				int r=dtoA.getAddPrice().compareTo(BigDecimal.ZERO);
				if(r==1){
					dtoA.setAdj_remark("涨价");
				}
				if(r==-1){
					dtoA.setAdj_remark("降价");
				}if(r==0){
					dtoA.setAdj_remark("定价");
				}
				dtoA.setAdj_createrId(dto.getCreaterId());
				dtoA.setAdj_createTime(dto.getCreateTime());
				for(ProductClass dtoC:listPC){
					if(dto.getClassNo().equals(dtoC.getClassNo())){
						dtoA.setClassText(dtoC.getName());
					}
				}
				for(ProductKind dtoK:listPK){
					if(dto.getKindNo().equals(dtoK.getKindNo())){
						dtoA.setKindText(dtoK.getName());
					}
				}
				listA.add(dtoA);
			}
			if(listC!=null&&listC.size()!=0){
				for(ImPriceAdjustRptDto ddto:listC){
					for(ImPriceAdjustRptDto dtoA:listA){
						if(ddto.getImportPriceId().equals(dtoA.getImportPriceId())){
							dtoA.setFdId(ddto.getFdId());
							dtoA.setImportPriceId(ddto.getImportPriceId());
							dtoA.setAdj_sourcePrice(ddto.getAdj_sourcePrice());
							dtoA.setAddPrice(ddto.getAdj_addPrice());
							dtoA.setPrice(ddto.getAdj_price());
							dtoA.setStartDate(ddto.getStartDate());
							dtoA.setEndDate(ddto.getEndDate());
							dtoA.setAdj_role(ddto.getAdj_role());
							dtoA.setCreaterId(ddto.getAdj_createrId());
//							dtoA.setCreateTime(ddto.getCreateTime());
							dtoA.setStatus(1);
							int r=dtoA.getAddPrice().compareTo(BigDecimal.ZERO);
							if(r==1){
								dtoA.setAdj_remark("涨价");
							}
							if(r==-1){
								dtoA.setAdj_remark("降价");
							}if(r==0){
								dtoA.setAdj_remark("定价");
							}

						}
					}
				}
			}
		}
		
		return entityToDtoMapper.mapAsList(listA, ImPriceAdjustRptDto.class);
	}
	@Autowired ImPriceServiceImpl imPriceServiceImpl;
	@Override
	public List<ImPriceAdjustDto> matching(List<ImPriceAdjustDto> dtos){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String curUserId = UserUtils.getUserId();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		if(dtos.size()==0){
			Assert.throwException("提交数据为空");
		}
		Wrapper<ImPriceAdjust> wrapper =new CriterionWrapper<ImPriceAdjust>(ImPriceAdjust.class);
//		wrapper.eq("import_price_id", importPriceId);
		wrapper.eq("creater_id", curUserId);
		wrapper.eq("status", 1);
		wrapper.eq("is_delete", 0);
		List<ImPriceAdjust> list=super.selectList(wrapper);
		List<ImPriceAdjust> listA=new ArrayList<>();
		List<ImPriceDto> listB=new ArrayList<>();
		if(list!=null&&list.size()==0){
			Assert.throwException("未有数据可以匹配");
		}else{
			for(ImPriceAdjust dto:list){
				
				
				String st=JSONObject.toJSONString(dto);
				ImPriceDto list3=JSONObject.parseObject(st, ImPriceDto.class);
				Wrapper<ImPriceAdjust> wrapper1=new CriterionWrapper<ImPriceAdjust>(ImPriceAdjust.class);
				wrapper1.eq("add_price",dto.getAddPrice());
				wrapper1.eq("start_date", dto.getStartDate());
				wrapper1.notIn("creater_id", dto.getCreaterId());
				wrapper1.notIn("role", dto.getRole());
				wrapper1.eq("status", 1);
//				wrapper1.notIn("role", dto.getRole());
				ImPriceAdjust list1=super.selectFirst(wrapper1);
				if(list1!=null){
					listA.add(list1);
					listA.add(dto);
					listB.add(list3);
					ImPrice listI=imPriceService.selectById(dto.getImportPriceId());
					if(listI!=null){
						ImPrice imp=new ImPrice();
						imp.setFdId(dto.getImportPriceId());
						imp.setStatus(2);
						imp.setIsDelete(1);
						imp.setEndDate(dto.getStartDate());
						imp.setLastAlterTime(new Date());
						imp.setLastAlterId(dto.getCreaterId());
						imPriceService.updateById(imp);
//						ImPrice imp1=new ImPrice();
						listI.setFdId(Long.valueOf(IdWorker.getId()));
						listI.setAddPrice(dto.getAddPrice());
						listI.setPrice(dto.getPrice());
						listI.setStartDate(dto.getStartDate());
						listI.setCreaterId(curUserId);
						listI.setCreateTime(doDate);
						listI.setStatus(1);
//						list.setAdjustId(dto.getCreaterId());
						imPriceService.insert(dtoToEntityMapper.map(listI, ImPrice.class));
					}

				}else{
					Assert.throwException("匹配失败");
				}
			}
			for(ImPriceAdjust dto:listA){
//				System.err.println(dto.getFdId());
				ImPriceAdjust impa =new ImPriceAdjust();
				impa.setFdId(dto.getFdId());
				impa.setStatus(10);
				super.updateById(impa);
				
			}
		}
		return dtos;
		
	}

}
