package com.hwagain.sp.policy.component.verification;

import javax.validation.Constraint;
import javax.validation.Payload;
import java.lang.annotation.*;

import static java.lang.annotation.ElementType.ANNOTATION_TYPE;
import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.METHOD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.ElementType.TYPE_USE;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * Created on 2019/6/21 11:28
 * by @author WeiBoWen
 */
@Constraint(validatedBy = ConstraintsConstraintValidator.class)
@Target({FIELD, METHOD, PARAMETER, ANNOTATION_TYPE, TYPE_USE})
@Retention(RUNTIME)
@Documented
public @interface Constraints {

    String[] value();

    Class<?>[] groups() default {};

    Class<? extends Payload>[] payload() default {};

    String message() default "{值不在限定之内}";
}
