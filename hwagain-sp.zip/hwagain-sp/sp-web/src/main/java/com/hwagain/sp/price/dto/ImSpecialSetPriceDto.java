package com.hwagain.sp.price.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ImSpecialSetPriceDto {
/**
 * <p>
 * 
 * </p>
 *
 * @author
 * @since 2018-11-19
 */

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	private Long fdId;
	/**
     * 企业套产品编号
     */
	private String enterpriseSetNo;
    /**
     * 品类
     */
	private String classNo;
	private String classText;
    /**
     * 定量
     */
	private BigDecimal ration;
    /**
     * 起趋率
     */
	private BigDecimal wrinkleRate;
    /**
     * 层数
     */
	private String layer;
	/**
     * 分切规格
     */
	private String cutSpec;
    /**
     * 分切幅宽合计
     */
	private String totalWidth;
	/**
     * 直径
     */
	private BigDecimal diameter;
	/**
     * 对应常规价格
     */
	private BigDecimal normalPrice;
	/**
     * 增加价格
     */
	private BigDecimal addPrice;
	
	/**
     * 单幅幅宽
     */
	private Integer width;
	/**
     * 幅数
     */
	private Integer qty;
	
	/**
     * 小幅宽加价
     */
	private BigDecimal minWidthAddPrice;
    
    /**
     * 执行价格
     */
	private BigDecimal price;
    /**
     * 开始时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date startDate;
    /**
     * 结束时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date endDate;
    /**
     * 是否享受政策
     */
	private Integer isPolicy;
    /**
     * 物理指标号
     */
	private String physicalNo;
	private Integer isHistory;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getEnterpriseSetNo() {
		return enterpriseSetNo;
	}

	public void setEnterpriseSetNo(String enterpriseSetNo) {
		this.enterpriseSetNo = enterpriseSetNo;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getClassText() {
		return classText;
	}

	public void setClassText(String classText) {
		this.classText = classText;
	}

	public BigDecimal getRation() {
		return ration;
	}

	public void setRation(BigDecimal ration) {
		this.ration = ration;
	}

	public BigDecimal getWrinkleRate() {
		return wrinkleRate;
	}

	public void setWrinkleRate(BigDecimal wrinkleRate) {
		this.wrinkleRate = wrinkleRate;
	}

	public String getLayer() {
		return layer;
	}

	public void setLayer(String layer) {
		this.layer = layer;
	}

	public String getTotalWidth() {
		return totalWidth;
	}

	public void setTotalWidth(String totalWidth) {
		this.totalWidth = totalWidth;
	}


	public BigDecimal getDiameter() {
		return diameter;
	}

	public void setDiameter(BigDecimal diameter) {
		this.diameter = diameter;
	}

	public BigDecimal getNormalPrice() {
		return normalPrice;
	}

	public void setNormalPrice(BigDecimal normalPrice) {
		this.normalPrice = normalPrice;
	}

	public BigDecimal getAddPrice() {
		return addPrice;
	}

	public void setAddPrice(BigDecimal addPrice) {
		this.addPrice = addPrice;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public Integer getIsPolicy() {
		return isPolicy;
	}

	public void setIsPolicy(Integer isPolicy) {
		this.isPolicy = isPolicy;
	}
	private String isPolicyText="111";
	public String getIsPolicyText(){
		if(this.isPolicy==1){
			this.isPolicyText="是";
		}else{
			this.isPolicyText="否";
		}
		return isPolicyText;
	}
	public String getPhysicalNo() {
		return physicalNo;
	}

	public void setPhysicalNo(String physicalNo) {
		this.physicalNo = physicalNo;
	}

	public String getCutSpec() {
		return cutSpec;
	}

	public void setCutSpec(String cutSpec) {
		this.cutSpec = cutSpec;
	}

	public Integer getWidth() {
		return width;
	}

	public void setWidth(Integer width) {
		this.width = width;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public BigDecimal getMinWidthAddPrice() {
		return minWidthAddPrice;
	}

	public void setMinWidthAddPrice(BigDecimal minWidthAddPrice) {
		this.minWidthAddPrice = minWidthAddPrice;
	}

	public Integer getIsHistory() {
		return isHistory;
	}

	public void setIsHistory(Integer isHistory) {
		this.isHistory = isHistory;
	}

}


