package com.hwagain.sp.disobey.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.disobey.service.IBaseDisobeyEditService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
@RestController
@RequestMapping(value="/disobey/baseDisobeyEdit",method={RequestMethod.GET,RequestMethod.POST})
public class BaseDisobeyEditController extends BaseController{
	
	@Autowired
	IBaseDisobeyEditService baseDisobeyEditService;
	
}
