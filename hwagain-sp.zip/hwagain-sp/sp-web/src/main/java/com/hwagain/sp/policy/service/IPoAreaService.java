package com.hwagain.sp.policy.service;

import com.hwagain.sp.policy.dto.params.area.CheckPoAreaDto;
import com.hwagain.sp.policy.dto.params.area.PoAreaAndCustomerDto;
import com.hwagain.sp.policy.entity.PoArea;
import com.hwagain.sp.policy.dto.PoAreaDto;
import com.hwagain.framework.mybatisplus.service.IService;

import java.util.List;

import com.hwagain.framework.core.exception.CustomException;

/**
 * <p>
 * 服务类
 * </p>
 *
 * @author weibw
 * @since 2019-06-24
 */
public interface IPoAreaService extends IService<PoArea> {

    public List<PoAreaAndCustomerDto> findAll() throws CustomException;

    public PoAreaAndCustomerDto findOne(String fdId) throws CustomException;

    public PoAreaDto save(PoAreaDto dto) throws CustomException;

    public PoAreaDto update(PoAreaDto dto) throws CustomException;

    public Boolean deleteByIds(String ids) throws CustomException;

    public Boolean check(CheckPoAreaDto checkPoAreaDto) throws CustomException;

//	public PageDto<PoAreaDto> findByPage(PoAreaDto dto, PageVO pageVo) throws CustomException;
}
