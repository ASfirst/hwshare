package com.hwagain.sp.policy.component.verification;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * Created on 2019/6/21 11:34
 * by @author WeiBoWen
 */
public class ConstraintsConstraintValidator implements ConstraintValidator<Constraints,
        String> {

    private Constraints constraints;

    @Override
    public void initialize(Constraints constraintAnnotation) {
        this.constraints=constraintAnnotation;
    }

    @Override
    public boolean isValid(String value,
                           ConstraintValidatorContext constraintValidatorContext) {
        String[] in = constraints.value();
        for (String i : in) {
            if (i.equals(value)) {
                return true;
            }
        }
        return false;
    }

}
