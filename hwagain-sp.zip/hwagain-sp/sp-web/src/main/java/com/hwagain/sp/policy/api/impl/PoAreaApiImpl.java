package com.hwagain.sp.policy.api.impl;

import com.hwagain.sp.policy.api.IPoAreaApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author weibw
 * @since 2019-06-24
 */
@Service("poAreaApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoAreaApiImpl implements IPoAreaApi {
	
}
