package com.hwagain.sp.base.api.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hwagain.sp.base.api.IPhysicalStandardApi;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author linhl
 * @since 2018-11-05
 */
@Service("physicalStandardApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PhysicalStandardApiImpl implements IPhysicalStandardApi {
	
}
