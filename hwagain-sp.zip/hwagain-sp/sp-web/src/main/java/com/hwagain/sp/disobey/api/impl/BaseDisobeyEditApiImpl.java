package com.hwagain.sp.disobey.api.impl;

import com.hwagain.sp.disobey.api.IBaseDisobeyEditApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
@Service("baseDisobeyEditApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class BaseDisobeyEditApiImpl implements IBaseDisobeyEditApi {
	
}
