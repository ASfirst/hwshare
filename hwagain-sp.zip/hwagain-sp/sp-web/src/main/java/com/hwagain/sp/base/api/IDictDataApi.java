package com.hwagain.sp.base.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
public interface IDictDataApi {
	
}
