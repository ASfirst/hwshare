package com.hwagain.sp.price.service.impl;

import com.hwagain.sp.price.entity.ImPrice;
import com.hwagain.sp.price.entity.ImSpecialPrice;
import com.hwagain.sp.price.entity.ImSpecialPriceAdjust;
import com.hwagain.sp.base.dto.OaAduitDetailDto;
import com.hwagain.sp.base.entity.RptTempData;
import com.hwagain.sp.base.mapper.RptTempMapper;
import com.hwagain.sp.price.dto.ImPriceDto;
import com.hwagain.sp.price.dto.ImSpecialPriceAdjustDto;
import com.hwagain.sp.price.dto.ImSpecialPriceAdjustExtDto;
import com.hwagain.sp.price.dto.ImSpecialPriceDto;
import com.hwagain.sp.price.dto.ImSpecialPriceExtDto;
import com.hwagain.sp.price.mapper.ImSpecialPriceAdjustMapper;
import com.hwagain.sp.price.mapper.ImSpecialPriceExtMapper;
import com.hwagain.sp.price.service.IImSpecialPriceAdjustService;
import com.hwagain.sp.price.service.IImSpecialPriceService;
import com.hwagain.sp.price.sync.PriceUtils;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 * 进口纸机特规品价格调整【双人录入】 服务实现类
 * </p>
 *
 * @author guoym
 * @since 2018-10-16
 */
@Service("imSpecialPriceAdjustService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImSpecialPriceAdjustServiceImpl extends ServiceImpl<ImSpecialPriceAdjustMapper, ImSpecialPriceAdjust>
		implements IImSpecialPriceAdjustService {

	// entity转dto
	static MapperFacade entityToDtoMapper;

	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImSpecialPriceAdjust.class, ImSpecialPriceAdjustDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();

		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImSpecialPriceAdjustDto.class, ImSpecialPriceAdjust.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

	@Autowired
	RptTempMapper rptTempMapper;
	@Autowired
	ImSpecialPriceExtMapper imSpecialPriceExtMapper;
	@Autowired
	IImSpecialPriceService imSpecialPriceService;

	@Override
	public String getUserOrder() {

		String cUserid = UserUtils.getUserId();
		// 判断当前是否已经有2个人在录入
		String sql = "select count(distinct  j.creater_id) c1 from im_special_price_adjust j where j.is_delete=0 and `status`=0 "
				+ "  and j.creater_id !='" + cUserid + "' ";
		List<RptTempData> tmL1 = rptTempMapper.queryTempData(sql);
		if (null != tmL1 && !tmL1.isEmpty()) {
			if (Integer.valueOf(tmL1.get(0).getC1()) >= 2) {
				Assert.throwException("当前已经有2个人正在录入");
			}
		}

		String sql2 = " select distinct creater_id c1 from (  "
				+ "	select creater_id from im_special_price_adjust j where j.is_delete=0 and `status`=0   "
				+ "	order by j.create_time ) t ";

		List<RptTempData> tmL2 = rptTempMapper.queryTempData(sql2);
		if (null == tmL2 || tmL2.isEmpty())
			return "第一人";
		else {
			if (tmL2.get(0).getC1().equals(cUserid))
				return "第一人";
			else
				return "第二人";
		}
	}

	@Override
	public List<ImSpecialPriceAdjustExtDto> queryAdjustList() {
		String cUserid = UserUtils.getUserId();
		List<ImSpecialPriceAdjustExtDto> list = imSpecialPriceExtMapper.queryImSpecialAdjustList(cUserid);
		return list;
	}

	@Override
	public List<ImSpecialPriceAdjustExtDto> selectSpecialPrice(String specialPriceIds) {
		Assert.notBlank(specialPriceIds, "请选择需要调整的特规品价格纪录");

		String[] lIds = specialPriceIds.split(";");
		Assert.isTrue(null != lIds && lIds.length > 0, "请选择需要调整的特规品价格纪录");

		String cUserid = UserUtils.getUserId();
		String userName = UserUtils.getUserInfo().getName();
		Date doDate = new Date();

		String sTemp = getUserOrder();

		for (String sid : lIds) {
			ImSpecialPrice p = imSpecialPriceService.selectById(sid);
			Assert.notNull(p, "没有找到ID[" + sid + "]为的特规品价格纪录");

			Wrapper<ImSpecialPriceAdjust> wrapper = new CriterionWrapper<ImSpecialPriceAdjust>(
					ImSpecialPriceAdjust.class);
			wrapper.eq("is_delete", 0);
			wrapper.eq("status", 0);
			wrapper.eq("im_special_price_id", sid);
			wrapper.eq("creater_id", cUserid);
			ImSpecialPriceAdjust obj = super.selectFirst(wrapper);

			if (null == obj) {
				ImSpecialPriceAdjust n = new ImSpecialPriceAdjust();
				n.setFdId(IdWorker.getId());
				n.setImSpecialPriceId(Long.valueOf(sid));
				n.setNormalPrice(p.getNormalPrice());
				n.setSourceAddPrice(p.getAddPrice());
				n.setSourceExecPrice(p.getPrice());
				n.setStatus(0);
				n.setCreaterId(cUserid);
				n.setCreateTime(doDate);
				n.setCreaterName(userName);
				super.insert(n);
			}
		}

		return queryAdjustList();

	}

	// 删除多条
	@Override
	public List<ImSpecialPriceAdjust> deleteAdjustRecord(String specialPriceIds) {
		Assert.notBlank(specialPriceIds, "请选择需要删除的特规品价格纪录");

		String[] lIds = specialPriceIds.split(";");
		Assert.isTrue(null != lIds && lIds.length > 0, "请选择需要删除的特规品价格纪录");

		List<ImSpecialPriceAdjust> list = new ArrayList<ImSpecialPriceAdjust>();

		for (String sid : lIds) {
			ImSpecialPriceAdjust obj = super.selectById(sid);
			if (null != obj) {
				obj.setLastAlterId(UserUtils.getUserId());
				obj.setLastAlterTime(new Date());
				obj.setIsDelete(1);
				super.updateById(obj);

				list.add(obj);
			}
		}

		return list;
	}

	// 更新多条
	@Override
	public List<ImSpecialPriceAdjustDto> updateAdjustSome(List<ImSpecialPriceAdjustDto> list) {
		List<ImSpecialPriceAdjustDto> list2 = new ArrayList<ImSpecialPriceAdjustDto>();

		int i = 1;
		for (ImSpecialPriceAdjustDto dto : list) {
			ImSpecialPriceAdjust p = super.selectById(String.valueOf(dto.getFdId()));
			Assert.notNull(p, "第" + String.valueOf(i) + "条纪录,没有找到需要修改的记录");
			if (p.getStatus() == 1)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,已经生效,不允许修改");
			Assert.notNull(dto.getFdId(), "第" + String.valueOf(i) + "条纪录,修改记录id不能为空");
			Assert.notNull(dto.getAdjustAddPrice(), "第" + String.valueOf(i) + "条纪录,调整后的加价或优惠不能为空");
			Assert.notNull(dto.getStartDate(), "第" + String.valueOf(i) + "条纪录,开始日期不能为空");

			i++;
		}

		for (ImSpecialPriceAdjustDto dto : list) {
			list2.add(updateAdjustOne(String.valueOf(dto.getFdId()), dto.getAdjustAddPrice(), dto.getStartDate(),
					dto.getIsPolicy(), dto.getRemark()));
		}

		return list2;
	}

	// 更新一条
	@Override
	public ImSpecialPriceAdjustDto updateAdjustOne(String fdid, BigDecimal adjustAddPrice, Date startDate,
			Integer isPolicy, String remark) {
		Assert.notBlank(fdid, "修改记录id不能为空");
		Assert.notNull(adjustAddPrice, "调整后的加价或优惠不能为空");
		Assert.notNull(startDate, "开始日期不能为空");

		ImSpecialPriceAdjust p = super.selectById(fdid);
		Assert.notNull(p, "没有找到需要修改的记录");

		if (p.getStatus() == 1)
			Assert.throwException("记录已经生效,不允许修改");

		Date doDate = new Date();
		String cUsaerid = UserUtils.getUserId();

		p.setAdjustAddPrice(adjustAddPrice);
		p.setAdjustExecPrice(adjustAddPrice.add(p.getNormalPrice()));
		p.setStartDate(startDate);
		// p.setEndDate(PriceUtils.getQuarterEndDate(startDate));
		if (null != isPolicy)
			p.setIsPolicy(isPolicy);
		p.setRemark(remark);
		p.setLastAlterTime(doDate);
		p.setLastAlterId(cUsaerid);

		Wrapper<ImSpecialPriceAdjust> wrapper = new CriterionWrapper<ImSpecialPriceAdjust>(ImSpecialPriceAdjust.class);
		wrapper.eq("is_delete", 0);
		wrapper.eq("status", 0);
		wrapper.eq("im_special_price_id", p.getImSpecialPriceId());
		wrapper.ne("creater_id", UserUtils.getUserId());
		ImSpecialPriceAdjust obj = super.selectFirst(wrapper);

		if (null != obj && null != obj.getAdjustAddPrice() && null != obj.getStartDate()) {
			Boolean b1 = adjustAddPrice.compareTo(obj.getAdjustAddPrice()) == 0;
			Boolean b2 = startDate.compareTo(obj.getStartDate()) == 0;

			if (b1 && b2) {
				p.setStatusText("校验通过");
				p.setStatus(1);
				super.updateAllById(p);

				obj.setStatusText("校验通过");
				obj.setStatus(1);
				obj.setLastAlterTime(doDate);
				obj.setLastAlterId(cUsaerid);
				super.updateAllById(obj);

				// 更新原有价格纪录
				ImSpecialPrice oldsp = imSpecialPriceService.selectById(p.getImSpecialPriceId());
				oldsp.setIsHistory(1);
				oldsp.setLastAlterTime(doDate);
				oldsp.setLastAlterId(cUsaerid);
				if (null == oldsp.getBatchId())
					oldsp.setBatchId(oldsp.getFdId());
				imSpecialPriceService.updateById(oldsp);

				ImSpecialPriceDto newspDto = entityToDtoMapper.map(oldsp, ImSpecialPriceDto.class);
				ImSpecialPrice newsp = dtoToEntityMapper.map(newspDto, ImSpecialPrice.class);
				newsp.setFdId(IdWorker.getId());
				newsp.setAddPrice(p.getAdjustAddPrice());
				newsp.setPrice(p.getAdjustExecPrice());
				newsp.setStartDate(p.getStartDate());
				// newsp.setEndDate(p.getEndDate());
				// newsp.setIsPolicy(p.getIsPolicy());
				// newsp.setRemark(p.getRemark());
				newsp.setIsHistory(0);
				newsp.setStatus(30);
				newsp.setAdjustId(p.getFdId());
				newsp.setIsDelete(0);
				newsp.setCreaterId(cUsaerid);
				newsp.setCreateTime(doDate);
				newsp.setLastAlterTime(null);
				newsp.setLastAlterId(null);

				imSpecialPriceService.insert(newsp);
			} else {
				p.setStatusText("校验未通过,请核对录入信息");
				super.updateAllById(p);
			}
		} else {
			p.setStatusText("等待校验");
			super.updateAllById(p);
		}

		return entityToDtoMapper.map(p, ImSpecialPriceAdjustDto.class);
	}

	
	
	
}
