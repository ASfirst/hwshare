package com.hwagain.sp.process.sync;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class ProcessDateUtil {

    /**
     * 将String字符串转换为java.util.Date格式日期
     * 
     * @param strDate
     *            表示日期的字符串
     * @param dateFormat
     *            传入字符串的日期表示格式（如："yyyy-MM-dd HH:mm:ss"）
     * @return java.util.Date类型日期对象（如果转换失败则返回null）
     */
    public static java.util.Date strToUtilDate(String strDate, String dateFormat) {
        SimpleDateFormat sf = new SimpleDateFormat(dateFormat);
        java.util.Date date = null;
        try {
            date = sf.parse(strDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return date;
    }

    /**
     * 将String字符串转换为java.sql.Timestamp格式日期,用于数据库保存
     * 
     * @param strDate
     *            表示日期的字符串
     * @param dateFormat
     *            传入字符串的日期表示格式（如："yyyy-MM-dd HH:mm:ss"）
     * @return java.sql.Timestamp类型日期对象（如果转换失败则返回null）
     */
    public static java.sql.Timestamp strToSqlDate(String strDate, String dateFormat) {
        SimpleDateFormat sf = new SimpleDateFormat(dateFormat);
        java.util.Date date = null;
        try {
            date = sf.parse(strDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
        java.sql.Timestamp dateSQL = new java.sql.Timestamp(date.getTime());
        return dateSQL;
    }

    /**
     * 将java.util.Date对象转化为String字符串
     * 
     * @param date
     *            要格式的java.util.Date对象
     * @param strFormat
     *            输出的String字符串格式的限定（如："yyyy-MM-dd HH:mm:ss"）
     * @return 表示日期的字符串
     */
    public static String dateToStr(java.util.Date date, String strFormat) {
        SimpleDateFormat sf = new SimpleDateFormat(strFormat);
        String str = sf.format(date);
        return str;
    }

    /**
     * 将java.sql.Timestamp对象转化为String字符串
     * 
     * @param time
     *            要格式的java.sql.Timestamp对象
     * @param strFormat
     *            输出的String字符串格式的限定（如："yyyy-MM-dd HH:mm:ss"）
     * @return 表示日期的字符串
     */
    public static String dateToStr(java.sql.Timestamp time, String strFormat) {
        DateFormat df = new SimpleDateFormat(strFormat);
        String str = df.format(time);
        return str;
    }

    /**
     * 将java.sql.Timestamp对象转化为java.util.Date对象
     * 
     * @param time
     *            要转化的java.sql.Timestamp对象
     * @return 转化后的java.util.Date对象
     */
    public static java.util.Date timeToDate(java.sql.Timestamp time) {
        return time;
    }

    /**
     * 将java.util.Date对象转化为java.sql.Timestamp对象
     * 
     * @param date
     *            要转化的java.util.Date对象
     * @return 转化后的java.sql.Timestamp对象
     */
    public static java.sql.Timestamp dateToTime(java.util.Date date) {
        String strDate = dateToStr(date, "yyyy-MM-dd HH:mm:ss SSS");
        return strToSqlDate(strDate, "yyyy-MM-dd HH:mm:ss SSS");
    }

    /**
     * 返回表示系统当前时间的java.util.Date对象
     * @return  返回表示系统当前时间的java.util.Date对象
     */
    public static java.util.Date nowDate(){
        return new java.util.Date();
    }
    
    /**
     * 返回表示系统当前时间的java.sql.Timestamp对象
     * @return  返回表示系统当前时间的java.sql.Timestamp对象
     */
    public static java.sql.Timestamp nowTime(){
        return dateToTime(new java.util.Date());
    }
    
  //获取当前月最后一天
  	 public static String getLastDate()
  	 {
  		 SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd"); 
  			
  		 Calendar c = Calendar.getInstance();    
  		 c.set(Calendar.DAY_OF_MONTH, c.getActualMaximum(Calendar.DAY_OF_MONTH));  
  		 String last = format.format(c.getTime());
  		 return last;
  	 }
  	//获取当前日期
  	 public static String getNowDate()
  	 {
  		 SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");  
  		 Calendar c = Calendar.getInstance();   
  		 String nowdate = format.format(c.getTime());
  		 return nowdate;
  	 }
  	//获取当前年月
  	 public static String getNowYM()
  	 {
  		 SimpleDateFormat format = new SimpleDateFormat("yyyy-MM");  
  		 Calendar c = Calendar.getInstance();   
  		 String nowym = format.format(c.getTime());
  		 return nowym;
  	 }
  	//获取当前年份
  	 public static String getNowYear()
  	 {
  		 SimpleDateFormat format = new SimpleDateFormat("yyyy");  
  		 Calendar c = Calendar.getInstance();   
  		 String nowym = format.format(c.getTime());
  		 return nowym;
  	 }
  	//获取当前月份
  	 public static Integer getNowMonth()
  	 {
  		 Calendar calendar=Calendar.getInstance(); 
  		//获得当前时间的月份，月份从0开始所以结果要加1 ff
  		int month=calendar.get(Calendar.MONTH)+1;
  		return month;
  	 }
  	 
  	//获取年份
  	 public static Integer getYearOfDate(Date date)
  	 { 
  		 Calendar c = Calendar.getInstance();  
  		 c.setTime(date);
  		 int year = c.get(Calendar.YEAR);
  		 return year;
  	 }
  	 
  	//获取月份
  	 public static Integer getMonthOfDate(Date date)
  	 {
  		 Calendar c = Calendar.getInstance();  
  		 c.setTime(date);
  		 int month = c.get(Calendar.MONTH)+1;
  		 return month;
  	 }
  	 
  	/**
      * 
      * @param date1 <String>
      * @param date2 <String>
      * @return int
      * @throws ParseException
      */
     public static int getMonthSpace(String date1, String date2)
             throws ParseException {

         int result = 0;

         SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

         Calendar c1 = Calendar.getInstance();
         Calendar c2 = Calendar.getInstance();

         c1.setTime(sdf.parse(date1));
         c2.setTime(sdf.parse(date2));

         result = c2.get(Calendar.MONTH) - c1.get(Calendar.MONTH);

         return result == 0 ? 1 : Math.abs(result);

     }
     
     /**
      * <li>功能描述：时间相减得到天数
      * @param beginDateStr
      * @param endDateStr
      * @return
      * long 
      * @author Administrator
      */
     public static long getDaySub(String beginDateStr,String endDateStr)
     {
         long day=0;
         java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("yyyy-MM-dd");    
         java.util.Date beginDate;
         java.util.Date endDate;
         try
         {
             beginDate = format.parse(beginDateStr);
             endDate= format.parse(endDateStr);    
             day=(endDate.getTime()-beginDate.getTime())/(24*60*60*1000);    
             //System.out.println("相隔的天数="+day);   
         } catch (ParseException e)
         {
             // TODO 自动生成 catch 块
             e.printStackTrace();
         }   
         return day;
     }
     
     /**
     * 获取某月的第一天
     * @param year
     * @param month
     * @return
     */
     public static String getFirstDayOfMonth(int year,int month){
         Calendar cal = Calendar.getInstance();
         //设置年份
         cal.set(Calendar.YEAR,year);
         //设置月份
         cal.set(Calendar.MONTH, month-1);
         //获取某月最小天数
         int firstDay = cal.getActualMinimum(Calendar.DAY_OF_MONTH);
         //设置日历中月份的最小天数
         cal.set(Calendar.DAY_OF_MONTH, firstDay);
         //格式化日期
         SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
         String firstDayOfMonth = sdf.format(cal.getTime());
         return firstDayOfMonth;
     }

     
     
     /**
      * 获取某月的最后一天
      * 
      */

     public static String getLastDayOfMonth(int year,int month)
     {
         Calendar cal = Calendar.getInstance();
         //设置年份
         cal.set(Calendar.YEAR,year);
         //设置月份
         cal.set(Calendar.MONTH, month-1);
         //获取某月最大天数
         int lastDay = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
         //设置日历中月份的最大天数
         cal.set(Calendar.DAY_OF_MONTH, lastDay);
         //格式化日期
         SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
         String lastDayOfMonth = sdf.format(cal.getTime());
         return lastDayOfMonth;

     }
}
