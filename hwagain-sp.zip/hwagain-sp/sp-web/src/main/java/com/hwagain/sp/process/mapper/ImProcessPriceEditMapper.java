package com.hwagain.sp.process.mapper;

import java.util.List;

import com.hwagain.sp.process.dto.ImProcessPriceEditDto;
import com.hwagain.sp.process.entity.ImProcessPriceEdit;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huanglf
 * @since 2018-12-20
 */
public interface ImProcessPriceEditMapper extends BaseMapper<ImProcessPriceEdit> {
	public List<ImProcessPriceEdit> getPriceEditRole();
}