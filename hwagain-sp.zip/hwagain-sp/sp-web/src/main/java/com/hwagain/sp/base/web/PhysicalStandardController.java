package com.hwagain.sp.base.web;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;



import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponse;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.base.service.IPhysicalStandardService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author linhl
 * @since 2018-11-01
 */
@RestController
@RequestMapping(value="/base/physicalStandard",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "原纸物理指标同步", description = "原纸物理指标同步")
public class PhysicalStandardController extends BaseController{
	
	@Autowired
	IPhysicalStandardService physicalStandardService;
	
	@RequestMapping("/syncData")
	@ApiOperation(value="指标库同步到销售平台",notes="指标库同步到销售平台",httpMethod="POST")
	
	public Response SyncData(){
		Boolean isOk =physicalStandardService.syncData();
		return SuccessResponse.newInstance(isOk?"生成成功！":"生成失败！");
	}
}
