package com.hwagain.sp.base.service;

import com.hwagain.sp.base.entity.OaAduitDetail;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author guoym
 * @since 2018-10-11
 */
public interface IOaAduitDetailService extends IService<OaAduitDetail> {
	
}
