package com.hwagain.sp.disobey.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

public class ImDisobeyOverPeriodListDto {
	private String orderNo;
	/**
     * 订单ID
     */
	private Long orderId;
    /**
     * 客户ID
     */
	private Long customerId;
    /**
     * 客户名称
     */
	private String customerName;
	private String customerType;
    /**
     * 产品类型
     */
	private String kindNo;
	private String kindName;
    /**
     * 约定提货结束时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date lastPickupDate;
    /**
     * 超期天数
     */
	private Integer overDays;
    /**
     * 订货数量
     */
	private BigDecimal weight;
    /**
     * 生产入库数量
     */
	private BigDecimal goinWeight;
    /**
     * 累计提货数量
     */
	private BigDecimal pickupWeight;
    /**
     * 剩余数量
     */
	private BigDecimal remainWeight;
    /**
     * 定金额度
     */
	private BigDecimal orderAmount;
	/**
     * 实扣定金额
     */
	private BigDecimal deductAmount;
	private String machineType;
	private Integer seqNum;
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public Long getOrderId() {
		return orderId;
	}
	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}
	public Long getCustomerId() {
		return customerId;
	}
	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getCustomerType() {
		return customerType;
	}
	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}
	public String getKindNo() {
		return kindNo;
	}
	public void setKindNo(String kindNo) {
		this.kindNo = kindNo;
	}
	public String getKindName() {
		return kindName;
	}
	public void setKindName(String kindName) {
		this.kindName = kindName;
	}
	public Date getLastPickupDate() {
		return lastPickupDate;
	}
	public void setLastPickupDate(Date lastPickupDate) {
		this.lastPickupDate = lastPickupDate;
	}
	public Integer getOverDays() {
		return overDays;
	}
	public void setOverDays(Integer overDays) {
		this.overDays = overDays;
	}
	public BigDecimal getWeight() {
		return weight;
	}
	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}
	public BigDecimal getGoinWeight() {
		return goinWeight;
	}
	public void setGoinWeight(BigDecimal goinWeight) {
		this.goinWeight = goinWeight;
	}
	public BigDecimal getPickupWeight() {
		return pickupWeight;
	}
	public void setPickupWeight(BigDecimal pickupWeight) {
		this.pickupWeight = pickupWeight;
	}
	public BigDecimal getRemainWeight() {
		return remainWeight;
	}
	public void setRemainWeight(BigDecimal remainWeight) {
		this.remainWeight = remainWeight;
	}
	public BigDecimal getOrderAmount() {
		return orderAmount;
	}
	public void setOrderAmount(BigDecimal orderAmount) {
		this.orderAmount = orderAmount;
	}
	public BigDecimal getDeductAmount() {
		return deductAmount;
	}
	public void setDeductAmount(BigDecimal deductAmount) {
		this.deductAmount = deductAmount;
	}
	public String getMachineType() {
		return machineType;
	}
	public void setMachineType(String machineType) {
		this.machineType = machineType;
	}
	public Integer getSeqNum() {
		return seqNum;
	}
	public void setSeqNum(Integer seqNum) {
		this.seqNum = seqNum;
	}
	
}
