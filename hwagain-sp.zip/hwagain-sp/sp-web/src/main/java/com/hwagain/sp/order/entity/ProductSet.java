package com.hwagain.sp.order.entity;

import java.io.Serializable;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@TableName("product_set")
public class ProductSet implements Serializable {

    private static final long serialVersionUID = 1L;

	@TableId("fd_id")
	private Long fdId;
	@TableField("enterprise_set_no")
	private String enterpriseSetNo;
	@TableField("class_no")
	private String classNo;
	@TableField("kind_no")
	private String kindNo;
	private String ration;
	private String layer;
	private Integer diameter;
	@TableField("cut_spec")
	private String cutSpec;
	@TableField("total_width")
	private Integer totalWidth;
	@TableField("creater_id")
	private String createrId;
	@TableField("create_time")
	private Date createTime;
	@TableField("last_alter_id")
	private String lastAlterId;
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getEnterpriseSetNo() {
		return enterpriseSetNo;
	}

	public void setEnterpriseSetNo(String enterpriseSetNo) {
		this.enterpriseSetNo = enterpriseSetNo;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getKindNo() {
		return kindNo;
	}

	public void setKindNo(String kindNo) {
		this.kindNo = kindNo;
	}

	public String getRation() {
		return ration;
	}

	public void setRation(String ration) {
		this.ration = ration;
	}

	public String getLayer() {
		return layer;
	}

	public void setLayer(String layer) {
		this.layer = layer;
	}

	public Integer getDiameter() {
		return diameter;
	}

	public void setDiameter(Integer diameter) {
		this.diameter = diameter;
	}

	public String getCutSpec() {
		return cutSpec;
	}

	public void setCutSpec(String cutSpec) {
		this.cutSpec = cutSpec;
	}

	public Integer getTotalWidth() {
		return totalWidth;
	}

	public void setTotalWidth(Integer totalWidth) {
		this.totalWidth = totalWidth;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
