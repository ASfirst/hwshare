package com.hwagain.sp.jdbc;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.slf4j.LoggerFactory;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

@Aspect
@Component
@Order(2)
public class AspectAuthority {

    private static final org.slf4j.Logger log = LoggerFactory.getLogger(AspectAuthority.class);

    @Before("@annotation(myDataSource)")
    public void setDataSource(MyDataSource myDataSource)  {

        DataSourceContextHolder.setDBType(myDataSource.value());

    }


}
