package com.hwagain.sp.base.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.base.service.IDictDataService;
import com.hwagain.sp.util.PublicUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
@RestController
@RequestMapping(value="/base/dictData",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "数据字典", description = "数据字典")
public class DictDataController extends BaseController{
	
	@Autowired
	IDictDataService dictDataService;
	
	/**
	 * 按类型查询
	 * 
	 * @return
	 */
	@RequestMapping("/findByType")
	@ApiOperation(value = "按类型查询", notes = "按类型查询", httpMethod = "GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "typename", value = "类型", paramType = "query", required = true, dataType = "String") })
	public Response findByType(String typename) {
		return SuccessResponseData.newInstance(dictDataService.findByType(typename));
	}
	
	@RequestMapping("/getNewId")
	@ApiOperation(value = "获取id", notes = "获取id", httpMethod = "GET")
	public Response getNewId() {
		return SuccessResponseData.newInstance(String.valueOf(IdWorker.getId()));
	}
	
	@RequestMapping("/getSerialCode")
	@ApiOperation(value = "获取单据编码", notes = "获取单据编码", httpMethod = "GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "prefixChar", value = "前缀", paramType = "query", required = true, dataType = "String"),
		@ApiImplicitParam(name = "remark", value = "说明", paramType = "query", required = true, dataType = "String") })	
	public Response getSerialCode(String prefixChar,String remark) {
		return SuccessResponseData.newInstance(PublicUtils.getSerialCode(prefixChar, remark));
	}
	
}
