package com.hwagain.sp.policy.service;

import com.hwagain.sp.policy.dto.PoPolicyFormatDto;
import com.hwagain.sp.policy.entity.PoPolicy;

import java.util.List;

import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
public interface IPoPolicyService extends IService<PoPolicy> {

	public PoPolicyFormatDto saveOne(PoPolicyFormatDto dto);

	public List<PoPolicyFormatDto> findPolicyCurrentMonth(String fdYear, String fdMonth);

	public boolean deleteOne(String detailId);
	
}
