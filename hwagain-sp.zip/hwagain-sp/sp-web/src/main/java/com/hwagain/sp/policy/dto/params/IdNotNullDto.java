package com.hwagain.sp.policy.dto.params;

import javax.validation.constraints.NotNull;

/**
 * Created on 2019/6/24 15:01
 * by @author WeiBoWen
 */
public class IdNotNullDto {

    @NotNull(message = "fdId不能为空")
    private Long fdId;

    public Long getFdId() {
        return fdId;
    }

    public void setFdId(Long fdId) {
        this.fdId = fdId;
    }
}
