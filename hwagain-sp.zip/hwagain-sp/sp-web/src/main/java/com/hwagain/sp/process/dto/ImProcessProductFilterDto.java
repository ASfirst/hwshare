package com.hwagain.sp.process.dto;

import java.math.BigDecimal;
import java.util.Date;

public class ImProcessProductFilterDto {
	/**
     * 纸卷编号
     */
	private String paperNo;
    /**
     * 品类名称
     */
	private String className;
	/**
     * 规格型号
     */
	private String fmodel;
	/**
     * 辅助属性
     */
	private String FAuxProdName;
    /**
     * 重量
     */
	private BigDecimal weight;
    /**
     * 生产日期
     */
	private Date productDate;
	public String getPaperNo() {
		return paperNo;
	}
	public void setPaperNo(String paperNo) {
		this.paperNo = paperNo;
	}
	public String getClassName() {
		return className;
	}
	public void setClassName(String className) {
		this.className = className;
	}
	public String getFmodel() {
		return fmodel;
	}
	public void setFmodel(String fmodel) {
		this.fmodel = fmodel;
	}
	public String getFAuxProdName() {
		return FAuxProdName;
	}
	public void setFAuxProdName(String fAuxProdName) {
		FAuxProdName = fAuxProdName;
	}
	public BigDecimal getWeight() {
		return weight;
	}
	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}
	public Date getProductDate() {
		return productDate;
	}
	public void setProductDate(Date productDate) {
		this.productDate = productDate;
	}
	
}
