package com.hwagain.sp.order.service;

import com.hwagain.sp.order.entity.ProductSetDetail;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
public interface IProductSetDetailService extends IService<ProductSetDetail> {
	
}
