package com.hwagain.sp.order.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author huangdh
 * @since 2018-11-16
 */
public class ImOrderDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
    /**
     * 订单编号，按各纸种约定规则生成
     */
	private String orderNo;
    /**
     * 产品ID，对product表主键
     */
	private Long productId;
    /**
     * 纸机类型
     */
	private String machineType;
	/**
     * 产品品类
     */
	private String classNo;
    /**
     * 产品类型
     */
	private String kindNo;
    /**
     * 定量
     */
	private String ration;
    /**
     * 伸长率
     */
	private String wrinkleRate;
    /**
     * 层数
     */
	private String layer;
    /**
     * 直径
     */
	private Integer diameter;
	/**
     * 颜色
     */
	private String color;
    /**
     * 压光
     */
	private String doLight;
    /**
     * 湿强剂
     */
	private String wetStrength;
    /**
     * 订单类型,1非常规，2非常规单卷，3非常规复卷，4原有特规，5按新指标，6按纸样
     */
	private Integer orderType;
    /**
     * 总幅宽
     */
	private Integer totalWidth;
    /**
     * 客户ID
     */
	private Long customerId;
    /**
     * 客户名称
     */
	private String customerName;
    /**
     * 订金缴纳单位
     */
	private String depositCompany;
    /**
     * 订货人
     */
	private String orderUser;
    /**
     * 联系电话
     */
	private String orderTel;
    /**
     * 下单日期
     */
	private Date orderDate;
    /**
     * 最早可提货时间
     */
	private Date planPickDate;
    /**
     * 计划提货天数
     */
	private Integer pickDays;
    /**
     * 提货完成时间
     */
	private Date finishPickDate;
    /**
     * 预计总货款
     */
	private BigDecimal totalAmount;
    /**
     * 总定金
     */
	private BigDecimal totalDeposit;
    /**
     * 订货总量（吨）
     */
	private BigDecimal weight;
    /**
     * 邮编
     */
	private String postCode;
    /**
     * 邮寄地址
     */
	private String postAddress;
    /**
     * 收件人
     */
	private String receiver;
    /**
     * 收件人手机号
     */
	private String receiverTel;
    /**
     * 纸样编号,ZY+三位流水号
     */
	private String paperPatternNo;
    /**
     * 纸样要求
     */
	private String paperRequirement;
    /**
     * 纸样确认结果:已检测，待检测
     */
	private String paperConfirmResult;
    /**
     * 纸样确认时间
     */
	private Date paperConfirmDate;
    /**
     * 生产确认结果:待确认，能生产，不能生产
     */
	private String produceConfirmResult;
    /**
     * 生产确认时间
     */
	private Date produceConfirmDate;
    /**
     * 工艺指标确认:待确认，已确认，无
     */
	private String technicConfirm;
    /**
     * 工艺指标确认时间
     */
	private Date technicConfirmDate;
    /**
     * 价格测算:待测算，已测算，无
     */
	private String priceCalculation;
    /**
     * 价格测算时间
     */
	private Date priceCalculationDate;
    /**
     * 企业套产品编号
     */
	private String enterpriseSetNo;
    /**
     * 用户套产品编号
     */
	private String customerSetNo;
    /**
     * 是否删除
     */
	private Integer isDelete;
    /**
     * 备注
     */
	private String remark;
    /**
     * 订单状态:0暂存，5待缴定金，10已交定金待生产，15生产中，20已生产未提货完成，30已完成，40订单终结
     */
	private Integer status;
	private String creatorId;
    /**
     * 创建时间
     */
	private Date createTime;
	private String lastAlterId;
    /**
     * 更新时间
     */
	private Date lastAlterTime;


	//扩展字段
	private String className;
	private String kindName;
	private List<ImOrderDetailDto> detailsList;   //明细表

		
	
	
	
	
	
	

	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Long getProductId() {
		return productId;
	}

	public void setProductId(Long productId) {
		this.productId = productId;
	}

	
	public String getMachineType() {
		return machineType;
	}

	public void setMachineType(String machineType) {
		this.machineType = machineType;
	}
	
	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getKindNo() {
		return kindNo;
	}

	public void setKindNo(String kindNo) {
		this.kindNo = kindNo;
	}

	public String getRation() {
		return ration;
	}

	public void setRation(String ration) {
		this.ration = ration;
	}

	public String getWrinkleRate() {
		return wrinkleRate;
	}

	public void setWrinkleRate(String wrinkleRate) {
		this.wrinkleRate = wrinkleRate;
	}

	public String getLayer() {
		return layer;
	}

	public void setLayer(String layer) {
		this.layer = layer;
	}

	public Integer getDiameter() {
		return diameter;
	}

	public void setDiameter(Integer diameter) {
		this.diameter = diameter;
	}
	
	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}
	

	public String getDoLight() {
		return doLight;
	}

	public void setDoLight(String doLight) {
		this.doLight = doLight;
	}

	public String getWetStrength() {
		return wetStrength;
	}

	public void setWetStrength(String wetStrength) {
		this.wetStrength = wetStrength;
	}

	public Integer getOrderType() {
		return orderType;
	}

	public void setOrderType(Integer orderType) {
		this.orderType = orderType;
	}

	public Integer getTotalWidth() {
		return totalWidth;
	}

	public void setTotalWidth(Integer totalWidth) {
		this.totalWidth = totalWidth;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getDepositCompany() {
		return depositCompany;
	}

	public void setDepositCompany(String depositCompany) {
		this.depositCompany = depositCompany;
	}

	public String getOrderUser() {
		return orderUser;
	}

	public void setOrderUser(String orderUser) {
		this.orderUser = orderUser;
	}

	public String getOrderTel() {
		return orderTel;
	}

	public void setOrderTel(String orderTel) {
		this.orderTel = orderTel;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public Date getPlanPickDate() {
		return planPickDate;
	}

	public void setPlanPickDate(Date planPickDate) {
		this.planPickDate = planPickDate;
	}

	public Integer getPickDays() {
		return pickDays;
	}

	public void setPickDays(Integer pickDays) {
		this.pickDays = pickDays;
	}

	public Date getFinishPickDate() {
		return finishPickDate;
	}

	public void setFinishPickDate(Date finishPickDate) {
		this.finishPickDate = finishPickDate;
	}

	public BigDecimal getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(BigDecimal totalAmount) {
		this.totalAmount = totalAmount;
	}

	public BigDecimal getTotalDeposit() {
		return totalDeposit;
	}

	public void setTotalDeposit(BigDecimal totalDeposit) {
		this.totalDeposit = totalDeposit;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public String getPostCode() {
		return postCode;
	}

	public void setPostCode(String postCode) {
		this.postCode = postCode;
	}

	public String getPostAddress() {
		return postAddress;
	}

	public void setPostAddress(String postAddress) {
		this.postAddress = postAddress;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getReceiverTel() {
		return receiverTel;
	}

	public void setReceiverTel(String receiverTel) {
		this.receiverTel = receiverTel;
	}

	public String getPaperPatternNo() {
		return paperPatternNo;
	}

	public void setPaperPatternNo(String paperPatternNo) {
		this.paperPatternNo = paperPatternNo;
	}

	public String getPaperRequirement() {
		return paperRequirement;
	}

	public void setPaperRequirement(String paperRequirement) {
		this.paperRequirement = paperRequirement;
	}

	public String getPaperConfirmResult() {
		return paperConfirmResult;
	}

	public void setPaperConfirmResult(String paperConfirmResult) {
		this.paperConfirmResult = paperConfirmResult;
	}

	public Date getPaperConfirmDate() {
		return paperConfirmDate;
	}

	public void setPaperConfirmDate(Date paperConfirmDate) {
		this.paperConfirmDate = paperConfirmDate;
	}

	public String getProduceConfirmResult() {
		return produceConfirmResult;
	}

	public void setProduceConfirmResult(String produceConfirmResult) {
		this.produceConfirmResult = produceConfirmResult;
	}

	public Date getProduceConfirmDate() {
		return produceConfirmDate;
	}

	public void setProduceConfirmDate(Date produceConfirmDate) {
		this.produceConfirmDate = produceConfirmDate;
	}

	public String getTechnicConfirm() {
		return technicConfirm;
	}

	public void setTechnicConfirm(String technicConfirm) {
		this.technicConfirm = technicConfirm;
	}

	public Date getTechnicConfirmDate() {
		return technicConfirmDate;
	}

	public void setTechnicConfirmDate(Date technicConfirmDate) {
		this.technicConfirmDate = technicConfirmDate;
	}

	public String getPriceCalculation() {
		return priceCalculation;
	}

	public void setPriceCalculation(String priceCalculation) {
		this.priceCalculation = priceCalculation;
	}

	public Date getPriceCalculationDate() {
		return priceCalculationDate;
	}

	public void setPriceCalculationDate(Date priceCalculationDate) {
		this.priceCalculationDate = priceCalculationDate;
	}

	public String getEnterpriseSetNo() {
		return enterpriseSetNo;
	}

	public void setEnterpriseSetNo(String enterpriseSetNo) {
		this.enterpriseSetNo = enterpriseSetNo;
	}

	public String getCustomerSetNo() {
		return customerSetNo;
	}

	public void setCustomerSetNo(String customerSetNo) {
		this.customerSetNo = customerSetNo;
	}

	public Integer getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

	
	//扩展字段
	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}
	
	public String getKindName() {
		return kindName;
	}

	public void setKindName(String kindName) {
		this.kindName = kindName;
	}
	
	
	//订单明细表
	public List<ImOrderDetailDto> getDetailsList() {
		return detailsList;
	}
	public void setDetailsList(List<ImOrderDetailDto> detailsList) {
		this.detailsList = detailsList;
	}
	
		
		
}
