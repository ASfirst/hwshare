package com.hwagain.sp.price.web;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.price.dto.ImPriceDto;
import com.hwagain.sp.price.dto.ImSpecialPriceAdjustDto;
import com.hwagain.sp.price.service.IImSpecialPriceAdjustService;
import com.hwagain.sp.price.service.IImSpecialPriceService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 *  进口纸机-特规品价格-前端控制器
 * </p>
 *
 * @author guoym
 * @since 2018-10-16
 */
@RestController
@RequestMapping(value="/price/imSpecialPrice",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "【进口纸机】特规品价格", description = "【进口纸机】特规品价格")
public class ImSpecialPriceController extends BaseController{
	
	@Autowired
	IImSpecialPriceService imSpecialPriceService;
	@Autowired
	IImSpecialPriceAdjustService imSpecialPriceAdjustService;
	
	@RequestMapping("/queryImSpecialPriceList")
	@ApiOperation(value = "查询特规品价格", notes = "查询特规品价格", httpMethod = "GET")
	public Response queryImSpecialPriceList() {
		return SuccessResponseData.newInstance(imSpecialPriceService.queryImSpecialPriceList());
	}
	
	@RequestMapping("/adjustUserOrder")
	@ApiOperation(value = "录入人顺序【价格调整】", notes = "录入人顺序【价格调整】", httpMethod = "GET")
	public Response adjustUserOrder() {
		return SuccessResponseData.newInstance(imSpecialPriceAdjustService.getUserOrder());
	}
	
	@RequestMapping("/adjustQueryList")
	@ApiOperation(value = "查询列表【价格调整】", notes = "查询列表【价格调整】", httpMethod = "GET")
	public Response adjustQueryList() {
		return SuccessResponseData.newInstance(imSpecialPriceAdjustService.queryAdjustList());
	}
	
	@RequestMapping(value = "/adjustSelectPrice", method = { RequestMethod.POST })
	@ApiOperation(value = "选择调整记录【价格调整】", notes = "选择调整记录【价格调整】", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "specialPriceIds", value = "选择的产品id,格式：1;2;3;4....", paramType = "query", required = true, dataType = "String") })
	public Response adjustSelectPrice(String specialPriceIds) {
		return SuccessResponseData.newInstance(imSpecialPriceAdjustService.selectSpecialPrice(specialPriceIds));
	}
	
	@RequestMapping(value = "/adjustDeleteRecords", method = { RequestMethod.POST })
	@ApiOperation(value = "删除调整记录【价格调整】", notes = "删除调整记录【价格调整】", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "specialPriceIds", value = "选择的产品id,格式：1;2;3;4....", paramType = "query", required = true, dataType = "String") })
	public Response adjustDeleteRecords(String specialPriceIds) {
		return SuccessResponseData.newInstance(imSpecialPriceAdjustService.deleteAdjustRecord(specialPriceIds));
	}
	
	@RequestMapping(value = "/adjustUpdateOne", method = { RequestMethod.POST })
	@ApiOperation(value = "更新一条【价格调整】", notes = "更新一条【价格调整】", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "fdid", value = "修改记录id", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "adjustAddPrice", value = "调整后的加价或优惠", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "startDate", value = "开始日期", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "isPolicy", value = "是否享受政策(1:是;0:否)", paramType = "query", required = false, dataType = "String"),
			@ApiImplicitParam(name = "remark", value = "备注", paramType = "query", required = false, dataType = "String"), })
	public Response adjustUpdateOne(String fdid, BigDecimal adjustAddPrice, Date startDate,
			Integer isPolicy, String remark) {
		return SuccessResponseData.newInstance(
				imSpecialPriceAdjustService.updateAdjustOne(fdid,  adjustAddPrice,  startDate, isPolicy, remark));
	}

	@RequestMapping(value = "/adjustUpdateSome", method = { RequestMethod.POST })
	@ApiOperation(value = "更新多条【价格调整】", notes = "更新多条【价格调整】<br/>需传字段：<br/>fdId:修改记录id<br/>  adjustAddPrice:调整后的加价或优惠<br/> "
			+ " startDate:开始日期<br/>  isPolicy:是否享受政策(1:是;0:否)<br/>    remark:备注 ", httpMethod = "POST")
	public Response adjustUpdateSome(@RequestBody List<ImSpecialPriceAdjustDto> list) {
		return SuccessResponseData.newInstance(imSpecialPriceAdjustService.updateAdjustSome(list));
	}
	
	@RequestMapping("/queryHistoryByBatchId")
	@ApiOperation(value = "查询历史(按批次id)", notes = "查询历史(按批次id)", httpMethod = "GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "batchId", value = "批次id", paramType = "query", required = true, dataType = "String") })
	public Response queryHistoryByBatchId(String batchId) {
		return SuccessResponseData.newInstance(imSpecialPriceService.queryHistoryByBatchId(batchId));
	}
	
	
}
