package com.hwagain.sp.order.entity;

import java.io.Serializable;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author huangdh
 * @since 2018-11-16
 */
@TableName("im_order_spec")
public class ImOrderSpec implements Serializable {

    private static final long serialVersionUID = 1L;

	@TableId("fd_id")
	private Long fdId;
    /**
     * 订单主表ID
     */
	@TableField("order_id")
	private Long orderId;
    /**
     * 品类
     */
	@TableField("class_no")
	private String classNo;
    /**
     * 定量
     */
	private String ration;
    /**
     * 层数
     */
	private Integer layer;
    /**
     * 颜色:白色，本色
     */
	private String color;
    /**
     * 白度
     */
	@TableField("white_rate")
	private String whiteRate;
    /**
     * 复卷工艺：不压光，轻压光，重压光
     */
	@TableField("do_light")
	private String doLight;
    /**
     * 起皱率
     */
	@TableField("wrinkle_rate")
	private String wrinkleRate;
    /**
     * 直径
     */
	private Integer diameter;
    /**
     * 厚度
     */
	private String deep;
    /**
     * 柔软度
     */
	@TableField("fibre_soft")
	private String fibreSoft;
    /**
     * 横向吸液高度
     */
	@TableField("horizontal_suck")
	private Integer horizontalSuck;
    /**
     * 纸筒心内径
     */
	@TableField("internal_diameter")
	private Integer internalDiameter;
    /**
     * 膜包装指标
     */
	@TableField("film_quota")
	private String filmQuota;
    /**
     * 湿强剂
     */
	@TableField("wet_strength")
	private String wetStrength;
    /**
     * 横向搞张强度
     */
	@TableField("resist_horizontal")
	private String resistHorizontal;
    /**
     * 纵向搞张强度
     */
	@TableField("resist_vertical")
	private String resistVertical;
    /**
     * 抗张强度纵横强比
     */
	@TableField("resist_ratio")
	private String resistRatio;
    /**
     * 横向抗张指数
     */
	@TableField("resist_horizontal_index")
	private String resistHorizontalIndex;
    /**
     * 纵向湿抗张强度
     */
	@TableField("resist_vertical_moisture")
	private String resistVerticalMoisture;
    /**
     * 状态
     */
	private Integer status;
	@TableField("creator_id")
	private String creatorId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 更新时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getRation() {
		return ration;
	}

	public void setRation(String ration) {
		this.ration = ration;
	}

	public Integer getLayer() {
		return layer;
	}

	public void setLayer(Integer layer) {
		this.layer = layer;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getWhiteRate() {
		return whiteRate;
	}

	public void setWhiteRate(String whiteRate) {
		this.whiteRate = whiteRate;
	}

	public String getDoLight() {
		return doLight;
	}

	public void setDoLight(String doLight) {
		this.doLight = doLight;
	}

	public String getWrinkleRate() {
		return wrinkleRate;
	}

	public void setWrinkleRate(String wrinkleRate) {
		this.wrinkleRate = wrinkleRate;
	}

	public Integer getDiameter() {
		return diameter;
	}

	public void setDiameter(Integer diameter) {
		this.diameter = diameter;
	}

	public String getDeep() {
		return deep;
	}

	public void setDeep(String deep) {
		this.deep = deep;
	}

	public String getFibreSoft() {
		return fibreSoft;
	}

	public void setFibreSoft(String fibreSoft) {
		this.fibreSoft = fibreSoft;
	}

	public Integer getHorizontalSuck() {
		return horizontalSuck;
	}

	public void setHorizontalSuck(Integer horizontalSuck) {
		this.horizontalSuck = horizontalSuck;
	}

	public Integer getInternalDiameter() {
		return internalDiameter;
	}

	public void setInternalDiameter(Integer internalDiameter) {
		this.internalDiameter = internalDiameter;
	}

	public String getFilmQuota() {
		return filmQuota;
	}

	public void setFilmQuota(String filmQuota) {
		this.filmQuota = filmQuota;
	}

	public String getWetStrength() {
		return wetStrength;
	}

	public void setWetStrength(String wetStrength) {
		this.wetStrength = wetStrength;
	}

	public String getResistHorizontal() {
		return resistHorizontal;
	}

	public void setResistHorizontal(String resistHorizontal) {
		this.resistHorizontal = resistHorizontal;
	}

	public String getResistVertical() {
		return resistVertical;
	}

	public void setResistVertical(String resistVertical) {
		this.resistVertical = resistVertical;
	}

	public String getResistRatio() {
		return resistRatio;
	}

	public void setResistRatio(String resistRatio) {
		this.resistRatio = resistRatio;
	}

	public String getResistHorizontalIndex() {
		return resistHorizontalIndex;
	}

	public void setResistHorizontalIndex(String resistHorizontalIndex) {
		this.resistHorizontalIndex = resistHorizontalIndex;
	}

	public String getResistVerticalMoisture() {
		return resistVerticalMoisture;
	}

	public void setResistVerticalMoisture(String resistVerticalMoisture) {
		this.resistVerticalMoisture = resistVerticalMoisture;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
