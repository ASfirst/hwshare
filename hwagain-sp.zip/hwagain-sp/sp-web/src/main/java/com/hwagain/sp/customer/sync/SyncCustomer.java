package com.hwagain.sp.customer.sync;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.core.util.SpringBeanUtil;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.sp.customer.entity.Customer;
import com.hwagain.sp.customer.service.ICustomerService;
import com.hwagain.sp.customer.service.impl.CustomerServiceImpl;
import com.hwagain.sp.util.JDBCConfig;
import com.hwagain.sp.util.SqlDbUtils;


@Configurable
@EnableScheduling
@Component
public class SyncCustomer {
	private static final Logger logger = LoggerFactory.getLogger(SqlDbUtils.class);

	static JDBCConfig jDBCConfig;
	@Autowired ICustomerService customerService;
	@Autowired CustomerServiceImpl customerServiceImpl;

	public static JDBCConfig getjDBCConfig() {
		if (jDBCConfig == null) {
			jDBCConfig = SpringBeanUtil.getBean(JDBCConfig.class);
		}
		return jDBCConfig;
	}
//	@Scheduled(cron = "0 0 1 ? * *") // 每天1点执行
//	@Scheduled(cron = "0/30 * * * * ?") // 每30秒执行一次
	public void customerSync() {
		Integer iresult = 1;

		String url = getjDBCConfig().getOA1Url();// 127.0.0.1是本机地址，XE是精简版Oracle的默认数据库名
		String username = getjDBCConfig().getOAUsername();// 用户名,系统默认的账户名
		String password = getjDBCConfig().getOAPassword();// 你安装时选设置的密码

		Connection con = null;// 创建一个数据库连接
		PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
		ResultSet result = null;// 创建一个结果集对象
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");// 加载sql驱动程序

			con = DriverManager.getConnection(url, username, password);// 获取连接
			String sql = "SELECT [ID] ,[省],[市],[县],[经销商名称]  ,[法人代表] ,[负责人] ,[手机] ,[电话],[传真],[地址] ,[邮编] ,[注册资金] ,[流动资金] ,[年销售额],[是否使用财务软件] ,[财务软件名称] ,[企业性质]  ,[是否一般纳税人] ,[调查人],[调查时间],[经销商类别]  ,CONVERT(int, [注册单位标记]) as 注册单位标记 ,[客户类型]  ,[开发人]  ,[生意开发期] ,[生意开发期起算时间]  ,[生意开发期结束时间] ,[合同约定月提货量]  ,[客户简称],[短信接收人],[短信接收号码] ,[最后更新时间] , 状态 from DB208.销售基础信息平台.dbo.进口纸机原纸经销商 T "
					+ "inner join (select ID as CustID,MAX(状态) as 状态  "
					+ "from (SELECT DISTINCT b.ID,a.状态 FROM DB208.销售基础信息平台.dbo.进口纸机原纸经销商付款单位 a  "
					+ "INNER JOIN DB208.销售基础信息平台.dbo.进口纸机原纸经销商 b  ON a.经销商ID=b.ID )t1 "
					+ "group by ID having COUNT(*)=1 union  select ID,MAX(状态) as 状态 "
					+ "from (SELECT DISTINCT b.ID,a.状态 FROM DB208.销售基础信息平台.dbo.进口纸机原纸经销商付款单位 a  "
					+ "INNER JOIN DB208.销售基础信息平台.dbo.进口纸机原纸经销商 b  ON a.经销商ID=b.ID )t2 "
					+ "group by ID having COUNT(*)>1 )A on T.ID=a.CustID";
				pre = con.prepareStatement(sql);// 实例化预编译语句
				result = pre.executeQuery();// 执行查询，注意括号中不需要再加参数
				ResultSetMetaData md = pre.getMetaData();
				int columnCount = md.getColumnCount();
				int count = 0;
				while (result.next()) {
					Map<String, Object> map = new HashMap<>();
					for (int i = 1; i <= columnCount; i++)
						map.put(md.getColumnName(i), result.getObject(i));
					customerSave(map);
					count++;
				}
	
				System.out.println("customer同步完成，总条数：" + count);

		} catch (Exception e) {
			e.printStackTrace();
			iresult = 0;
		} finally {
			try {
				if (result != null)
					result.close();
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}
	@Transactional
	private boolean customerSave(Map<String, Object> obj) {
		//根据客户名称进行更新完善客户资料
		String custName=(String)obj.get("经销商名称");
//		System.err.println(custName);
		Customer dst= customerService.findByCustName((String) obj.get("经销商名称"));
		Boolean bNew = false;
		if (dst == null) {
			return false;
		} else {
			if (!dst.getCustName().equals(custName)) {
				bNew = true;
				dst = new Customer();
			}
		}

		String str;

//		dst.setFdId(Long.valueOf(IdWorker.getId()));
//		dst.setId((Integer) obj.get("ID"));
//		dst.setPlatform("Import");
		dst.setProvince((String) obj.get("省"));
		dst.setCity((String) obj.get("市"));
		dst.setCounty((String) obj.get("县"));
		dst.setCustName((String) obj.get("经销商名称"));
		dst.setLawMan((String) obj.get("法人代表"));
		dst.setLawReposibility((String) obj.get("负责人"));
		dst.setMobile((String) obj.get("手机"));
		dst.setTel((String) obj.get("电话"));
		dst.setFax((String) obj.get("传真"));
		dst.setAddress((String) obj.get("地址"));
		dst.setPostNo((String) obj.get("邮编"));
		dst.setRegisterAmount((BigDecimal) obj.get("注册资金"));
		dst.setFlowAmount((BigDecimal) obj.get("流动资金"));
		dst.setYearAmount((BigDecimal) obj.get("年销售额"));
		dst.setIsUseFinanceSoft((String) obj.get("是否使用财务软件"));
		dst.setSoftName((String) obj.get("财务软件名称"));
		dst.setEnterpriseType((String) obj.get("企业性质"));
//		dst.setIsRatePaying((Integer) obj.get("是否一般纳税人"));
		if(obj.get("是否一般纳税人").equals("否")){
			dst.setIsRatePaying(0);
		}
		if(obj.get("是否一般纳税人").equals("是")){
			dst.setIsRatePaying(1);
		}
		dst.setInvestigateBy((String) obj.get("调查人"));
		dst.setInvestigateDate((Date) obj.get("调查时间"));
		dst.setDealerTypeId((Integer) obj.get("经销商类别"));
	
		dst.setIsRegister((Integer) obj.get("注册单位标记"));
		dst.setCustTypeName((String) obj.get("客户类型"));
		dst.setDeveloper((String) obj.get("开发人"));
		dst.setStartupBusiness((Integer) obj.get("生意开发期"));
		dst.setBusinessStartDate((Date) obj.get("生意开发期起算时间"));
		dst.setBusinessEndDate((Date) obj.get("生意开发期结束时间"));
		dst.setPromiseWeight((BigDecimal) obj.get("合同约定月提货量"));
		dst.setShortName((String) obj.get("客户简称"));
		dst.setReceiverBy((String) obj.get("短信接收人"));
		dst.setReceiverMobile((String) obj.get("短信接收号码"));
//		dst.setLastedUpdateDate((Date) obj.get("最后更新时间"));
		dst.setStatus((String) obj.get("状态"));
		if(obj.get("状态").equals("使用")){
			dst.setUse(true);
		}
		if(obj.get("状态").equals("关闭")){
			dst.setUse(false);
		}
	    customerService.updateAllById(dst);

		return true;
	}


}
