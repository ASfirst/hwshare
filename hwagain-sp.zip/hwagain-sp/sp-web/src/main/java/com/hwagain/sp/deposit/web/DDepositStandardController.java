package com.hwagain.sp.deposit.web;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.deposit.dto.DDepositStandardDto;
import com.hwagain.sp.deposit.dto.DDepositStandardEditDto;
import com.hwagain.sp.deposit.service.IDDepositStandardEditService;
import com.hwagain.sp.deposit.service.IDDepositStandardService;
import com.hwagain.sp.price.dto.ImPriceDifferenceEditDto;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;
import oracle.net.aso.d;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xionglz
 * @since 2018-11-05
 */
@RestController
@RequestMapping(value="/deposit/dDepositStandard",method={RequestMethod.GET,RequestMethod.POST})
@Api(value="【进口纸机】产品定金标准",description="【进口纸机】产品定金标准")
public class DDepositStandardController extends BaseController{
	
	@Autowired
	IDDepositStandardService dDepositStandardService;
	@Autowired
	IDDepositStandardEditService dDepositStandardEditService;
	
	//查询所有有效定金标准
	@RequestMapping("/findAll")
	@ApiOperation(value="查询有效定金标准",notes="查询有效定金标准",httpMethod="GET")
	public Response findAll(){
		return SuccessResponseData.newInstance(dDepositStandardService.findAll());
	}
	
	@RequestMapping("/findHistoryDeposit")
	@ApiOperation(value="查询历史定金标准",notes="查询历史定金标准",httpMethod="GET")
	public Response findHistoryDeposit(){
		return SuccessResponseData.newInstance(dDepositStandardService.findHistoryDeposit());
	}
	//添加一条
//	@RequestMapping("/addOne")
//	@ApiOperation(value="新增一条定金标准",notes="新增一条定金标准",httpMethod="POST")
//	public Response addOne(@RequestBody DDepositStandardEditDto dto){
//		return SuccessResponseData.newInstance(dDepositStandardEditService.addOne(dto));
//	}
//	
	//更新一条
//	@RequestMapping("/updateOne")
//	@ApiOperation(value="更新一条定金标准",notes="更新一条定金标准",httpMethod="POST")
//	@ApiImplicitParams({
//		@ApiImplicitParam(name="fdId",value="fdId",paramType = "query", required = true, dataType = "Long"),
//		@ApiImplicitParam(name="specification",value="规格",paramType="query",required=false,dataType="String"),
//		@ApiImplicitParam(name="deposit",value="定金标准",paramType="query",required=false,dataType="BigDecimal")
//	})
//	public Response updateOne(Long fdId,String specification,BigDecimal deposit){
//		return SuccessResponseData.newInstance(dDepositStandardService.updateOne(fdId, specification, deposit));
//	}
	

	//更新1条
	@RequestMapping("/updateOneDeposit")
	@ApiOperation(value="更新一条定金标准",notes="更新一条定金标准",httpMethod="POST")
	public Response updateOneDeposit(@RequestBody DDepositStandardEditDto dto){
		return SuccessResponseData.newInstance(dDepositStandardEditService.updateOneDeposit(dto));
	}
	
	//更新多条
	@RequestMapping("/updateDeposits")
	@ApiOperation(value="更新多条定金标准",notes="更新多条定金标准",httpMethod="POST")
	public Response updateDeposits(@RequestBody List<DDepositStandardEditDto> dtos){
		return SuccessResponseData.newInstance(dDepositStandardEditService.updateDeposits(dtos));
	}
	
	//初始化
	@RequestMapping("/inputQueryDepo")
	@ApiOperation(value="初始化定金标准",notes="初始化定金标准",httpMethod="GET")
	public Response inputQueryDepo(){
		return SuccessResponseData.newInstance(dDepositStandardService.inputQueryDepo());
	}
	
	//edit初始化
	@RequestMapping("/findAllEdit")
	@ApiOperation(value="初始化edit定金标准",notes="初始化edit定金标准",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="edit",value="录入人",paramType="query",required=false,dataType="String")
	})
	public Response findAllEdit(String edit){
		return SuccessResponseData.newInstance(dDepositStandardEditService.findAllEdit(edit));
	}
	
	//当前用户历史修改记录
	@RequestMapping("/findNewHistory")
	@ApiOperation(value="当前用户历史",notes="当前用户历史",httpMethod="GET")
	public Response findNewHistory(){
		return SuccessResponseData.newInstance(dDepositStandardEditService.findNewHistory());
	}
	
	@RequestMapping("/addOneEdit")
	@ApiOperation(value="双人录入",notes="双人录入",httpMethod="POST")
	public Response addOneEdit(@RequestBody DDepositStandardEditDto dto){
		return SuccessResponseData.newInstance(dDepositStandardEditService.addOneEdit(dto));
	}
	
	@RequestMapping("/delete")
	@ApiOperation(value="双人删除",notes="双人删除",httpMethod="POST")
	public Response delete(@RequestBody List<DDepositStandardEditDto> dtos){
		return SuccessResponseData.newInstance(dDepositStandardEditService.delete(dtos));
	}
	
	@RequestMapping("/matching")
	@ApiOperation(value="双人录入数据匹配",notes="双人录入数据匹配",httpMethod="POST")
	public Response matching(@RequestBody List<DDepositStandardEditDto> dtos){
		return SuccessResponseData.newInstance(dDepositStandardEditService.matching(dtos));
	}
}
