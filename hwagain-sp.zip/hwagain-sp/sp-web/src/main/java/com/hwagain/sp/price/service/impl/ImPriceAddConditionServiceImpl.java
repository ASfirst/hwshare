package com.hwagain.sp.price.service.impl;

import com.hwagain.sp.price.entity.ImPriceAddCondition;
import com.hwagain.sp.price.dto.ImPriceAddConditionDto;
import com.hwagain.sp.price.dto.ImSpecialSetPriceDto;
import com.hwagain.sp.price.mapper.ImPriceAddConditionMapper;
import com.hwagain.sp.price.service.IImPriceAddConditionService;
import com.hwagain.sp.product.entity.ProductClass;
import com.hwagain.sp.product.service.IProductClassService;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import oracle.net.aso.e;

/**
 * <p>
 * 小幅产品加价表 服务实现类
 * </p>
 *
 * @author 
 * @since 2018-11-16
 */
@Service("imPriceAddConditionService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImPriceAddConditionServiceImpl extends ServiceImpl<ImPriceAddConditionMapper, ImPriceAddCondition> implements IImPriceAddConditionService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	@Autowired ImPriceAddConditionMapper imPriceAddConditionMapper;
	@Autowired IProductClassService iProductClassService;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImPriceAddCondition.class, ImPriceAddConditionDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImPriceAddConditionDto.class, ImPriceAddCondition.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	@Override
	public List<ImPriceAddConditionDto> findAll(){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
//		Wrapper<ImPriceAddCondition> wrapper=new CriterionWrapper<ImPriceAddCondition>(ImPriceAddCondition.class);
//		wrapper.eq("status", 1);
//		List<ImPriceAddCondition> list=super.selectList(wrapper);
//		if(list!=null&&list.size()!=0){
//			for(ImPriceAddCondition dto:list){
//				ImPriceAddCondition impa=new ImPriceAddCondition();
//				SimpleDateFormat simpleDateFormat=new SimpleDateFormat("yyyy-MM-dd");
//				if(dto.getEndDate()!=null){
//					String d=simpleDateFormat.format(dto.getEndDate());
//					Date date1=null;
//					try {
//						date1=simpleDateFormat.parse(d);
//					} catch (ParseException e) {
//						// TODO Auto-generated catch block
//						e.printStackTrace();
//					}
//					Calendar c=Calendar.getInstance();
//					c.setTime(new Date());
//					c.add(Calendar.DAY_OF_MONTH, -1);
//					Date yesterday=c.getTime();
//					if(date1.before(yesterday)){
//						impa.setFdId(dto.getFdId());
//						impa.setStatus(2);
//						impa.setLastAlterId(cUserid);
//						impa.setLastAlterTime(doDate);
//						super.updateById(impa);
//					}
//				}
//			}
//		}
		Wrapper<ImPriceAddCondition> wrapper1=new CriterionWrapper<ImPriceAddCondition>(ImPriceAddCondition.class);
		wrapper1.eq("status", 1);
		List<ImPriceAddCondition> list1=super.selectList(wrapper1);
		return entityToDtoMapper.mapAsList(list1, ImPriceAddConditionDto.class);	
	}
	@Override
	public ImPriceAddConditionDto updateOne(ImPriceAddConditionDto dto){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserId();
		Wrapper<ImPriceAddCondition> wrapper=new CriterionWrapper<ImPriceAddCondition>(ImPriceAddCondition.class);
		wrapper.eq("width", dto.getWidth());
		wrapper.eq("qty", dto.getQty());
		wrapper.eq("status", 1);
		ImPriceAddCondition list=super.selectFirst(wrapper);
		ImPriceAddCondition impa=new ImPriceAddCondition();
		impa.setFdId(list.getFdId());
//		System.err.println(list.getFdId());
		impa.setStatus(2);
		impa.setEndDate(dto.getStartDate());
		impa.setLastAlterId(cUserid);
		impa.setLastAlterTime(doDate);
		super.updateById(impa);
		ImPriceAddCondition impa1=new ImPriceAddCondition();
		impa1.setFdId(Long.valueOf(IdWorker.getId()));
		impa1.setWidth(dto.getWidth());
		impa1.setQty(dto.getQty());
		impa1.setAddPrice(dto.getAddPrice());
		impa1.setStatus(1);
		impa1.setIsPolicy(dto.isIsPolicy());
		impa1.setStartDate(dto.getStartDate());
		impa1.setCreaterId(cUserid);
		impa1.setCreateTime(doDate);
		super.insert(impa1);
		return entityToDtoMapper.map(super.selectById(impa1.getFdId()), ImPriceAddConditionDto.class);
	}
	
	@Override
	public List<ImPriceAddConditionDto> findHistory(){
		Wrapper<ImPriceAddCondition> wrapper=new CriterionWrapper<ImPriceAddCondition>(ImPriceAddCondition.class);
		wrapper.eq("status", 2);
		List<ImPriceAddCondition> list=super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, ImPriceAddConditionDto.class);		
	}
	
	/*特规品套产品价格明细表*/
	@Override
	public List<ImSpecialSetPriceDto> findAllSpecialSetPrice(){
		Wrapper<ImPriceAddCondition> wrapper=new CriterionWrapper<ImPriceAddCondition>(ImPriceAddCondition.class);
		wrapper.eq("status", 1);
		ImPriceAddCondition imPriceAdd=super.selectFirst(wrapper);
		
		int isHistory=0;
		List<ImSpecialSetPriceDto> list=imPriceAddConditionMapper.findList(isHistory);
		if(list!=null&&list.size()!=0){
			for(ImSpecialSetPriceDto dto:list){
				BigDecimal pri;
				if(dto.getWidth()<=imPriceAdd.getWidth()&&dto.getQty()>=imPriceAdd.getQty()){
					dto.setMinWidthAddPrice(imPriceAdd.getAddPrice());
					pri=dto.getPrice().subtract(imPriceAdd.getAddPrice());
					dto.setPrice(pri);
				}
				Wrapper<ProductClass> wrapperclass=new CriterionWrapper<ProductClass>(ProductClass.class);
				wrapperclass.eq("platform", "Import");
				wrapperclass.eq("enabled", 2);
				wrapperclass.eq("is_delete", 0);
				wrapperclass.eq("class_no", dto.getClassNo());
				ProductClass Class=iProductClassService.selectFirst(wrapperclass);
				dto.setClassText(Class.getName());
			}
		}
		return list;
	}
	
	@Override
	public List<ImSpecialSetPriceDto> findHistorySpecialSetPrice(BigDecimal ration,BigDecimal wrinkleRate,String physicalNo){
		Wrapper<ImPriceAddCondition> wrapper=new CriterionWrapper<ImPriceAddCondition>(ImPriceAddCondition.class);
		wrapper.eq("status", 1);
		ImPriceAddCondition imPriceAdd=super.selectFirst(wrapper);
		int isHistory=1;
		List<ImSpecialSetPriceDto> list=imPriceAddConditionMapper.findHistory(isHistory, physicalNo, wrinkleRate, ration);
		if(list!=null&&list.size()!=0){
			for(ImSpecialSetPriceDto dto:list){
				BigDecimal pri;
				if(dto.getWidth()<=imPriceAdd.getWidth()&&dto.getQty()>=imPriceAdd.getQty()){
					dto.setMinWidthAddPrice(imPriceAdd.getAddPrice());
					pri=dto.getPrice().subtract(imPriceAdd.getAddPrice());
					dto.setPrice(pri);
				}
			}
		}
		return list;
		
	}
}
