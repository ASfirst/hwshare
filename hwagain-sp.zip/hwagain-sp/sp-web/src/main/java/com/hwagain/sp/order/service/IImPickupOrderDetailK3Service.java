package com.hwagain.sp.order.service;

import com.hwagain.sp.order.entity.ImPickupOrderDetailK3;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
public interface IImPickupOrderDetailK3Service extends IService<ImPickupOrderDetailK3> {
	
}
