package com.hwagain.sp.policy.dto.params.transport;

import org.hibernate.validator.constraints.NotBlank;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 * Created on 2019/6/21 15:23
 * by @author WeiBoWen
 */
public class CheckDto implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotNull(message = "FdId参数不能为空")
    private Long fdId;

    @NotNull(message = "状态码参数不能为空")
    private Integer status;

    @NotBlank(message = "不能填写空白字符")
    private String checkedRemark;

    public Long getFdId() {
        return fdId;
    }

    public void setFdId(Long fdId) {
        this.fdId = fdId;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getCheckedRemark() {
        return checkedRemark;
    }

    public void setCheckedRemark(String checkedRemark) {
        this.checkedRemark = checkedRemark;
    }
}
