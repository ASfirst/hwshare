package com.hwagain.sp.process.service.impl;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import com.hwagain.sp.process.entity.ImProcess;
import com.hwagain.sp.process.entity.ImProcessBatchProduct;
import com.hwagain.sp.process.entity.ImProcessPrice;
import com.hwagain.sp.process.dto.ImProcessBatchProductDto;
import com.hwagain.sp.process.dto.ImProcessPriceListDto;
import com.hwagain.sp.process.dto.ImProcessProductRptDto;
import com.hwagain.sp.process.mapper.ImProcessBatchProductMapper;
import com.hwagain.sp.process.mapper.ImProcessMapper;
import com.hwagain.sp.process.mapper.ImProcessPriceMapper;
import com.hwagain.sp.process.mapper.ImProcessRptMapper;
import com.hwagain.sp.process.service.IImProcessBatchProductService;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
@Service("imProcessBatchProductService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImProcessBatchProductServiceImpl extends ServiceImpl<ImProcessBatchProductMapper, ImProcessBatchProduct> implements IImProcessBatchProductService {
	@Autowired
	ImProcessBatchProductMapper imProductMapper;
	@Autowired
	ImProcessRptMapper imProcessRptMapper;
	@Autowired
	ImProcessPriceMapper imProcessPriceMapper;
	@Autowired
	ImProcessMapper imProcessMapper;
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImProcessBatchProduct.class, ImProcessBatchProductDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImProcessBatchProductDto.class, ImProcessBatchProduct.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

	@Override
	public Boolean save(List<ImProcessBatchProduct> productList)
			throws CustomException {
		Boolean flag=false;
		flag=imProductMapper.insertProcessProductBatch(productList);
		return flag;
	}

	@Override
	public List<ImProcessPriceListDto> getCollectProduct(BigInteger fdId)
			throws CustomException {
		List<ImProcessPriceListDto> list=imProductMapper.getCollectProduct(fdId);
		return list;
	}

	@Override
	public List<ImProcessProductRptDto> findByPriceId(String priceId)
			throws CustomException {
		
		Assert.notBlank(priceId, "处理品价格ID不能为空");
		List<ImProcessProductRptDto> list=imProcessRptMapper.queryImProductList(priceId);
		Integer seqNum = 1;
		for(ImProcessProductRptDto dto:list)
		{
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list;
	}

	@Override
	public Boolean audit(List<ImProcessBatchProductDto> productList) throws CustomException {
		Assert.notNull(productList, "处理品明细不存在");
		Long priceId=null;
		Long processId=null;
		for(ImProcessBatchProductDto dto : productList)
		{
			ImProcessBatchProduct pp=super.selectById(dto.getFdId());
			Assert.notNull(pp, "没有找到处理品明细信息!");
			pp.setIsThisBatch(dto.getIsThisBatch());
			pp.setStatus(2);
			super.updateById(pp);
			priceId=pp.getImProcessPriceId();
			processId=pp.getImProcessId();
		}
		if(null!=priceId)
		{
			Date doDate = new Date();
			String curUser = UserUtils.getUserInfo().getName();
			ImProcessPrice entity2=imProcessPriceMapper.selectById(priceId);
			entity2.setAuditor(curUser);
			entity2.setAuditDate(doDate);
			entity2.setLastAlterId(curUser);
			entity2.setLastAlterTime(doDate);
			entity2.setStatus(2);
			imProcessPriceMapper.updateAllById(entity2);
			
		}
		if(null!=processId)
		{
			Date doDate = new Date();
			String curUser = UserUtils.getUserInfo().getName();
			ImProcess entity3=imProcessMapper.selectById(processId);
			entity3.setLastAlterId(curUser);
			entity3.setLastAlterTime(doDate);
			entity3.setStatus(2);
			imProcessMapper.updateAllById(entity3);
		}
		return true;
	}

	@Override
	public List<ImProcessProductRptDto> querpImProcessProductDetail()
			throws CustomException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<ImProcessPriceListDto> getCollectProductById(String ids)
			throws CustomException {
		String str[] = ids.split(",");
		List<String> strlist = new ArrayList<>();
		strlist = Arrays.asList(str);
		List<ImProcessPriceListDto> list=imProductMapper.getCollectProductById(strlist);
		return list;
	}

	@Override
	public Boolean deleteByIds(String ids)
			throws CustomException {
		String[] id = ids.split(",");
		return super.deleteBatchIds(Arrays.asList(id));
	}
	
	
}
