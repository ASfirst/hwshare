package com.hwagain.sp.customer.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.customer.service.IBaseCapacityEditService;

///**
// * <p>
// *  前端控制器
// * </p>
// *
// * @author xionglz
// * @since 2018-11-29
// */
//@RestController
//@RequestMapping(value="/customer/baseCapacityEdit",method={RequestMethod.GET,RequestMethod.POST})
//public class BaseCapacityEditController extends BaseController{
//	
//	@Autowired
//	IBaseCapacityEditService baseCapacityEditService;
//	
//}
