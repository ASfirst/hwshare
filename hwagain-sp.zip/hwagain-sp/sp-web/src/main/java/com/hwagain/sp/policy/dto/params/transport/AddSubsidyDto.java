package com.hwagain.sp.policy.dto.params.transport;

import com.hwagain.sp.policy.component.verification.Constraints;

import org.hibernate.validator.constraints.NotBlank;
import org.hibernate.validator.constraints.NotEmpty;

import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created on 2019/6/20 15:48
 * by @author WeiBoWen
 */
public class AddSubsidyDto implements Serializable {

    private static final long serialVersionUID = 1L;

    @NotNull(message = "客户id不能为空")
    private Long customerId;

    @NotEmpty(message = "运输方式不能为空")
    @Constraints(value = {"代办", "自提"}, message = "method参数只能填代办和自提")
    private String method;

    @NotNull(message = "现执行运价不能为空")
    private BigDecimal price;

    @NotNull(message = "补贴金额不能为空")
    private BigDecimal addPrice;

    @NotNull(message = "开始时间不能为空")
    private Date startDate;

    private Date endDate;

    @NotBlank(message = "不能填写空白字符")
    private String remark;

    @NotEmpty(message = "创建人Id不能为空")
    private String createrId;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getAddPrice() {
        return addPrice;
    }

    public void setAddPrice(BigDecimal addPrice) {
        this.addPrice = addPrice;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getCreaterId() {
        return createrId;
    }

    public void setCreaterId(String createrId) {
        this.createrId = createrId;
    }
}
