package com.hwagain.sp.price.service;

import com.hwagain.sp.price.dto.ImPriceAddConditionDto;
import com.hwagain.sp.price.dto.ImSpecialSetPriceDto;
import com.hwagain.sp.price.entity.ImPriceAddCondition;

import java.math.BigDecimal;
import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 * 小幅宽产品加价表 服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-16
 */
public interface IImPriceAddConditionService extends IService<ImPriceAddCondition> {

	public List<ImPriceAddConditionDto> findAll()throws CustomException;

	public ImPriceAddConditionDto updateOne(ImPriceAddConditionDto dto)throws CustomException;

	public List<ImPriceAddConditionDto> findHistory()throws CustomException;

	public List<ImSpecialSetPriceDto> findAllSpecialSetPrice()throws CustomException;

	public List<ImSpecialSetPriceDto> findHistorySpecialSetPrice(BigDecimal ration, BigDecimal wrinkleRate, String physicalNo)throws CustomException;
	
}
