package com.hwagain.sp.process.dto;

import java.math.BigDecimal;
import java.util.Date;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author huanglf
 * @since 2018-12-20
 */
public class ImProcessPriceEditDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
	private Long imPriceId;
	private Long imProcessId;
    /**
     * 品类
     */
	private String classNo;
    /**
     * 定量
     */
	private BigDecimal ration;
    /**
     * 起趋率
     */
	private BigDecimal wrinkleRate;
    /**
     * 层数
     */
	private Integer layer;
    /**
     * 单幅幅宽
     */
	private String width;
    /**
     * 直径
     */
	private BigDecimal diameter;
    /**
     * 产品等级
     */
	private String grade;
    /**
     * 库龄
     */
	private String age;
    /**
     * 库存量
     */
	private BigDecimal weight;
    /**
     * 是否享受政策
     */
	private Integer isPolicy;
    /**
     * 现行价格
     */
	private BigDecimal normalPrice;
    /**
     * 处理价格
     */
	private BigDecimal processPrice;
    /**
     * 降幅
     */
	private BigDecimal fallPrice;
    /**
     * 处理原因说明
     */
	private String reason;
    /**
     * 备注
     */
	private String remark;
	private String statusText;
	private String auditor;
	private Date auditDate;
    /**
     * 创建人
     */
	private String createrId;
    /**
     * 创建时间
     */
	private Date createTime;
    /**
     * 最后修改人
     */
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	private Date lastAlterTime;
	private String role;
    /**
     * 状态（1：第一次录入，10：已生效）
     */
	private Integer status;
	private Integer statusEdit;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getImPriceId() {
		return imPriceId;
	}

	public void setImPriceId(Long imPriceId) {
		this.imPriceId = imPriceId;
	}

	public Long getImProcessId() {
		return imProcessId;
	}

	public void setImProcessId(Long imProcessId) {
		this.imProcessId = imProcessId;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public BigDecimal getRation() {
		return ration;
	}

	public void setRation(BigDecimal ration) {
		this.ration = ration;
	}

	public BigDecimal getWrinkleRate() {
		return wrinkleRate;
	}

	public void setWrinkleRate(BigDecimal wrinkleRate) {
		this.wrinkleRate = wrinkleRate;
	}

	public Integer getLayer() {
		return layer;
	}

	public void setLayer(Integer layer) {
		this.layer = layer;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public BigDecimal getDiameter() {
		return diameter;
	}

	public void setDiameter(BigDecimal diameter) {
		this.diameter = diameter;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public Integer getIsPolicy() {
		return isPolicy;
	}

	public void setIsPolicy(Integer isPolicy) {
		this.isPolicy = isPolicy;
	}

	public BigDecimal getNormalPrice() {
		return normalPrice;
	}

	public void setNormalPrice(BigDecimal normalPrice) {
		this.normalPrice = normalPrice;
	}

	public BigDecimal getProcessPrice() {
		return processPrice;
	}

	public void setProcessPrice(BigDecimal processPrice) {
		this.processPrice = processPrice;
	}

	public BigDecimal getFallPrice() {
		return fallPrice;
	}

	public void setFallPrice(BigDecimal fallPrice) {
		this.fallPrice = fallPrice;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	public String getAuditor() {
		return auditor;
	}

	public void setAuditor(String auditor) {
		this.auditor = auditor;
	}

	public Date getAuditDate() {
		return auditDate;
	}

	public void setAuditDate(Date auditDate) {
		this.auditDate = auditDate;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getStatusEdit() {
		return statusEdit;
	}

	public void setStatusEdit(Integer statusEdit) {
		this.statusEdit = statusEdit;
	}

}
