package com.hwagain.sp.policy.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
@TableName("po_policy_details")
public class PoPolicyDetails implements Serializable {

    private static final long serialVersionUID = 1L;

	@TableId("fd_id")
	private Long fdId;
	@TableField("po_policy_id")
	private Long poPolicyId;
	private Integer level;
	@TableField("min_weight")
	private BigDecimal minWeight;
	@TableField("max_weight")
	private BigDecimal maxWeight;
	private BigDecimal amount;
	@TableField("fmin_weight")
	private BigDecimal fminWeight;
	@TableField("fmax_weight")
	private BigDecimal fmaxWeight;
	private BigDecimal famount;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getPoPolicyId() {
		return poPolicyId;
	}

	public void setPoPolicyId(Long poPolicyId) {
		this.poPolicyId = poPolicyId;
	}

	public Integer getLevel() {
		return level;
	}

	public void setLevel(Integer level) {
		this.level = level;
	}

	public BigDecimal getMinWeight() {
		return minWeight;
	}

	public void setMinWeight(BigDecimal minWeight) {
		this.minWeight = minWeight;
	}

	public BigDecimal getMaxWeight() {
		return maxWeight;
	}

	public void setMaxWeight(BigDecimal maxWeight) {
		this.maxWeight = maxWeight;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getFminWeight() {
		return fminWeight;
	}

	public void setFminWeight(BigDecimal fminWeight) {
		this.fminWeight = fminWeight;
	}

	public BigDecimal getFmaxWeight() {
		return fmaxWeight;
	}

	public void setFmaxWeight(BigDecimal fmaxWeight) {
		this.fmaxWeight = fmaxWeight;
	}

	public BigDecimal getFamount() {
		return famount;
	}

	public void setFamount(BigDecimal famount) {
		this.famount = famount;
	}

}
