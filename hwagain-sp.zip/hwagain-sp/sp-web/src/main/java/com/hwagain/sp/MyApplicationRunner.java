package com.hwagain.sp;

import com.alibaba.druid.pool.DruidDataSource;
import com.hwagain.framework.core.util.SpringBeanUtil;
import com.hwagain.sp.jdbc.DynamicDataSource;
import com.hwagain.sp.jdbc.MyDataSource;
import com.hwagain.sp.jdbc.SourceEnum;
import com.hwagain.sp.util.JDBCConfig;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.Map;

@Component
@Order(value=1)
public class MyApplicationRunner implements ApplicationRunner {

	private final static String sqlServerDriverClassName = "com.microsoft.sqlserver.jdbc.SQLServerDriver";

	private final static Logger logger = LoggerFactory.getLogger(MyApplicationRunner.class);

	@Override
	public void run(ApplicationArguments arg0) {

		initSqlServerDB();
	}

	/**
     * 初始化动态切换SqlServer数据源
	 */
	private void initSqlServerDB() {
		JDBCConfig jDBCConfig = SpringBeanUtil.getBean(JDBCConfig.class);

		DynamicDataSource dynamicDataSource = DynamicDataSource.getInstance();

		DruidDataSource oaSource = new DruidDataSource();
		oaSource.setUrl(jDBCConfig.getOAUrl());
		oaSource.setUsername(jDBCConfig.getOAUsername());
		oaSource.setPassword(jDBCConfig.getOAPassword());
		oaSource.setDriverClassName(sqlServerDriverClassName);

		DruidDataSource pdSource = new DruidDataSource();
		pdSource.setDriverClassName(sqlServerDriverClassName);
		pdSource.setUrl(jDBCConfig.getPDUrl());
		pdSource.setUsername(jDBCConfig.getPDUsername());
		pdSource.setPassword(jDBCConfig.getPDPassword());

		DruidDataSource k3Source = new DruidDataSource();
		k3Source.setDriverClassName(sqlServerDriverClassName);
		k3Source.setUrl(jDBCConfig.getK3Url());
		k3Source.setUsername(jDBCConfig.getK3Username());
		k3Source.setPassword(jDBCConfig.getK3Password());

		Map<Object,Object> map = new HashMap<>();
		map.put(SourceEnum.OA, oaSource);
		map.put(SourceEnum.PD, pdSource);
		map.put(SourceEnum.K3, k3Source);
		dynamicDataSource.setTargetDataSources(map);
		dynamicDataSource.setDefaultTargetDataSource(k3Source);
	}


}
