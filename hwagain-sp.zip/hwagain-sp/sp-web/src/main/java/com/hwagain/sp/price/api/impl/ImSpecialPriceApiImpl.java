package com.hwagain.sp.price.api.impl;

import com.hwagain.sp.price.api.IImSpecialPriceApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author guoym
 * @since 2018-10-16
 */
@Service("imSpecialPriceApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImSpecialPriceApiImpl implements IImSpecialPriceApi {
	
}
