package com.hwagain.sp.disobey.service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.hwagain.sp.disobey.dto.BaseDisobeyEditDto;
import com.hwagain.sp.disobey.entity.BaseDisobeyEdit;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
public interface IBaseDisobeyEditService extends IService<BaseDisobeyEdit> {
	//public String getUserOrder() throws CustomException;
	public BaseDisobeyEditDto insert(BaseDisobeyEditDto dto) throws CustomException;
	public BaseDisobeyEditDto updateOneDisobey(String fdId,String disobeyContent,String unit,BigDecimal penaltyStandard,Date startDate,String remark) throws CustomException;
	public List<BaseDisobeyEditDto> updateMoreDisobey(List<BaseDisobeyEditDto> list) throws CustomException;
	public List<BaseDisobeyEditDto> queryDisobeyEdit(String curUserId) throws CustomException;
	public List<BaseDisobeyEditDto> findDisobeyList(String disobeyContent,String unit,BigDecimal penaltyStandard) throws CustomException;
	public List<BaseDisobeyEditDto> matching(List<BaseDisobeyEditDto> list) throws CustomException;
	public Boolean deleteByIds(String ids) throws CustomException;
}
