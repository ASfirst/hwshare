package com.hwagain.sp.order.service;

import com.hwagain.sp.order.entity.ImOrder;
import com.hwagain.sp.order.entity.ImOrderDetail;
import com.hwagain.sp.order.dto.ImOrderDto;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;
import java.util.List;
import java.math.BigInteger;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
public interface IImOrderService extends IService<ImOrder> {
	
	public List<ImOrderDto> findAll() throws CustomException; 
	
	public ImOrderDto findOne(Long fdId) throws CustomException;
	
	//
	public ImOrderDto save(ImOrderDto dto) throws CustomException;
	
	public ImOrderDto update(ImOrderDto dto) throws CustomException;
	
	//通过order_no查询一条记录
	public ImOrderDto findImOrderByOrderNo(String orderNo) throws CustomException;
	
	
	
	
}
