package com.hwagain.sp.process.api.impl;

import com.hwagain.sp.process.api.IImProcessPriceApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
@Service("imProcessPriceApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImProcessPriceApiImpl implements IImProcessPriceApi {
	
}
