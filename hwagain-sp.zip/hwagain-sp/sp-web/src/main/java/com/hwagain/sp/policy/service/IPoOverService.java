package com.hwagain.sp.policy.service;

import com.hwagain.sp.policy.dto.PoOverDto;
import com.hwagain.sp.policy.entity.PoOver;

import java.util.List;
import java.util.Map;

import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
public interface IPoOverService extends IService<PoOver> {
	public PoOverDto saveOne(PoOverDto dto);

	public List<PoOverDto> findListByParams(Map<String, Object> params);

	public boolean deleteOne(String fdId);
}
