package com.hwagain.sp.price.service;

import com.hwagain.sp.base.entity.RptTempData;
import com.hwagain.sp.price.dto.ImPriceDto;
import com.hwagain.sp.price.dto.ImPriceRptDto;
import com.hwagain.sp.price.dto.ImTransPriceDto;
import com.hwagain.sp.price.entity.ImPrice;
import com.hwagain.sp.product.dto.ProductBaseExtDto;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 * 常规、非常规产品统一销售价格表 服务类
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
public interface IImPriceService extends IService<ImPrice> {

	public List<RptTempData> queryTempData();

	public List<ImPriceRptDto> queryImPriceList();

	public List<ImPriceRptDto> inputQueryList();

	public List<ProductBaseExtDto> inputQuerySelect();

	public List<ImPriceRptDto> inputSelectProd(String prodBaseIds);

	public ImPriceDto findOne(String fdId);

	public ImPriceDto inputUpdateOne(String fdid, String unit, BigDecimal addPrice, BigDecimal extPrice, Date startDate,
			Integer isPolicy, String remark);

	public List<ImPriceDto> inputUpdateSome(List<ImPriceDto> list);

	public ImPriceDto inputDeleteOne(String fdid);

	public List<ImPriceRptDto> inputSentToOa();

	public List<ImPriceRptDto> inputOaAduitFlow(String oACode, Integer status, String nodeName, String empName, String empNo,
			String flowDjbh, String flowDjlsh);

	public List<ImPriceRptDto> inputQueryByOaCode(String oaCode);

	public void outDateStatus();

	public List<RptTempData> queryHistoryPrice();

	public List<ImPriceRptDto> queryHistoryPriceDetail(Date startDate, BigDecimal price, BigDecimal addPrice);
	
	//获取销售运输价格
	public List<ImTransPriceDto> getTransPrice(String procuctType,String custName,String address,String carType,String province,String city,String county,Date startdate);

	public ImPriceDto updateOneEdit(ImPriceDto dto)throws CustomException;

	public List<ImPriceRptDto> findAllList()throws CustomException;

}
