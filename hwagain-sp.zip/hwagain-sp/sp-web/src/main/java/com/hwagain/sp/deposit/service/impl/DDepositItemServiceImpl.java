package com.hwagain.sp.deposit.service.impl;

import com.hwagain.sp.deposit.entity.DDepositItem;
import com.hwagain.sp.deposit.dto.DDepositItemDto;
import com.hwagain.sp.deposit.mapper.DDepositItemMapper;
import com.hwagain.sp.deposit.service.IDDepositItemService;
import com.hwagain.sp.deposit.service.IDDepositMainService;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.security.common.util.UserUtils;


import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 * 客户当月定金对账明细表 服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
@Service("dDepositItemService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DDepositItemServiceImpl extends ServiceImpl<DDepositItemMapper, DDepositItem> implements IDDepositItemService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	@Autowired IDDepositMainService dDepositMainService;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(DDepositItem.class, DDepositItemDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(DDepositItemDto.class, DDepositItem.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	//根据主表ID查询客户上一月份定金流水明细
		@Override
		public List<DDepositItemDto> findCustDepositItem(String depositMainId,Date happenDate){
			Date doDate = new Date();
			String cUserid = UserUtils.getUserInfo().getName();
			String dept=UserUtils.getUserInfo().getFdDepartmentName();
			if(happenDate==null){
				Calendar calendar=Calendar.getInstance();
				calendar.setTime(doDate);
				calendar.add(Calendar.MONTH, -1);
				happenDate=calendar.getTime();
			}
			
			Wrapper<DDepositItem> wrapper=new CriterionWrapper<DDepositItem>(DDepositItem.class);
			wrapper.eq("deposit_main_id", depositMainId);
			List<DDepositItem> list=super.selectList(wrapper);
			if(list.size()>0){
				for(DDepositItem dto:list){
					
				}
			}
			return null;
			
		}
}
