package com.hwagain.sp.customer.web;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.customer.dto.BaseCapacityDto;
import com.hwagain.sp.customer.service.IBaseCapacityService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

///**
// * <p>
// *  前端控制器
// * </p>
// *
// * @author xionglz
// * @since 2018-11-29
// */
//@RestController
//@RequestMapping(value="/customer/baseCapacity",method={RequestMethod.GET,RequestMethod.POST})
//@Api(value = "【进口纸机】生产机器产能明细", description = "【进口纸机】生产机器产能明细")
//public class BaseCapacityController extends BaseController{
//	
//	@Autowired
//	IBaseCapacityService baseCapacityService;
//	
//	@RequestMapping("/findAll")
//	@ApiOperation(value = "生产机器列表", notes = "生产机器列表", httpMethod = "GET")
//	public Response findAll() {
//		return SuccessResponseData.newInstance(baseCapacityService.findAllCapacity());
//	}
//	
//	@RequestMapping("addOne")
//	@ApiOperation(value="新增一条数据",notes="新增一条数据",httpMethod="POST")
//	public Response addOne(@RequestBody BaseCapacityDto dto) throws Exception{
//		return SuccessResponseData.newInstance(baseCapacityService.addOne(dto));
//	}
//}
