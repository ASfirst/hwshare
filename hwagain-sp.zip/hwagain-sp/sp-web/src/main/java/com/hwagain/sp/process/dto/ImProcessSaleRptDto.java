package com.hwagain.sp.process.dto;

import java.math.BigDecimal;
import java.util.Date;

public class ImProcessSaleRptDto extends ImProcessProductRptDto {
	private static final long serialVersionUID = 1L;
	private Integer isPolicy;
	private BigDecimal normalPrice;
	private BigDecimal processPrice;
	private BigDecimal fallPrice;
	private String reason;
	private String customer;
	public Integer getIsPolicy() {
		return isPolicy;
	}
	public void setIsPolicy(Integer isPolicy) {
		this.isPolicy = isPolicy;
	}
	public BigDecimal getNormalPrice() {
		return normalPrice;
	}
	public void setNormalPrice(BigDecimal normalPrice) {
		this.normalPrice = normalPrice;
	}
	public BigDecimal getProcessPrice() {
		return processPrice;
	}
	public void setProcessPrice(BigDecimal processPrice) {
		this.processPrice = processPrice;
	}
	public BigDecimal getFallPrice() {
		return fallPrice;
	}
	public void setFallPrice(BigDecimal fallPrice) {
		this.fallPrice = fallPrice;
	}
	public String getReason() {
		return reason;
	}
	public void setReason(String reason) {
		this.reason = reason;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	
}
