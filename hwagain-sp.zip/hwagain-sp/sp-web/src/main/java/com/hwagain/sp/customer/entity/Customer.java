package com.hwagain.sp.customer.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;

/**
 * <p>
 * 
 * </p>
 *
 * @author huangdh
 * @since 2019-05-07
 */
public class Customer implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * FdId
     */
	@TableId("fd_id")
	private Long fdId;
	@TableField("map_import_id")
	private Integer mapImportId;
	@TableField("map_culture_id")
	private Integer mapCultureId;
	@TableField("map_china_id")
	private Integer mapChinaId;
    /**
     * 省
     */
	private String province;
    /**
     * 市
     */
	private String city;
    /**
     * 区/县
     */
	private String county;
    /**
     * 客户名称
     */
	@TableField("cust_name")
	private String custName;
    /**
     * 客户简称
     */
	@TableField("short_name")
	private String shortName;
    /**
     * 法人代表
     */
	@TableField("law_man")
	private String lawMan;
    /**
     * 负责人
     */
	@TableField("law_reposibility")
	private String lawReposibility;
    /**
     * 手机
     */
	private String mobile;
    /**
     * 电话
     */
	private String tel;
    /**
     * 传真
     */
	private String fax;
    /**
     * 地址
     */
	private String address;
    /**
     * 邮编
     */
	@TableField("post_no")
	private String postNo;
    /**
     * 注册资金
     */
	@TableField("register_amount")
	private BigDecimal registerAmount;
    /**
     * 流动资金
     */
	@TableField("flow_amount")
	private BigDecimal flowAmount;
    /**
     * 年销售额
     */
	@TableField("year_amount")
	private BigDecimal yearAmount;
    /**
     * 是否使用财务软件
     */
	@TableField("is_use_finance_soft")
	private String isUseFinanceSoft;
    /**
     * 财务软件名称
     */
	@TableField("soft_name")
	private String softName;
    /**
     * 企业性质
     */
	@TableField("enterprise_type")
	private String enterpriseType;
    /**
     * 是否一般纳税人
     */
	@TableField("is_rate_paying")
	private Integer isRatePaying;
    /**
     * 调查人
     */
	@TableField("investigate_by")
	private String investigateBy;
    /**
     * 调查时间
     */
	@TableField("investigate_date")
	private Date investigateDate;
    /**
     * 经销商类别
     */
	@TableField("dealer_type_id")
	private Integer dealerTypeId;
    /**
     * 注册单位标记
     */
	@TableField("is_register")
	private Integer isRegister;
    /**
     * 客户类型
     */
	@TableField("cust_type_name")
	private String custTypeName;
    /**
     * 开发人
     */
	private String developer;
    /**
     * 生意开发期
     */
	@TableField("startup_business")
	private Integer startupBusiness;
    /**
     * 生意开发期起算时间
     */
	@TableField("business_start_date")
	private Date businessStartDate;
    /**
     * 生意开发期结束时间
     */
	@TableField("business_end_date")
	private Date businessEndDate;
    /**
     * 合同约定月提货量
     */
	@TableField("promise_weight")
	private BigDecimal promiseWeight;
    /**
     * 短信接收人
     */
	@TableField("receiver_by")
	private String receiverBy;
    /**
     * 最后更新时间
     */
	/*@TableField("lasted_update_date")
	private Date lastedUpdateDate;*/
    /**
     * 短信接收号码
     */
	@TableField("receiver_mobile")
	private String receiverMobile;
	private Boolean use;
	private String remark;
    /**
     * 状态
     */
	private String status;
    /**
     * 创建人
     */
	@TableField("creater_id")
	private String createrId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
    /**
     * 最后修改人
     */
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Integer getMapImportId() {
		return mapImportId;
	}

	public void setMapImportId(Integer mapImportId) {
		this.mapImportId = mapImportId;
	}

	public Integer getMapCultureId() {
		return mapCultureId;
	}

	public void setMapCultureId(Integer mapCultureId) {
		this.mapCultureId = mapCultureId;
	}

	public Integer getMapChinaId() {
		return mapChinaId;
	}

	public void setMapChinaId(Integer mapChinaId) {
		this.mapChinaId = mapChinaId;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getCounty() {
		return county;
	}

	public void setCounty(String county) {
		this.county = county;
	}

	public String getCustName() {
		return custName;
	}

	public void setCustName(String custName) {
		this.custName = custName;
	}

	public String getShortName() {
		return shortName;
	}

	public void setShortName(String shortName) {
		this.shortName = shortName;
	}

	public String getLawMan() {
		return lawMan;
	}

	public void setLawMan(String lawMan) {
		this.lawMan = lawMan;
	}

	public String getLawReposibility() {
		return lawReposibility;
	}

	public void setLawReposibility(String lawReposibility) {
		this.lawReposibility = lawReposibility;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPostNo() {
		return postNo;
	}

	public void setPostNo(String postNo) {
		this.postNo = postNo;
	}

	public BigDecimal getRegisterAmount() {
		return registerAmount;
	}

	public void setRegisterAmount(BigDecimal registerAmount) {
		this.registerAmount = registerAmount;
	}

	public BigDecimal getFlowAmount() {
		return flowAmount;
	}

	public void setFlowAmount(BigDecimal flowAmount) {
		this.flowAmount = flowAmount;
	}

	public BigDecimal getYearAmount() {
		return yearAmount;
	}

	public void setYearAmount(BigDecimal yearAmount) {
		this.yearAmount = yearAmount;
	}

	public String getIsUseFinanceSoft() {
		return isUseFinanceSoft;
	}

	public void setIsUseFinanceSoft(String isUseFinanceSoft) {
		this.isUseFinanceSoft = isUseFinanceSoft;
	}

	public String getSoftName() {
		return softName;
	}

	public void setSoftName(String softName) {
		this.softName = softName;
	}

	public String getEnterpriseType() {
		return enterpriseType;
	}

	public void setEnterpriseType(String enterpriseType) {
		this.enterpriseType = enterpriseType;
	}

	public Integer getIsRatePaying() {
		return isRatePaying;
	}

	public void setIsRatePaying(Integer isRatePaying) {
		this.isRatePaying = isRatePaying;
	}

	public String getInvestigateBy() {
		return investigateBy;
	}

	public void setInvestigateBy(String investigateBy) {
		this.investigateBy = investigateBy;
	}

	public Date getInvestigateDate() {
		return investigateDate;
	}

	public void setInvestigateDate(Date investigateDate) {
		this.investigateDate = investigateDate;
	}

	public Integer getDealerTypeId() {
		return dealerTypeId;
	}

	public void setDealerTypeId(Integer dealerTypeId) {
		this.dealerTypeId = dealerTypeId;
	}

	public Integer getIsRegister() {
		return isRegister;
	}

	public void setIsRegister(Integer isRegister) {
		this.isRegister = isRegister;
	}

	public String getCustTypeName() {
		return custTypeName;
	}

	public void setCustTypeName(String custTypeName) {
		this.custTypeName = custTypeName;
	}

	public String getDeveloper() {
		return developer;
	}

	public void setDeveloper(String developer) {
		this.developer = developer;
	}

	public Integer getStartupBusiness() {
		return startupBusiness;
	}

	public void setStartupBusiness(Integer startupBusiness) {
		this.startupBusiness = startupBusiness;
	}

	public Date getBusinessStartDate() {
		return businessStartDate;
	}

	public void setBusinessStartDate(Date businessStartDate) {
		this.businessStartDate = businessStartDate;
	}

	public Date getBusinessEndDate() {
		return businessEndDate;
	}

	public void setBusinessEndDate(Date businessEndDate) {
		this.businessEndDate = businessEndDate;
	}

	public BigDecimal getPromiseWeight() {
		return promiseWeight;
	}

	public void setPromiseWeight(BigDecimal promiseWeight) {
		this.promiseWeight = promiseWeight;
	}

	public String getReceiverBy() {
		return receiverBy;
	}

	public void setReceiverBy(String receiverBy) {
		this.receiverBy = receiverBy;
	}

	/*public Date getLastedUpdateDate() {
		return lastedUpdateDate;
	}

	public void setLastedUpdateDate(Date lastedUpdateDate) {
		this.lastedUpdateDate = lastedUpdateDate;
	}*/

	public String getReceiverMobile() {
		return receiverMobile;
	}

	public void setReceiverMobile(String receiverMobile) {
		this.receiverMobile = receiverMobile;
	}

	public Boolean isUse() {
		return use;
	}

	public void setUse(Boolean use) {
		this.use = use;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
