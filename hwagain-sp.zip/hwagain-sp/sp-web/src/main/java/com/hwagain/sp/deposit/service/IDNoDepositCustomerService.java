package com.hwagain.sp.deposit.service;

import com.hwagain.sp.deposit.dto.DDepositStandardEditDto;
import com.hwagain.sp.deposit.dto.DNoDepositCustomerDto;
import com.hwagain.sp.deposit.entity.DNoDepositCustomer;
import com.hwagain.sp.product.dto.ProductOutStockDto;

import java.util.Date;
import java.util.List;

import javax.xml.crypto.Data;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-05
 */
public interface IDNoDepositCustomerService extends IService<DNoDepositCustomer> {

	public List<DNoDepositCustomerDto> findAll(Date queryTime)throws CustomException;

	public List<DNoDepositCustomerDto> inputQueryNoDepoProd(int year,int month)throws CustomException;

	public List<DNoDepositCustomerDto> findNoDepositStandardList(Date monthDate)throws CustomException;

	public List<DNoDepositCustomerDto> findAllNoDepositProd()throws CustomException;

}
