package com.hwagain.sp.deposit.service.impl;

import com.hwagain.sp.deposit.entity.DNoDepositStandard;
import com.hwagain.sp.deposit.entity.DNoDepositStandardEdit;
import com.hwagain.sp.deposit.dto.DNoDepositStandardEditDto;
import com.hwagain.sp.deposit.mapper.DNoDepositStandardEditMapper;
import com.hwagain.sp.deposit.service.IDNoDepositStandardEditService;
import com.hwagain.sp.deposit.service.IDNoDepositStandardService;
import com.alibaba.fastjson.JSONObject;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
@Service("dNoDepositStandardEditService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DNoDepositStandardEditServiceImpl extends ServiceImpl<DNoDepositStandardEditMapper, DNoDepositStandardEdit> implements IDNoDepositStandardEditService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	@Autowired IDNoDepositStandardService dNoDepositStandardService;
	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(DNoDepositStandardEdit.class, DNoDepositStandardEditDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();

		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(DNoDepositStandardEditDto.class, DNoDepositStandardEdit.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	//当前用户双人录入记录
	@Override
	public List<DNoDepositStandardEditDto> findNewHistory(){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		Wrapper<DNoDepositStandardEdit> wrapper=new CriterionWrapper<DNoDepositStandardEdit>(DNoDepositStandardEdit.class);
		wrapper.eq("is_history", 0);
		wrapper.eq("creater_id", cUserid);
		DNoDepositStandardEdit list=super.selectFirst(wrapper);
		List<DNoDepositStandardEdit> listA=new ArrayList<>();
		if(list!=null){
			listA.add(list);
		}else{
			Wrapper<DNoDepositStandard> wrapper1=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
			wrapper1.eq("is_history", 0);
			DNoDepositStandard list1=dNoDepositStandardService.selectFirst(wrapper1);
			if(list1!=null){
				System.err.println(list1.getIsHistory());
				String st=JSONObject.toJSONString(list1);
				DNoDepositStandardEditDto list2=JSONObject.parseObject(st,DNoDepositStandardEditDto.class);
				listA.add(dtoToEntityMapper.map(list1, DNoDepositStandardEdit.class));
			}
		}
		return entityToDtoMapper.mapAsList(listA, DNoDepositStandardEditDto.class);
	}
	//修改
	@Override
	public DNoDepositStandardEditDto addOneEdit(DNoDepositStandardEditDto dto){
		Assert.notNull(dto.getMonthDeliveryWeight(), "月出库量不能为空");
		Assert.notNull(dto.getMonthOrderWeight(), "月订单量不能为空");
		Assert.notNull(dto.getContinuousMonth(), "连续月数不能为空");
		Assert.notNull(dto.getStartTime(), "开始执行时间不能为空");
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		Wrapper<DNoDepositStandardEdit> wrapperd=new CriterionWrapper<DNoDepositStandardEdit>(DNoDepositStandardEdit.class);
		wrapperd.eq("month_order_weight", dto.getMonthOrderWeight());
		wrapperd.eq("month_delivery_weight", dto.getMonthDeliveryWeight());
		wrapperd.eq("continuous_month", dto.getContinuousMonth());
		wrapperd.eq("start_time", dto.getStartTime());
		wrapperd.eq("is_history", 0);
		wrapperd.eq("creater_id", cUserid);
		DNoDepositStandardEdit listd=super.selectFirst(wrapperd);
		if(listd!=null){
			Assert.throwException("数据已存在，请确认是否有进行调整");
		}
		Date dt1=null;
		Date dt2=null;
		DateFormat df = new SimpleDateFormat("yyyy-MM");
		String nowTime = df.format(doDate);
		String startTime = df.format(dto.getStartTime());
		try {
			dt1 = df.parse(nowTime);
			dt2 = df.parse(startTime);
			if(dt1.after(dt2)){
				Assert.throwException("开始执行日期不能在当前月份【"+nowTime+"】前");
			}
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Wrapper<DNoDepositStandardEdit> wrapper=new CriterionWrapper<DNoDepositStandardEdit>(DNoDepositStandardEdit.class);
		wrapper.eq("is_history", 0);
		wrapper.eq("creater_id", cUserid);
		DNoDepositStandardEdit list=super.selectFirst(wrapper);
		if(list!=null){
			list.setMonthOrderWeight(dto.getMonthOrderWeight());
			list.setMonthDeliveryWeight(dto.getMonthDeliveryWeight());
			list.setContinuousMonth(dto.getContinuousMonth());
			list.setStartTime(dto.getStartTime());
			list.setLastAlterId(cUserid);
			list.setLastAlterTime(doDate);
			super.updateById(list);
		}else{
			dto.setFdId(Long.valueOf(IdWorker.getId()));
			dto.setIsHistory(0);
			dto.setCreaterId(cUserid);
			dto.setCreateTime(doDate);
			dto.setRole(dept);
			super.insert(dtoToEntityMapper.map(dto, DNoDepositStandardEdit.class));
		}
		return entityToDtoMapper.map(super.selectById(dto.getFdId()), DNoDepositStandardEditDto.class);		
	}
	
	//匹配
	@Override
	public DNoDepositStandardEditDto matching(DNoDepositStandardEditDto dto){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		DNoDepositStandardEdit list1=super.selectById(dto.getFdId());
		if(dto==null||list1==null){
			Assert.throwException("不存在匹配数据");
		}else{
			Wrapper<DNoDepositStandardEdit> wrapper=new CriterionWrapper<DNoDepositStandardEdit>(DNoDepositStandardEdit.class);
			wrapper.eq("is_history", 0);
			wrapper.notIn("creater_id", cUserid);
			wrapper.eq("month_order_weight", dto.getMonthOrderWeight());
			wrapper.eq("month_delivery_weight", dto.getMonthDeliveryWeight());
			wrapper.eq("continuous_month", dto.getContinuousMonth());
			wrapper.eq("start_time", dto.getStartTime());
			wrapper.notIn("role", dept);
			DNoDepositStandardEdit list=super.selectFirst(wrapper);
			if(list==null){
				Assert.throwException("匹配失败");
			}else{		
				Wrapper<DNoDepositStandard> wrapperA=new CriterionWrapper<DNoDepositStandard>(DNoDepositStandard.class);
				wrapper.eq("is_history", 0);
				List<DNoDepositStandard> listA=dNoDepositStandardService.selectList(wrapperA);
				if(listA.size()>0){
					for(DNoDepositStandard ddto:listA){
						ddto.setIsHistory(1);
						//在下一个定金标准生效前一个月当前标准失效
						Calendar calendar = Calendar.getInstance();
						calendar.setTime(dto.getStartTime());
						calendar.add(Calendar.MONTH, -1);
						ddto.setEndTime(calendar.getTime());
						dNoDepositStandardService.updateById(ddto);
					}
				}
				DNoDepositStandard dds=new DNoDepositStandard();
				dds.setFdId(Long.valueOf(IdWorker.getId()));
				dds.setMonthDeliveryWeight(dto.getMonthDeliveryWeight());
				dds.setMonthOrderWeight(dto.getMonthOrderWeight());
				dds.setContinuousMonth(dto.getContinuousMonth());
				dds.setStartTime(dto.getStartTime());
				dds.setCreaterId(cUserid);
				dds.setCreateTime(doDate);
				dds.setIsHistory(0);
				dNoDepositStandardService.insert(dds);
				
				dto.setIsHistory(1);
				dto.setLastAlterId(cUserid);
				dto.setLastAlterTime(doDate);
				super.updateById(dtoToEntityMapper.map(dto, DNoDepositStandardEdit.class));
				list.setIsHistory(1);
				list.setLastAlterId(cUserid);
				list.setLastAlterTime(doDate);
				super.updateById(list);
			}
		}
		return dto;
		
	}
}
