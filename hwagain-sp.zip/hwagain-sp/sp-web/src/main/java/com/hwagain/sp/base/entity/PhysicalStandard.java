package com.hwagain.sp.base.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author linhl
 * @since 2018-11-05
 */
@TableName("physical_standard")
public class PhysicalStandard implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键
     */
	private Long id;
    /**
     * 物料指标编号
     */
	@TableField("physical_no")
	private String physicalNo;
    /**
     * 定量
     */
	private BigDecimal ration;
    /**
     * 层数
     */
	private Integer layer;
    /**
     * 松紧度
     */
	@TableField("loose_tighten")
	private BigDecimal looseTighten;
    /**
     * 横向抗张强度
     */
	@TableField("horizontal_resist")
	private BigDecimal horizontalResist;
    /**
     * 纵向抗张强度
     */
	@TableField("vertical_resist")
	private BigDecimal verticalResist;
    /**
     * 手感值
     */
	@TableField("handFeel_value")
	private BigDecimal handFeelValue;
    /**
     * 纤维柔软度
     */
	@TableField("fibre_soft")
	private BigDecimal fibreSoft;
    /**
     * 粗糙度
     */
	private BigDecimal crassitude;
    /**
     * 硬挺度
     */
	private BigDecimal rigidity;
    /**
     * 横向吸液高度
     */
	@TableField("horizontal_suck")
	private BigDecimal horizontalSuck;
    /**
     * 白度
     */
	private BigDecimal white;
    /**
     * 单包片膜厚度
     */
	@TableField("unit_film")
	private BigDecimal unitFilm;
    /**
     * 中包包膜厚度
     */
	@TableField("middle_film")
	private BigDecimal middleFilm;
    /**
     * 纸箱层数
     */
	@TableField("box_layer")
	private Integer boxLayer;
    /**
     * 纸箱厚度
     */
	@TableField("box_deep")
	private BigDecimal boxDeep;
    /**
     * 备注
     */
	private String remarks;
    /**
     * 创建人
     */
	@TableField("created_by")
	private String createdBy;
    /**
     * 创建时间
     */
	@TableField("created_date")
	private Date createdDate;
    /**
     * 修改人
     */
	@TableField("updated_by")
	private String updatedBy;
    /**
     * 修改时间
     */
	@TableField("updated_date")
	private Date updatedDate;


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPhysicalNo() {
		return physicalNo;
	}

	public void setPhysicalNo(String physicalNo) {
		this.physicalNo = physicalNo;
	}

	public BigDecimal getRation() {
		return ration;
	}

	public void setRation(BigDecimal ration) {
		this.ration = ration;
	}

	public Integer getLayer() {
		return layer;
	}

	public void setLayer(Integer layer) {
		this.layer = layer;
	}

	public BigDecimal getLooseTighten() {
		return looseTighten;
	}

	public void setLooseTighten(BigDecimal looseTighten) {
		this.looseTighten = looseTighten;
	}

	public BigDecimal getHorizontalResist() {
		return horizontalResist;
	}

	public void setHorizontalResist(BigDecimal horizontalResist) {
		this.horizontalResist = horizontalResist;
	}

	public BigDecimal getVerticalResist() {
		return verticalResist;
	}

	public void setVerticalResist(BigDecimal verticalResist) {
		this.verticalResist = verticalResist;
	}

	public BigDecimal getHandFeelValue() {
		return handFeelValue;
	}

	public void setHandFeelValue(BigDecimal handFeelValue) {
		this.handFeelValue = handFeelValue;
	}

	public BigDecimal getFibreSoft() {
		return fibreSoft;
	}

	public void setFibreSoft(BigDecimal fibreSoft) {
		this.fibreSoft = fibreSoft;
	}

	public BigDecimal getCrassitude() {
		return crassitude;
	}

	public void setCrassitude(BigDecimal crassitude) {
		this.crassitude = crassitude;
	}

	public BigDecimal getRigidity() {
		return rigidity;
	}

	public void setRigidity(BigDecimal rigidity) {
		this.rigidity = rigidity;
	}

	public BigDecimal getHorizontalSuck() {
		return horizontalSuck;
	}

	public void setHorizontalSuck(BigDecimal horizontalSuck) {
		this.horizontalSuck = horizontalSuck;
	}

	public BigDecimal getWhite() {
		return white;
	}

	public void setWhite(BigDecimal white) {
		this.white = white;
	}

	public BigDecimal getUnitFilm() {
		return unitFilm;
	}

	public void setUnitFilm(BigDecimal unitFilm) {
		this.unitFilm = unitFilm;
	}

	public BigDecimal getMiddleFilm() {
		return middleFilm;
	}

	public void setMiddleFilm(BigDecimal middleFilm) {
		this.middleFilm = middleFilm;
	}

	public Integer getBoxLayer() {
		return boxLayer;
	}

	public void setBoxLayer(Integer boxLayer) {
		this.boxLayer = boxLayer;
	}

	public BigDecimal getBoxDeep() {
		return boxDeep;
	}

	public void setBoxDeep(BigDecimal boxDeep) {
		this.boxDeep = boxDeep;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

}
