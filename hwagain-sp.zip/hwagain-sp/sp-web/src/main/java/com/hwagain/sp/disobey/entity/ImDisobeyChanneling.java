package com.hwagain.sp.disobey.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author huanglf
 * @since 2018-11-29
 */
@TableName("im_disobey_channeling")
public class ImDisobeyChanneling implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 单据ID
     */
	@TableId("fd_id")
	private Long fdId;
    /**
     * 提货单号
     */
	@TableField("pickup_order_id")
	private String pickupOrderId;
    /**
     * 客户ID
     */
	@TableField("customer_id")
	private Integer customerId;
    /**
     * 客户名称
     */
	@TableField("customer_name")
	private String customerName;
    /**
     * 发货日期
     */
	@TableField("shipment_date")
	private Date shipmentDate;
    /**
     * 承运物流公司
     */
	@TableField("logis_company")
	private String logisCompany;
    /**
     * 车牌号
     */
	@TableField("car_no")
	private String carNo;
    /**
     * 客户经销区域
     */
	@TableField("customer_area")
	private String customerArea;
    /**
     * 窜货区域
     */
	@TableField("channeling_area")
	private String channelingArea;
    /**
     * 翼讯定位情况
     */
	@TableField("place_point")
	private String placePoint;
    /**
     * 窜货确认时间
     */
	@TableField("channeling_date")
	private Date channelingDate;
    /**
     * 窜货数量
     */
	private BigDecimal weight;
    /**
     * 规定扣款金额
     */
	private BigDecimal amount;
    /**
     * 申请扣款金额
     */
	@TableField("apply_amount")
	private BigDecimal applyAmount;
    /**
     * 实际扣款金额
     */
	@TableField("deduct_amount")
	private BigDecimal deductAmount;
    /**
     * 扣款时间
     */
	@TableField("deduct_date")
	private Date deductDate;
    /**
     * 备注
     */
	private String remarks;
    /**
     * 状态
     */
	private Integer status;
    /**
     * OA流程状态
     */
	@TableField("oa_status")
	private Integer oaStatus;
    /**
     * OA单据编号
     */
	@TableField("oa_code")
	private String oaCode;
    /**
     * 创建人
     */
	@TableField("creater_id")
	private String createrId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
    /**
     * 最后修改人
     */
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}
	
	public String getPickupOrderId() {
		return pickupOrderId;
	}

	public void setPickupOrderId(String pickupOrderId) {
		this.pickupOrderId = pickupOrderId;
	}

	public Integer getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Integer customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getShipmentDate() {
		return shipmentDate;
	}

	public void setShipmentDate(Date shipmentDate) {
		this.shipmentDate = shipmentDate;
	}

	public String getLogisCompany() {
		return logisCompany;
	}

	public void setLogisCompany(String logisCompany) {
		this.logisCompany = logisCompany;
	}

	public String getCarNo() {
		return carNo;
	}

	public void setCarNo(String carNo) {
		this.carNo = carNo;
	}

	public String getCustomerArea() {
		return customerArea;
	}

	public void setCustomerArea(String customerArea) {
		this.customerArea = customerArea;
	}

	public String getChannelingArea() {
		return channelingArea;
	}

	public void setChannelingArea(String channelingArea) {
		this.channelingArea = channelingArea;
	}

	public String getPlacePoint() {
		return placePoint;
	}

	public void setPlacePoint(String placePoint) {
		this.placePoint = placePoint;
	}

	public Date getChannelingDate() {
		return channelingDate;
	}

	public void setChannelingDate(Date channelingDate) {
		this.channelingDate = channelingDate;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getApplyAmount() {
		return applyAmount;
	}

	public void setApplyAmount(BigDecimal applyAmount) {
		this.applyAmount = applyAmount;
	}

	public BigDecimal getDeductAmount() {
		return deductAmount;
	}

	public void setDeductAmount(BigDecimal deductAmount) {
		this.deductAmount = deductAmount;
	}

	public Date getDeductDate() {
		return deductDate;
	}

	public void setDeductDate(Date deductDate) {
		this.deductDate = deductDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getOaStatus() {
		return oaStatus;
	}

	public void setOaStatus(Integer oaStatus) {
		this.oaStatus = oaStatus;
	}

	public String getOaCode() {
		return oaCode;
	}

	public void setOaCode(String oaCode) {
		this.oaCode = oaCode;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
