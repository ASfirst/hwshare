package com.hwagain.sp.policy.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.core.util.StringUtil;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;
import com.hwagain.sp.policy.dto.PoOverDto;
import com.hwagain.sp.policy.entity.PoOver;
import com.hwagain.sp.policy.mapper.PoOverMapper;
import com.hwagain.sp.policy.service.IPoOverService;
import com.hwagain.sp.product.dto.ProductDto;
import com.hwagain.sp.product.entity.Product;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
@Service("poOverService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoOverServiceImpl extends ServiceImpl<PoOverMapper, PoOver> implements IPoOverService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(PoOver.class, PoOverDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(PoOverDto.class, PoOver.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

	@Override
	public PoOverDto saveOne(PoOverDto dto) {
		Assert.notBlank(dto.getPlatform(), "纸机不能为空");
		Assert.notBlank(dto.getPaperType(), "纸种不能为空");
		Assert.notBlank(dto.getClassName(), "纸种不能为空");
		Wrapper<PoOver> wrapper = new CriterionWrapper<>(PoOver.class);
		wrapper.eq("fd_year", dto.getFdYear());
		wrapper.eq("fd_month", dto.getFdMonth());
		
		wrapper.eq("platform", dto.getPlatform());
		wrapper.eq("paper_type", dto.getPaperType());
		wrapper.eq("class_name", dto.getClassName());
		if(dto.isIsPromise()){
			wrapper.eq("base_condition", dto.getBaseCondition());
			wrapper.eq("base_amount", dto.getBaseAmount());
			if(StringUtil.isNull(dto.getOverCondition())){
				wrapper.isNull("over_condition");
			}else{
				wrapper.eq("over_condition", dto.getOverCondition());
			}
			if(dto.getOverAmount() == null){
				wrapper.isNull("over_amount");
			}else{
				wrapper.eq("over_amount", dto.getOverAmount());
			}
			
		}else{
			wrapper.eq("is_promise", dto.isIsPromise());
		}
		PoOver product = super.selectFirst(wrapper);
		
		if (product != null && dto.getFdId() == null) {
		    Assert.throwException("已存在该记录");
		}
		
		PoOver over = dtoToEntityMapper.map(dto, PoOver.class);
		if(dto.getFdId() == null){
			over.setFdId(IdWorker.getId());
		}
		over.setCreaterId(UserUtils.getUserCode());
		over.setCreateTime(new Date());
		over.setStatus(30);
		super.insertOrUpdate(over);
		return entityToDtoMapper.map(super.selectById(over.getFdId()), PoOverDto.class);

		
	}
	@Override
	public List<PoOverDto> findListByParams(Map<String, Object> params) {
		 Wrapper<PoOver> wrapper = new CriterionWrapper<>(PoOver.class);
		 wrapper.eq("fd_year", params.get("fdYear"));
         wrapper.eq("fd_month", params.get("fdMonth"));
         
         wrapper.orderBy("platform desc,paper_type, class_name asc, is_promise desc, base_condition desc, over_condition desc");
         List<PoOver> productList = super.selectList(wrapper);
         return entityToDtoMapper.mapAsList(productList, PoOverDto.class);
    
	}
	@Override
	public boolean deleteOne(String fdId) {
		return super.deleteById(fdId);
	}
}
