package com.hwagain.sp.process.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-12-20
 */
public interface IImProcessPriceEditApi {
	
}
