package com.hwagain.sp.process.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public interface IImProcessApi {
	
}
