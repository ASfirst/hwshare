package com.hwagain.sp.deposit.mapper;

import com.hwagain.sp.deposit.entity.DNoDepositStandardEdit;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
public interface DNoDepositStandardEditMapper extends BaseMapper<DNoDepositStandardEdit> {

}