package com.hwagain.sp.customer.api.impl;

import com.hwagain.sp.customer.api.ICustomerApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author hanj
 * @since 2018-10-11
 */
@Service("customerApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class CustomerApiImpl implements ICustomerApi {
	
}
