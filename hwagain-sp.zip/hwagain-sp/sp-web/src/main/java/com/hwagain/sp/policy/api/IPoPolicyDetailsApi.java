package com.hwagain.sp.policy.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
public interface IPoPolicyDetailsApi {
	
}
