package com.hwagain.sp.deposit.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.deposit.service.IDNoDepositCustomerService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author xionglz
 * @since 2018-11-05
 */
@RestController
@RequestMapping(value="/deposit/dNoDepositCustomer",method={RequestMethod.GET,RequestMethod.POST})
@Api(value="【进口纸机】当月不收取定金非常规品明细",description="【进口纸机】当月不收取定金非常规品明细")
public class DNoDepositCustomerController extends BaseController{
	
	@Autowired
	IDNoDepositCustomerService dNoDepositCustomerService;

	@RequestMapping("/inputQueryNoDepoProd")
	@ApiOperation(value="所有非常规品数据",notes="所有非常规品数据",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="year",value="年",paramType="query",required=false,dataType="int"),
		@ApiImplicitParam(name="month",value="月",paramType="query",required=false,dataType="int")
	})
	public Response inputQueryNoDepoProd(int year,int month){
		return SuccessResponseData.newInstance(dNoDepositCustomerService.inputQueryNoDepoProd(year,month));
	}
	
	@RequestMapping("/findNoDepositStandardList")
	@ApiOperation(value="所有非常规品数据",notes="所有非常规品数据",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="monthDate",value="月份",paramType="query",required=false,dataType="Date")
	})
	public Response findNoDepositStandardList(Date monthDate){
		return SuccessResponseData.newInstance(dNoDepositCustomerService.findNoDepositStandardList(monthDate));
	}
	
	@RequestMapping("/findAllNoDepositProd")
	@ApiOperation(value="当前月份不收定金的企业套产品",notes="当前月份不收定金的企业套产品",httpMethod="GET")
	public Response findAllNoDepositProd(){
		return SuccessResponseData.newInstance(dNoDepositCustomerService.findAllNoDepositProd());
	}
	
	@RequestMapping("/findAll")
	@ApiOperation(value="所有非常规品数据",notes="所有非常规品数据",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="queryTime",value="查阅日期",paramType="query",required=false,dataType="Date")
	})
	public Response findAll(Date queryTime){
		return SuccessResponseData.newInstance(dNoDepositCustomerService.findAll(queryTime));
	}

}
