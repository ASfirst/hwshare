package com.hwagain.sp.price.service;

import com.hwagain.sp.price.dto.ImPriceDifferenceEditDto;
import com.hwagain.sp.price.entity.ImPriceDifferenceEdit;

import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 * 副品及承兑汇票结算差价表 服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-22
 */
public interface IImPriceDifferenceEditService extends IService<ImPriceDifferenceEdit> {

	public ImPriceDifferenceEditDto addOneEdit(ImPriceDifferenceEditDto dto)throws CustomException;

	public List<ImPriceDifferenceEditDto> findNewHistory()throws CustomException;

	public List<ImPriceDifferenceEditDto> matching(List<ImPriceDifferenceEditDto> dtos)throws CustomException;
	
}
