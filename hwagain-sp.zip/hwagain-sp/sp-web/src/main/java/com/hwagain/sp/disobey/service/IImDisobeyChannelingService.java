package com.hwagain.sp.disobey.service;

import com.hwagain.sp.base.entity.DictData;
import com.hwagain.sp.disobey.dto.ImDisobeyChannelingDto;
import com.hwagain.sp.disobey.dto.ImDisobeyChannelingRptDto;
import com.hwagain.sp.disobey.entity.ImDisobeyChanneling;

import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
public interface IImDisobeyChannelingService extends IService<ImDisobeyChanneling> {
	public List<ImDisobeyChannelingDto> getDriverByOrder(String orderNo) throws CustomException;
	public ImDisobeyChannelingDto save(ImDisobeyChannelingDto dto) throws CustomException;
	public ImDisobeyChannelingDto update(ImDisobeyChannelingDto dto) throws CustomException; 
	public Boolean deleteByIds(String ids) throws CustomException;
	public List<ImDisobeyChannelingRptDto> findByOACode(String oaCode) throws CustomException;
	public List<ImDisobeyChannelingRptDto> disobeySentToOa();
	public List<ImDisobeyChannelingRptDto> findDisobeyChannelingList() throws CustomException;
	public List<ImDisobeyChannelingRptDto> findChannelingApplyList() throws CustomException;
	public DictData findOaTemId(String itemName,String groupName) throws CustomException;
}
