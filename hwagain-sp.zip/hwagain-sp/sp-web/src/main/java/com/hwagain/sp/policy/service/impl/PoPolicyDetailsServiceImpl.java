package com.hwagain.sp.policy.service.impl;

import com.hwagain.sp.policy.entity.PoPolicy;
import com.hwagain.sp.policy.entity.PoPolicyDetails;
import com.hwagain.sp.policy.dto.PoPolicyDetailsDto;
import com.hwagain.sp.policy.dto.PoPolicyFormatDto;
import com.hwagain.sp.policy.mapper.PoPolicyDetailsMapper;
import com.hwagain.sp.policy.service.IPoPolicyDetailsService;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.util.Date;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
@Service("poPolicyDetailsService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoPolicyDetailsServiceImpl extends ServiceImpl<PoPolicyDetailsMapper, PoPolicyDetails> implements IPoPolicyDetailsService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(PoPolicyDetails.class, PoPolicyDetailsDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(PoPolicyDetailsDto.class, PoPolicyDetails.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	@Override
	public void saveDetails(PoPolicyFormatDto dto) {
		PoPolicyDetails detail = dtoToEntityMapper.map(dto, PoPolicyDetails.class);
		if(dto.getDetailId() == null){
			detail.setFdId(IdWorker.getId());
		}else{
			detail.setFdId(dto.getDetailId());
		}
		detail.setPoPolicyId(dto.getFdId());
		super.insertOrUpdate(detail);
	}
}
