package com.hwagain.sp.base.service;

import com.hwagain.sp.base.dto.DictDataDto;
import com.hwagain.sp.base.entity.DictData;

import java.util.List;

import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
public interface IDictDataService extends IService<DictData> {

 public	List<DictDataDto> findByType(String typename);

 public DictData findOaTemId(String itemName, String groupName);

 public DictData findoneByfdid(Long fdid);
 
 public void save(DictDataDto dto)  throws ClassNotFoundException, IllegalAccessException ;



}
