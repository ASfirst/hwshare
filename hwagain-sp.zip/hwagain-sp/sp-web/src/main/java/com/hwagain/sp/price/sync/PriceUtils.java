package com.hwagain.sp.price.sync;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class PriceUtils {

	public static String const_OaFlowName_ImPriceInput = "产品统一销售价格录入";
	public static String const_OaFlowName_ImPriceAdjust = "产品统一销售价格调整";

	// 获取日期所在季度的最后一天
	public static Date getQuarterEndDate(Date beginDate) {
		Date endDate = null;
		Calendar now = Calendar.getInstance();
		now.setTime(beginDate);
		int year = now.get(Calendar.YEAR);
		int month = now.get(Calendar.MONTH) + 1; // 0-based!
		// int day = now.get(Calendar.DAY_OF_MONTH);

		try {
			if (month == 1 || month == 2 || month == 3)
				endDate = new SimpleDateFormat("yyyy-MM-dd").parse(String.valueOf(year) + "-03-31");
			if (month == 4 || month == 5 || month == 6)
				endDate = new SimpleDateFormat("yyyy-MM-dd").parse(String.valueOf(year) + "-06-30");
			if (month == 7 || month == 8 || month == 9)
				endDate = new SimpleDateFormat("yyyy-MM-dd").parse(String.valueOf(year) + "-09-30");
			if (month == 10 || month == 11 || month == 12)
				endDate = new SimpleDateFormat("yyyy-MM-dd").parse(String.valueOf(year) + "-12-31");
		} catch (Exception e1) {

		}
		return endDate;
	}

}
