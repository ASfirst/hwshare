package com.hwagain.sp.process.service;

import java.math.BigInteger;
import java.util.List;

import com.hwagain.sp.process.dto.ImProcessBatchProductDto;
import com.hwagain.sp.process.dto.ImProcessDto;
import com.hwagain.sp.process.dto.ImProcessPriceDto;
import com.hwagain.sp.process.dto.ImProcessPriceRptDto;
import com.hwagain.sp.process.dto.ImProcessProductFilterDto;
import com.hwagain.sp.process.dto.ImProcessProductRptDto;
import com.hwagain.sp.process.dto.ImProcessRptDto;
import com.hwagain.sp.process.dto.ImProcessSaleRptDto;
import com.hwagain.sp.process.dto.ImProductListDto;
import com.hwagain.sp.process.entity.ImProcess;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public interface IImProcessService extends IService<ImProcess> {
	public List<ImProcessProductFilterDto> findProcessProduct(String className,String fmodel,String sDate,String eDate,String auxprod,String sfnumber,String efnumber) throws CustomException;
	public List<ImProductListDto> getProductDetail(String paperNos,String platform) throws CustomException;
	public List<ImProcessDto> findAll() throws CustomException;
	public ImProcessDto findOne(Long fdId) throws CustomException; 
	public Boolean save(List<ImProductListDto> productList) throws CustomException;
	public ImProcessDto save(ImProcessDto dto,List<ImProcessPriceDto> priceList,List<ImProcessBatchProductDto> productList) throws CustomException;
	public Boolean delete(String fdId) throws CustomException;
	public List<ImProcessSaleRptDto> queryProcessSaleList() throws CustomException;
	
	public Boolean finishSale() throws CustomException;
	public List<ImProcessRptDto> queryProcessHistorySale() throws CustomException;
	public List<ImProcessSaleRptDto> queryProcessSaleByBatch(String batchNo) throws CustomException;
	
	public List<ImProcessProductRptDto> saveProcessProduct(String paperNos,String platform) throws CustomException;
	public List<ImProcessProductRptDto> findProcessProductDetail() throws CustomException;
	public List<ImProcessProductRptDto> getProcessProductDetailById(String ids) throws CustomException;
	public Boolean collectFinish(String ids) throws CustomException;
	
	public List<ImProcessPriceRptDto> findProcessPriceList() throws CustomException;
	
}
