package com.hwagain.sp.process.mapper;

import java.math.BigInteger;

import org.apache.ibatis.annotations.Param;

import com.hwagain.sp.process.entity.ImProcess;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public interface ImProcessMapper extends BaseMapper<ImProcess> {
	public Boolean delProduct(@Param("fdId") String fdId);
	public Boolean delPrice(@Param("fdId") String fdId);
}