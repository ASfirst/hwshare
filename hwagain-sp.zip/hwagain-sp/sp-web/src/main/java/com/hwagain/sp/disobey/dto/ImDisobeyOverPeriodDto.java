package com.hwagain.sp.disobey.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.io.Serializable;

import com.fasterxml.jackson.annotation.JsonFormat;


/**
 * <p>
 * 
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
public class ImDisobeyOverPeriodDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 单据ID
     */
	private Long fdId;
    /**
     * 订单ID
     */
	private Long orderId;
    /**
     * 客户ID
     */
	private Long customerId;
    /**
     * 客户名称
     */
	private String customerName;
    /**
     * 产品类型
     */
	private String kindNo;
    /**
     * 约定提货结束时间
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date lastPickupDate;
    /**
     * 超期天数
     */
	private Integer overDays;
    /**
     * 订货数量
     */
	private BigDecimal weight;
    /**
     * 生产入库数量
     */
	private BigDecimal goinWeight;
    /**
     * 累计提货数量
     */
	private BigDecimal pickupWeight;
    /**
     * 剩余数量
     */
	private BigDecimal remainWeight;
    /**
     * 定金额度
     */
	private BigDecimal orderAmount;
    /**
     * 应扣定金额
     */
	private BigDecimal remainAmount;
    /**
     * 实扣定金额
     */
	private BigDecimal deductAmount;
    /**
     * 是否免责
     */
	private Boolean isDedect;
    /**
     * 申请扣款金额
     */
	private BigDecimal applyDeductAmount;
    /**
     * 扣款日期
     */
	@JsonFormat(pattern = "yyyy-MM-dd", timezone = "GMT+8")
	private Date deductDate;
    /**
     * 备注
     */
	private String remarks;
    /**
     * 状态
     */
	private Integer status;
    /**
     * OA流程状态
     */
	private Integer oaStatus;
    /**
     * OA单据编号
     */
	private String oaCode;
    /**
     * 创建人
     */
	private String createrId;
    /**
     * 创建时间
     */
	private Date createTime;
    /**
     * 最后修改人
     */
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getOrderId() {
		return orderId;
	}

	public void setOrderId(Long orderId) {
		this.orderId = orderId;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getKindNo() {
		return kindNo;
	}

	public void setKindNo(String kindNo) {
		this.kindNo = kindNo;
	}

	public Date getLastPickupDate() {
		return lastPickupDate;
	}

	public void setLastPickupDate(Date lastPickupDate) {
		this.lastPickupDate = lastPickupDate;
	}

	public Integer getOverDays() {
		return overDays;
	}

	public void setOverDays(Integer overDays) {
		this.overDays = overDays;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public BigDecimal getGoinWeight() {
		return goinWeight;
	}

	public void setGoinWeight(BigDecimal goinWeight) {
		this.goinWeight = goinWeight;
	}

	public BigDecimal getPickupWeight() {
		return pickupWeight;
	}

	public void setPickupWeight(BigDecimal pickupWeight) {
		this.pickupWeight = pickupWeight;
	}

	public BigDecimal getRemainWeight() {
		return remainWeight;
	}

	public void setRemainWeight(BigDecimal remainWeight) {
		this.remainWeight = remainWeight;
	}

	public BigDecimal getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(BigDecimal orderAmount) {
		this.orderAmount = orderAmount;
	}

	public BigDecimal getRemainAmount() {
		return remainAmount;
	}

	public void setRemainAmount(BigDecimal remainAmount) {
		this.remainAmount = remainAmount;
	}

	public BigDecimal getDeductAmount() {
		return deductAmount;
	}

	public void setDeductAmount(BigDecimal deductAmount) {
		this.deductAmount = deductAmount;
	}

	public Boolean getIsDedect() {
		return isDedect;
	}

	public void setIsDedect(Boolean isDedect) {
		this.isDedect = isDedect;
	}

	public BigDecimal getApplyDeductAmount() {
		return applyDeductAmount;
	}

	public void setApplyDeductAmount(BigDecimal applyDeductAmount) {
		this.applyDeductAmount = applyDeductAmount;
	}

	public Date getDeductDate() {
		return deductDate;
	}

	public void setDeductDate(Date deductDate) {
		this.deductDate = deductDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getOaStatus() {
		return oaStatus;
	}

	public void setOaStatus(Integer oaStatus) {
		this.oaStatus = oaStatus;
	}

	public String getOaCode() {
		return oaCode;
	}

	public void setOaCode(String oaCode) {
		this.oaCode = oaCode;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
