package com.hwagain.sp.base.service.impl;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.util.List;

import com.hwagain.sp.product.entity.ProductBase;
import com.hwagain.sp.product.service.IProductBaseService;
import com.hwagain.sp.base.dto.PhysicalStandardDto;
import com.hwagain.sp.base.entity.PhysicalStandard;
import com.hwagain.sp.base.mapper.PhysicalStandardMapper;
import com.hwagain.sp.base.service.IPhysicalStandardService;
import com.hwagain.sp.util.JDBCConfig;
import com.hwagain.framework.core.util.SpringBeanUtil;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author linhl
 * @since 2018-11-01
 */
@Service("physicalStandardService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PhysicalStandardServiceImpl extends ServiceImpl<PhysicalStandardMapper, PhysicalStandard> implements IPhysicalStandardService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	
	
	
	@Autowired
	IProductBaseService pdtBase;
	
	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(PhysicalStandard.class, PhysicalStandardDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(PhysicalStandardDto.class, PhysicalStandard.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

	@Override
	public boolean syncData(){
		
		System.err.print("===物理指标同步开始===");
		// TODO Auto-generated method stub
		JDBCConfig jDBCConfig=SpringBeanUtil.getBean(JDBCConfig.class);
		String url = jDBCConfig.getPDUrl();// 127.0.0.1鏄湰鏈哄湴鍧�锛孹E鏄簿绠�鐗圤racle鐨勯粯璁ゆ暟鎹簱鍚�
		String username = jDBCConfig.getPDUsername();// 鐢ㄦ埛鍚�,绯荤粺榛樿鐨勮处鎴峰悕
		String password = jDBCConfig.getPDPassword();// 浣犲畨瑁呮椂閫夎缃殑瀵嗙爜

		Connection con = null;// 鍒涘缓涓�涓暟鎹簱杩炴帴
		PreparedStatement pre = null;// 鍒涘缓棰勭紪璇戣鍙ュ璞★紝涓�鑸兘鏄敤杩欎釜鑰屼笉鐢⊿tatement
		try {
			Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");// 鍔犺浇sql椹卞姩绋嬪簭
			con = DriverManager.getConnection(url, username, password);// 鑾峰彇杩炴帴
			
			UpdateProduct();//鎻掑叆鏂扮殑浜у搧
			String sql = "select * from SP_T_Physical";
			//String sql = "{call dbo.SP_sp_CreatePhysical}";
			
			Statement stat = con.createStatement();
			
			ResultSet resultSet = null;  
			try 
			{  

				resultSet = stat.executeQuery(sql);  
			} 
			catch (SQLException e) 
			{
				e.printStackTrace();  

			}
			try 
			{
				while(resultSet.next())
			    {
					//List<Map> lst=new List<Map>();
					
					  UpdatePhysical(con,resultSet);
		        }  
				resultSet.close();
		      } 
			catch (SQLException e) 
			{
				e.printStackTrace();  
			}  
				

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (pre != null)
					pre.close();
				if (con != null)
					con.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		return true;
	}
	
	//娣诲姞骞舵洿鏂颁骇鍝�
		private boolean UpdateProduct() throws SQLException
		{
			Wrapper<PhysicalStandard> wrapper=new CriterionWrapper<PhysicalStandard>(PhysicalStandard.class);
			List<PhysicalStandard> lstPhysical= super.selectList(wrapper);
			
			
			Wrapper<ProductBase> wrapperProduct=new CriterionWrapper<ProductBase>(ProductBase.class);
			List<ProductBase> lstProduct= pdtBase.selectList(wrapperProduct);
			
			for(ProductBase pt:lstProduct)
			{
				boolean bln;
				bln=false;
				for(PhysicalStandard phy:lstPhysical)
				{
					if(pt.getPhysicalNo()==phy.getPhysicalNo())
					{
						bln=true;
					}
				}
				if(bln==false)
				{
					PhysicalStandard entity=new PhysicalStandard();
					entity.setPhysicalNo(pt.getPhysicalNo());
					
					entity.setCreatedDate(new Date());
					
					super.insert(entity);
				}
				
			}
			
			return true;
		}
		
	//鏇存柊鐗╃悊鎸囨爣
	private boolean UpdatePhysical(Connection con,ResultSet rs) throws SQLException
	{
		Wrapper<PhysicalStandard> wrapper=new CriterionWrapper<PhysicalStandard>(PhysicalStandard.class);
		wrapper.addFilter("physical_no='"+rs.getString("sPhysicalNo")+"'");
		PhysicalStandard phy= super.selectFirst(wrapper);
		if(phy==null)	return false;
		//System.err.println(rs.getString("loose_tighten"));
		BigDecimal bdl=new BigDecimal(rs.getString("loose_tighten"));
		phy.setLooseTighten(bdl);
		phy.setHorizontalResist(new BigDecimal(rs.getString("horizontal_resist")));
		phy.setVerticalResist(new BigDecimal(rs.getString("vertical_resist")));
		phy.setHandFeelValue(new BigDecimal(rs.getString("handFeel_value")));
		phy.setFibreSoft(new BigDecimal(rs.getString("fibre_soft")));
		phy.setCrassitude(new BigDecimal(rs.getString("crassitude")));
		phy.setRigidity(new BigDecimal(rs.getString("rigidity")));
		phy.setHorizontalSuck(new BigDecimal(rs.getString("horizontal_suck")));
		phy.setWhite(new BigDecimal(rs.getString("white")));
		phy.setUpdatedDate(new Date());
		super.update(phy, wrapper);
		return true;
	}
	
	
}
