package com.hwagain.sp.price.service;

import com.hwagain.sp.price.dto.ImPriceDifferenceDto;
import com.hwagain.sp.price.entity.ImPriceDifference;

import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 * 副品及承兑汇票结算差价表 服务类
 * </p>
 *
 * @author 
 * @since 2018-11-16
 */
public interface IImPriceDifferenceService extends IService<ImPriceDifference> {

	public ImPriceDifferenceDto addOne(String itemName)throws CustomException;

	public ImPriceDifferenceDto updateOne(ImPriceDifferenceDto dto)throws CustomException;

	public List<ImPriceDifferenceDto> findAll()throws CustomException;

	public List<ImPriceDifferenceDto> findHistoryImPrice(String ItemName)throws CustomException;

	public List<ImPriceDifferenceDto> findOne(Long fdId)throws CustomException;
	
}
