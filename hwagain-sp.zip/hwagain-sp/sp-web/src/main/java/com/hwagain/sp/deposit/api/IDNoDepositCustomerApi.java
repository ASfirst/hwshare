package com.hwagain.sp.deposit.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-05
 */
public interface IDNoDepositCustomerApi {
	
}
