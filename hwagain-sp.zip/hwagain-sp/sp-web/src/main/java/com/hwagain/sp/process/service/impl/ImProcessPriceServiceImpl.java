package com.hwagain.sp.process.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

import com.hwagain.sp.base.entity.RptTempData;
import com.hwagain.sp.base.mapper.RptTempMapper;
import com.hwagain.sp.process.entity.ImProcess;
import com.hwagain.sp.process.entity.ImProcessBatchProduct;
import com.hwagain.sp.process.entity.ImProcessPrice;
import com.hwagain.sp.process.dto.ImProcessPriceDto;
import com.hwagain.sp.process.dto.ImProcessPriceRptDto;
import com.hwagain.sp.process.mapper.ImProcessBatchProductMapper;
import com.hwagain.sp.process.mapper.ImProcessPriceMapper;
import com.hwagain.sp.process.mapper.ImProcessRptMapper;
import com.hwagain.sp.process.service.IImProcessPriceService;
import com.hwagain.sp.process.service.IImProcessService;
import com.hwagain.sp.process.service.ISysDataService;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.security.common.util.UserUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
@Service("imProcessPriceService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImProcessPriceServiceImpl extends ServiceImpl<ImProcessPriceMapper, ImProcessPrice> implements IImProcessPriceService {
	@Autowired
	ImProcessPriceMapper imProcessPriceMapper;
	@Autowired
	ImProcessBatchProductMapper imProcessBatchProductMapper;
	@Autowired
	IImProcessService imProcessService;
	@Autowired
	RptTempMapper rptTempMapper;
	@Autowired
	ImProcessRptMapper imProcessRptMapper;
	@Autowired
	ISysDataService sysDataService;
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImProcessPrice.class, ImProcessPriceDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImProcessPriceDto.class, ImProcessPrice.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

//	//根据处理品主表Id查找价格录入信息
//	@Override
//	public List<ImProcessPriceRptDto> findPriceByFdId(String processId) throws CustomException {
//		List<ImProcessPriceRptDto> list=imProcessRptMapper.queryImProcessPricetList();
//		Integer seqNum = 1;
//		for(ImProcessPriceRptDto dto:list)
//		{
//			dto.setSeqNum(seqNum);
//			seqNum++;
//		}
//		return list;
//	}


	@Override
	public Boolean isAuditComplate(String priceId) throws CustomException {
		Assert.notBlank(priceId, "处理品价格明细ID不能为空");
		Wrapper<ImProcessPrice> wrapper=new CriterionWrapper<ImProcessPrice> (ImProcessPrice.class);
		wrapper.eq("fd_id", priceId);
		wrapper.isNotNull("audit_date");
		ImProcessPrice entity=super.selectOne(wrapper);
		Boolean flag=false;
		if(Objects.nonNull(entity))
			flag=true;
		return flag;
	}



	@Override
	public Boolean delete(String fdId) {
		Boolean flag=false;
		flag=imProcessPriceMapper.delProductDetail(fdId);
		if(imProcessPriceMapper.deleteById(fdId)>0)
			flag=true;
		return flag;
	}

	@Override
	public String getUserOrder() {
		String cUserid = UserUtils.getUserId();
		// 判断当前是否已经有2个人在录入
		String sql = "select count(distinct  j.update_id) c1 from im_process_price j where `status`<=2 "
				+ "  and j.update_id !='" + cUserid + "' ";
		List<RptTempData> tmL1 = rptTempMapper.queryTempData(sql);
		if (null != tmL1 && !tmL1.isEmpty()) {
			if (Integer.valueOf(tmL1.get(0).getC1()) >= 2) {
				Assert.throwException("当前已经有2个人正在录入");
			}
		}

		String sql2 = " select distinct update_id c1 from (  "
					+" select update_id from im_process_price j where  `status`<=2  "
					+" order by j.update_date ) t  ";

		List<RptTempData> tmL2 = rptTempMapper.queryTempData(sql2);
		System.out.println(tmL2.size());
		if (Objects.isNull(tmL2))
			return "第一人";
		else {
			if (tmL2.get(0).getC1().equals(cUserid))
				return "第一人";
			else
				return "第二人";
		}
	}

	@Override
	public List<ImProcessPriceRptDto> queryPriceFirstList()
			throws CustomException {
		List<ImProcessPriceRptDto> list=imProcessRptMapper.queryImPricetFirstList();
		return list;
	}


	@Override
	public List<ImProcessPriceRptDto> queryPriceSecondList()
			throws CustomException {
		List<ImProcessPriceRptDto> list=imProcessRptMapper.queryImPricetSecondList();
		return list;
	}


	@Override
	public ImProcessPriceDto updateProcessPriceOne(String fdId,
			String userOrder, Integer isPolicy, BigDecimal normalPrice,BigDecimal processPrice,
			String remark) throws CustomException {
		Assert.notBlank(fdId, "修改记录id不能为空");
		Assert.notBlank(userOrder, "当前录入人顺序不能为空");
		Assert.notNull(normalPrice, "现行价格不能为空");
		Assert.notNull(processPrice, "处理价格不能为空");

		ImProcessPrice p = super.selectById(fdId);
		Assert.notNull(p, "没有找到需要修改的记录");

		if (p.getStatus() != 2)
			Assert.throwException("记录未审核或已发布,不允许修改");

		Date doDate = new Date();
		String cUsaerid = UserUtils.getUserId();

		p.setProcessPrice(processPrice);
		p.setFallPrice(normalPrice.divide(processPrice));
		if (null != isPolicy)
			p.setIsPolicy(isPolicy);
		p.setRemark(remark);
		p.setLastAlterId(cUsaerid);
		p.setLastAlterTime(doDate);
		if(userOrder.equals("第一人"))
		{
			Assert.notBlank(remark, "处理原因说明不能为空");
			p.setRemark(remark);
		}

		Wrapper<ImProcessPrice> wrapper = new CriterionWrapper<ImProcessPrice>(ImProcessPrice.class);
		wrapper.eq("status", 1);
		wrapper.eq("im_process_id", p.getImProcessId());
		wrapper.ne("update_id", UserUtils.getUserId());
		ImProcessPrice obj = super.selectFirst(wrapper);

		if (null != obj && null != obj.getProcessPrice() ) {
			Boolean b1 = processPrice.compareTo(obj.getProcessPrice()) == 0;

			if (b1) {
				p.setStatusText("校验通过");
				p.setStatus(2);
				super.updateAllById(p);

				obj.setStatusText("校验通过");
				obj.setStatus(1);
				obj.setLastAlterTime(doDate);
				obj.setLastAlterId(cUsaerid);
				super.updateAllById(obj);
				
				//更新处理品明细状态
				Wrapper<ImProcessBatchProduct> w2=new CriterionWrapper<ImProcessBatchProduct>(ImProcessBatchProduct.class);
				w2.eq("im_process_id", obj.getImProcessId());
				List<ImProcessBatchProduct> list=imProcessBatchProductMapper.selectList(w2);
				for(ImProcessBatchProduct pp:list)
				{
					String saleStatus=sysDataService.getSaleStatus(pp.getPaperNo());
					pp.setStatus(2);
					pp.setSaleStatus(saleStatus);
					imProcessBatchProductMapper.updateAllById(pp);
				}
			} else {
				p.setStatusText("校验未通过,请核对录入信息");
				super.updateAllById(p);
			}
		} else {
			p.setStatusText("等待校验");
			super.updateAllById(p);
		}
		return entityToDtoMapper.map(p, ImProcessPriceDto.class);
	}


	@Override
	public List<ImProcessPriceDto> updateProcessPriceSome(
			List<ImProcessPriceDto> list,String userOrder) throws CustomException {
		List<ImProcessPriceDto> list2 = new ArrayList<ImProcessPriceDto>();

		int i = 1;
		for (ImProcessPriceDto dto : list) {
			ImProcessPrice p = super.selectById(String.valueOf(dto.getFdId()));
			Assert.notNull(p, "第" + String.valueOf(i) + "条纪录,没有找到需要修改的记录");
			if (p.getStatus() != 1)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,未审核或已经发布,不允许修改");
			Assert.notNull(dto.getFdId(), "第" + String.valueOf(i) + "条纪录,修改记录id不能为空");
			Assert.notNull(dto.getProcessPrice(), "第" + String.valueOf(i) + "条纪录,处理价格不能为空");
			if(userOrder.equals("第一人"))
				Assert.notNull(dto.getRemark(), "第" + String.valueOf(i) + "条纪录,处理原因说明不能为空");

			i++;
		}
		Long imProcessId=null;
		Date doDate = new Date();
		for (ImProcessPriceDto dto : list) {
			
			list2.add(updateProcessPriceOne(String.valueOf(dto.getFdId()), userOrder,dto.getIsPolicy(),dto.getNormalPrice(),
					dto.getProcessPrice(), dto.getRemark()));
			imProcessId=dto.getImProcessId();
		}
		if(null!=imProcessId)
		{
			//更新处理品主表状态
			Wrapper<ImProcess> wrapper=new CriterionWrapper<ImProcess>(ImProcess.class);
			wrapper.eq("fdId", imProcessId);
			ImProcess mp=imProcessService.selectOne(wrapper);
			mp.setStatus(3);
			mp.setStardDate(doDate);
			imProcessService.updateAllById(mp);
		}
		return list2;
	}
	
}
