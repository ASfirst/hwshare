package com.hwagain.sp.policy.service;

import com.hwagain.sp.policy.dto.PoDiscountDto;
import com.hwagain.sp.policy.entity.PoDiscount;

import java.util.Date;
import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author linhl
 * @since 2018-11-02
 */
public interface IPoDiscountService extends IService<PoDiscount> {
	public PoDiscountDto findoneByfdid(Long fdid)throws CustomException;

	public List<PoDiscount> findAll(Integer customerID, Date startDate, Date endDate);
	
	public List<PoDiscountDto> queryList(Long customerId, String startDate, String endDate);

	public PoDiscountDto save(PoDiscountDto dto);
	
	public PoDiscountDto update(PoDiscountDto dto);

	public Boolean deleteByIds(String ids);

	
}
