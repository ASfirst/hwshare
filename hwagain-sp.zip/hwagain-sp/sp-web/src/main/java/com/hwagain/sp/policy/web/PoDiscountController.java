package com.hwagain.sp.policy.web;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.policy.dto.PoDiscountDto;
import com.hwagain.sp.policy.service.IPoDiscountService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author linhl
 * @since 2018-11-02
 */
@RestController
@RequestMapping(value="/policy/poDiscount",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "折扣信息单", description = "折扣信息单")
public class PoDiscountController extends BaseController{
	
	@Autowired
	IPoDiscountService poDiscountService;
	
	@RequestMapping(value = "/save", method = { RequestMethod.POST })
	@ApiOperation(value = "新增记录", notes = "新增记录<br/>需传字段：<br/>customerID:客户ID <br/>date:录入日期<br/>  price:单价<br/>  amount:金额<br/> "
			+ "  startdate:生效日期<br/>	  enddate:失效日期<br/>  Policyid:项目ID<br/>    remarks:备注 ", httpMethod = "POST")
	public Response save(@RequestBody PoDiscountDto dto) {
		return SuccessResponseData.newInstance(poDiscountService.save(dto));
	}
	
	@RequestMapping(value = "/update", method = { RequestMethod.POST })
	@ApiOperation(value = "修改记录", notes = "修改记录<br/>需传字段：<br/>customerID:客户ID<br/>date:录入日期<br/>  price:单价<br/>  amount:金额<br/> "
			+ "  startdate:生效日期<br/>	  enddate:失效日期<br/>  Policyid:项目ID<br/>    remarks:备注 ", httpMethod = "POST")
	public Response update(@RequestBody PoDiscountDto dto) {
		return SuccessResponseData.newInstance(poDiscountService.update(dto));
	}
	
	@RequestMapping(value = "/deleteByIds", method = { RequestMethod.POST })
	@ApiOperation(value = "删除记录", notes = "删除记录（多条记录使用“,”分隔）", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "ids", value = "删除记录id,格式：1,2,3,4....", paramType = "query", required = true, dataType = "String") })
	public Response inputDeleteOne(String ids) {
		return SuccessResponseData.newInstance(poDiscountService.deleteByIds(ids));
	}
	
	@RequestMapping("/findoneByfdId")
	@ApiOperation(value="查询单条",notes="按fdId查询单条记录",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="fdid",value="fdid",paramType="query",required=true,dataType="Long")
	})
	public Response findOne(Long fdid){
		return SuccessResponseData.newInstance(poDiscountService.findoneByfdid(fdid));
	}
	
	@RequestMapping("/findAll")
	@ApiOperation(value="查询全部",notes="按客户、日期范围查询数据<br/>参数可录或不录入，参数如不录入则该参数的条件不起作用",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="customerId",value="客户ID",paramType="query",required=false,dataType="long"),
		@ApiImplicitParam(name="startDate",value="起始日期",paramType="query",required=false,dataType="String"),
		@ApiImplicitParam(name="endDate",value="结束日期",paramType="query",required=false,dataType="String")
	})
	public Response QueryList(Long customerId, String startDate,String endDate){
		return SuccessResponseData.newInstance(poDiscountService.queryList(customerId,startDate,endDate));
	}
	
}
