package com.hwagain.sp.policy.api.impl;

import com.hwagain.sp.policy.api.IPoDiscountApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author linhl
 * @since 2018-11-02
 */
@Service("poDiscountApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoDiscountApiImpl implements IPoDiscountApi {
	
}
