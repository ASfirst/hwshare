package com.hwagain.sp.disobey.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hwagain.sp.disobey.dto.BaseDisobeyEditDto;
import com.hwagain.sp.disobey.entity.BaseDisobeyEdit;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
public interface BaseDisobeyEditMapper extends BaseMapper<BaseDisobeyEdit> {
	public List<BaseDisobeyEditDto> queryEditList(@Param("curUserId") String curUserId);
}