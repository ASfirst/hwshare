package com.hwagain.sp.disobey.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;
import com.hwagain.sp.disobey.dto.ImDisobeyChannelingRptDto;
import com.hwagain.sp.disobey.entity.ImDisobeyChanneling;

public interface ImDisobeyChannelingRptMapper extends BaseMapper<ImDisobeyChanneling> {
	public List<ImDisobeyChannelingRptDto> queryImChannelingList();
	public List<ImDisobeyChannelingRptDto> queryChannelingSendOAList();
	public List<ImDisobeyChannelingRptDto> queryChannelingApplyList();
	public List<ImDisobeyChannelingRptDto> queryChannelingByOACode(@Param("oaCode") String oaCode);
}
