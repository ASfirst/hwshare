package com.hwagain.sp.process.service.impl;

import com.hwagain.sp.process.entity.ImProcessBatch;
import com.hwagain.sp.process.dto.ImProcessBatchDto;
import com.hwagain.sp.process.mapper.ImProcessBatchMapper;
import com.hwagain.sp.process.service.IImProcessBatchService;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
@Service("imProcessBatchService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImProcessBatchServiceImpl extends ServiceImpl<ImProcessBatchMapper, ImProcessBatch> implements IImProcessBatchService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImProcessBatch.class, ImProcessBatchDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImProcessBatchDto.class, ImProcessBatch.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
}
