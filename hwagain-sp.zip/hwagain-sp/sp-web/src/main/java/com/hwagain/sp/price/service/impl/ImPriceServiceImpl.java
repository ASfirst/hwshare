package com.hwagain.sp.price.service.impl;

import com.hwagain.sp.price.entity.ImPrice;
import com.hwagain.sp.base.dto.DictDataDto;
import com.hwagain.sp.base.dto.OaAduitDetailDto;
import com.hwagain.sp.base.entity.DictData;
import com.hwagain.sp.base.entity.OaAduit;
import com.hwagain.sp.base.entity.OaAduitDetail;
import com.hwagain.sp.base.entity.RptTempData;
import com.hwagain.sp.base.mapper.RptTempMapper;
import com.hwagain.sp.base.service.IDictDataService;
import com.hwagain.sp.base.service.IOaAduitDetailService;
import com.hwagain.sp.base.service.IOaAduitService;
import com.hwagain.sp.price.dto.ImPriceDto;
import com.hwagain.sp.price.dto.ImPriceRptDto;
import com.hwagain.sp.price.dto.ImTransPriceDto;
import com.hwagain.sp.price.mapper.ImPriceMapper;
import com.hwagain.sp.price.mapper.ImPriceRptMapper;
import com.hwagain.sp.price.service.IImPriceService;
import com.hwagain.sp.price.sync.PriceUtils;
import com.hwagain.sp.product.dto.ProductBaseExtDto;
import com.hwagain.sp.product.dto.ProductOutStockDto;
import com.hwagain.sp.product.entity.ProductBase;
import com.hwagain.sp.product.mapper.ProductBaseMapper;
import com.hwagain.sp.product.service.IProductBaseService;
import com.hwagain.sp.util.JDBCConfig;
import com.hwagain.sp.util.PublicUtils;
import com.hwagain.sp.util.SqlDbUtils;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.core.util.SpringBeanUtil;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;
import com.hwagain.framework.util.judge.IsNotNullUtil;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 * 常规、非常规产品统一销售价格表 服务实现类
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
@Service("imPriceService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImPriceServiceImpl extends ServiceImpl<ImPriceMapper, ImPrice> implements IImPriceService {

	// entity转dto
	static MapperFacade entityToDtoMapper;

	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImPrice.class, ImPriceDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();

		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImPriceDto.class, ImPrice.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

	@Autowired
	RptTempMapper rptTempMapper;
	@Autowired
	ImPriceRptMapper imPriceRptMapper;
	@Autowired
	ProductBaseMapper productBaseMapper;
	@Autowired
	IProductBaseService productBaseService;

	@Override
	public List<RptTempData> queryTempData() {
		String sql = "select fd_id c1,Class_No c2 , color c3  from im_price";
		return rptTempMapper.queryTempData(sql);
	}

	@Override
	public List<ImPriceRptDto> queryImPriceList() {
		List<ImPriceRptDto> list = imPriceRptMapper.queryImPriceList();
		if (null != list && !list.isEmpty()) {
			list = getRowSpan(list);
		}
		return list;
	}

	// 价格录入-查询列表
	@Override
	public List<ImPriceRptDto> inputQueryList() {
		List<ImPriceRptDto> list = imPriceRptMapper.queryInputList();

		Integer seqNum = 1;
		for (ImPriceRptDto dto : list) {
			dto.setSeqNum(seqNum);
			seqNum++;
		}

		return list;
	}

	// 价格录入-查询选择产品
	@Override
	public List<ProductBaseExtDto> inputQuerySelect() {
		List<ProductBaseExtDto> list = productBaseMapper.queryList();
		return list;
	}

	// 价格录入-选择产品
	@Override
	public List<ImPriceRptDto> inputSelectProd(String prodBaseIds) {
		Assert.notBlank(prodBaseIds, "请选择产品");

		String[] lIds = prodBaseIds.split(";");
		Assert.isTrue(null != lIds && lIds.length > 0, "请选择产品");

		List<ImPriceRptDto> oldList = imPriceRptMapper.queryInputList();
		String oACode = null;
		Integer status = 10;
		if (null != oldList && !oldList.isEmpty()) {
			for (ImPriceRptDto dto : oldList) {
				if (dto.getStatus() == 20)
					Assert.throwException("现有记录正在OA流程审核中,不允许修改");
				if (dto.getStatus() == 11)
					status = 11;
				if (null != dto.getOACode())
					oACode = dto.getOACode();
			}
		}

		Date doDate = new Date();
		String curUserId = UserUtils.getUserId();

		for (String sid : lIds) {
			ProductBase p = productBaseService.selectById(sid);
			Assert.notNull(p, "没有找到产品信息[" + sid + "]");

			ImPrice n = new ImPrice();

			n.setFdId(IdWorker.getId());
			n.setClassNo(p.getClassNo());
			n.setColor(p.getColor());
			n.setKindNo(p.getKindNo());
			// n.setUnit(unit);
			n.setRation(p.getRation());
			n.setMinRation(p.getMinRation());
			n.setMaxRation(p.getMaxRation());
//			n.setLayers(p.getLayers());
//
//			if (p.getKindNo().equals("b")) // 非常规品
//				n.setWidth("定制幅宽");
//			else
//				n.setWidth(p.getWidth());
//
//			n.setMinWidth(p.getMinWidth());
//			n.setMaxWidth(p.getMaxWidth());
//			n.setTotalWidth(p.getTotalWidth());
//			n.setMinTotalWidth(p.getMinTotalWidth());
//			n.setMaxTotalWidth(p.getMaxTotalWidth());
//			n.setDiameter(p.getDiameter());
//			n.setMinDiameter(p.getMinDiameter());
//			n.setMaxDiameter(p.getMaxDiameter());
//			n.setWrinkleRate(p.getWrinkleRate());

			n.setIsPolicy(1);
			n.setStatus(status);
			n.setOACode(oACode);
			n.setProdBaseId(Long.valueOf(sid));
			n.setIsHistory(0);
			n.setIsDelete(0);
			n.setCreaterId(curUserId);
			n.setCreateTime(doDate);

			super.insert(n);
		}

		return imPriceRptMapper.queryInputList();
	}

	// 价格录入-更新一条
	@Override
	public ImPriceDto inputUpdateOne(String fdid, String unit, BigDecimal addPrice, BigDecimal extPrice, Date startDate,
			Integer isPolicy, String remark) {
		Assert.notBlank(fdid, "修改记录id不能为空");
		Assert.notNull(extPrice, "执行价格不能为空");
		Assert.notNull(startDate, "开始日期不能为空");

		ImPrice p = super.selectById(fdid);
		Assert.notNull(p, "没有找到需要修改的记录");

		if (p.getStatus() == 20)
			Assert.throwException("记录正在OA流程审核中,不允许修改");
		if (p.getStatus() == 30)
			Assert.throwException("记录已经审批,不允许修改");

		p.setUnit(unit);
		p.setAddPrice(addPrice);
		p.setPrice(extPrice);
		p.setStartDate(startDate);
		//p.setEndDate(PriceUtils.getQuarterEndDate(startDate));
		p.setIsPolicy(isPolicy);
		p.setRemark(remark);
		p.setLastAlterTime(new Date());
		p.setLastAlterId(UserUtils.getUserId());

		super.updateAllById(p);

		return entityToDtoMapper.map(p, ImPriceDto.class);
	}

	// 价格录入-更新多条
	@Override
	public List<ImPriceDto> inputUpdateSome(List<ImPriceDto> list) {
		List<ImPriceDto> list2 = new ArrayList<ImPriceDto>();

		int i = 1;
		for (ImPriceDto dto : list) {
			ImPrice p = super.selectById(String.valueOf(dto.getFdId()));
			Assert.notNull(p, "第" + String.valueOf(i) + "条纪录,没有找到需要修改的记录");
			if (p.getStatus() == 20)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,记录正在OA流程审核中,不允许修改");
			if (p.getStatus() == 30)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,记录已经审批,不允许修改");
			i++;
		}

		for (ImPriceDto dto : list) {
			list2.add(inputUpdateOne(String.valueOf(dto.getFdId()), dto.getUnit(), dto.getAddPrice(), dto.getPrice(),
					dto.getStartDate(), dto.getIsPolicy(), dto.getRemark()));
		}

		return list2;
	}

	// 价格录入-删除一条
	@Override
	public ImPriceDto inputDeleteOne(String fdid) {
		Assert.notBlank(fdid, "删除记录id不能为空");

		ImPrice p = super.selectById(fdid);
		Assert.notNull(p, "没有找到需要修改的记录");

		p.setIsDelete(1);
		p.setLastAlterTime(new Date());
		p.setLastAlterId(UserUtils.getUserId());
		super.updateAllById(p);

		return entityToDtoMapper.map(p, ImPriceDto.class);
	}

	@Autowired
	IDictDataService dictDataService;
	@Autowired
	IOaAduitService oaAduitService;
	@Autowired
	IOaAduitDetailService oaAduitDetailService;

	// 价格录入-提交OA
	@Override
	public List<ImPriceRptDto> inputSentToOa() {

		List<ImPriceRptDto> list = imPriceRptMapper.queryInputList();

		Assert.notNull(list, "没有找到需要推送OA的价格录入记录");
		Assert.isTrue(!list.isEmpty(), "没有找到需要推送OA的价格录入记录");

		int i = 1;
		for (ImPriceRptDto dto : list) {
			if (dto.getStatus() != 10)
				Assert.throwException("第" + String.valueOf(i) + "条纪录,不是未提交状态,无法提交OA");
			if (null != dto.getOACode() && !dto.getOACode().isEmpty())
				Assert.throwException("第" + String.valueOf(i) + "条纪录,OACode不为空,无法提交OA");
			if (null == dto.getPrice())
				Assert.throwException("第" + String.valueOf(i) + "条纪录,执行价格不能为空");
			if (null == dto.getStartDate())
				Assert.throwException("第" + String.valueOf(i) + "条纪录,开始日期不能为空");

			i++;
		}

		Date doDate = new Date();
		String oACode = String.valueOf(IdWorker.getId());

		String flowName = PriceUtils.const_OaFlowName_ImPriceInput;
		String platform = PublicUtils.const_Platform_Import;

		DictData dic = dictDataService.findOaTemId(flowName, platform);
		Assert.notNull(dic, "没有找到[" + flowName + "]的OA流程配置信息");
		Assert.notBlank(dic.getCode(), "没有找到[" + flowName + "]的OA流程配置信息");

		String temid = dic.getCode();
		String title = dic.getText();
		String userEmpNo = UserUtils.getUserInfo().getFdEmployeeNumber();
		String userName = UserUtils.getUserInfo().getName();
		Integer iresult = SqlDbUtils.sentOaFlow(temid, oACode, title, userEmpNo, userName, platform + ";" + flowName);
		Assert.isTrue(iresult == 1, "提交OA失败");

		// 记录日志
		OaAduit oa = new OaAduit();
		oa.setFdId(IdWorker.getId());
		oa.setOaCode(oACode);
		oa.setPlatform(platform);
		oa.setTableName("im_price");
		oa.setFlowName(flowName);
		oa.setNodeName("提交OA");
		oa.setEmpName(userName);
		oa.setEmpNo(userEmpNo);
		oa.setStatus(11);
		oa.setCreaterId(UserUtils.getUserId());
		oa.setCreateTime(doDate);
		oaAduitService.insert(oa);

		OaAduitDetailDto oaDetailDto = entityToDtoMapper.map(oa, OaAduitDetailDto.class);

		for (ImPriceRptDto dto : list) {
			dto.setOACode(oACode);
			dto.setStatus(11);
			dto.setStatusText("已提交");

			ImPrice p = dtoToEntityMapper.map(dto, ImPrice.class);
			p.setLastAlterTime(doDate);
			p.setLastAlterId(UserUtils.getUserId());

			super.updateById(p);

			OaAduitDetail oaDetail = dtoToEntityMapper.map(oaDetailDto, OaAduitDetail.class);
			oaDetail.setFdId(IdWorker.getId());
			oaDetail.setRecFdId(p.getFdId());
			oaAduitDetailService.insert(oaDetail);
		}

		return list;
	}

	// 价格录入-OA审批过程
	@Override
	public List<ImPriceRptDto> inputOaAduitFlow(String oACode, Integer status, String nodeName, String empName,
			String empNo, String flowDjbh, String flowDjlsh) {

		Assert.isTrue(status == 11 || status == 20 || status == 30, "状态无效（只能是11或20或30）");

		List<ImPriceRptDto> list = imPriceRptMapper.queryInputByOaCode(oACode);

		Assert.notNull(list, "没有找到oACode对应的价格录入记录");
		Assert.isTrue(!list.isEmpty(), "没有找到oACode对应的价格录入记录");

		for (ImPriceRptDto dto : list) {
			if (dto.getStatus() == 30)
				Assert.throwException("部分记录已经审批");
			if (dto.getStatus() == 40)
				Assert.throwException("部分记录已经过期");
		}

		Date doDate = new Date();
		String flowName = PriceUtils.const_OaFlowName_ImPriceInput;
		String platform = PublicUtils.const_Platform_Import;

		// 记录日志
		OaAduit oa = new OaAduit();
		oa.setFdId(IdWorker.getId());
		oa.setOaCode(oACode);
		oa.setPlatform(platform);
		oa.setTableName("im_price");
		oa.setFlowName(flowName);
		oa.setNodeName(nodeName);
		oa.setEmpName(empName);
		oa.setEmpNo(empNo);
		oa.setFlowDjbh(flowDjbh);
		oa.setFlowDjlsh(flowDjlsh);
		oa.setStatus(status);
		// oa.setCreaterId(UserUtils.getUserId());
		oa.setCreateTime(doDate);
		oaAduitService.insert(oa);

		OaAduitDetailDto oaDetailDto = entityToDtoMapper.map(oa, OaAduitDetailDto.class);

		for (ImPriceRptDto dto : list) {
			dto.setOACode(oACode);
			dto.setStatus(status);

			ImPrice p = dtoToEntityMapper.map(dto, ImPrice.class);
			p.setLastAlterTime(doDate);
			// p.setLastAlterId(UserUtils.getUserId());

			super.updateById(p);

			OaAduitDetail oaDetail = dtoToEntityMapper.map(oaDetailDto, OaAduitDetail.class);
			oaDetail.setFdId(IdWorker.getId());
			oaDetail.setRecFdId(p.getFdId());
			oaAduitDetailService.insert(oaDetail);
		}

		return list;
	}

	// 价格录入-OA查询列表
	@Override
	public List<ImPriceRptDto> inputQueryByOaCode(String oaCode) {
		List<ImPriceRptDto> list = imPriceRptMapper.queryInputByOaCode(oaCode);

		Integer seqNum = 1;
		for (ImPriceRptDto dto : list) {
			dto.setSeqNum(seqNum);
			seqNum++;
		}

		return list;
	}

	// 合并单元格
	public List<ImPriceRptDto> getRowSpan(List<ImPriceRptDto> list) {
		// 合并单元格
		if (null != list && !list.isEmpty()) {
			Integer seqNum = 1;
			String perClassNo = null;
			ImPriceRptDto perDto = null;
			for (ImPriceRptDto dto : list) {
				dto.setSeqNum(seqNum);
				seqNum++;

				if (null == perDto) {
					perClassNo = dto.getClassNo();
					perDto = dto;
					perDto.setRowSpan1(1);
				} else {
					if (dto.getClassNo().equals(perClassNo)) {
						perDto.setRowSpan1(perDto.getRowSpan1() + 1);
					} else {
						perClassNo = dto.getClassNo();
						perDto = dto;
						perDto.setRowSpan1(1);
					}
				}
			}

			perClassNo = null;
			String perColor = null;
			perDto = null;
			for (ImPriceRptDto dto : list) {
				if (null == perDto) {
					perClassNo = dto.getClassNo();
					perColor = dto.getColor();

					perDto = dto;
					perDto.setRowSpan2(1);
				} else {
					if (dto.getClassNo().equals(perClassNo) && dto.getColor().equals(perColor)) {
						perDto.setRowSpan2(perDto.getRowSpan2() + 1);
					} else {
						perClassNo = dto.getClassNo();
						perColor = dto.getColor();
						perDto = dto;
						perDto.setRowSpan2(1);
					}
				}
			}
		}

		return list;
	}

	@Override
	public ImPriceDto findOne(String fdId) {
		return entityToDtoMapper.map(super.selectById(fdId), ImPriceDto.class);
	}

	// 过期状态更新
	@Override
	public void outDateStatus() {
		try {
			Wrapper<ImPrice> wrapper = new CriterionWrapper<ImPrice>(ImPrice.class);
			wrapper.eq("status", 30);
			wrapper.lt("end_date", new Date());
			wrapper.eq("is_delete", 0);
			List<ImPrice> list = super.selectList(wrapper);
			if (null != list && !list.isEmpty()) {
				for (ImPrice o : list) {
					o.setStatus(40); // 已过期
					super.updateById(o);
				}
			}
		} catch (Exception e1) {

		}
	}

	// 历史价格-列表
	@Override
	public List<RptTempData> queryHistoryPrice() {
		String sql = "select t.start_date c1 , case when t.add_price >0 then '涨价' when t.add_price <0 then '降价' else '' end as c2 , "
				+ "       t.add_price c3 ,  t.price c4 from ( "
				+ "		select distinct p.start_date , p.add_price , p.price from im_price p  "
				+ "		 where p.is_delete=0 and (p.`status` =30 or p.`status` =40) ) t  "
				+ " order by t.start_date desc ";
		return rptTempMapper.queryTempData(sql);
	}

	// 历史价格-明细
	@Override
	public List<ImPriceRptDto> queryHistoryPriceDetail(Date startDate, BigDecimal price, BigDecimal addPrice) {
		List<ImPriceRptDto> list = imPriceRptMapper.queryHistoryPriceDetail(startDate,price, addPrice );
		if (null != list && !list.isEmpty()) {
			list = getRowSpan(list);
		}
		return list;
	}

	@Override
	public List<ImTransPriceDto> getTransPrice(String procuctType,String custName, String address, String carType, String province,
			String city, String county, Date startdate) {
		// TODO Auto-generated method stub
		// TODO Auto-generated method stub
				JDBCConfig jDBCConfig=SpringBeanUtil.getBean(JDBCConfig.class);
				String url = jDBCConfig.getK3Url();// 127.0.0.1是本机地址，XE是精简版Oracle的默认数据库名
				String username = jDBCConfig.getK3Username();// 用户名,系统默认的账户名
				String password = jDBCConfig.getK3Password();// 你安装时选设置的密码

				List<ImTransPriceDto> list= new ArrayList<ImTransPriceDto>();
				Connection con = null;// 创建一个数据库连接
				PreparedStatement pre = null;// 创建预编译语句对象，一般都是用这个而不用Statement
				ResultSet result = null;// 创建一个结果集对象
				try {
					Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");// 加载sql驱动程序
					con = DriverManager.getConnection(url, username, password);// 获取连接
					province=IsNotNullUtil.stringIsNotNull(province);
					city=IsNotNullUtil.stringIsNotNull(city);
					county=IsNotNullUtil.stringIsNotNull(county);
					SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
					String sdate=sdf.format(startdate);
					String sql = "select top 1 isnull(TransPriceOffSeason,0) TransPriceOffSeason" + 
							",isnull(OffTransPriceByDirectPay,0) OffTransPriceByDirectPay" + 
							",isnull(TransPriceBusySeason,0) TransPriceBusySeason" + 
							",isnull(BusyTransPriceByDirectPay,0) BusyTransPriceByDirectPay from 物流管理系统.dbo.v_transprice where cartType='" +carType 
							+"' and ContractStartDate<='" +sdate.toString() +"' and ContractEndDate>='" 
							+ sdate.toString() +"' and ReceiptProvince='"+province.toString()+"' and Receiptcity='"
							+city.toString()+"' and Receiptcounty like '%"+county.toString()+"%'" ;// 预编译语句，“？”代表参数
					pre = con.prepareStatement(sql);// 实例化预编译语句
					result = pre.executeQuery();// 执行查询，注意括号中不需要再加参数
					ResultSetMetaData md = pre.getMetaData();
					int columnCount = md.getColumnCount();
					while (result.next()) {
						Map<String, Object> map = new HashMap<>();
						for (int i = 1; i <= columnCount; i++)
							map.put(md.getColumnName(i).toString(), result.getObject(i));
						ImTransPriceDto dto=new ImTransPriceDto();
						
						dto=ImTransPriceAdd(map);
						list.add(dto);
					}
					
					//查询不到数据负空值
					if (list.size()==0) {
						ImTransPriceDto dto=new ImTransPriceDto();
						list.add(dto);
					}
			
				} catch (Exception e) {
					e.printStackTrace();
				} finally {
					try {
						if (result != null)
							result.close();
						if (pre != null)
							pre.close();
						if (con != null)
							con.close();
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
				return entityToDtoMapper.mapAsList(list, ImTransPriceDto.class);
	}
	
	private ImTransPriceDto ImTransPriceAdd(Map<String, Object> obj) {
		ImTransPriceDto dto=new ImTransPriceDto();
		
		String a=IsNotNullUtil.stringIsNotNull(String.valueOf(obj.get("BusyTransPriceByDirectPay")));
		BigDecimal busyTransPriceByDirectPay;
		if (a!=null) {busyTransPriceByDirectPay=new BigDecimal(a);} else {busyTransPriceByDirectPay=new BigDecimal("0");}
		busyTransPriceByDirectPay=new BigDecimal(a);
		
		String b=IsNotNullUtil.stringIsNotNull(String.valueOf(obj.get("OffTransPriceByDirectPay")));
		BigDecimal offTransPriceByDirectPay;
		if (b!=null) {offTransPriceByDirectPay=new BigDecimal(b);} else  {offTransPriceByDirectPay=new BigDecimal("0");}
		
		String c=IsNotNullUtil.stringIsNotNull(String.valueOf(obj.get("TransPriceBusySeason")));
		BigDecimal transPriceBusySeason;
		if (c!=null) {transPriceBusySeason=new BigDecimal(c);} else  {transPriceBusySeason=new BigDecimal("0");}
		
		String d=IsNotNullUtil.stringIsNotNull(String.valueOf(obj.get("TransPriceOffSeason")));
		BigDecimal transPriceOffSeason;
		if (d!=null) {transPriceOffSeason=new BigDecimal(d);} else  {transPriceOffSeason=new BigDecimal("0");}
		
		dto.setBusyTransPriceByDirectPay(busyTransPriceByDirectPay);
		dto.setOffTransPriceByDirectPay(offTransPriceByDirectPay);
		dto.setTransPriceBusySeason(transPriceBusySeason);
		dto.setTransPriceOffSeason(transPriceOffSeason);
		
		
		return dto;
	}
	
	//==================================================================================
	@Override
	public List<ImPriceRptDto> findAllList(){
		List<ImPriceRptDto> list = imPriceRptMapper.findAllList();
		if (null != list && !list.isEmpty()) {
			list = getRowSpan(list);
		}
		return list;
		
	}
	@Override
	public ImPriceDto updateOneEdit(ImPriceDto dto){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String curUserId = UserUtils.getUserId();
//		Wrapper<ImPrice> wrapper=new CriterionWrapper<ImPrice>(ImPrice.class);
//		wrapper.eq("fd_id", dto.getFdId());
		ImPrice list=super.selectById(dto.getFdId());
		if(list!=null){
			ImPrice imp=new ImPrice();
			imp.setFdId(dto.getFdId());
			imp.setStatus(2);
			imp.setEndDate(dto.getStartDate());
			imp.setLastAlterTime(new Date());
			imp.setLastAlterId(dto.getCreaterId());
			super.updateById(imp);
//			ImPrice imp1=new ImPrice();
			list.setFdId(Long.valueOf(IdWorker.getId()));
			list.setAddPrice(dto.getAddPrice());
			list.setPrice(dto.getPrice());
			list.setStartDate(dto.getStartDate());
			list.setCreaterId(curUserId);
			list.setCreateTime(doDate);
			list.setStatus(1);
//			list.setAdjustId(dto.getCreaterId());
			super.insert(dtoToEntityMapper.map(list, ImPrice.class));
		}
		return entityToDtoMapper.map(super.selectById(list.getFdId()), ImPriceDto.class);
		
	}

}


