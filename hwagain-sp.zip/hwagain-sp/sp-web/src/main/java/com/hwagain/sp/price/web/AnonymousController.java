package com.hwagain.sp.price.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.hwagain.framework.core.response.ErrorResponseData;
import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.sp.base.mapper.RptTempMapper;
import com.hwagain.sp.price.service.IImPriceAdjustService;
import com.hwagain.sp.price.service.IImPriceService;
import com.hwagain.sp.price.sync.PriceUtils;
import com.hwagain.sp.util.PublicUtils;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 匿名访问-价格管理
 * </p>
 *
 * @author hanj
 * @since 2018-03-14
 */
@RestController
@RequestMapping(value = "/anonymous/price", method = { RequestMethod.GET, RequestMethod.POST })
@Api(value = "匿名接口-价格管理", description = "匿名接口-价格管理")
public class AnonymousController {

	@Autowired
	IImPriceService imPriceService;
	@Autowired
	IImPriceAdjustService imPriceAdjustService;

	@RequestMapping(value = "/oaFlowDataQuery", method = { RequestMethod.GET })
	@ApiOperation(value = "查询流程展示数据", notes = "查询流程展示数据", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "platform", value = "纸机平台(传到OA系统中间表的meno:Import/China/Culture)", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "flowName", value = "流程名称(传到OA系统中间表的meno)", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "oaCode", value = "oaCode(传到OA系统中间表的recordId)", paramType = "query", required = true, dataType = "String") })
	public Response oaFlowDataQuery(String platform, String flowName, String oaCode) {

		if (platform.equals(PublicUtils.const_Platform_Import)
				&& flowName.equals(PriceUtils.const_OaFlowName_ImPriceInput))
			return SuccessResponseData.newInstance(imPriceService.inputQueryByOaCode(oaCode));
		else if (platform.equals(PublicUtils.const_Platform_Import)
				&& flowName.equals(PriceUtils.const_OaFlowName_ImPriceAdjust))
			return SuccessResponseData.newInstance(imPriceAdjustService.adjustQueryByOaCode(oaCode));
		else
			return ErrorResponseData.newInstance("参数不正确：" + platform + ";" + flowName);

	}

	@RequestMapping(value = "/oaAduitFlow", method = { RequestMethod.POST })
	@ApiOperation(value = "OA审批过程", notes = "OA审批过程", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "platform", value = "纸机平台(传到OA系统中间表的meno:Import/China/Culture)", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "flowName", value = "流程名称(传到OA系统中间表的meno)", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "oaCode", value = "oaCode(传到OA系统中间表的recordId)", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "status", value = "状态(11,20,30)", paramType = "query", required = true, dataType = "Integer"),
			@ApiImplicitParam(name = "nodeName1", value = "OA流程节点名称", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "empName", value = "审核审批人姓名", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "empNo", value = "审核审批人工号", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "flowDjbh", value = "OA单据编号", paramType = "query", required = false, dataType = "String"),
			@ApiImplicitParam(name = "flowDjlsh", value = "OA单据流水号", paramType = "query", required = false, dataType = "String") })
	public Response oaAduitFlow(String platform, String flowName, String oaCode, Integer status, String nodeName1,
			String empName, String empNo, String flowDjbh, String flowDjlsh) {
		if (platform.equals(PublicUtils.const_Platform_Import)
				&& flowName.equals(PriceUtils.const_OaFlowName_ImPriceInput))
			return SuccessResponseData.newInstance(
					imPriceService.inputOaAduitFlow(oaCode, status, nodeName1, empName, empNo, flowDjbh, flowDjlsh));
		else if (platform.equals(PublicUtils.const_Platform_Import)
				&& flowName.equals(PriceUtils.const_OaFlowName_ImPriceAdjust))
			return SuccessResponseData.newInstance(imPriceAdjustService.adjustOaAduitFlow(oaCode, status, nodeName1, empName, empNo, flowDjbh, flowDjlsh));
		else
			return ErrorResponseData.newInstance("参数不正确：" + platform + ";" + flowName);
	}

}
