package com.hwagain.sp.policy.mapper;

import com.hwagain.sp.policy.entity.PoTransport;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

/**
 * <p>
 * Mapper 接口
 * </p>
 *
 * @author weibw
 * @since 2019-06-20
 */
@Repository
public interface PoTransportMapper extends BaseMapper<PoTransport> {

    void insertPoTransportEntity(PoTransport poTransport);

}