package com.hwagain.sp.order.web;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.order.service.IImOrderSpecService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@RestController
@RequestMapping(value="/order/imOrderSpec",method={RequestMethod.GET,RequestMethod.POST})
public class ImOrderSpecController extends BaseController{
	
	@Autowired
	IImOrderSpecService imOrderSpecService;
	
}
