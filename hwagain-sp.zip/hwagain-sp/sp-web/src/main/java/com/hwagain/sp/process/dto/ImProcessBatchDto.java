package com.hwagain.sp.process.dto;

import java.math.BigDecimal;
import java.util.Date;
import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public class ImProcessBatchDto implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	private Long fdId;
    /**
     * 处理品批号
     */
	private String batchNo;
    /**
     * 总重量
     */
	private BigDecimal totalWeight;
    /**
     * 开始销售日期
     */
	private Date stardDate;
    /**
     * 结束销售日期
     */
	private Date endDate;
    /**
     * 备注
     */
	private String remark;
    /**
     * 状态
     */
	private Integer status;
	/**
     * 创建人
     */
	private String createrId;
    /**
     * 创建时间
     */
	private Date createTime;
    /**
     * 最后修改人
     */
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getBatchNo() {
		return batchNo;
	}

	public void setBatchNo(String batchNo) {
		this.batchNo = batchNo;
	}

	public BigDecimal getTotalWeight() {
		return totalWeight;
	}

	public void setTotalWeight(BigDecimal totalWeight) {
		this.totalWeight = totalWeight;
	}

	public Date getStardDate() {
		return stardDate;
	}

	public void setStardDate(Date stardDate) {
		this.stardDate = stardDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
