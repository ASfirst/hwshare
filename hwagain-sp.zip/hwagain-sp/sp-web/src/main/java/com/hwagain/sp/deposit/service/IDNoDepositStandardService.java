package com.hwagain.sp.deposit.service;

import com.hwagain.sp.deposit.dto.DNoDepositStandardDto;
import com.hwagain.sp.deposit.entity.DNoDepositStandard;

import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-08
 */
public interface IDNoDepositStandardService extends IService<DNoDepositStandard> {

//	public List<DNoDepositStandardDto> inputQueryProd() throws CustomException;
//
//	public List<DNoDepositStandardDto> updatDepoStandards(List<DNoDepositStandardDto> dtos)throws CustomException;
//
	public List<DNoDepositStandardDto> findAllHistory()throws CustomException;
//
//	public List<DNoDepositStandardDto> updatDepoStandard(DNoDepositStandardDto dto)throws CustomException;

	public List<DNoDepositStandardDto> findEffectList()throws CustomException;

	public List<DNoDepositStandardDto> findAllList()throws CustomException;
	
}
