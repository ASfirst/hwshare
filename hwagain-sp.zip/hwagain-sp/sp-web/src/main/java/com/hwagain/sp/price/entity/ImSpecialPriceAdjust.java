package com.hwagain.sp.price.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author guoym
 * @since 2018-10-17
 */
@TableName("im_special_price_adjust")
public class ImSpecialPriceAdjust implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * 主键id
     */
	@TableId("fd_id")
	private Long fdId;
    /**
     * 特规品价格id
     */
	@TableField("im_special_price_id")
	private Long imSpecialPriceId;
    /**
     * 对应常规价格 
     */
	@TableField("normal_price")
	private BigDecimal normalPrice;
    /**
     * 调整前加价
     */
	@TableField("source_add_price")
	private BigDecimal sourceAddPrice;
    /**
     * 调整后加价
     */
	@TableField("adjust_add_price")
	private BigDecimal adjustAddPrice;
    /**
     * 调整前执行价
     */
	@TableField("source_exec_price")
	private BigDecimal sourceExecPrice;
    /**
     * 调整后执行价
     */
	@TableField("adjust_exec_price")
	private BigDecimal adjustExecPrice;
    /**
     * 生效日期
     */
	@TableField("start_date")
	private Date startDate;
    /**
     * 失效日期
     */
	@TableField("end_date")
	private Date endDate;
    /**
     * 备注
     */
	private String remark;
    /**
     * 状态 (0:未生效
     1:已生效)
     */
	private Integer status;
    /**
     * 状态描述
     */
	@TableField("status_text")
	private String statusText;
    /**
     * 是否享受政策
     */
	@TableField("is_policy")
	private Integer isPolicy;
    /**
     * 是否删除
     */
	@TableField("is_delete")
	private Integer isDelete;
    /**
     * 创建人姓名
     */
	@TableField("creater_name")
	private String createrName;
    /**
     * 创建人
     */
	@TableField("creater_id")
	private String createrId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
    /**
     * 最后修改人
     */
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getImSpecialPriceId() {
		return imSpecialPriceId;
	}

	public void setImSpecialPriceId(Long imSpecialPriceId) {
		this.imSpecialPriceId = imSpecialPriceId;
	}

	public BigDecimal getNormalPrice() {
		return normalPrice;
	}

	public void setNormalPrice(BigDecimal normalPrice) {
		this.normalPrice = normalPrice;
	}

	public BigDecimal getSourceAddPrice() {
		return sourceAddPrice;
	}

	public void setSourceAddPrice(BigDecimal sourceAddPrice) {
		this.sourceAddPrice = sourceAddPrice;
	}

	public BigDecimal getAdjustAddPrice() {
		return adjustAddPrice;
	}

	public void setAdjustAddPrice(BigDecimal adjustAddPrice) {
		this.adjustAddPrice = adjustAddPrice;
	}

	public BigDecimal getSourceExecPrice() {
		return sourceExecPrice;
	}

	public void setSourceExecPrice(BigDecimal sourceExecPrice) {
		this.sourceExecPrice = sourceExecPrice;
	}

	public BigDecimal getAdjustExecPrice() {
		return adjustExecPrice;
	}

	public void setAdjustExecPrice(BigDecimal adjustExecPrice) {
		this.adjustExecPrice = adjustExecPrice;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getStatusText() {
		return statusText;
	}

	public void setStatusText(String statusText) {
		this.statusText = statusText;
	}

	public Integer getIsPolicy() {
		return isPolicy;
	}

	public void setIsPolicy(Integer isPolicy) {
		this.isPolicy = isPolicy;
	}

	public Integer getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}

	public String getCreaterName() {
		return createrName;
	}

	public void setCreaterName(String createrName) {
		this.createrName = createrName;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
