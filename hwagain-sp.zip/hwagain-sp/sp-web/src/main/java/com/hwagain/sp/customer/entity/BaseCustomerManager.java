package com.hwagain.sp.customer.entity;

import java.io.Serializable;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author xionglz
 * @since 2018-11-29
 */
@TableName("base_customer_manager")
public class BaseCustomerManager implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * fdId
     */
	@TableId("fd_id")
	private Long fdId;
    /**
     * 省
     */
	private String province;
    /**
     * 市
     */
	private String city;
    /**
     * 客户ID
     */
	@TableField("customer_id")
	private Long customerId;
    /**
     * 客户名称
     */
	@TableField("customer_name")
	private String customerName;
    /**
     * 客户类型
     */
	@TableField("customer_type")
	private String customerType;
    /**
     * 区域经理
     */
	@TableField("sale_manager")
	private String saleManager;
    /**
     * 运营专员
     */
	@TableField("running_man")
	private String runningMan;
    /**
     * 制单员
     */
	@TableField("bill_operator")
	private String billOperator;
    /**
     * 录入人
     */
	private String operator;
    /**
     * 生效时间
     */
	@TableField("start_time")
	private Date startTime;
    /**
     * 失效时间
     */
	@TableField("end_time")
	private Date endTime;
    /**
     * 备注
     */
	private String remark;
    /**
     * 创建人
     */
	@TableField("creater_id")
	private String createrId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
    /**
     * 最后修改人
     */
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerType() {
		return customerType;
	}

	public void setCustomerType(String customerType) {
		this.customerType = customerType;
	}

	public String getSaleManager() {
		return saleManager;
	}

	public void setSaleManager(String saleManager) {
		this.saleManager = saleManager;
	}

	public String getRunningMan() {
		return runningMan;
	}

	public void setRunningMan(String runningMan) {
		this.runningMan = runningMan;
	}

	public String getBillOperator() {
		return billOperator;
	}

	public void setBillOperator(String billOperator) {
		this.billOperator = billOperator;
	}

	public String getOperator() {
		return operator;
	}

	public void setOperator(String operator) {
		this.operator = operator;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
