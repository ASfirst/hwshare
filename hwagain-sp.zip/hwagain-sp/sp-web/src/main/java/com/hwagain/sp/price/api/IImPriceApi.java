package com.hwagain.sp.price.api;

/**
 * <p>
 * 常规、非常规产品统一销售价格表 服务类
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
public interface IImPriceApi {
	
}
