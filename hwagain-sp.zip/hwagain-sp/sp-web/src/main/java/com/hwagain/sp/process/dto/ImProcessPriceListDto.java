package com.hwagain.sp.process.dto;

import java.math.BigDecimal;
import java.util.Date;



/**
 * <p>
 * 
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public class ImProcessPriceListDto {

	/**
     * 品类名称
     */
	private String className;
    /**
     * 品类
     */
	private String classNo;
    /**
     * 定量
     */
	private BigDecimal ration;
    /**
     * 起趋率
     */
	private BigDecimal wrinkleRate;
    /**
     * 层数
     */
	private Integer layer;
    /**
     * 单幅幅宽
     */
	private String width;
    /**
     * 直径
     */
	private BigDecimal diameter;
    /**
     * 产品等级
     */
	private String grade;
    /**
     * 库龄
     */
	private String age;
    /**
     * 库存量
     */
	private BigDecimal weight;
	/**
     * 最小生产日期
     */
	private Date minProductDate;
	/**
     * 最大生产日期
     */
	private Date maxProductDate;

	public String getClassName() {
		return className;
	}

	public void setClassName(String className) {
		this.className = className;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public BigDecimal getRation() {
		return ration;
	}

	public void setRation(BigDecimal ration) {
		this.ration = ration;
	}

	public BigDecimal getWrinkleRate() {
		return wrinkleRate;
	}

	public void setWrinkleRate(BigDecimal wrinkleRate) {
		this.wrinkleRate = wrinkleRate;
	}

	public Integer getLayer() {
		return layer;
	}

	public void setLayer(Integer layer) {
		this.layer = layer;
	}

	public String getWidth() {
		return width;
	}

	public void setWidth(String width) {
		this.width = width;
	}

	public BigDecimal getDiameter() {
		return diameter;
	}

	public void setDiameter(BigDecimal diameter) {
		this.diameter = diameter;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getAge() {
		return age;
	}

	public void setAge(String age) {
		this.age = age;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public Date getMinProductDate() {
		return minProductDate;
	}

	public void setMinProductDate(Date minProductDate) {
		this.minProductDate = minProductDate;
	}

	public Date getMaxProductDate() {
		return maxProductDate;
	}

	public void setMaxProductDate(Date maxProductDate) {
		this.maxProductDate = maxProductDate;
	}

}
