package com.hwagain.sp.policy.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author linhl
 * @since 2018-11-02
 */
public class PoDiscountDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
	private Integer fdYear;
	private Integer fdMonth;
	@JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss", timezone = "GMT+8")
	private Date businessDate;
	private Long customerId;
	private String customerName;
	private Long poPolicyId;
	private String poPolicyName;
	private Long policyMethodId;
	private String policyMethodName;
	private BigDecimal price;
	private BigDecimal amount;
	private BigDecimal commitAmount;
	private BigDecimal notCommitAmount;
	@JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss", timezone = "GMT+8")
	private Date startDate;
	@JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss", timezone = "GMT+8")
	private Date endDate;
	private String sourceBillNo;
	private Integer sourceClassTypeId;
	private Long sourceIntegerId;
	private Long sourceDetailsId;
	private Boolean isRowClose;
	private Boolean isCancel;
	private String cancelBy;
	@JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss", timezone = "GMT+8")
	private Date cancelDate;
	private String cancelRemark;
	private String productKind;
	private String physicalNo;
	private String fromSystem;
	private String remark;
	private Integer status;
	private String createrId;
	@JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss", timezone = "GMT+8")
	private Date createTime;
	private String lastAlterId;
	@JsonFormat(pattern = "yyyy-MM-dd hh:mm:ss", timezone = "GMT+8")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Integer getFdYear() {
		return fdYear;
	}

	public void setFdYear(Integer fdYear) {
		this.fdYear = fdYear;
	}

	public Integer getFdMonth() {
		return fdMonth;
	}

	public void setFdMonth(Integer fdMonth) {
		this.fdMonth = fdMonth;
	}

	public Date getBusinessDate() {
		return businessDate;
	}

	public void setBusinessDate(Date businessDate) {
		this.businessDate = businessDate;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}
	
	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Long getPoPolicyId() {
		return poPolicyId;
	}

	public void setPoPolicyId(Long poPolicyId) {
		this.poPolicyId = poPolicyId;
	}
	
	public String getPoPolicyName() {
		return poPolicyName;
	}

	public void setPoPolicyName(String poPolicyName) {
		this.poPolicyName = poPolicyName;
	}

	public Long getPolicyMethodId() {
		return policyMethodId;
	}

	public void setPolicyMethodId(Long policyMethodId) {
		this.policyMethodId = policyMethodId;
	}
	
	public String getPolicyMethodName() {
		return policyMethodName;
	}

	public void setPolicyMethodName(String policyMethodName) {
		this.policyMethodName = policyMethodName;
	}

	public BigDecimal getPrice() {
		return price;
	}

	public void setPrice(BigDecimal price) {
		this.price = price;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getCommitAmount() {
		return commitAmount;
	}

	public void setCommitAmount(BigDecimal commitAmount) {
		this.commitAmount = commitAmount;
	}

	public BigDecimal getNotCommitAmount() {
		return notCommitAmount;
	}

	public void setNotCommitAmount(BigDecimal notCommitAmount) {
		this.notCommitAmount = notCommitAmount;
	}

	public Date getStartDate() {
		return startDate;
	}

	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public String getSourceBillNo() {
		return sourceBillNo;
	}

	public void setSourceBillNo(String sourceBillNo) {
		this.sourceBillNo = sourceBillNo;
	}

	public Integer getSourceClassTypeId() {
		return sourceClassTypeId;
	}

	public void setSourceClassTypeId(Integer sourceClassTypeId) {
		this.sourceClassTypeId = sourceClassTypeId;
	}

	public Long getSourceIntegerId() {
		return sourceIntegerId;
	}

	public void setSourceIntegerId(Long sourceIntegerId) {
		this.sourceIntegerId = sourceIntegerId;
	}

	public Long getSourceDetailsId() {
		return sourceDetailsId;
	}

	public void setSourceDetailsId(Long sourceDetailsId) {
		this.sourceDetailsId = sourceDetailsId;
	}

	public Boolean isIsRowClose() {
		return isRowClose;
	}

	public void setIsRowClose(Boolean isRowClose) {
		this.isRowClose = isRowClose;
	}

	public Boolean isIsCancel() {
		return isCancel;
	}

	public void setIsCancel(Boolean isCancel) {
		this.isCancel = isCancel;
	}

	public String getCancelBy() {
		return cancelBy;
	}

	public void setCancelBy(String cancelBy) {
		this.cancelBy = cancelBy;
	}

	public Date getCancelDate() {
		return cancelDate;
	}

	public void setCancelDate(Date cancelDate) {
		this.cancelDate = cancelDate;
	}

	public String getCancelRemark() {
		return cancelRemark;
	}

	public void setCancelRemark(String cancelRemark) {
		this.cancelRemark = cancelRemark;
	}

	public String getProductKind() {
		return productKind;
	}

	public void setProductKind(String productKind) {
		this.productKind = productKind;
	}

	public String getPhysicalNo() {
		return physicalNo;
	}

	public void setPhysicalNo(String physicalNo) {
		this.physicalNo = physicalNo;
	}

	public String getFromSystem() {
		return fromSystem;
	}

	public void setFromSystem(String fromSystem) {
		this.fromSystem = fromSystem;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
