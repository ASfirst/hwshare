package com.hwagain.sp.base.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author guoym
 * @since 2018-10-11
 */
public interface IOaAduitDetailApi {
	
}
