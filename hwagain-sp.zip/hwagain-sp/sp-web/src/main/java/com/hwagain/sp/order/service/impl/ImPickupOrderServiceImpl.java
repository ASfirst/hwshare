package com.hwagain.sp.order.service.impl;

import com.hwagain.sp.order.entity.ImPickupOrder;
import com.hwagain.sp.order.dto.ImPickupOrderDto;
import com.hwagain.sp.order.mapper.ImPickupOrderMapper;
import com.hwagain.sp.order.service.IImPickupOrderService;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
@Service("imPickupOrderService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImPickupOrderServiceImpl extends ServiceImpl<ImPickupOrderMapper, ImPickupOrder> implements IImPickupOrderService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImPickupOrder.class, ImPickupOrderDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImPickupOrderDto.class, ImPickupOrder.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
}
