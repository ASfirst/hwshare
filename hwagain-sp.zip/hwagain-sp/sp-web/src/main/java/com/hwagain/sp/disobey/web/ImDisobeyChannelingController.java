package com.hwagain.sp.disobey.web;

import java.util.Date;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponse;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.security.common.util.UserUtils;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.disobey.dto.ImDisobeyChannelingDto;
import com.hwagain.sp.disobey.service.IImDisobeyChannelingService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
@RestController
@RequestMapping(value="/disobey/imDisobeyChanneling",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "违约扣款-窜货", description = "违约扣款-窜货")
public class ImDisobeyChannelingController extends BaseController{
	
	@Autowired
	IImDisobeyChannelingService imDisobeyChannelingService;
	
	@RequestMapping("/getDriverByOrder")
	@ApiOperation(value="获取物流信息",notes="获取物流信息",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="orderNo",value="订单编号",paramType = "query", required = true, dataType = "String")
	})
	public Response getDriverByOrder(String orderNo){
		return SuccessResponseData.newInstance(imDisobeyChannelingService.getDriverByOrder(orderNo));
	}
	
	@RequestMapping("/findChannelingApplyList")
	@ApiOperation(value="生活原纸客户窜货扣款申请表",notes="生活原纸客户窜货扣款申请表(未提交OA数据)",httpMethod="GET")
	public Response findChannelingApplyList(){
		return SuccessResponseData.newInstance(imDisobeyChannelingService.findChannelingApplyList());
	}
	
//	@RequestMapping("/findAll")
//	@ApiOperation(value="查询列表",notes="查询列表",httpMethod="GET")
//	public Response findAll(){
//		return null;
//	}
	/**
	 * 新增数据
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/save",method={RequestMethod.POST})
	@ApiOperation(value = "新增数据", notes = "新增数据",httpMethod="POST")
	public Response save(@RequestBody ImDisobeyChannelingDto dto){
		String userId=UserUtils.getUserId();
		dto.setCreaterId(userId);
		dto.setCreateTime(new Date());
		return SuccessResponseData.newInstance(imDisobeyChannelingService.save(dto));
	}
	
	/**
	 * 修改数据
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/update",method={RequestMethod.POST})
	@ApiOperation(value = "修改数据", notes = "修改数据",httpMethod="POST")
	public Response update(@RequestBody ImDisobeyChannelingDto dto){
		String userId=UserUtils.getUserId();
		dto.setLastAlterId(userId);
		dto.setLastAlterTime(new Date());
		return SuccessResponseData.newInstance(imDisobeyChannelingService.update(dto));
	}
	
	/**
	 * 删除数据，可批量
	 * 
	 * @param ids  格式：1;2;3;4....
	 * @return
	 */
	@RequestMapping(value="/delete",method={RequestMethod.GET})
	@ApiOperation(value = "删除数据", notes = "删除数据",httpMethod="GET")
		@ApiImplicitParams({
		@ApiImplicitParam(name = "ids", value = "数据集,格式：1;2;3;4....", paramType = "query", required = false, dataType = "String")
	})
	public Response delete(String ids){
		Boolean isOk = imDisobeyChannelingService.deleteByIds(ids);
		return SuccessResponse.newInstance(isOk?"删除成功！":"删除失败！");
	}
	
	
	@RequestMapping(value = "/findChannelingListByOACode", method = { RequestMethod.GET })
	@ApiOperation(value = "根据OA单号查窜货明细", notes = "根据OA单号查窜货明细", httpMethod = "GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "oaCode", value = "oaCode", paramType = "query", required = true, dataType = "String") })
	public Response findChannelingListByOACode(String oaCode) {
		return SuccessResponseData.newInstance(imDisobeyChannelingService.findByOACode(oaCode));
	}
	
	/**
	 * 提交OA
	 * 
	 */
	
	@RequestMapping(value = "/disobeySentToOa", method = { RequestMethod.POST })
	@ApiOperation(value = "提交OA【窜货扣款】", notes = "提交OA【窜货扣款】", httpMethod = "POST")
	public Response disobeySentToOa() {
		return SuccessResponseData.newInstance(imDisobeyChannelingService.disobeySentToOa());
	}
	
	/**
	 * 生活原纸客户窜货扣款明细查询
	 * 
	 */
	
	@RequestMapping("/findDisobeyChannelingList")
	@ApiOperation(value="客户窜货明细",notes="客户窜货明细",httpMethod="GET")
	public Response findDisobeyChannelingList(){
		return SuccessResponseData.newInstance(imDisobeyChannelingService.findDisobeyChannelingList());
	}
}
