package com.hwagain.sp.price.dto;

import java.io.Serializable;
import java.math.BigDecimal;

public class ImTransPriceDto implements Serializable {
	
	private static final long serialVersionUID = 1L;
	private BigDecimal TransPriceOffSeason;
	private BigDecimal OffTransPriceByDirectPay;
	private BigDecimal TransPriceBusySeason;
	private BigDecimal BusyTransPriceByDirectPay;
	
	public BigDecimal getTransPriceOffSeason() {
		return TransPriceOffSeason;
	}
	public void setTransPriceOffSeason(BigDecimal transPriceOffSeason) {
		TransPriceOffSeason = transPriceOffSeason;
	}
	public BigDecimal getOffTransPriceByDirectPay() {
		return OffTransPriceByDirectPay;
	}
	public void setOffTransPriceByDirectPay(BigDecimal offTransPriceByDirectPay) {
		OffTransPriceByDirectPay = offTransPriceByDirectPay;
	}
	public BigDecimal getTransPriceBusySeason() {
		return TransPriceBusySeason;
	}
	public void setTransPriceBusySeason(BigDecimal transPriceBusySeason) {
		TransPriceBusySeason = transPriceBusySeason;
	}
	public BigDecimal getBusyTransPriceByDirectPay() {
		return BusyTransPriceByDirectPay;
	}
	public void setBusyTransPriceByDirectPay(BigDecimal busyTransPriceByDirectPay) {
		BusyTransPriceByDirectPay = busyTransPriceByDirectPay;
	}
	
	
	

}
