package com.hwagain.sp.deposit.mapper;

import com.hwagain.sp.deposit.entity.DDepositItem;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  * 客户当月定金对账明细表 Mapper 接口
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
public interface DDepositItemMapper extends BaseMapper<DDepositItem> {

}