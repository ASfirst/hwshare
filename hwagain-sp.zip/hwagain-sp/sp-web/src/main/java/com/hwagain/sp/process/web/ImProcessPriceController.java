package com.hwagain.sp.process.web;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponse;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.process.dto.ImProcessBatchProductDto;
import com.hwagain.sp.process.dto.ImProcessPriceDto;
import com.hwagain.sp.process.dto.ImProcessPriceRptDto;
import com.hwagain.sp.process.service.IImProcessBatchProductService;
import com.hwagain.sp.process.service.IImProcessPriceService;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
@RestController
@RequestMapping(value="/process/imProcessPrice",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "【进口纸机】处理品价格录入", description = "【进口纸机】处理品价格录入")
public class ImProcessPriceController extends BaseController{
	
	@Autowired
	IImProcessPriceService imProcessPriceService;
	@Autowired
	IImProcessBatchProductService imProcessBatchProductService;
	
	/**
	 * 当前录入人：第一人/第二人
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/getUserOrder")
	@ApiOperation(value = "当前录入人", notes = "当前录入人",httpMethod="GET")
	public Response getUserOrder(){
		return SuccessResponseData.newInstance(imProcessPriceService.getUserOrder());
	}
	
	/**
	 * 根据主表Id获取处理品价格表
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/findByProcessId")
	@ApiOperation(value = "根据主表Id获取处理品价格表", notes = "根据主表Id获取处理品价格表",httpMethod="GET")
	@ApiImplicitParams(
		{
			@ApiImplicitParam(name = "processId", value = "处理品主表ID", paramType = "query", required = true, dataType = "String")
		}
	)
	public Response findByProcessId(String processId){
		//return SuccessResponseData.newInstance(imProcessPriceService.findPriceByFdId(processId));
		return null;
	}
	
	
	
	/**
	 * 根据第一人、第二人获取不同处理品价格数据
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/queryProcessPriceList")
	@ApiOperation(value = "当前录入人处理品价格录入表", notes = "根据当前录入人(第一人/第二人)获取不同的处理品价格录入数据",httpMethod="GET")
	@ApiImplicitParams(
		{
			@ApiImplicitParam(name = "userOrder", value = "当前录入人(第一人,第二人)", paramType = "query", required = true, dataType = "String")
		}
	)
	public Response queryProcessPriceList(String userOrder){
		List<ImProcessPriceRptDto> list=new ArrayList<ImProcessPriceRptDto>();
		if("第二人".equals(userOrder))
			list=imProcessPriceService.queryPriceSecondList();
		else
			list=imProcessPriceService.queryPriceFirstList();
		return SuccessResponseData.newInstance(list);
	}
	
	/**
	 * 根据处理品价格表Id获取处理品明细
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/findByPriceId")
	@ApiOperation(value = "根据处理品价格表Id获取处理品明细", notes = "根据处理品价格表Id获取处理品明细",httpMethod="GET")
	@ApiImplicitParams(
		{
			@ApiImplicitParam(name = "priceId", value = "处理品价格表ID", paramType = "query", required = true, dataType = "String")
		}
	)
	public Response findByPriceId(String priceId){
		return SuccessResponseData.newInstance(imProcessBatchProductService.findByPriceId(priceId));
	}
	/**
	 * 删除处理品一条处理品价格，同时删除处理品明细
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/delete",method={RequestMethod.POST})
	@ApiOperation(value = "删除处理品一条处理品价格，同时删除处理品明细", notes = "删除处理品一条处理品价格，同时删除处理品明细",httpMethod="POST")
	@ApiImplicitParams(
			{
				@ApiImplicitParam(name = "fdId", value = "处理品价格表ID", paramType = "query", required = true, dataType = "String")
			}
		)
	public Response delete(String fdId){
		Boolean isOk = imProcessPriceService.delete(fdId);
		return SuccessResponse.newInstance(isOk?"删除成功！":"删除失败！");
	}
	/**
	 * 删除处理品一条处理品价格，同时删除处理品明细
	 * 
	 * @param dto
	 * @return
	 */
	@RequestMapping(value="/audit",method={RequestMethod.POST})
	@ApiOperation(value = "审核处理品明细", notes = "审核处理品明细",httpMethod="POST")
	public Response audit(@RequestBody List<ImProcessBatchProductDto> productList){
		Boolean isOk = imProcessBatchProductService.audit(productList);
		return SuccessResponse.newInstance(isOk?"审核成功！":"审核失败！");
	}
	
	@RequestMapping(value = "/adjustUpdateOne", method = { RequestMethod.POST })
	@ApiOperation(value = "更新一条【处理品价格】", notes = "更新一条【处理品价格】", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "fdId", value = "修改记录id", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "userOrder", value = "当前录入人(第一人,第二人)", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "normalPrice", value = "现行价格", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "processPrice", value = "处理价格", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "isPolicy", value = "是否享受政策(1:是;0:否)", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "remark", value = "备注", paramType = "query", required = false, dataType = "String"), })
	public Response adjustUpdateOne(String fdId, String userOrder, BigDecimal normalPrice, BigDecimal processPrice,
			Integer isPolicy, String remark) {
		return SuccessResponseData.newInstance(
				imProcessPriceService.updateProcessPriceOne(fdId, userOrder, isPolicy, normalPrice, processPrice, remark));
	}

	@RequestMapping(value = "/adjustUpdateSome", method = { RequestMethod.POST })
	@ApiOperation(value = "更新多条【处理品价格】", notes = "更新多条【处理品价格】<br/>需传字段：<br/>fdId:修改记录id <br/> "
			+ " normalPrice：现行价格 <br/> processPrice:处理价格<br/> "
			+ " isPolicy:是否享受政策(1:是;0:否)<br/>    remark:备注 ", httpMethod = "POST")
	@ApiImplicitParams({
		@ApiImplicitParam(name = "userOrder", value = "当前录入人(第一人,第二人)", paramType = "query", required = true, dataType = "String") 
		})
	public Response adjustUpdateSome(@RequestBody List<ImProcessPriceDto> list,String userOrder) {
		return SuccessResponseData.newInstance(imProcessPriceService.updateProcessPriceSome(list, userOrder));
	}
}
