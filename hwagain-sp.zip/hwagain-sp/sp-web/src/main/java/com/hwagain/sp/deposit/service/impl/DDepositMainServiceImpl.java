package com.hwagain.sp.deposit.service.impl;

import com.hwagain.sp.deposit.entity.DDepositMain;
import com.hwagain.sp.deposit.dto.DDepositMainDto;
import com.hwagain.sp.deposit.mapper.DDepositMainMapper;
import com.hwagain.sp.deposit.service.IDDepositMainService;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 * 客户当月定金对账主表 服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
@Service("dDepositMainService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class DDepositMainServiceImpl extends ServiceImpl<DDepositMainMapper, DDepositMain> implements IDDepositMainService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(DDepositMain.class, DDepositMainDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(DDepositMainDto.class, DDepositMain.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	
}
