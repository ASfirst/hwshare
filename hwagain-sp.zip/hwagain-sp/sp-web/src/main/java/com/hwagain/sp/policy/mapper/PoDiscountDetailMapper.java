package com.hwagain.sp.policy.mapper;

import com.hwagain.sp.policy.entity.PoDiscountDetail;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author linhl
 * @since 2018-11-02
 */
public interface PoDiscountDetailMapper extends BaseMapper<PoDiscountDetail> {

}