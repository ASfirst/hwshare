package com.hwagain.sp.customer.entity;

import java.io.Serializable;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author xionglz
 * @since 2018-11-29
 */
@TableName("base_machine")
public class BaseCapacity implements Serializable {

    private static final long serialVersionUID = 1L;

    /**
     * fdId
     */
	@TableId("fd_id")
	private Long fdId;
    /**
     * 机型
     */
	@TableField("machine_type")
	private String machineType;
    /**
     * 机台
     */
	@TableField("machine_no")
	private String machineNo;
    /**
     * 单台产能（吨/月）
     */
	@TableField("single_capacity")
	private Integer singleCapacity;
    /**
     * 总产能（吨/月）
     */
	@TableField("total_capacity")
	private Integer totalCapacity;
    /**
     * 生效时间
     */
	@TableField("start_time")
	private Date startTime;
    /**
     * 失效时间
     */
	@TableField("end_time")
	private Date endTime;

    /**
     * 备注
     */
	private String remark;

	
    /**
     * 创建人
     */
	@TableField("creater_id")
	private String createrId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
    /**
     * 最后修改人
     */
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getMachineType() {
		return machineType;
	}

	public void setMachineType(String machineType) {
		this.machineType = machineType;
	}

	public String getMachineNo() {
		return machineNo;
	}

	public void setMachineNo(String machineNo) {
		this.machineNo = machineNo;
	}

	public Integer getSingleCapacity() {
		return singleCapacity;
	}

	public void setSingleCapacity(Integer singleCapacity) {
		this.singleCapacity = singleCapacity;
	}

	public Integer getTotalCapacity() {
		return totalCapacity;
	}

	public void setTotalCapacity(Integer totalCapacity) {
		this.totalCapacity = totalCapacity;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}



	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
