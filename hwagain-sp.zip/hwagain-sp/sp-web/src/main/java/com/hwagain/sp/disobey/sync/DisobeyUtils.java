package com.hwagain.sp.disobey.sync;

public class DisobeyUtils {
	public static String const_OaFlowName_ImDisobeyChanneling = "生活原纸客户窜货扣款申请表";
	public static String const_OaFlowName_ImDisobeyOverPeriod = "定制品超期未提货扣款申请表";
}
