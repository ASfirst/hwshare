package com.hwagain.sp.customer.web;
import org.springframework.web.bind.annotation.RequestMethod;

import java.math.BigDecimal;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.hwagain.framework.core.dto.PageVO;
import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponse;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.core.util.SpringBeanUtil;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.customer.dto.CustomerDto;
import com.hwagain.sp.customer.service.ICustomerService;
import com.hwagain.sp.customer.sync.SyncCustomer;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 *  前端控制器
 * </p>
 *
 * @author hanj
 * @since 2018-10-11
 */
@RestController
@RequestMapping(value="/customer/customer",method={RequestMethod.GET,RequestMethod.POST})
@Api(value = "【进口纸机】客户资料", description = "【进口纸机】客户资料")
public class CustomerController extends BaseController{
	
	@Autowired
	ICustomerService customerService;
	@Autowired
	SyncCustomer syncCustomer;
	
	@RequestMapping("/updateCustomer")
	@ApiOperation(value = "更新完善客户资料", notes = "更新完善客户资料", httpMethod = "GET")
	public Response customerSync() {
		SyncCustomer cust=SpringBeanUtil.getBean(SyncCustomer.class);
		cust.customerSync();
		return SuccessResponseData.newInstance("更新完成");
	}
//	@RequestMapping("/findByCustName")
//	@ApiOperation(value="findByCustName",notes="findByCustName",httpMethod="GET")
//	@ApiImplicitParams({
//		@ApiImplicitParam(name="custName",value="custName",paramType="query",required=true,dataType="String")
//	})
//	public Response findByCustName(String custName){
//		return SuccessResponseData.newInstance(customerService.findByCustName(custName));
//	}
	
	@RequestMapping("/findCooperatingCustomer")
	@ApiOperation(value = "查询正在合作的Customer", notes = "查询正在合作的Customer", httpMethod = "GET")
	public Response findCooperatingCustomer() {
		return SuccessResponseData.newInstance(customerService.findCooperatingCustomer());
	}
	
	@RequestMapping("/findByPage")
	@ApiOperation(value="按条件查询",notes="按条件查询",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="custName",value="客户名称",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="province",value="省",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="city",value="市",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="county",value="县",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="custTypeName",value="客户类型",paramType = "query", required = false, dataType = "String")
	})
	public Response fingByPage(String custName,String province,String city,String county,String custTypeName){
		return SuccessResponseData.newInstance(customerService.findByPage(custName, province, city, county, custTypeName));
	}
	/**
	 * 查询客户信息--分页
	 * @param fdId
	 * @return
	 */
	@RequestMapping("/findCustomerByPage")
	@ApiOperation(value="按条件查询",notes="按条件查询",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="custName",value="客户名称",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="province",value="省",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="city",value="市",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="county",value="县",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="custTypeName",value="客户类型",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="page",value="当前页",paramType = "query", required = false, dataType = "int"),
		@ApiImplicitParam(name="pageSize",value="每页显示数",paramType = "query", required = false, dataType = "int")
	})
	public Response fingByPage(String custName,String province,String city,String county,String custTypeName, Integer page, Integer pageSize){
		PageVO pageVO = new PageVO();
		pageVO.setPage(page);
		pageVO.setPageSize(pageSize);
		
		CustomerDto dto = new CustomerDto();
		dto.setCustName(custName);
		dto.setProvince(province);
		dto.setCity(city);
		dto.setCounty(county);
		dto.setCounty(county);
		dto.setCustTypeName(custTypeName);
		
		
		return SuccessResponseData.newInstance(customerService.findByPage(dto, pageVO));
	}
	@RequestMapping("/findOne")
	@ApiOperation(value="findOne",notes="findOne",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="fdId",value="fdId",paramType="query",required=true,dataType="Long")
	})
	public Response findOne(Long fdId){
		return SuccessResponseData.newInstance(customerService.findOne(fdId));
	}
	
	 /*linhl@2018-10-18
	 * 生成K3资金转移单（冻结资金）
	 * 调用参数说明
	 * SourceID=源单ID BillNo=订单编号   sDate=日期  sCustName=提货客户名称  DepositAmountTotal=订金金额  sCooperationCustomerName=合作客户名称
	 */
	@RequestMapping("/createDepositmove")
	@ApiOperation(value="生成K3资金转移单（冻结资金）",notes="生成K3资金转移单（冻结资金）",httpMethod="POST")
	@ApiImplicitParams({
		@ApiImplicitParam(name="SourceID",value="源单ID",paramType = "query", required = false, dataType = "Integer"),
		@ApiImplicitParam(name="BillNo",value="订单编号",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="orderDate",value="日期",paramType = "query", required = false, dataType = "Date"),
		@ApiImplicitParam(name="sCustName",value="提货客户名称 ",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="DepositAmountTotal",value="订金金额",paramType = "query", required = false, dataType = "BigDecimal"),
		@ApiImplicitParam(name="sCooperationCustomerName",value="合作客户名称",paramType = "query", required = false, dataType = "String")
	})
	public Response createDepositmove(int SourceID, String BillNo, Date orderDate, String sCustName,
			BigDecimal DepositAmountTotal, String sCooperationCustomerName){
		Boolean isOk =customerService.createDepositmove(SourceID, BillNo,orderDate,sCustName,DepositAmountTotal,sCooperationCustomerName);
		return SuccessResponse.newInstance(isOk?"生成成功！":"生成失败！");
	}

	
	/*linhl@2018-10-18
	 * 获取客户余额
	 */
	@RequestMapping("/getGoodsBanlanceByCust")
	@ApiOperation(value="获取K3客户货款余额",notes="获取K3客户货款余额",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="custName",value="客户名称",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="year",value="年",paramType = "query", required = true, dataType = "Integer"),
		@ApiImplicitParam(name="month",value="月",paramType = "query", required = true, dataType = "Integer")
	})
	public Response getGoodsBanlanceByCust(String custName, Integer year, Integer month){
		return SuccessResponseData.newInstance(customerService.getGoodsBanlanceByCust(custName, year, month));
	}
	
	@RequestMapping("/getDepositBanlanceByCust")
	@ApiOperation(value="获取K3客户订金余额",notes="获取K3客户订金余额",httpMethod="GET")
	@ApiImplicitParams({
		@ApiImplicitParam(name="custName",value="客户名称",paramType = "query", required = false, dataType = "String"),
		@ApiImplicitParam(name="year",value="年",paramType = "query", required = true, dataType = "Integer"),
		@ApiImplicitParam(name="month",value="月",paramType = "query", required = true, dataType = "Integer")
	})
	public Response getDepositBanlanceByCust(String custName, Integer year, Integer month){
		return SuccessResponseData.newInstance(customerService.getDepositBanlanceByCust(custName, year, month));
	}
}
