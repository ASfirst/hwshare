package com.hwagain.sp.policy.mapper;

import com.hwagain.sp.policy.dto.PoDiscountDto;
import com.hwagain.sp.policy.entity.PoDiscount;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author linhl
 * @since 2018-11-02
 */
public interface PoDiscountMapper extends BaseMapper<PoDiscount> {
	public List<PoDiscountDto> queryPoDiscountList(@Param("customerId") Long customerId,
			@Param("startDate") String startDate, @Param("endDate") String endDate);
}