package com.hwagain.sp.deposit.service;

import com.hwagain.sp.deposit.dto.DDepositItemDto;
import com.hwagain.sp.deposit.entity.DDepositItem;

import java.util.Date;
import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 * 客户当月定金对账明细表 服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
public interface IDDepositItemService extends IService<DDepositItem> {

	public List<DDepositItemDto> findCustDepositItem(String depositMainId, Date happenDate)throws CustomException;
	
}
