package com.hwagain.sp.order.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import com.hwagain.framework.mybatisplus.annotations.TableField;
import com.hwagain.framework.mybatisplus.annotations.TableId;
import com.hwagain.framework.mybatisplus.annotations.TableName;

/**
 * <p>
 * 
 * </p>
 *
 * @author huangdh
 * @since 2018-11-16
 */
@TableName("im_pickup_order")
public class ImPickupOrder implements Serializable {

    private static final long serialVersionUID = 1L;

	@TableId("fd_id")
	private Long fdId;
    /**
     * 提货单编号，按各纸种约定规则生成
     */
	@TableField("pickup_no")
	private String pickupNo;
    /**
     * 客户ID
     */
	@TableField("customer_id")
	private Long customerId;
    /**
     * 客户名称
     */
	@TableField("customer_name")
	private String customerName;
    /**
     * 制单日期
     */
	@TableField("order_date")
	private Date orderDate;
    /**
     * 发货公司
     */
	@TableField("delivery_company")
	private String deliveryCompany;
    /**
     * 收货单位
     */
	@TableField("receiver_company")
	private String receiverCompany;
    /**
     * 收货地址
     */
	@TableField("receiver_address")
	private String receiverAddress;
    /**
     * 运输方式
     */
	private String transport;
    /**
     * 车型
     */
	@TableField("car_mode")
	private String carMode;
    /**
     * 预计提货日期
     */
	@TableField("pickup_date")
	private Date pickupDate;
    /**
     * 收货人
     */
	private String receiver;
    /**
     * 收货人电话
     */
	@TableField("receiver_tel")
	private String receiverTel;
    /**
     * 可提货重量
     */
	@TableField("avaliable_weight")
	private BigDecimal avaliableWeight;
    /**
     * 本次提货重量
     */
	private BigDecimal weight;
    /**
     * 折前总金额
     */
	private BigDecimal amount;
    /**
     * 折扣金额
     */
	private BigDecimal discount;
    /**
     * 折后金额
     */
	@TableField("discount_amount")
	private BigDecimal discountAmount;
    /**
     * 汽运总金额
     */
	@TableField("total_car_fee")
	private BigDecimal totalCarFee;
    /**
     * 应缴金额（货款及运费合计）
     */
	@TableField("payment_amount")
	private BigDecimal paymentAmount;
    /**
     * 1删除，0未删除
     */
	@TableField("is_delete")
	private Integer isDelete;
    /**
     * 备注
     */
	private String remark;
    /**
     * 状态
     */
	private Integer status;
    /**
     * 是否冲正单：0否，1是
     */
	@TableField("is_reversal")
	private Integer isReversal;
    /**
     * 冲正单对应的提货单ID。不是冲正单时，此ID为空
     */
	@TableField("reversal_fd_id")
	private Long reversalFdId;
	@TableField("creator_id")
	private String creatorId;
    /**
     * 创建时间
     */
	@TableField("create_time")
	private Date createTime;
	@TableField("last_alter_id")
	private String lastAlterId;
    /**
     * 更新时间
     */
	@TableField("last_alter_time")
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getPickupNo() {
		return pickupNo;
	}

	public void setPickupNo(String pickupNo) {
		this.pickupNo = pickupNo;
	}

	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getDeliveryCompany() {
		return deliveryCompany;
	}

	public void setDeliveryCompany(String deliveryCompany) {
		this.deliveryCompany = deliveryCompany;
	}

	public String getReceiverCompany() {
		return receiverCompany;
	}

	public void setReceiverCompany(String receiverCompany) {
		this.receiverCompany = receiverCompany;
	}

	public String getReceiverAddress() {
		return receiverAddress;
	}

	public void setReceiverAddress(String receiverAddress) {
		this.receiverAddress = receiverAddress;
	}

	public String getTransport() {
		return transport;
	}

	public void setTransport(String transport) {
		this.transport = transport;
	}

	public String getCarMode() {
		return carMode;
	}

	public void setCarMode(String carMode) {
		this.carMode = carMode;
	}

	public Date getPickupDate() {
		return pickupDate;
	}

	public void setPickupDate(Date pickupDate) {
		this.pickupDate = pickupDate;
	}

	public String getReceiver() {
		return receiver;
	}

	public void setReceiver(String receiver) {
		this.receiver = receiver;
	}

	public String getReceiverTel() {
		return receiverTel;
	}

	public void setReceiverTel(String receiverTel) {
		this.receiverTel = receiverTel;
	}

	public BigDecimal getAvaliableWeight() {
		return avaliableWeight;
	}

	public void setAvaliableWeight(BigDecimal avaliableWeight) {
		this.avaliableWeight = avaliableWeight;
	}

	public BigDecimal getWeight() {
		return weight;
	}

	public void setWeight(BigDecimal weight) {
		this.weight = weight;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public BigDecimal getDiscount() {
		return discount;
	}

	public void setDiscount(BigDecimal discount) {
		this.discount = discount;
	}

	public BigDecimal getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(BigDecimal discountAmount) {
		this.discountAmount = discountAmount;
	}

	public BigDecimal getTotalCarFee() {
		return totalCarFee;
	}

	public void setTotalCarFee(BigDecimal totalCarFee) {
		this.totalCarFee = totalCarFee;
	}

	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}

	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}

	public Integer getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(Integer isDelete) {
		this.isDelete = isDelete;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getIsReversal() {
		return isReversal;
	}

	public void setIsReversal(Integer isReversal) {
		this.isReversal = isReversal;
	}

	public Long getReversalFdId() {
		return reversalFdId;
	}

	public void setReversalFdId(Long reversalFdId) {
		this.reversalFdId = reversalFdId;
	}

	public String getCreatorId() {
		return creatorId;
	}

	public void setCreatorId(String creatorId) {
		this.creatorId = creatorId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
