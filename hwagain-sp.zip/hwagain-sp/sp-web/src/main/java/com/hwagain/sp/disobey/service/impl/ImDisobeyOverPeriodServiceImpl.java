package com.hwagain.sp.disobey.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.hwagain.sp.base.dto.OaAduitDetailDto;
import com.hwagain.sp.base.entity.DictData;
import com.hwagain.sp.base.entity.OaAduit;
import com.hwagain.sp.base.entity.OaAduitDetail;
import com.hwagain.sp.base.service.IOaAduitDetailService;
import com.hwagain.sp.base.service.IOaAduitService;
import com.hwagain.sp.disobey.entity.ImDisobeyOverPeriod;
import com.hwagain.sp.disobey.dto.ImDisobeyOverPeriodDto;
import com.hwagain.sp.disobey.dto.ImDisobeyOverPeriodListDto;
import com.hwagain.sp.disobey.dto.ImDisobeyOverPeriodRptDto;
import com.hwagain.sp.disobey.mapper.ImDisobeyOverPeriodMapper;
import com.hwagain.sp.disobey.mapper.ImDisobeyOverPeriodRptMapper;
import com.hwagain.sp.disobey.service.IImDisobeyChannelingService;
import com.hwagain.sp.disobey.service.IImDisobeyOverPeriodService;
import com.hwagain.sp.disobey.sync.DisobeyUtils;
import com.hwagain.sp.process.service.ISysDataService;
import com.hwagain.sp.process.sync.ProcessDateUtil;
import com.hwagain.sp.util.PublicUtils;
import com.hwagain.sp.util.SqlDbUtils;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huanglf
 * @since 2018-11-22
 */
@Service("imDisobeyOverPeriodService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImDisobeyOverPeriodServiceImpl extends ServiceImpl<ImDisobeyOverPeriodMapper, ImDisobeyOverPeriod> implements IImDisobeyOverPeriodService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImDisobeyOverPeriod.class, ImDisobeyOverPeriodDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImDisobeyOverPeriodDto.class, ImDisobeyOverPeriod.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	
	@Autowired
	ImDisobeyOverPeriodRptMapper imDisobeyOverPeriodRptMapper;
	@Autowired
	ISysDataService sysDataService;
	@Autowired
	IImDisobeyChannelingService imDisobeyChannelingService;
	
	@Autowired
	IOaAduitService oaAduitService;
	@Autowired
	IOaAduitDetailService oaAduitDetailService;

	@Override
	public List<ImDisobeyOverPeriodListDto> queryOverPeriodCustomer()
			throws CustomException {
		List<ImDisobeyOverPeriodListDto> list=imDisobeyOverPeriodRptMapper.queryOverPeriodCustomer();
		return list;
	}

	@Override
	public List<ImDisobeyOverPeriodListDto> queryOverPeriodFromOrder(
			String customerId) throws CustomException {
		List<ImDisobeyOverPeriodListDto> list=imDisobeyOverPeriodRptMapper.queryOverPeriodFromOrder(customerId);
		String nowStrDate=ProcessDateUtil.getNowDate();
		int seqNum=1;
		for(ImDisobeyOverPeriodListDto dto:list)
		{
			String strLastPickupDate=ProcessDateUtil.dateToStr(dto.getLastPickupDate(),"yyyy-MM-dd"); //yyyy-MM-dd
			int overDays=(int)ProcessDateUtil.getDaySub(strLastPickupDate, nowStrDate);
			BigDecimal orderAmount=dto.getOrderAmount();
			BigDecimal bigOverDays=new BigDecimal(overDays);
			BigDecimal deductAmount=orderAmount.multiply(bigOverDays);
			dto.setGoinWeight(sysDataService.getInQtyByOrderNo(dto.getOrderNo()));
			dto.setPickupWeight(sysDataService.getOutQtyByOrderNo(dto.getOrderNo()));
			if(dto.getKindNo().equals("b") || dto.getKindNo().equals("c"))
			{
				
				dto.setRemainWeight(sysDataService.getStockQtyOrderNo(dto.getOrderNo()));
			}
			dto.setOverDays(overDays);
			
			dto.setDeductAmount(deductAmount);
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list;
	}

	@Override
	public ImDisobeyOverPeriodDto saveOneOverPeriod(ImDisobeyOverPeriodDto dto)
			throws CustomException {
		BigDecimal a=BigDecimal.valueOf(1.0);
		if((dto.getRemainAmount()!=null && dto.getRemainAmount().compareTo(a)>0) && dto.getIsDedect())
		{
			Assert.throwException("实扣定金额与是否免责两者保留一种！");
		}
		if(dto.getRemainAmount()!=null && dto.getDeductAmount()!=null)
		{
			if(dto.getDeductAmount().compareTo(dto.getRemainAmount())!=0)
			{
				if(dto.getRemarks()==null || "".equals(dto.getRemarks()))
				{
					Assert.throwException("实扣金额与应扣金额不一致，请录入说明！");
				}
			}
		}
		if(dto.getRemainAmount()==null && dto.getIsDedect())
		{
			Assert.throwException("已确定免责处理，请录入免责说明！");
		}
		ImDisobeyOverPeriod entity=dtoToEntityMapper.map(dto, ImDisobeyOverPeriod.class);
		String userId=UserUtils.getUserId();
		entity.setFdId(IdWorker.getId());
		entity.setStatus(10);
		entity.setCreaterId(userId);
		entity.setCreateTime(new Date());
		super.insert(entity);
		return entityToDtoMapper.map(entity, ImDisobeyOverPeriodDto.class);
	}

	@Override
	public List<ImDisobeyOverPeriodDto> saveMoreOverPeriod(
			List<ImDisobeyOverPeriodDto> list) throws CustomException {
		List<ImDisobeyOverPeriodDto> list2=new ArrayList<ImDisobeyOverPeriodDto>();
		for(ImDisobeyOverPeriodDto dto:list)
		{
			list2.add(saveOneOverPeriod(dto));
		}
		return list2;
	}

	@Override
	public List<ImDisobeyOverPeriodListDto> overPeriodSentToOa() {
		List<ImDisobeyOverPeriodListDto> list = imDisobeyOverPeriodRptMapper.queryOverPeriodGroupByCust();

		Assert.notNull(list, "没有找到需要推送OA的定制品超期未提货扣款记录");
		Assert.isTrue(!list.isEmpty(), "没有找到需要推送OA的定制品超期未提货扣款记录");

		Date doDate = new Date();
		String oACode = String.valueOf(IdWorker.getId());

		String flowName = DisobeyUtils.const_OaFlowName_ImDisobeyOverPeriod;
		String platform = PublicUtils.const_Platform_Import;

		DictData dic = imDisobeyChannelingService.findOaTemId(flowName, platform);
		Assert.notNull(dic, "没有找到[" + flowName + "]的OA流程配置信息");
		Assert.notBlank(dic.getCode(), "没有找到[" + flowName + "]的OA流程配置信息");

		String temid = dic.getCode();
		String title = dic.getText();
		String userEmpNo = UserUtils.getUserInfo().getFdEmployeeNumber();
		String userName = UserUtils.getUserInfo().getName();
		Integer iresult = SqlDbUtils.sentOaFlow(temid, oACode, title, userEmpNo, userName, platform + ";" + flowName);
		Assert.isTrue(iresult == 1, "提交OA失败");

		// 记录日志
		OaAduit oa = new OaAduit();
		oa.setFdId(IdWorker.getId());
		oa.setOaCode(oACode);
		oa.setPlatform(platform);
		oa.setTableName("im_disobey_over_period");
		oa.setFlowName(flowName);
		oa.setNodeName("提交OA");
		oa.setEmpName(userName);
		oa.setEmpNo(userEmpNo);
		oa.setStatus(11);
		oa.setCreaterId(UserUtils.getUserId());
		oa.setCreateTime(doDate);
		oaAduitService.insert(oa);

		OaAduitDetailDto oaDetailDto = entityToDtoMapper.map(oa, OaAduitDetailDto.class);

		for (ImDisobeyOverPeriodListDto dto : list) {
			Wrapper<ImDisobeyOverPeriod> wrapper = new CriterionWrapper<ImDisobeyOverPeriod>(ImDisobeyOverPeriod.class);
			wrapper.eq("customer_id", dto.getCustomerId());
			wrapper.eq("status", 10);
			List<ImDisobeyOverPeriod> list2=super.selectList(wrapper);
			for(ImDisobeyOverPeriod entity:list2)
			{
				entity.setOaCode(oACode);
				entity.setStatus(11);
				entity.setLastAlterTime(doDate);
				entity.setLastAlterId(UserUtils.getUserId());
				super.updateById(entity);

				OaAduitDetail oaDetail = dtoToEntityMapper.map(oaDetailDto, OaAduitDetail.class);
				oaDetail.setFdId(IdWorker.getId());
				oaDetail.setRecFdId(entity.getFdId());
				oaAduitDetailService.insert(oaDetail);
			}
		}

		return list;
	}

	@Override
	public List<ImDisobeyOverPeriodListDto> findOverPeriodApplyList()
			throws CustomException {
		List<ImDisobeyOverPeriodListDto> list= imDisobeyOverPeriodRptMapper.queryOverPeriodGroupByCust();
		int seqNum=1;
		for(ImDisobeyOverPeriodListDto dto:list)
		{
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list;
	}

	@Override
	public List<ImDisobeyOverPeriodRptDto> findOverPeriodDetailList(String customerId)
			throws CustomException {
		List<ImDisobeyOverPeriodRptDto> list=imDisobeyOverPeriodRptMapper.queryOverPeriodeDetailByCustomerId(customerId);
		
		int seqNum=1;
		for(ImDisobeyOverPeriodRptDto dto:list)
		{
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list;
	}

	@Override
	public List<ImDisobeyOverPeriodListDto> findOverPeriodDeductList(
			String strDate) throws CustomException {
		String date1="";
		String date2="";
		Date date=new Date();
		int year;
		int month;
		if(!strDate.equals(""))
		{
			date=ProcessDateUtil.strToUtilDate(strDate, "yyyy-MM-dd");
		}
		
		year=ProcessDateUtil.getYearOfDate(date);
		month=ProcessDateUtil.getMonthOfDate(date);
		date1=ProcessDateUtil.getFirstDayOfMonth(year, month);
		date2=ProcessDateUtil.getLastDayOfMonth(year, month);
		List<ImDisobeyOverPeriodListDto> list=imDisobeyOverPeriodRptMapper.queryOverPeriodDeductList(date1, date2);
		int seqNum=1;
		for(ImDisobeyOverPeriodListDto dto:list)
		{
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list;
	}

	@Override
	public List<ImDisobeyOverPeriodRptDto> findOverPeriodDeductDetailList(
			String customerId, String strDate) throws CustomException {
		String date1="";
		String date2="";
		Date date=new Date();
		int year;
		int month;
		if(!strDate.equals(""))
		{
			date=ProcessDateUtil.strToUtilDate(strDate, "yyyy-MM-dd");
		}
		
		year=ProcessDateUtil.getYearOfDate(date);
		month=ProcessDateUtil.getMonthOfDate(date);
		date1=ProcessDateUtil.getFirstDayOfMonth(year, month);
		date2=ProcessDateUtil.getLastDayOfMonth(year, month);
		List<ImDisobeyOverPeriodRptDto> list=imDisobeyOverPeriodRptMapper.queryOverPeriodDeductDetailList(customerId, date1, date2);
		int seqNum=1;
		for(ImDisobeyOverPeriodRptDto dto:list)
		{
			dto.setSeqNum(seqNum);
			seqNum++;
		}
		return list;
	}
	
	
}
