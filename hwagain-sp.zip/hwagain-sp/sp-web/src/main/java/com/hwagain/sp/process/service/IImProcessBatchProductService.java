package com.hwagain.sp.process.service;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

import com.hwagain.sp.process.dto.ImProcessBatchProductDto;
import com.hwagain.sp.process.dto.ImProcessPriceListDto;
import com.hwagain.sp.process.dto.ImProcessProductFilterDto;
import com.hwagain.sp.process.dto.ImProcessProductRptDto;
import com.hwagain.sp.process.dto.ImProductListDto;
import com.hwagain.sp.process.entity.ImProcessBatchProduct;
import com.hwagain.sp.product.dto.ProductClassDto;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huanglf
 * @since 2018-10-30
 */
public interface IImProcessBatchProductService extends IService<ImProcessBatchProduct> {
	public Boolean save(List<ImProcessBatchProduct> productList) throws CustomException;
	public List<ImProcessPriceListDto> getCollectProduct(BigInteger fdId) throws CustomException;
	public List<ImProcessProductRptDto> findByPriceId(String PriceId) throws CustomException;
	public Boolean audit(List<ImProcessBatchProductDto> productList) throws CustomException;
	public List<ImProcessProductRptDto> querpImProcessProductDetail() throws CustomException;
	public List<ImProcessPriceListDto> getCollectProductById(String ids) throws CustomException;
	public Boolean deleteByIds(String ids) throws CustomException; 
	
}
