package com.hwagain.sp.price.mapper;

import com.hwagain.sp.price.entity.ImPriceDifference;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  * 副品及承兑汇票结算差价表 Mapper 接口
 * </p>
 *
 * @author
 * @since 2018-11-16
 */
public interface ImPriceDifferenceMapper extends BaseMapper<ImPriceDifference> {

}