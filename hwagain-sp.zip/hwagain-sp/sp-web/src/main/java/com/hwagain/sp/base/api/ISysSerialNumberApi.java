package com.hwagain.sp.base.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author guoym
 * @since 2018-11-05
 */
public interface ISysSerialNumberApi {
	
}
