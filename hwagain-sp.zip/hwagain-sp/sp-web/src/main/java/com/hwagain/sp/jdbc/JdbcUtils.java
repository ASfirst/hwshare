package com.hwagain.sp.jdbc;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class JdbcUtils {

    private static final Logger LOG = LoggerFactory.getLogger(JdbcUtils.class);


    /**
     * 获得数据
     * @param sql 查询语句
     * @return list里面的每个map集合是一条数据，map.get("字段名称")来获得数据
     */
    public static List<Map<String, Object>> getData(String sql) {
        List<Map<String, Object>> datas = new ArrayList<>();
        DynamicDataSource dataSource = DynamicDataSource.getInstance();
        Connection connection = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        try {
            connection = dataSource.getConnection();
            ps = connection.prepareStatement(sql);
            rs = ps.executeQuery();
            ResultSetMetaData rsmd = ps.getMetaData();
            int columnCount = rsmd.getColumnCount();

            Map<String, Object> data ;
            while (rs.next()) {
                data = new HashMap<>();
                for (int i = 1; i <= columnCount; i++) {
                    data.put(rsmd.getColumnLabel(i), rs.getObject(rsmd
                            .getColumnLabel(i)));
                }
                datas.add(data);
            }

        } catch (SQLException e) {
            LOG.error(e.getMessage());
        } finally {
            free(rs, ps, connection);
        }
        return datas;

    }


    /**
     * 更新单条记录
     * @param sql 有占位符的sql语句，有多少个问号，就要相应传入多少个condition
     * @param condition 对应sql语句中问号的参数
     * @return
     */
    public static boolean update(String sql, String...condition){
        DynamicDataSource dataSource = DynamicDataSource.getInstance();
        PreparedStatement ps = null;
        Connection connection = null;
        try {
            connection = dataSource.getConnection();
            ps = connection.prepareStatement(sql);
            for (int i = 0; i < condition.length; i++) {
                ps.setObject(i + 1, condition[i]);
            }
            int i = ps.executeUpdate();
            if (i != 0){
                return true ;
            } else {
                return false ;
            }
        } catch (SQLException e) {
            e.printStackTrace();
            return false ;
        } finally {
            free(null, ps, connection);
        }
    }



    // 释放连接
    private static void free(ResultSet rs, Statement st, Connection conn) {
        try {
            if (rs != null) {
                rs.close(); // 关闭结果集
            }
        } catch (SQLException e) {
            e.printStackTrace();
        } finally {
            try {
                if (st != null) {
                    st.close(); // 关闭Statement
                }
            } catch (SQLException e) {
                e.printStackTrace();
            } finally {
                try {
                    if (conn != null) {
                        conn.close(); // 关闭连接
                    }
                } catch (SQLException e) {
                    e.printStackTrace();
                }

            }

        }
    }

}
