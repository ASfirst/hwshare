package com.hwagain.sp.deposit.dto;

import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

import java.io.Serializable;


/**
 * <p>
 * 
 * </p>
 *
 * @author xionglz
 * @since 2018-11-08
 */
public class DNoDepositStandardDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
    /**
     * 产品品类
     */
	private String classNo;
    /**
     * 企业套产品编号
     */
	private String enterpriseSetNo;
    /**
     * 开始执行时间
     */
	@JsonFormat(pattern="yyyy-MM",timezone="GMT+8")
	private Date startTime;
    /**
     * 结束时间
     */
	@JsonFormat(pattern="yyyy-MM",timezone="GMT+8")
	private Date endTime;
    /**
     * 月订单量
     */
	private BigDecimal monthOrderWeight;
    /**
     * 月出库量
     */
	private BigDecimal monthDeliveryWeight;
    /**
     * 持续月数
     */
	private Integer continuousMonth;
    /**
     * 创建人
     */
	private String createrId;
    /**
     * 创建时间
     */
	private Date createTime;
    /**
     * 修改人
     */
	private String lastAlterId;
    /**
     * 修改时间
     */
	private Date lastAlterTime;
    /**
     * 是否是历史数据
     */
	private Integer isHistory;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getEnterpriseSetNo() {
		return enterpriseSetNo;
	}

	public void setEnterpriseSetNo(String enterpriseSetNo) {
		this.enterpriseSetNo = enterpriseSetNo;
	}

	public Date getStartTime() {
		return startTime;
	}

	public void setStartTime(Date startTime) {
		this.startTime = startTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public BigDecimal getMonthOrderWeight() {
		return monthOrderWeight;
	}

	public void setMonthOrderWeight(BigDecimal monthOrderWeight) {
		this.monthOrderWeight = monthOrderWeight;
	}

	public BigDecimal getMonthDeliveryWeight() {
		return monthDeliveryWeight;
	}

	public void setMonthDeliveryWeight(BigDecimal monthDeliveryWeight) {
		this.monthDeliveryWeight = monthDeliveryWeight;
	}

	public Integer getContinuousMonth() {
		return continuousMonth;
	}

	public void setContinuousMonth(Integer continuousMonth) {
		this.continuousMonth = continuousMonth;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

	public Integer getIsHistory() {
		return isHistory;
	}

	public void setIsHistory(Integer isHistory) {
		this.isHistory = isHistory;
	}

}
