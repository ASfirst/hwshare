package com.hwagain.sp.policy.component.response;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.jeramtough.jtcomponent.task.response.TaskResponse;

/**
 * Created on 2019/6/21 8:21
 * by @author WeiBoWen
 */
public class ResponseData {
    public static Response newInstance(TaskResponse taskResponse) {
        if (!taskResponse.isSuccessful()) {
            Response response;
            response = new Response();
            response.setSuccess(false);
            response.setMsg(taskResponse.getTaskResult().getMessage());
            return response;
        }
        else {
            try {
                Object data = taskResponse.getTaskResult().getSerializablePayload("data");
                SuccessResponseData successResponseData = new SuccessResponseData();
                successResponseData.setMsg(taskResponse.getTaskResult().getMessage() != null ?
                        taskResponse.getTaskResult().getMessage() : "执行成功");
                successResponseData.setSuccess(true);
                successResponseData.setData(data);
                return successResponseData;

            }
            catch (NullPointerException e) {
                Response response;
                response = SuccessResponseData.newInstance();
                response.setMsg(taskResponse.getTaskResult().getMessage() != null ?
                        taskResponse.getTaskResult().getMessage() : "执行成功");
                response.setSuccess(true);
                return response;
            }

        }
    }
}
