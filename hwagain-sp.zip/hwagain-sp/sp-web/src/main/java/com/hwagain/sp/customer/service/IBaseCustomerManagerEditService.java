package com.hwagain.sp.customer.service;

import com.hwagain.sp.customer.entity.BaseCustomerManagerEdit;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-28
 */
public interface IBaseCustomerManagerEditService extends IService<BaseCustomerManagerEdit> {
	
}
