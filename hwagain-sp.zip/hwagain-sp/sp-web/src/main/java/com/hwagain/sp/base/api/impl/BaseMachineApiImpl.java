package com.hwagain.sp.base.api.impl;

import com.hwagain.sp.base.api.IBaseMachineApi;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author huangdh
 * @since 2019-05-12
 */
@Service("baseMachineApi")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class BaseMachineApiImpl implements IBaseMachineApi {
	
}
