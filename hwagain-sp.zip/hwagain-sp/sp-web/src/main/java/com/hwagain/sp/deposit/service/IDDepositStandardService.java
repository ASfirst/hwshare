package com.hwagain.sp.deposit.service;

import com.hwagain.sp.deposit.dto.DDepositStandardDto;
import com.hwagain.sp.deposit.entity.DDepositStandard;

import java.math.BigDecimal;
import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-05
 */
public interface IDDepositStandardService extends IService<DDepositStandard> {

	public List<DDepositStandardDto> findAll() throws CustomException;

	public DDepositStandardDto addOne(DDepositStandardDto ddto)throws CustomException;

	public DDepositStandardDto updateOne(Long fdId,String specification, BigDecimal deposit) throws CustomException;

	public List<DDepositStandardDto> updateBBase()throws CustomException;

	public List<DDepositStandardDto> isHistory()throws CustomException;

	public List<DDepositStandardDto> findHistoryDeposit()throws CustomException;

	public DDepositStandardDto updateDeposits(DDepositStandardDto ddto)throws CustomException;

	public List<DDepositStandardDto> inputQueryDepo()throws CustomException;
	
	//求订单非常规品每吨要交多少订金？
	public BigDecimal findOrderDepositByKindNo(String kindNo)throws CustomException;

	public DDepositStandardDto updateOneEdit(DDepositStandardDto dto)throws CustomException;
	
}
