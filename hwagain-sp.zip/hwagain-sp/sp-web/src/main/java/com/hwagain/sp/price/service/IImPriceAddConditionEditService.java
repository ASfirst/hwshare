package com.hwagain.sp.price.service;

import com.hwagain.sp.price.dto.ImPriceAddConditionEditDto;
import com.hwagain.sp.price.entity.ImPriceAddConditionEdit;

import java.util.List;

import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;

/**
 * <p>
 * 小幅宽产品加价表 服务类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-21
 */
public interface IImPriceAddConditionEditService extends IService<ImPriceAddConditionEdit> {

	public ImPriceAddConditionEditDto addOneEdit(ImPriceAddConditionEditDto dto)throws CustomException;

	public List<ImPriceAddConditionEditDto> findNewHistory(int width,int qty)throws CustomException;

	public List<ImPriceAddConditionEditDto> matching(List<ImPriceAddConditionEditDto> dtos)throws CustomException;
	
}
