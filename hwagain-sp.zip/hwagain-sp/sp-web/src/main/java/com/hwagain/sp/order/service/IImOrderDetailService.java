package com.hwagain.sp.order.service;

import com.hwagain.sp.order.entity.ImOrderDetail;
import com.hwagain.sp.order.dto.ImOrderDetailDto;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.mybatisplus.service.IService;
import java.util.List;
import java.math.BigInteger;



/**
 * <p>
 *  服务类
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
public interface IImOrderDetailService extends IService<ImOrderDetail> {
	
	//新增一条记录
	public ImOrderDetailDto save(ImOrderDetailDto dto) throws CustomException;
		
	//通过im_order_id查询一张订单明细列表
	public List<ImOrderDetailDto> findImOrderDetailListByOrderId(Long orderId) throws CustomException;
	 
	//通过im_order_id删除订单明细
	public Integer deleteImOrderDetailByOrderId(Long orderId) throws CustomException;
	
	//当天下订单到第几张订单
	public Integer findTodayOrderIndex();	
	
	
		 
}
