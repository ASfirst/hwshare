package com.hwagain.sp.policy.mapper;

import com.hwagain.sp.policy.entity.PoOver;
import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  *  Mapper 接口
 * </p>
 *
 * @author mon
 * @since 2019-06-12
 */
public interface PoOverMapper extends BaseMapper<PoOver> {

}