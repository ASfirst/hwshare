package com.hwagain.sp.policy.api;

/**
 * <p>
 *  服务类
 * </p>
 *
 * @author weibw
 * @since 2019-06-24
 */
public interface IPoAreaApi {
	
}
