package com.hwagain.sp.price.service.impl;

import com.hwagain.sp.price.entity.ImPriceAddCondition;
import com.hwagain.sp.price.entity.ImPriceAddConditionEdit;
import com.hwagain.sp.price.dto.ImPriceAddConditionDto;
import com.hwagain.sp.price.dto.ImPriceAddConditionEditDto;
import com.hwagain.sp.price.mapper.ImPriceAddConditionEditMapper;
import com.hwagain.sp.price.service.IImPriceAddConditionEditService;
import com.hwagain.sp.price.service.IImPriceAddConditionService;
import com.alibaba.fastjson.JSONObject;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import oracle.net.aso.w;

/**
 * <p>
 * 小幅宽产品加价表 服务实现类
 * </p>
 *
 * @author xionglz
 * @since 2018-11-21
 */
@Service("imPriceAddConditionEditService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class ImPriceAddConditionEditServiceImpl extends ServiceImpl<ImPriceAddConditionEditMapper, ImPriceAddConditionEdit> implements IImPriceAddConditionEditService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	@Autowired IImPriceAddConditionService iImPriceAddConditionService;
	@Autowired ImPriceAddConditionServiceImpl imPriceAddConditionServiceImpl;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(ImPriceAddConditionEdit.class, ImPriceAddConditionEditDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(ImPriceAddConditionEditDto.class, ImPriceAddConditionEdit.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}
	//新增一条
	@Override
	public ImPriceAddConditionEditDto addOneEdit(ImPriceAddConditionEditDto dto){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		String dept=UserUtils.getUserInfo().getFdDepartmentName();
		Wrapper<ImPriceAddConditionEdit> wrapper=new CriterionWrapper<ImPriceAddConditionEdit>(ImPriceAddConditionEdit.class);
		wrapper.eq("creater_id", cUserid);
		wrapper.eq("width", dto.getWidth());
		wrapper.eq("qty", dto.getQty());
		wrapper.eq("status", 1);
		ImPriceAddConditionEdit list=super.selectFirst(wrapper);
		if(list!=null){
			super.updateById(dtoToEntityMapper.map(dto, ImPriceAddConditionEdit.class));
		}else{
			dto.setFdId(Long.valueOf(IdWorker.getId()));
			dto.setStatus(1);
			dto.setRole(dept);
			dto.setIsPolicy(true);
			dto.setCreaterId(cUserid);
			dto.setCreateTime(doDate);
			super.insert(dtoToEntityMapper.map(dto, ImPriceAddConditionEdit.class));
		}
		return entityToDtoMapper.map(super.selectById(dto.getFdId()), ImPriceAddConditionEditDto.class);
		
	}
	//查看当前用户历史数据
	@Override
	public List<ImPriceAddConditionEditDto> findNewHistory(int width,int qty){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		Wrapper<ImPriceAddConditionEdit> wrapper=new CriterionWrapper<ImPriceAddConditionEdit>(ImPriceAddConditionEdit.class);
		wrapper.eq("creater_id", cUserid);
		wrapper.eq("width", width);
		wrapper.eq("qty", qty);
		wrapper.eq("status", 1);
		List<ImPriceAddConditionEdit> list=super.selectList(wrapper);
		Wrapper<ImPriceAddCondition> wrapper1=new CriterionWrapper<ImPriceAddCondition>(ImPriceAddCondition.class);
		wrapper1.eq("width", width);
		wrapper1.eq("qty", qty);
		wrapper1.eq("status", 1);
		List<ImPriceAddCondition> list1=iImPriceAddConditionService.selectList(wrapper1);
		String st=JSONObject.toJSONString(list1.get(0));
		ImPriceAddConditionEdit list11=JSONObject.parseObject(st,ImPriceAddConditionEdit.class);
		List<ImPriceAddConditionEdit> listA=new ArrayList<>();
		if(list.size()==0){
			listA.add(list11);
		}else{
			listA.addAll(list);
			
		}
		return entityToDtoMapper.mapAsList(listA, ImPriceAddConditionEditDto.class);
	}
	@Override
	public List<ImPriceAddConditionEditDto> matching(List<ImPriceAddConditionEditDto> dtos){
		Date doDate = new Date();
		String cUserid = UserUtils.getUserInfo().getName();
		Wrapper<ImPriceAddConditionEdit> wrapper0=new CriterionWrapper<ImPriceAddConditionEdit>(ImPriceAddConditionEdit.class);
		wrapper0.eq("status",1);		
		List<ImPriceAddConditionEdit> list0=super.selectList(wrapper0);
		if(list0.size()==0){
			Assert.throwException("数据未调整");
		}
//		System.err.println(UserUtils.getUserInfo());
		if(dtos!=null&&dtos.size()==0){
			Assert.throwException("提交数据为空");
		}
		List<ImPriceAddConditionEdit> listA=new ArrayList<>();
		List<ImPriceAddConditionDto> listB=new ArrayList<>();
		for(ImPriceAddConditionEditDto dto:dtos){
			//原始数据
			Wrapper<ImPriceAddConditionEdit> wrapper1=new CriterionWrapper<ImPriceAddConditionEdit>(ImPriceAddConditionEdit.class);
			wrapper1.eq("fd_id", dto.getFdId());		
			ImPriceAddConditionEdit list1=super.selectFirst(wrapper1);
			String st=JSONObject.toJSONString(list1);
			ImPriceAddConditionDto adto=JSONObject.parseObject(st,ImPriceAddConditionDto.class);
			Wrapper<ImPriceAddConditionEdit> wrapper=new CriterionWrapper<ImPriceAddConditionEdit>(ImPriceAddConditionEdit.class);
			wrapper.eq("width", dto.getWidth());
			wrapper.eq("qty", dto.getQty());
			wrapper.eq("status", 1);
			wrapper.eq("add_price", dto.getAddPrice());
			wrapper.eq("start_date", dto.getStartDate());
			wrapper.notIn("creater_id", dto.getCreaterId());
			wrapper.notIn("role", dto.getRole());
			ImPriceAddConditionEdit list=super.selectFirst(wrapper);
			if(list==null){
				Assert.throwException("匹配失败");
			}else{
				listA.add(list);
				listA.add(list1);
				listB.add(adto);
			}
		}
		for(ImPriceAddConditionEdit dto:listA){
			ImPriceAddConditionEdit impe=new ImPriceAddConditionEdit();
			impe.setFdId(dto.getFdId());
			impe.setStatus(10);
			super.updateById(impe);
		}
		for(ImPriceAddConditionDto dto:listB){
			imPriceAddConditionServiceImpl.updateOne(dto);
		}
		return dtos;
		
	}

}
