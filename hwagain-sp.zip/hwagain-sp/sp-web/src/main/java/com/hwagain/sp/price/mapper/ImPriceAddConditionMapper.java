package com.hwagain.sp.price.mapper;

import com.hwagain.sp.price.dto.ImSpecialSetPriceDto;
import com.hwagain.sp.price.entity.ImPriceAddCondition;

import java.math.BigDecimal;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hwagain.framework.mybatisplus.mapper.BaseMapper;

/**
 * <p>
  * 副品及承兑汇票结算价差表 Mapper 接口
 * </p>
 *
 * @author 
 * @since 2018-11-16
 */
public interface ImPriceAddConditionMapper extends BaseMapper<ImPriceAddCondition> {
	public List<ImSpecialSetPriceDto> findList(@Param("isHistory")Integer isHistory);
	public List<ImSpecialSetPriceDto> findHistory(@Param("isHistory")Integer isHistory,
			@Param("physicalNo")String physicalNo,@Param("wrinkleRate")BigDecimal wrinkleRate,
			@Param("ration")BigDecimal ration);
}