package com.hwagain.sp.order.dto;

import com.hwagain.sp.product.dto.ProductDto;

import java.util.Date;

import java.io.Serializable;
import java.util.List;


/**
 * <p>
 * 
 * </p>
 *
 * @author huangdh
 * @since 2018-10-30
 */
public class ProductSetDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
	private String enterpriseSetNo;
	private String classNo;
	private String kindNo;
	private String ration;
	private String layer;
	private Integer diameter;
	private String cutSpec;
	private Integer totalWidth;

	private List<ProductSetDetailDto> productSetDetailDtoList;
	private Integer width;
	private Integer qty;
	private String enterpriseWidthNo;
	private String enterpriseWidthName;

	private String createrId;
	private Date createTime;
	private String lastAlterId;
	private Date lastAlterTime;

	public Integer getWidth() {
		return width;
	}

	public void setWidth(Integer width) {
		this.width = width;
	}

	public Integer getQty() {
		return qty;
	}

	public void setQty(Integer qty) {
		this.qty = qty;
	}

	public String getEnterpriseWidthNo() {
		return enterpriseWidthNo;
	}

	public void setEnterpriseWidthNo(String enterpriseWidthNo) {
		this.enterpriseWidthNo = enterpriseWidthNo;
	}

	public String getEnterpriseWidthName() {
		return enterpriseWidthName;
	}

	public void setEnterpriseWidthName(String enterpriseWidthName) {
		this.enterpriseWidthName = enterpriseWidthName;
	}

	public List<ProductSetDetailDto> getProductSetDetailDtoList() {
		return productSetDetailDtoList;
	}

	public void setProductSetDetailDtoList(List<ProductSetDetailDto> productSetDetailDtoList) {
		this.productSetDetailDtoList = productSetDetailDtoList;
	}

	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public String getEnterpriseSetNo() {
		return enterpriseSetNo;
	}

	public void setEnterpriseSetNo(String enterpriseSetNo) {
		this.enterpriseSetNo = enterpriseSetNo;
	}

	public String getClassNo() {
		return classNo;
	}

	public void setClassNo(String classNo) {
		this.classNo = classNo;
	}

	public String getKindNo() {
		return kindNo;
	}

	public void setKindNo(String kindNo) {
		this.kindNo = kindNo;
	}

	public String getRation() {
		return ration;
	}

	public void setRation(String ration) {
		this.ration = ration;
	}

	public String getLayer() {
		return layer;
	}

	public void setLayer(String layer) {
		this.layer = layer;
	}

	public Integer getDiameter() {
		return diameter;
	}

	public void setDiameter(Integer diameter) {
		this.diameter = diameter;
	}

	public String getCutSpec() {
		return cutSpec;
	}

	public void setCutSpec(String cutSpec) {
		this.cutSpec = cutSpec;
	}

	public Integer getTotalWidth() {
		return totalWidth;
	}

	public void setTotalWidth(Integer totalWidth) {
		this.totalWidth = totalWidth;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
