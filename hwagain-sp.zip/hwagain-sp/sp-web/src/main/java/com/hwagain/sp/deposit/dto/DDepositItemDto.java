package com.hwagain.sp.deposit.dto;

import java.math.BigDecimal;
import java.util.Date;

import java.io.Serializable;


/**
 * <p>
 * 客户当月定金对账明细表
 * </p>
 *
 * @author xionglz
 * @since 2018-12-25
 */
public class DDepositItemDto implements Serializable {

    private static final long serialVersionUID = 1L;

	private Long fdId;
    /**
     * 客户当月定金对账主表ID
     */
	private Long depositMainId;
    /**
     * 日期
     */
	private Date happenDate;
    /**
     * 项目
     */
	private String project;
    /**
     * 单据类别
     */
	private String category;
    /**
     * 单据编号
     */
	private String number;
    /**
     * 汇入定金
     */
	private BigDecimal addDeposit;
    /**
     * 转出定金
     */
	private BigDecimal reduceDeposit;
    /**
     * 冻结定金
     */
	private BigDecimal frozenDeposit;
    /**
     * 解冻定金
     */
	private BigDecimal thawDeposit;
    /**
     * 可用定金
     */
	private BigDecimal availableDeposit;
    /**
     * 账户总冻结定金
     */
	private BigDecimal totalFrozenDeposit;
    /**
     * 定金总额
     */
	private BigDecimal totalDeposit;
    /**
     * 创建人
     */
	private String createrId;
    /**
     * 创建时间
     */
	private Date createTime;
    /**
     * 最后修改人
     */
	private String lastAlterId;
    /**
     * 最后修改时间
     */
	private Date lastAlterTime;


	public Long getFdId() {
		return fdId;
	}

	public void setFdId(Long fdId) {
		this.fdId = fdId;
	}

	public Long getDepositMainId() {
		return depositMainId;
	}

	public void setDepositMainId(Long depositMainId) {
		this.depositMainId = depositMainId;
	}

	public Date getHappenDate() {
		return happenDate;
	}

	public void setHappenDate(Date happenDate) {
		this.happenDate = happenDate;
	}

	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public BigDecimal getAddDeposit() {
		return addDeposit;
	}

	public void setAddDeposit(BigDecimal addDeposit) {
		this.addDeposit = addDeposit;
	}

	public BigDecimal getReduceDeposit() {
		return reduceDeposit;
	}

	public void setReduceDeposit(BigDecimal reduceDeposit) {
		this.reduceDeposit = reduceDeposit;
	}

	public BigDecimal getFrozenDeposit() {
		return frozenDeposit;
	}

	public void setFrozenDeposit(BigDecimal frozenDeposit) {
		this.frozenDeposit = frozenDeposit;
	}

	public BigDecimal getThawDeposit() {
		return thawDeposit;
	}

	public void setThawDeposit(BigDecimal thawDeposit) {
		this.thawDeposit = thawDeposit;
	}

	public BigDecimal getAvailableDeposit() {
		return availableDeposit;
	}

	public void setAvailableDeposit(BigDecimal availableDeposit) {
		this.availableDeposit = availableDeposit;
	}

	public BigDecimal getTotalFrozenDeposit() {
		return totalFrozenDeposit;
	}

	public void setTotalFrozenDeposit(BigDecimal totalFrozenDeposit) {
		this.totalFrozenDeposit = totalFrozenDeposit;
	}

	public BigDecimal getTotalDeposit() {
		return totalDeposit;
	}

	public void setTotalDeposit(BigDecimal totalDeposit) {
		this.totalDeposit = totalDeposit;
	}

	public String getCreaterId() {
		return createrId;
	}

	public void setCreaterId(String createrId) {
		this.createrId = createrId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getLastAlterId() {
		return lastAlterId;
	}

	public void setLastAlterId(String lastAlterId) {
		this.lastAlterId = lastAlterId;
	}

	public Date getLastAlterTime() {
		return lastAlterTime;
	}

	public void setLastAlterTime(Date lastAlterTime) {
		this.lastAlterTime = lastAlterTime;
	}

}
