package com.hwagain.sp.price.web;

import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.hwagain.framework.core.response.Response;
import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.web.common.controller.BaseController;
import com.hwagain.sp.price.dto.ImPriceAddConditionEditDto;
import com.hwagain.sp.price.dto.ImPriceAdjustDto;
import com.hwagain.sp.price.dto.ImPriceDto;
import com.hwagain.sp.price.service.IImPriceAdjustService;
import com.hwagain.sp.price.service.IImPriceService;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiImplicitParam;
import io.swagger.annotations.ApiImplicitParams;
import io.swagger.annotations.ApiOperation;

/**
 * <p>
 * 进口纸机-常规、非常规产品统一销售价格表 前端控制器
 * </p>
 *
 * @author guoym
 * @since 2018-10-10
 */
@RestController
@RequestMapping(value = "/price/imPrice", method = { RequestMethod.GET, RequestMethod.POST })
@Api(value = "【进口纸机】统一销售价格", description = "【进口纸机】统一销售价格")
public class ImPriceController extends BaseController {

	@Autowired
	IImPriceService imPriceService;

	@Autowired
	IImPriceAdjustService imPriceAdjustService;

	@RequestMapping("/queryOnePrice")
	@ApiOperation(value = "查询一条", notes = "查询一条", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "fdid", value = "fdid", paramType = "query", required = true, dataType = "String") })
	public Response queryOnePrice(String fdid) {
		return SuccessResponseData.newInstance(imPriceService.findOne(fdid));
	}

	@RequestMapping("/queryImPriceList")
	@ApiOperation(value = "查询常规、非常规价格", notes = "查询常规、非常规价格", httpMethod = "GET")
	public Response queryImPriceList() {
		return SuccessResponseData.newInstance(imPriceService.queryImPriceList());
	}

	@RequestMapping("/inputQueryList")
	@ApiOperation(value = "查询列表【价格录入】", notes = "查询列表【价格录入】", httpMethod = "GET")
	public Response inputQueryList() {
		return SuccessResponseData.newInstance(imPriceService.inputQueryList());
	}

	@RequestMapping("/inputQuerySelect")
	@ApiOperation(value = "查询选择的产品【价格录入】", notes = "查询选择的产品【价格录入】", httpMethod = "GET")
	public Response inputQuerySelect() {
		return SuccessResponseData.newInstance(imPriceService.inputQuerySelect());
	}

	@RequestMapping(value = "/inputSelectProd", method = { RequestMethod.POST })
	@ApiOperation(value = "选择产品【价格录入】", notes = "选择产品【价格录入】", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "prodBaseIds", value = "选择的产品id,格式：1;2;3;4....", paramType = "query", required = true, dataType = "String") })
	public Response inputSelectProd(String prodBaseIds) {
		return SuccessResponseData.newInstance(imPriceService.inputSelectProd(prodBaseIds));
	}

	@RequestMapping(value = "/inputUpdateOne", method = { RequestMethod.POST })
	@ApiOperation(value = "更新一条【价格录入】", notes = "更新一条【价格录入】", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "fdid", value = "修改记录id", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "unit", value = "定价单位(单幅产品/套产品)", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "addPrice", value = "增加价格", paramType = "query", required = false, dataType = "String"),
			@ApiImplicitParam(name = "extPrice", value = "执行价格", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "startDate", value = "开始日期", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "isPolicy", value = "是否享受政策(1:是;0:否)", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "remark", value = "备注", paramType = "query", required = false, dataType = "String"), })
	public Response inputUpdateOne(String fdid, String unit, BigDecimal addPrice, BigDecimal extPrice, Date startDate,
			Integer isPolicy, String remark) {
		return SuccessResponseData.newInstance(
				imPriceService.inputUpdateOne(fdid, unit, addPrice, extPrice, startDate, isPolicy, remark));
	}

	@RequestMapping(value = "/inputUpdateSome", method = { RequestMethod.POST })
	@ApiOperation(value = "更新多条【价格录入】", notes = "更新多条【价格录入】<br/>需传字段：<br/>fdId:修改记录id<br/>  unit:定价单位(单幅产品/套产品)<br/>  addPrice:增加价格<br/> "
			+ "  price:执行价格<br/>	  startDate:开始日期<br/>  isPolicy:是否享受政策(1:是;0:否)<br/>    remark:备注 ", httpMethod = "POST")
	public Response inputUpdateSome(@RequestBody List<ImPriceDto> list) {
		return SuccessResponseData.newInstance(imPriceService.inputUpdateSome(list));
	}

	@RequestMapping(value = "/inputDeleteOne", method = { RequestMethod.POST })
	@ApiOperation(value = "删除一条【价格录入】", notes = "删除一条【价格录入】", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "fdid", value = "删除记录id", paramType = "query", required = true, dataType = "String") })
	public Response inputDeleteOne(String fdid) {
		return SuccessResponseData.newInstance(imPriceService.inputDeleteOne(fdid));
	}

	@RequestMapping(value = "/inputSentToOa", method = { RequestMethod.POST })
	@ApiOperation(value = "提交OA【价格录入】", notes = "提交OA【价格录入】", httpMethod = "POST")
	public Response inputSentToOa() {
		return SuccessResponseData.newInstance(imPriceService.inputSentToOa());
	}

	@RequestMapping(value = "/inputOaAduitFlow", method = { RequestMethod.POST })
	@ApiOperation(value = "OA审批过程【价格录入】", notes = "OA审批过程【价格录入】", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "oACode", value = "oACode", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "status", value = "状态(11,20,30)", paramType = "query", required = true, dataType = "Integer"),
			@ApiImplicitParam(name = "nodeName1", value = "OA流程节点名称", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "empName", value = "审核人审批姓名", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "empNo", value = "审核审批人工号", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "flowDjbh", value = "OA单据编号", paramType = "query", required = false, dataType = "String"),
			@ApiImplicitParam(name = "flowDjlsh", value = "OA单据流水号", paramType = "query", required = false, dataType = "String") })
	public Response inputOaAduitFlow(String oACode, Integer status, String nodeName1, String empName, String empNo,
			String flowDjbh, String flowDjlsh) {
		return SuccessResponseData.newInstance(
				imPriceService.inputOaAduitFlow(oACode, status, nodeName1, empName, empNo, flowDjbh, flowDjlsh));
	}

	@RequestMapping(value = "/inputQueryByOaCode", method = { RequestMethod.GET })
	@ApiOperation(value = "OA查询列表【价格录入】", notes = "OA查询列表【价格录入】", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "oaCode", value = "oaCode", paramType = "query", required = true, dataType = "String") })
	public Response inputQueryByOaCode(String oaCode) {
		return SuccessResponseData.newInstance(imPriceService.inputQueryByOaCode(oaCode));
	}

	@RequestMapping("/adjustQueryList")
	@ApiOperation(value = "查询列表【价格调整】", notes = "查询列表【价格调整】", httpMethod = "GET")
	public Response adjustQueryList() {
		return SuccessResponseData.newInstance(imPriceAdjustService.adjustQueryList());
	}

	@RequestMapping(value = "/adjustUpdateOne", method = { RequestMethod.POST })
	@ApiOperation(value = "更新一条【价格调整】", notes = "更新一条【价格调整】", httpMethod = "POST")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "fdid", value = "调整表记录id（adj_fdId）", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "addPrice", value = "增加价格", paramType = "query", required = false, dataType = "String"),
			@ApiImplicitParam(name = "startDate", value = "开始日期", paramType = "query", required = false, dataType = "String"),
			@ApiImplicitParam(name = "remark", value = "备注", paramType = "query", required = false, dataType = "String"), })
	public Response adjustUpdateOne(String fdid, BigDecimal addPrice, Date startDate, String remark) {
		return SuccessResponseData.newInstance(imPriceAdjustService.adjustUpdateOne(fdid, addPrice, startDate, remark));
	}

	@RequestMapping(value = "/adjustUpdateSome", method = { RequestMethod.POST })
	@ApiOperation(value = "更新多条【价格调整】", notes = "更新多条【价格调整】<br/>需传字段：<br/>fdId:修改记录id（adj_fdId）<br/>  addPrice:增加价格<br/> "
			+ "startDate:开始日期<br/>remark:备注 ", httpMethod = "POST")
	public Response adjustUpdateSome(@RequestBody List<ImPriceAdjustDto> list) {
		return SuccessResponseData.newInstance(imPriceAdjustService.adjustUpdateSome(list));
	}
	
	@RequestMapping(value = "/adjustSentToOa", method = { RequestMethod.POST })
	@ApiOperation(value = "提交OA【价格调整】", notes = "提交OA【价格调整】", httpMethod = "POST")
	public Response adjustSentToOa() {
		return SuccessResponseData.newInstance(imPriceAdjustService.adjustSentToOa());
	}
	
	@RequestMapping(value = "/adjustQueryByOaCode", method = { RequestMethod.GET })
	@ApiOperation(value = "OA查询列表【价格调整】", notes = "OA查询列表【价格调整】", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "oaCode", value = "oaCode", paramType = "query", required = true, dataType = "String") })
	public Response adjustQueryByOaCode(String oaCode) {
		return SuccessResponseData.newInstance(imPriceAdjustService.adjustQueryByOaCode(oaCode));
	}
	
	@RequestMapping(value = "/queryHistoryPrice", method = { RequestMethod.GET })
	@ApiOperation(value = "列表【历史价格】", notes = "列表【历史价格】", httpMethod = "GET")
	public Response queryHistoryPrice() {
		return SuccessResponseData.newInstance(imPriceService.queryHistoryPrice());
	}
	
	@RequestMapping(value = "/queryHistoryPriceDetail", method = { RequestMethod.GET })
	@ApiOperation(value = "明细列表【历史价格】", notes = "明细列表【历史价格】", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "startDate", value = "开始日期", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "price", value = "价格", paramType = "query", required = true, dataType = "String") ,
			@ApiImplicitParam(name = "addPrice", value = "调整价格", paramType = "query", required = false, dataType = "String") 			
	})
	public Response queryHistoryPriceDetail(Date startDate, BigDecimal price, BigDecimal addPrice) {
		return SuccessResponseData.newInstance(imPriceService.queryHistoryPriceDetail(startDate, price,addPrice));
	}
	
	@RequestMapping(value = "/getTransPrice", method = { RequestMethod.GET })
	@ApiOperation(value = "获取物料系统运输单价", notes = "获取物料系统运输单价", httpMethod = "GET")
	@ApiImplicitParams({
			@ApiImplicitParam(name = "procuctType", value = "品类", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "custName", value = "客户名称", paramType = "query", required = false, dataType = "String") ,
			@ApiImplicitParam(name = "address", value = "运输地址", paramType = "query", required = false, dataType = "String"),
			@ApiImplicitParam(name = "carType", value = "车辆类型", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "province", value = "省", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "city", value = "市", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "county", value = "县", paramType = "query", required = true, dataType = "String"),
			@ApiImplicitParam(name = "startdate", value = "日期", paramType = "query", required = true, dataType = "Date")
	})
	public Response getTransPrice(String procuctType,String custName,String address,String carType,String province,String city,String county,Date startdate) {
		return SuccessResponseData.newInstance(imPriceService.getTransPrice(procuctType,custName,address,carType,province,city,county,startdate));
	}
	
	//=========================================================================================
	//双人录入
	@RequestMapping("/addOneEdit")
	@ApiOperation(value="双人录入",notes="双人录入",httpMethod="POST")
	public Response addOneEdit(@RequestBody ImPriceAdjustDto dto){
		return SuccessResponseData.newInstance(imPriceAdjustService.addOneEdit(dto));
	}
	
	@RequestMapping(value="/findNewHistory",method={RequestMethod.GET})
	@ApiOperation(value="当前用户历史记录",notes="当前用户历史记录",httpMethod="GET")
	public Response findHistory(){
		return SuccessResponseData.newInstance(imPriceAdjustService.findNewHistory());
	}
	
	
	@RequestMapping("/matching")
	@ApiOperation(value="双人录入数据匹配",notes="双人录入数据匹配",httpMethod="POST")
	public Response matching(@RequestBody List<ImPriceAdjustDto> dtos){
		return SuccessResponseData.newInstance(imPriceAdjustService.matching(dtos));
	}
	
	@RequestMapping("/findAllList")
	@ApiOperation(value = "查询常规、非常规价格", notes = "查询常规、非常规价格", httpMethod = "GET")
	public Response findAllList() {
		return SuccessResponseData.newInstance(imPriceService.findAllList());
	}


}
