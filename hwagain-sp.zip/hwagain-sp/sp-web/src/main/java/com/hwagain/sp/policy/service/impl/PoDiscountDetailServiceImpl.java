package com.hwagain.sp.policy.service.impl;

import com.hwagain.sp.policy.entity.PoDiscountDetail;
import com.hwagain.sp.base.service.IDictDataService;
import com.hwagain.sp.policy.dto.PoDiscountDetailDto;
import com.hwagain.sp.policy.dto.PoDiscountDto;
import com.hwagain.sp.policy.mapper.PoDiscountDetailMapper;
import com.hwagain.sp.policy.service.IPoDiscountDetailService;
import com.hwagain.sp.policy.service.IPoDiscountService;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.framework.core.util.Assert;
import com.hwagain.framework.mybatisplus.mapper.CriterionWrapper;
import com.hwagain.framework.mybatisplus.mapper.Wrapper;
import com.hwagain.framework.mybatisplus.service.impl.ServiceImpl;
import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.framework.security.common.util.UserUtils;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;

/**
 * <p>
 *  服务实现类
 * </p>
 *
 * @author linhl
 * @since 2018-11-02
 */
@Service("poDiscountDetailService")
@Transactional(propagation = Propagation.REQUIRED, rollbackFor = Exception.class)
public class PoDiscountDetailServiceImpl extends ServiceImpl<PoDiscountDetailMapper, PoDiscountDetail> implements IPoDiscountDetailService {
	
	// entity转dto
	static MapperFacade entityToDtoMapper;
	
	// dto转entity
	static MapperFacade dtoToEntityMapper;
	
	@Autowired
	IDictDataService dictDataService;
	
	@Autowired
	IPoDiscountService poDiscountService;

	static {
		MapperFactory factory = new DefaultMapperFactory.Builder().build();
		factory.classMap(PoDiscountDetail.class, PoDiscountDetailDto.class).byDefault().register();
		entityToDtoMapper = factory.getMapperFacade();
		
		MapperFactory factorytwo = new DefaultMapperFactory.Builder().build();
		factorytwo.classMap(PoDiscountDetailDto.class, PoDiscountDetail.class).byDefault().register();
		dtoToEntityMapper = factorytwo.getMapperFacade();
	}

	@Override
	public PoDiscountDetail findoneByfdid(Long fdid) throws CustomException {
		// TODO Auto-generated method stub
		Wrapper<PoDiscountDetail> wrapper=new CriterionWrapper<PoDiscountDetail>(PoDiscountDetail.class);
		wrapper.eq("fd_id", fdid);
		PoDiscountDetail entity=super.selectFirst(wrapper);
		return entityToDtoMapper.map(entity, PoDiscountDetail.class);
	}

	@Override
	public List<PoDiscountDetail> findAll( String orderNo) {
		// TODO Auto-generated method stub
		Wrapper<PoDiscountDetail> wrapper=new CriterionWrapper<>(PoDiscountDetail.class);
		
		if (orderNo!=null)
		{
			wrapper.eq("order_no", orderNo);
		}
		
		
		List<PoDiscountDetail> list=super.selectList(wrapper);
		return entityToDtoMapper.mapAsList(list, PoDiscountDetail.class);
	}
	
	@Override
	public Double findSumAmountByParentID(long parentID) {
		// TODO Auto-generated method stub
		Wrapper<PoDiscountDetail> wrapper=new CriterionWrapper<>(PoDiscountDetail.class);
		wrapper.eq("po_discount_id", parentID);
		List<PoDiscountDetail> list=super.selectList(wrapper);

		Double sumamount = list.stream().mapToDouble(pd->{
			return pd.getAmount()!=null?pd.getAmount().doubleValue():0;
		}).sum();
		return sumamount;
	}
	
	@Override
	public PoDiscountDetailDto save(PoDiscountDetailDto dto) {
		// TODO Auto-generated method stub
		Date date=dto.getBusinessDate();
		if (date==null) 
		{
			Assert.throwException("日期不允许为空");
		}
		
		long discountId=Long.valueOf(dto.getPoDiscountId());
		Assert.notNull(discountId, "折扣单ID不允许为空");
		PoDiscountDto d=poDiscountService.findoneByfdid(discountId);
		if (d==null){Assert.throwException("折扣单ID不正确！");
		}
		
		if (d.getStatus()==0) {
			Assert.throwException("源头折扣单未审核！不允许生成计算单！");
		}
		//71代表一次性返还的单据
		if (d.getPolicyMethodId().equals(new Long(71)))
		{
			//已冲金额+当前冲减金额不允许大于折扣单上申请金额
			Double sumamount=findSumAmountByParentID(discountId);
			if (sumamount+dto.getAmount().doubleValue()>d.getAmount().doubleValue()) {
				Assert.throwException("冲减金额不允许大于申请金额！");
			}
		}
		Assert.notNull(dto.getPrice(), "单价不允许为空");
		Assert.notNull(dto.getAmount(), "金额不允许为空");
		
		BigDecimal amount=dto.getAmount()!=null?dto.getAmount():new BigDecimal(0);
		if (amount.equals(new BigDecimal(0))) {
			Assert.throwException("金额不允许为0！");
		}
				
		Assert.notNull(dto.getWeight(), "重量不允许为空");
		Assert.notNull(dto.getOrderNo(), "订单编号不允许为空");
		
		
		
		dto.setFdId(Long.valueOf(IdWorker.getId()));
		String createrId = UserUtils.getUserId();
		dto.setCreaterId(createrId);
		Date createTime = new Date();
		dto.setCreateTime(createTime);
	    if (super.insertOrUpdate(dtoToEntityMapper.map(dto, PoDiscountDetail.class)))
	    {
	    	//新增记录时更新已冲减金额到折扣信息表
	    	Double sumamount=findSumAmountByParentID(discountId);
	    	BigDecimal commitAmount = new BigDecimal( sumamount );
	    	d.setCommitAmount(commitAmount);
	    	BigDecimal notCommitAmount=new BigDecimal(d.getAmount().doubleValue()>0 ? d.getAmount().doubleValue()-sumamount :0);
	    	Boolean isRowClose= notCommitAmount.compareTo(new BigDecimal(0))<=0 && d.getPolicyMethodId().equals(new Long(71)) ? true : false  ;
	    	d.setIsRowClose(isRowClose);
	    	d.setNotCommitAmount(notCommitAmount);
	    	
	    	PoDiscountDto newdiscountDto=poDiscountService.update(d);
	    	if (newdiscountDto!=null)
	    		return dto;
	    	else
	    		return null;	
	    }
	    else
	    {
	    	return null;
	    }
	}

	@Override
	@Transactional
	public Boolean deleteByOrderNo(String orderNo) {
		// TODO Auto-generated method stub
		Boolean returnFlag=true;
		Wrapper<PoDiscountDetail> wrapper=new CriterionWrapper<>(PoDiscountDetail.class);
		
		if (orderNo!=null) {
			wrapper.eq("order_no", orderNo);
		}
		
		List<PoDiscountDetail> list=super.selectList(wrapper);
		for(PoDiscountDetail model : list){
			long fdid =model.getFdId();
			Wrapper<PoDiscountDetail> wrapperTemp=new CriterionWrapper<>(PoDiscountDetail.class);
			wrapper.eq("fd_id", fdid);
			
			if (super.delete(wrapperTemp))
			{
				//删除记录时更新已冲减金额到折扣信息表
				PoDiscountDto d=poDiscountService.findoneByfdid(model.getPoDiscountId());
				Double sumamount=findSumAmountByParentID(model.getPoDiscountId());
		    	BigDecimal commitAmount = new BigDecimal(sumamount);
		    	d.setCommitAmount(commitAmount);
		    	BigDecimal notCommitAmount=new BigDecimal(d.getAmount().doubleValue()>0 ? d.getAmount().doubleValue()-sumamount :0);
		    	d.setNotCommitAmount(notCommitAmount);
		    	Boolean isRowClose= notCommitAmount.compareTo(new BigDecimal(0))<=0 && d.getPolicyMethodId().equals(new Long(71)) ? true : false  ;
		    	d.setIsRowClose(isRowClose);
		    	
		    	PoDiscountDto newdiscountDto=poDiscountService.update(d);
		    	if (newdiscountDto==null) {
		    		returnFlag=false;
		    	}
			}
			else
			{
				returnFlag=false;
			}
		}
		
		return returnFlag;
	}

	@Override
	@Transactional
	public Boolean deleteByIds(String ids) {
		// TODO Auto-generated method stub
		Boolean returnFlag=true;
		Assert.notBlank(ids, "请选择需要删除的纪录");
		String[] id = ids.split(",");
		Assert.isTrue(null != id && id.length > 0, "请选择需要删除的纪录");
		
		for (String s : id) {
			PoDiscountDetail p = super.selectById(s);
			Wrapper<PoDiscountDetail> wrapper=new CriterionWrapper<>(PoDiscountDetail.class);
			wrapper.eq("fd_id", s);
			if (super.delete(wrapper))
			{
				//删除记录时更新已冲减金额到折扣信息表
				PoDiscountDto d=poDiscountService.findoneByfdid(p.getPoDiscountId());
				Double sumamount=findSumAmountByParentID(p.getPoDiscountId());
		    	BigDecimal commitAmount = new BigDecimal(sumamount);
		    	d.setCommitAmount(commitAmount);
		    	BigDecimal notCommitAmount=new BigDecimal(d.getAmount().doubleValue()>0 ? d.getAmount().doubleValue()-sumamount :0);
		    	d.setNotCommitAmount(notCommitAmount);
		    	Boolean isRowClose= notCommitAmount.compareTo(new BigDecimal(0))<=0 && d.getPolicyMethodId().equals(new Long(71)) ? true : false  ;
		    	d.setIsRowClose(isRowClose);
		    	
		    	PoDiscountDto newdiscountDto=poDiscountService.update(d);
		    	if (newdiscountDto==null) {
		    		returnFlag=false;
		    	}
			}
			else
			{
				returnFlag=false;
			}
		}
		
		return returnFlag;		
	}

	
}
