package com.hwagain.sp;

import com.hwagain.sp.policy.dto.params.AddSubsidyDto;
import com.hwagain.sp.policy.dto.params.UpdateSubsidyDto;
import com.hwagain.sp.policy.service.IPoTransportService;
import com.hwagain.sp.policy.web.PoTransportController;
import com.jeramtough.jtcomponent.task.response.TaskResponse;
import com.jeramtough.jtlog.facade.L;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;

import java.math.BigDecimal;
import java.util.Date;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = {HwagainSpApplication.class})
public class HwagainSpApplicationTests {

    @Autowired
    public IPoTransportService poTransportService;

    @Test
    public void addSubsidy() {
        AddSubsidyDto addSubsidyDto = new AddSubsidyDto();
        addSubsidyDto.setAddPrice(new BigDecimal("100.0"));
        addSubsidyDto.setCheckedBy("韦博文");
        addSubsidyDto.setAddPrice(new BigDecimal(0.32));
        addSubsidyDto.setCheckedDate(new Date());
        addSubsidyDto.setCreaterId("1");
        addSubsidyDto.setCheckedRemark("aaaa");
        addSubsidyDto.setStartDate(new Date());
        addSubsidyDto.setEndDate(new Date());
        addSubsidyDto.setRemark("vvvv");
        addSubsidyDto.setMethod("abcd");
        addSubsidyDto.setPrice(new BigDecimal("32323.2121"));
        addSubsidyDto.setCustomerId(12L);
        TaskResponse taskResponse = poTransportService.addSubsidy(addSubsidyDto);
        L.debug(taskResponse.isSuccessful());
    }

    @Test
    public void updateSubsidy() {
        UpdateSubsidyDto updateSubsidyDto = new UpdateSubsidyDto();
        updateSubsidyDto.setCheckedBy("写生");
        updateSubsidyDto.setFdId(1L);
        TaskResponse taskResponse = poTransportService.updateSubsidy(updateSubsidyDto);
        L.debug(taskResponse.isSuccessful());
    }

    @Test
    public void selectTest() {
        TaskResponse taskResponse = poTransportService.findAllSubsidys();
        L.debug(taskResponse.isSuccessful());
    }

}
