package com.hwagain.sp.policy.component.factory;

import com.hwagain.framework.mybatisplus.toolkit.IdWorker;
import com.hwagain.sp.policy.dto.PoTransportDto;
import com.hwagain.sp.policy.dto.params.AddSubsidyDto;
import com.hwagain.sp.policy.dto.params.UpdateSubsidyDto;
import com.hwagain.sp.policy.entity.PoTransport;
import ma.glasnost.orika.MapperFacade;
import ma.glasnost.orika.MapperFactory;
import ma.glasnost.orika.impl.DefaultMapperFactory;
import org.springframework.stereotype.Component;

import java.util.Date;

/**
 * Created on 2019-06-20 22:44
 * by @author JeramTough
 */
@Component
public class PoTransportFactory {

    private MapperFacade mapperFacade1;
    private MapperFacade mapperFacade2;
    private MapperFacade mapperFacade3;

    public PoTransportFactory() {
        MapperFactory factory = new DefaultMapperFactory.Builder().build();

        factory.classMap(PoTransportDto.class, PoTransport.class).byDefault().register();
        mapperFacade1 = factory.getMapperFacade();

        factory.classMap(PoTransport.class, AddSubsidyDto.class).byDefault().register();
        mapperFacade2 = factory.getMapperFacade();

        factory.classMap(PoTransport.class, UpdateSubsidyDto.class).byDefault().register();
        mapperFacade3 = factory.getMapperFacade();

    }

    public PoTransport getPoTransport(AddSubsidyDto addSubsidyDto) {
        PoTransport poTransport = mapperFacade2.map(addSubsidyDto, PoTransport.class);
        poTransport.setFdId(IdWorker.getId());
        poTransport.setCreateTime(new Date());
        poTransport.setLastAlterId(null);
        poTransport.setLastAlterTime(new Date());
        poTransport.setStatus(11);
        return poTransport;
    }

    public PoTransport getPoTransport(UpdateSubsidyDto updateSubsidyDto) {
        PoTransport poTransport = mapperFacade3.map(updateSubsidyDto, PoTransport.class);
        poTransport.setLastAlterId(null);
        poTransport.setLastAlterTime(new Date());
        return poTransport;
    }
}
