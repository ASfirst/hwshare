package com.hwagain.sp.policy.web;

import com.hwagain.sp.policy.dto.params.AddSubsidyDto;
import com.hwagain.sp.policy.service.IPoTransportService;
import com.jeramtough.jtlog.with.WithLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.Date;

/**
 * <p>
 * 前端控制器
 * </p>
 *
 * @author weibw
 * @since 2019-06-20
 */
@RestController
@RequestMapping(value = "/policy/poTransport",
        method = {RequestMethod.GET, RequestMethod.POST})
//@Api(value = "交通补贴")
public class PoTransportController extends BaseController implements WithLogger {


    private final IPoTransportService poTransportService;

    @Autowired
    public PoTransportController(
            IPoTransportService poTransportService) {
        this.poTransportService = poTransportService;
    }


    @RequestMapping(value = "/addSubsidy", method = RequestMethod.POST)
    //@ApiOperation(value = "新增【运输补贴】", notes = "新增一条数据到po_transport表", httpMethod = "POST")
    public String addSubsidy(@RequestBody AddSubsidyDto addSubsidyDto) {
        getLogger().info("开始执行新增【运输补贴】API接口");
        poTransportService.addSubsidy(addSubsidyDto);
        return "finished";
    }

}
