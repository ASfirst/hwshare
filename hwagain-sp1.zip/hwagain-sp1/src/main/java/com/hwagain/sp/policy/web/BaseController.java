package com.hwagain.sp.policy.web;

/**
 * Created on 2019-06-20 21:28
 * by @author JeramTough
 */
public class BaseController {
}
