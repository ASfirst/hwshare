package com.hwagain.sp.policy.entity.annotations;

/**
 * Created on 2019-06-20 21:49
 * by @author JeramTough
 */
public @interface TableField {
    String value();
}
