package com.hwagain.sp.policy.dto.params;

import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.util.Date;

/**
 * Created on 2019/6/20 15:48
 * by @author WeiBoWen
 */
public class AddSubsidyDto {

    @NotNull(message = "1")
    private Long customerId;

    @NotNull(message = "2")
    private String method;

    @NotNull(message = "3")
    private BigDecimal price;

    @NotNull(message = "4")
    private BigDecimal addPrice;

    @NotNull(message = "5")
    private Date startDate;

    @NotNull(message = "6")
    private Date endDate;

    @NotNull(message = "7")
    private String checkedBy;

    @NotNull(message = "8")
    private Date checkedDate;

    @NotNull(message = "9")
    private String checkedRemark;

    @NotNull(message = "11")
    private String remark;

    @NotNull(message = "22")
    private String createrId;

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public BigDecimal getAddPrice() {
        return addPrice;
    }

    public void setAddPrice(BigDecimal addPrice) {
        this.addPrice = addPrice;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public String getCheckedBy() {
        return checkedBy;
    }

    public void setCheckedBy(String checkedBy) {
        this.checkedBy = checkedBy;
    }

    public Date getCheckedDate() {
        return checkedDate;
    }

    public void setCheckedDate(Date checkedDate) {
        this.checkedDate = checkedDate;
    }

    public String getCheckedRemark() {
        return checkedRemark;
    }

    public void setCheckedRemark(String checkedRemark) {
        this.checkedRemark = checkedRemark;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getCreaterId() {
        return createrId;
    }

    public void setCreaterId(String createrId) {
        this.createrId = createrId;
    }
}
