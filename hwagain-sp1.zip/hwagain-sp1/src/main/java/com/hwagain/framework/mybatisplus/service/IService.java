package com.hwagain.framework.mybatisplus.service;

/**
 * Created on 2019-06-20 21:41
 * by @author JeramTough
 */
public interface IService<T> {
}
