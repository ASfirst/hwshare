package com.hwagain.framework.mybatisplus.annotations;

/**
 * Created on 2019-06-20 21:47
 * by @author JeramTough
 */
public @interface TableName {
    String value();
}
