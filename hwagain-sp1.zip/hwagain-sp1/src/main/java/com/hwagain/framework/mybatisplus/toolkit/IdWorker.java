package com.hwagain.framework.mybatisplus.toolkit;

/**
 * Created on 2019-06-20 22:02
 * by @author JeramTough
 */
public class IdWorker {
    public static Long getId() {
        int random = (int) (Math.random() * 100);
        return new Long((long)random);
    }
}
