package com.hwagain.framework.mybatisplus.service.impl;

/**
 * Created on 2019-06-20 21:51
 * by @author JeramTough
 */
public class ServiceImpl<T, T1> {
}
