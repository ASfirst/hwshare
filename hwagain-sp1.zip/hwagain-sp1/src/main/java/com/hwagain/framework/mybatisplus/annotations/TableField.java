package com.hwagain.framework.mybatisplus.annotations;

/**
 * Created on 2019-06-20 21:49
 * by @author JeramTough
 */
public @interface TableField {
    String value();
}
