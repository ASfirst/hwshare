package com.hwagain.framework.mybatisplus.mapper;

/**
 * Created on 2019-06-20 22:01
 * by @author JeramTough
 */
public interface BaseMapper<T> {
}
