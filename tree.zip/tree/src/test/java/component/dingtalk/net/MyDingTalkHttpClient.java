package component.dingtalk.net;

import java.util.ArrayList;
import java.util.List;

/**
 * Created on 2019/7/11 16:41
 * by @author WeiBoWen
 */
public class MyDingTalkHttpClient implements DingTalkHttpClient {

    @Override
    public List<Long> getSubDepartmentIdList(Long departmentId) {
        int length = (int) (Math.random() * 3);
        List<Long> ids=new ArrayList<>();
        for (int i=0;i<length;i++){
            long id= (long) (1+Math.random() * 100);
            ids.add(id);
        }
        return ids;
    }
}
