import com.jeramtough.component.tree.SortMethod;
import com.jeramtough.component.tree.foreach.CalledNode;
import com.jeramtough.component.tree.util.TreeNodeUtils;
import com.jeramtough.component.tree.adapter.BaseTreeNodeAdapter;
import com.jeramtough.component.tree.adapter.FileTreeNodeAdapter;
import com.jeramtough.component.tree.processor.DefaultTreeProcessor;
import com.jeramtough.component.tree.processor.TreeProcessor;
import com.jeramtough.component.tree.structure.DefaultTreeNode;
import com.jeramtough.component.tree.structure.TreeNode;
import com.jeramtough.jtlog.facade.L;
import component.dingtalk.DepartmentTreeNodeAdapter;
import component.dingtalk.net.DingTalkHttpClient;
import component.dingtalk.net.MyDingTalkHttpClient;
import org.junit.Test;

import java.io.File;
import java.util.*;

/**
 * Created on 2019/7/11 16:31
 * by @author WeiBoWen
 */
public class TestMain {

    @Test
    public void test1() {
        boolean root = true;

        File startFile = new File("C:\\Users\\weibw\\Desktop\\a\\c");
        LinkedList<File> tempFileLinkedList = new LinkedList<>();

        File rootFile;
        TreeNode rootTreeNode;
        Map<File, TreeNode> keyFileTreeStructureMap = new HashMap<>();


        if (root) {
            rootFile = startFile;
        }
        else {
            for (; ; ) {
                File parentFile = getParent(startFile);
                if (parentFile != null) {
                    startFile = parentFile;
                }
                else {
                    rootFile = startFile;
                    break;
                }
            }
        }


        rootTreeNode = new DefaultTreeNode(rootFile);

        if (hasSubs(rootFile)) {
            List<File> subFileList = getSubs(rootFile);
            for (File file : subFileList) {
                tempFileLinkedList.add(file);

                TreeNode treeNode = new DefaultTreeNode(file);
                rootTreeNode.addSub(treeNode);
                keyFileTreeStructureMap.put(file, treeNode);
            }

            File tempFile;
            while (!tempFileLinkedList.isEmpty()) {

                tempFile = tempFileLinkedList.removeFirst();
                TreeNode treeNode = keyFileTreeStructureMap.get(tempFile);

                if (hasSubs(tempFile)) {
                    List<File> subFileList1 = getSubs(tempFile);
                    for (File file1 : subFileList1) {
                        if (hasSubs(file1)) {
                            tempFileLinkedList.add(file1);
                        }
                        TreeNode treeNode1 = new DefaultTreeNode(file1);
                        keyFileTreeStructureMap.put(file1, treeNode1);
                        treeNode.addSub(treeNode1);
                    }
                }

            }
        }

        L.arrive();

    }


    @Test
    public void test() {

        File rootFile = new File("C:\\Users\\weibw\\Desktop");
        FileTreeNodeAdapter adapter = new FileTreeNodeAdapter(rootFile);
        TreeProcessor treeProcessor = new DefaultTreeProcessor();
        TreeNode treeNode = treeProcessor.processing(true, adapter);

        String detail = treeNode.getDetail();
        L.debug(detail);

    }


    @Test
    public void test2() {
        DingTalkHttpClient dingTalkHttpClient = new MyDingTalkHttpClient();
        TreeProcessor treeProcessor = new DefaultTreeProcessor();
        BaseTreeNodeAdapter adapter = new DepartmentTreeNodeAdapter(dingTalkHttpClient, 0L);
        TreeNode treeNode = treeProcessor.processing(true, adapter);

        if (treeNode.getSubs().size() > 0) {
            if (treeNode.getSubs().get(0).getBrothers().size() > 0) {
                L.debug(treeNode.getSubs().get(0).getBrothers().get(0).getDetail());
            }
        }
    }


    //**********
    private boolean hasSubs(File file) {
        if (file.isFile()) {
            return false;
        }

        if (file.listFiles() == null) {
            return false;
        }

        return true;
    }

    private List<File> getSubs(File file) {
        return Arrays.asList(Objects.requireNonNull(file.listFiles()));
    }

    private File getParent(File file) {
        File parentFile = file.getParentFile();
       /* if (!"Desktop".equalsIgnoreCase(parentFile.getName())) {
            return parentFile;
        }
        return null;*/
        return parentFile;
    }
}
