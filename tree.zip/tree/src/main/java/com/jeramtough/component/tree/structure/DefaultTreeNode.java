package com.jeramtough.component.tree.structure;

import com.jeramtough.component.tree.SortMethod;
import com.jeramtough.component.tree.foreach.CalledNode;
import com.jeramtough.component.tree.util.TreeNodeUtils;

import java.util.ArrayList;
import java.util.List;

/**
 * Created on 2019/7/11 15:44
 * by @author WeiBoWen
 */
public class DefaultTreeNode implements TreeNode {

    private Object value;
    private List<TreeNode> subTreeNodes;
    private TreeNode parentTreeNode;
    private int level = 0;

    public DefaultTreeNode() {
        subTreeNodes = new ArrayList<>();
    }

    public DefaultTreeNode(Object value) {
        this();
        this.value = value;
    }

    @Override
    public boolean isRoot() {
        return parentTreeNode == null;
    }

    @Override
    public boolean hasSubs() {
        return getSubs().size() > 0;
    }

    @Override
    public List<TreeNode> getSubs() {
        return subTreeNodes;
    }


    @Override
    public TreeNode getParent() {
        return parentTreeNode;
    }

    @Override
    public void setParent(TreeNode parentTreeNode) {
        this.parentTreeNode = parentTreeNode;
    }

    @Override
    public void addSub(TreeNode treeNode) {
        getSubs().add(treeNode);
        treeNode.setParent(this);
        treeNode.setLevel(this.level + 1);
    }

    @Override
    public Object getValue() {
        return value;
    }

    @Override
    public void setValue(Object value) {
        this.value = value;
    }

    @Override
    public int getLevel() {
        return level;
    }

    @Override
    public void setLevel(int level) {
        this.level = level;
    }

    @Override
    public List<TreeNode> getAll() {
        return TreeNodeUtils.getAll(this);
    }

    @Override
    public List<TreeNode> getAll(SortMethod sortMethod) {
        return TreeNodeUtils.getAll(this, sortMethod);
    }

    @Override
    public List<List<TreeNode>> getAllForLevel(SortMethod sortMethod) {
        return TreeNodeUtils.getAllForLevel(this, sortMethod);
    }

    @Override
    public List<TreeNode> getBrothers() {
        List<TreeNode> brothers = new ArrayList<>();
        foreach(new CalledNode() {
            @Override
            public void called(TreeNode treeNode) {
                if (treeNode.getLevel() == DefaultTreeNode.this.level &&
                        treeNode != DefaultTreeNode.this) {
                    brothers.add(treeNode);
                }
            }
        });
        return brothers;
    }

    @Override
    public void foreach(CalledNode calledNode) {
        TreeNodeUtils.foreach(this, calledNode);
    }


    @Override
    public String toString() {
        return "DefaultTreeNode{" +
                "value=" + value +
                ", level=" + level +
                '}';
    }

    @Override
    public String getDetail() {
        StringBuilder stringBuilder = new StringBuilder();

        foreach(new CalledNode() {
            @Override
            public void called(TreeNode treeNode) {
                stringBuilder.append(treeNode.toString()).append("\n");
            }
        });

        return stringBuilder.toString();
    }
}
