package com.jeramtough.component.tree.structure;

import com.jeramtough.component.tree.SortMethod;
import com.jeramtough.component.tree.foreach.CalledNode;

import java.util.List;

/**
 * Created on 2019/7/11 15:25
 * by @author WeiBoWen
 */
public interface TreeNode {

    boolean isRoot();

    List<TreeNode> getSubs();

    boolean hasSubs();

    TreeNode getParent();

    void setParent(TreeNode parentTreeNode);

    void addSub(TreeNode treeNode);

    Object getValue();

    void setValue(Object value);

    int getLevel();

    void setLevel(int level);

    List<TreeNode> getAll();

    List<TreeNode> getAll(SortMethod sortMethod);

    List<List<TreeNode>> getAllForLevel(SortMethod sortMethod);

    List<TreeNode> getBrothers();

    void foreach(CalledNode calledNode);

    String getDetail();
}
