package com.jeramtough.component.tree.foreach;

import com.jeramtough.component.tree.structure.TreeNode;

/**
 * Created on 2019/7/12 16:49
 * by @author WeiBoWen
 */
public interface CalledNode {

    void called(TreeNode treeNode);
}
