package com.jeramtough.component.tree.processor;

import com.jeramtough.component.tree.adapter.TreeNodeAdapter;
import com.jeramtough.component.tree.structure.TreeNode;

/**
 * Created on 2019/7/12 8:24
 * by @author WeiBoWen
 */
public interface TreeProcessor {

    TreeNode processing(boolean root, TreeNodeAdapter baseTreeNodeAdapter);

}
