package com.hwagain.sync.component.structure;

import java.util.*;

/**
 * Created on 2019-06-12 21:09
 * by @author JeramTough
 */
public class DefaultStructure implements Structure {

    private Object value;
    private Set<Structure> subStructures;
    private Structure parentStructure;
    private int level = 0;

    public DefaultStructure() {
        subStructures = new HashSet<>();
    }

    @Override
    public boolean isRoot() {
        return parentStructure == null;
    }

    @Override
    public boolean hasSubs() {
        return subStructures.size() > 0;
    }

    @Override
    public Structure[] getSubs() {
        return subStructures.toArray(new Structure[0]);
    }

    @Override
    public Structure getParent() {
        return parentStructure;
    }

    @Override
    public void setParent(Structure parentStructure) {
        this.parentStructure = parentStructure;
    }

    @Override
    public void addSub(Structure structure) {
        subStructures.add(structure);
        structure.setParent(this);
        structure.setLevel(this.level + 1);
    }

    @Override
    public Object getValue() {
        return value;
    }


    @Override
    public void setValue(Object value) {
        this.value = value;
    }

    @Override
    public int getLevel() {
        return level;
    }

    @Override
    public void setLevel(int level) {
        this.level = level;
    }


    //***************

}
