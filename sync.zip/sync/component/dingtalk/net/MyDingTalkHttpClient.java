package com.hwagain.sync.component.dingtalk.net;

import com.dingtalk.api.DefaultDingTalkClient;
import com.dingtalk.api.request.*;
import com.dingtalk.api.response.*;
import com.hwagain.sync.component.dingtalk.DingTalkConfig;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.hwagain.sync.component.dingtalk.transverter.DingtalkDepartmentTransverter;
import com.hwagain.sync.component.dingtalk.transverter.DingtalkEmployeeTransverter;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;
import com.hwagain.sync.component.log.MyLogRecorder;
import com.jeramtough.jtlog.annotation.LogConfiguration;
import com.jeramtough.jtlog.with.WithLogger;
import com.taobao.api.ApiException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Created on 2019/6/11 8:20
 * by @author JeramTough
 */
@Component("dingTalkHttpClient")
@LogConfiguration(logRecorders = MyLogRecorder.class)
public class MyDingTalkHttpClient implements DingTalkHttpClient, WithLogger {

    private String appKey;
    private String appSecret;

    private String corpId;
    private String ssoSecret;

    private String accessToken;
    private DefaultDingTalkClient dingTalkClient;
    private DingtalkEmployeeTransverter dingtalkEmployeeTransverter;
    private DingtalkDepartmentTransverter dingtalkDepartmentTransverter;

    @Autowired
    public MyDingTalkHttpClient(DingTalkConfig dingTalkConfig) {
        this(dingTalkConfig.getAppKey(), dingTalkConfig.getAppSecret(),
                dingTalkConfig.getCorpId(), dingTalkConfig.getSsoSecret());
    }

    public MyDingTalkHttpClient(String appKey, String appSecret, String corpId,
                                String ssoSecret) {
        this.appKey = appKey;
        this.appSecret = appSecret;
        this.ssoSecret = ssoSecret;
        this.corpId = corpId;
        init();
    }

    protected void init() {
        dingTalkClient = new DefaultDingTalkClient("https://oapi.dingtalk" +
                ".com/gettoken");

        if (appKey != null) {
            refreshTokenByAppKey();
        }
        if (corpId != null) {
            refreshTokenByCorpId();
        }

        dingtalkEmployeeTransverter = new DingtalkEmployeeTransverter();
        dingtalkDepartmentTransverter = new DingtalkDepartmentTransverter();
    }

    @Override
    public String refreshTokenByAppKey() {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/gettoken");
        OapiGettokenRequest request = new OapiGettokenRequest();
        request.setAppkey(appKey);
        request.setAppsecret(appSecret);
        request.setHttpMethod("GET");
        try {
            OapiGettokenResponse response = dingTalkClient.execute(request);
            if (response.getErrcode() == 0) {
                this.accessToken = response.getAccessToken();
            }
            else {
                return null;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
        return accessToken;
    }

    @Override
    public String refreshTokenByCorpId() {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/sso/gettoken");
        OapiSsoGettokenRequest request = new OapiSsoGettokenRequest();
        request.setCorpid(corpId);
        request.setCorpsecret(ssoSecret);
        request.setHttpMethod("GET");
        try {
            OapiSsoGettokenResponse response = dingTalkClient.execute(request);
            accessToken = response.getAccessToken();
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        return accessToken;
    }

    @Override
    public List<String> getDeptMemberList(Long departmentId) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/getDeptMember");
        OapiUserGetDeptMemberRequest req = new OapiUserGetDeptMemberRequest();
        req.setDeptId(departmentId + "");
        req.setHttpMethod("GET");
        OapiUserGetDeptMemberResponse response = null;
        try {
            response = dingTalkClient.execute(req, accessToken);
            if (response != null && response.getErrcode() == 0) {
                getLogger().debug("获取[%s]部门的职员Id列表成功", departmentId);
                return response.getUserIds();
            }
            else {
                getLogger().warn("获取[%d]的职员Id列表失败,因为%s", departmentId,
                        response != null ? response.getErrmsg() : null);
            }

        }
        catch (ApiException e) {
            e.printStackTrace();
            getLogger().error("获取[%d]的职员Id列表失败,因为服务器响应为null");
        }
        return new ArrayList<>();
    }


    @Override
    public DingtalkEmployee getDingtalkEmployee(String userId) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/get");
        OapiUserGetRequest request = new OapiUserGetRequest();
        request.setUserid(userId);
        request.setHttpMethod("GET");
        OapiUserGetResponse response = null;
        try {
            response = dingTalkClient.execute(request, accessToken);
            if (response != null && response.getErrcode() == 0) {
                getLogger().debug("成功获取[" + userId +
                        "]的钉钉职工信息");
                return dingtalkEmployeeTransverter.getDingtalkEmployee(response);
            }
            else {
                getLogger().warn("失败获取[" + userId +
                        "]的钉钉职工信息，因为" + (response != null ? response.getErrmsg() : null));
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public Map<String, DingtalkEmployee> getAllEmployees() {
        //以员工工号作为键
        Map<String, DingtalkEmployee> dingtalkEmployeeMap = new HashMap<>(1000);
        ExecutorService executorService = getExecutorService();

        //TODO:
       /* if (true) {
            return dingtalkEmployeeMap;
        }*/

        List<String> userIds = new ArrayList<>();
        List<DingtalkDepartment> departments = getSubDepartmentList(1);

        CountDownLatch departmentsLatch = new CountDownLatch(departments.size());
        for (int i = 0; i < departments.size(); i++) {
            int finalI = i;
            executorService.submit(() -> {
                DingtalkDepartment dingtalkDepartment = departments.get(finalI);
                List<String> tempUserIds = getDeptMemberList(dingtalkDepartment.getId());
                userIds.addAll(tempUserIds);
                getLogger().debug("获取[%s]部门[%d]人完毕，剩余[%d]个部门",
                        dingtalkDepartment.getName(),
                        tempUserIds.size(), departmentsLatch.getCount() - 1);

                departmentsLatch.countDown();
            });
        }
        try {
            departmentsLatch.await();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }

        CountDownLatch employeesLatch = new CountDownLatch(userIds.size());

        getLogger().debug("所有部门Id列表获取成功，开始获取钉钉员工信息详情\n。。。");

        AtomicLong failedCount = new AtomicLong();
        for (String userId : userIds) {
            executorService.submit(() -> {
                DingtalkEmployee dingtalkEmployee = getDingtalkEmployee(userId);
                if (dingtalkEmployee != null) {
                    dingtalkEmployeeMap.put(dingtalkEmployee.getJobnumber(), dingtalkEmployee);
                }
                else {
                    failedCount.getAndIncrement();
                }
                employeesLatch.countDown();
            });
        }

        executorService.shutdown();
        try {
            employeesLatch.await();
            getLogger().debug("获取所有员工信息完毕，共[%d]人成功，共[%d]人失败", dingtalkEmployeeMap.size(),
                    failedCount.get());
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        return dingtalkEmployeeMap;
    }


    @Override
    public int createBundleEmployees(List<DingtalkEmployee> dingtalkEmployees) {
        return doBundleEmployeeOperation(dingtalkEmployees, 0);
    }

    @Override
    public boolean createEmployee(DingtalkEmployee dingtalkEmployee) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/create");
        OapiUserCreateRequest request =
                dingtalkEmployeeTransverter.getOapiUserCreateRequest(dingtalkEmployee);
        String errMessage = "";
        try {
            OapiUserCreateResponse response = dingTalkClient.execute(request, accessToken);
            if (response.isSuccess() && response.getErrcode() == 0) {
                getLogger().debug("创建新钉钉员工UserId[%s]【成功】", dingtalkEmployee.getUserId());
                return true;
            }
            errMessage = response.getErrmsg();
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        getLogger().warn("创建新钉钉员工UserId[%s]【失败】，因为%s", dingtalkEmployee.getUserId(),
                errMessage);
        return false;
    }

    @Override
    public boolean updateEmployee(DingtalkEmployee dingtalkEmployee) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/update");
        OapiUserUpdateRequest request =
                dingtalkEmployeeTransverter.getOapiUserUpdateRequest(dingtalkEmployee);

        String errMessage = "";
        try {
            OapiUserUpdateResponse response = dingTalkClient.execute(request, accessToken);
            if (response.isSuccess() && response.getErrcode() == 0) {
                getLogger().debug("更新钉钉员工UserId[%s]信息【成功】", dingtalkEmployee.getUserId());
                return true;
            }
            errMessage = response.getErrmsg();
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        getLogger().warn("更新钉钉员工UserId[%s]信息【失败】,因为%s", dingtalkEmployee.getUserId(),
                errMessage);
        return false;
    }

    @Override
    public int updateBundleEmployees(List<DingtalkEmployee> dingtalkEmployees) {
        return doBundleEmployeeOperation(dingtalkEmployees, 1);
    }

    @Override
    public boolean deleteEmployee(DingtalkEmployee dingtalkEmployee) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/delete");
        OapiUserDeleteRequest request = new OapiUserDeleteRequest();
        request.setUserid(dingtalkEmployee.getUserId());
        request.setHttpMethod("GET");

        String errMessage = "";
        try {
            OapiUserDeleteResponse response = dingTalkClient.execute(request, accessToken);
            if (response.isSuccess() && response.getErrcode() == 0) {
                getLogger().debug("删除钉钉员工UserId[%s]信息【成功】", dingtalkEmployee.getUserId());
                return true;
            }
            errMessage = response.getErrmsg();
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        getLogger().warn("删除钉钉员工UserId[%s]信息【失败】，因为%s", dingtalkEmployee.getUserId(),
                errMessage);
        return false;
    }

    @Override
    public int deleteBundleEmployees(List<DingtalkEmployee> dingtalkEmployees) {
        return doBundleEmployeeOperation(dingtalkEmployees, 2);
    }

    @Override
    @Deprecated
    public List<DingtalkDepartment> getSubDepartmentList(int departmentId) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/department/list");
        OapiDepartmentListRequest request = new OapiDepartmentListRequest();

        request.setId(departmentId + "");
        //递归查询设为true
        request.setFetchChild(true);
        request.setHttpMethod("GET");
        try {
            OapiDepartmentListResponse response = dingTalkClient.execute(request,
                    accessToken);
            if (response != null && response.getErrcode() == 0) {
                getLogger().debug("从钉钉获取所有部门信息成功");
                return dingtalkDepartmentTransverter.getDingtalkDepartmentList(
                        response.getDepartment());
            }
            else {
                getLogger().error("从钉钉获取所有部门信息失败,因为%s",
                        response != null ? response.getErrmsg() : null);
                return null;
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public List<Long> getSubDepartmentIdList(Long departmentId) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/department/list_ids");
        OapiDepartmentListIdsRequest request = new OapiDepartmentListIdsRequest();
        request.setId(departmentId + "");
        request.setHttpMethod("GET");
        try {
            OapiDepartmentListIdsResponse response = dingTalkClient.execute(request,
                    accessToken);
            if (response.getErrcode() == 0) {
                getLogger().debug("从钉钉获取所有部门Id[%d]列表成功", departmentId);
                return response.getSubDeptIdList();
            }
            else {
                getLogger().error("从钉钉获取所有部门Id列表失败,因为%s",
                        response.getErrmsg());
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public List<Long> getAllSubDepartmentIdList() {
        List<Long> allIds = new ArrayList<>();
        List<Long> tempIds = new LinkedList<>();

        List<Long> rootIds = getSubDepartmentIdList(1L);
        allIds.add(1L);

        for (Long id : rootIds) {
            List<Long> idds = getSubDepartmentIdList(id);
            allIds.addAll(idds);
            tempIds.addAll(idds);
        }

        Long tempId;
        while (tempIds.size() > 0) {
            tempId = tempIds.get(0);
            tempIds.remove(0);

            List<Long> ids = getSubDepartmentIdList(tempId);
            allIds.addAll(ids);

            for (Long id : ids) {
                List<Long> ids2 = getSubDepartmentIdList(id);
                if (ids2.size() > 0) {
                    tempIds.addAll(ids2);
                }
                allIds.addAll(ids2);
            }
        }
        return allIds;
    }

    @Override
    public List<DingtalkDepartment> getAllSubDepartmentList() {
        List<Long> ids = getAllSubDepartmentIdList();
        List<DingtalkDepartment> dingtalkDepartments = new ArrayList<>();
        for (Long id : ids) {
            dingtalkDepartments.add(getDepartment(id));
        }
        return dingtalkDepartments;
    }

    @Override
    public DingtalkDepartment getDepartment(Long departmentId) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/department/get");
        OapiDepartmentGetRequest request = new OapiDepartmentGetRequest();
        request.setId(departmentId + "");
        request.setHttpMethod("GET");
        try {
            OapiDepartmentGetResponse response = dingTalkClient.execute(request, accessToken);
            if (response != null && response.getErrcode() == 0) {
                DingtalkDepartment dingtalkDepartment =
                        dingtalkDepartmentTransverter.getDingtalkDepartment(response);
                getLogger().debug("成功获取[%d%s]部门信息", departmentId,
                        dingtalkDepartment.getName());
                return dingtalkDepartment;
            }
            else {
                getLogger().debug("失败获取[%d]部门信息，因为%s", departmentId,
                        response != null ? response.getErrmsg() : null);
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        return null;
    }

    @Override
    public boolean createdDepartment(DingtalkDepartment dingtalkDepartment) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/department/create");
        OapiDepartmentCreateRequest request = new OapiDepartmentCreateRequest();
        request.setParentid("1");
        request.setCreateDeptGroup(false);
        request.setName(dingtalkDepartment.getName());
        request.setSourceIdentifier(dingtalkDepartment.getSourceIdentifier());
        OapiDepartmentCreateResponse response = null;
        try {
            response = dingTalkClient.execute(request, accessToken);
            if (response != null && response.getErrcode() == 0) {
                getLogger().debug("创建部门[%s]成功",
                        dingtalkDepartment.getSourceIdentifier() + "_" + dingtalkDepartment.getName());
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        if (response != null && response.getErrcode() == 0) {
            return true;
        }
        getLogger().warn("创建部门[%s]失败%s", dingtalkDepartment.getSourceIdentifier(),
                response != null ? ",因为" + response.getErrmsg() : "");
        return false;
    }

    @Override
    public boolean updateDepartment(DingtalkDepartment dingtalkDepartment) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/department/update");
        OapiDepartmentUpdateRequest request =
                dingtalkDepartmentTransverter.getOapiDepartmentUpdateRequest(
                        dingtalkDepartment);
        try {
            OapiDepartmentUpdateResponse response = dingTalkClient.execute(request,
                    accessToken);
            if (response != null && response.getErrcode() == 0) {
                getLogger().debug("%d更新部门[%d-%s]成功",
                        response != null ? response.getErrcode() : null,
                        dingtalkDepartment.getId(),
                        dingtalkDepartment.getName());
                return true;
            }
            else {
                getLogger().debug("%d更新部门[%d-%s]失败，因为%s",
                        response != null ? response.getErrcode() : null,
                        dingtalkDepartment.getId(),
                        dingtalkDepartment.getName(),
                        response != null ? response.getErrmsg() : null);
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
            getLogger().debug("更新部门[%d-%s]失败，因为服务器响应为null", dingtalkDepartment.getId(),
                    dingtalkDepartment.getName());
        }
        return false;
    }

    @Override
    public long updateBundleDepartments(List<DingtalkDepartment> dingtalkDepartments) {
        ExecutorService executorService = getExecutorService();
        CountDownLatch latch = new CountDownLatch(dingtalkDepartments.size());
        AtomicLong failedCount = new AtomicLong();
        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            executorService.submit(() -> {
                boolean isSuccessful = updateDepartment(dingtalkDepartment);
                if (!isSuccessful) {
                    failedCount.getAndIncrement();
                }
                getLogger().debug("更新部门[%s]完毕，剩余更新数[%d]", dingtalkDepartment.getName(),
                        latch.getCount() - 1);
                latch.countDown();
            });
        }

        try {
            latch.await();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }

        return failedCount.get();
    }


    @Override
    public int createdBundleDepartments(
            List<DingtalkDepartment> dingtalkDepartments) {

        AtomicInteger failedCount = new AtomicInteger();

        if (dingtalkDepartments.size() == 0) {
            return failedCount.get();
        }

        CountDownLatch latch = new CountDownLatch(dingtalkDepartments.size());
        ExecutorService executorService = getExecutorService();

        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            executorService.submit(() -> {
                boolean isSuccessful = createdDepartment(dingtalkDepartment);
                if (!isSuccessful) {
                    failedCount.getAndIncrement();
                }
                getLogger().debug("剩余部门创建数为[%d]",
                        latch.getCount() - 1);
                latch.countDown();
            });
        }

        try {
            executorService.shutdown();
            latch.await();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }

        return failedCount.get();
    }

    @Override
    @Deprecated
    public int createdBundleDepartments(Collection<DingtalkDepartment> dingtalkDepartments) {
        int failedCount = 0;
        int index = 0;
        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            if (!createdDepartment(dingtalkDepartment)) {
                failedCount++;
            }
            getLogger().debug("正在创建第[%d]个部门，剩余为创建数[%d]", index,
                    dingtalkDepartments.size() - 1 - index);
            index++;
        }
        return failedCount;
    }

    @Override
    public boolean deleteDepartment(DingtalkDepartment dingtalkDepartment) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/department/delete");
        OapiDepartmentDeleteRequest request = new OapiDepartmentDeleteRequest();
        request.setId(dingtalkDepartment.getId() + "");
        request.setHttpMethod("GET");
        try {
            OapiDepartmentDeleteResponse response = dingTalkClient.execute(request,
                    accessToken);
            if (response != null && response.getErrcode() == 0) {
                getLogger().debug(
                        "删除部门[%s]成功",
                        dingtalkDepartment.getSourceIdentifier() + dingtalkDepartment.getName()
                );
                return true;
            }
            else {
                getLogger().warn("删除部门[%s]失败,因为%s", dingtalkDepartment.getName(),
                        response != null ? response.getErrmsg() : "请求失败response为null");
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        getLogger().warn("删除部门[%s]失败", dingtalkDepartment.getName());
        return false;
    }

    @Override
    public long deleteBundleDepartments(List<DingtalkDepartment> dingtalkDepartments) {
        ExecutorService executorService = getExecutorService();
        CountDownLatch latch = new CountDownLatch(dingtalkDepartments.size());
        AtomicLong failedCount = new AtomicLong();
        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            executorService.submit(() -> {
                boolean isSuccessful = deleteDepartment(dingtalkDepartment);
                if (!isSuccessful) {
                    failedCount.getAndIncrement();
                }
                getLogger().debug("删除部门[%s]完毕，剩余删除数[%d]", dingtalkDepartment.getName(),
                        latch.getCount() - 1);
                latch.countDown();
            });
        }

        try {
            latch.await();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }

        return failedCount.get();
    }

    //*************

    private ExecutorService getExecutorService() {
        //由于钉钉api调用有频率限制，并发调用数还是10以内好了
        int processCount = 3;
        ExecutorService executorService = executorService = new ThreadPoolExecutor(
                processCount, Integer.MAX_VALUE, 1800L, TimeUnit.MINUTES,
                new LinkedBlockingQueue<Runnable>());
        return executorService;
    }

    private int doBundleEmployeeOperation(List<DingtalkEmployee> dingtalkEmployees, int sign) {

        if (dingtalkEmployees.size() == 0) {
            return 0;
        }

        int failCount = 0;
        ExecutorService executorService = getExecutorService();
        List<Future<Boolean>> futures = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(dingtalkEmployees.size());

        for (DingtalkEmployee dingtalkEmployee : dingtalkEmployees) {
            futures.add(executorService.submit((Callable<Boolean>) () -> {
                boolean isSuccessful = false;
                switch (sign) {
                    case 0:
                        isSuccessful = createEmployee(dingtalkEmployee);
                        break;
                    case 1:
                        isSuccessful = updateEmployee(dingtalkEmployee);
                        break;
                    case 2:
                        isSuccessful = deleteEmployee(dingtalkEmployee);
                        break;
                    default:
                        break;
                }
                latch.countDown();
                return isSuccessful;
            }));
        }

        try {
            executorService.shutdown();
            latch.await();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        finally {
            for (Future<Boolean> future : futures) {
                try {
                    if (future.get() == null || !future.get()) {
                        failCount++;
                    }
                }
                catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
            }
        }

        return failCount;
    }

}
