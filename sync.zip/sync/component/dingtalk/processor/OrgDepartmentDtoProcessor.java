package com.hwagain.sync.component.dingtalk.processor;

import com.hwagain.framework.api.org.dto.SysOrgDepartmentDto;
import com.hwagain.sync.component.proxy.SysOrgDepartmentProxy;
import com.hwagain.sync.component.structure.DefaultStructure;
import com.hwagain.sync.component.structure.Structure;
import com.jeramtough.jtlog.facade.L;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created on 2019-06-12 20:59
 * by @author JeramTough
 */
public class OrgDepartmentDtoProcessor implements StructureProcessor {

    private List<SysOrgDepartmentDto> sysOrgDepartmentDtos;

    //以华劲部门departmentNumber作为键
    private Map<String, SysOrgDepartmentDto> departmentDtoMap;

    // //以华劲部门departmentNumber作为键
    private Map<String, Structure> structureMap;

    public OrgDepartmentDtoProcessor(SysOrgDepartmentProxy sysOrgDepartmentProxy) {
        this.sysOrgDepartmentDtos = sysOrgDepartmentProxy.getSysOrgDepartmentDtos();
        this.departmentDtoMap = sysOrgDepartmentProxy.getDepartmentNumberDepartmentDtoMap();
        structureMap = new HashMap<>();
    }

    public OrgDepartmentDtoProcessor(
            List<SysOrgDepartmentDto> sysOrgDepartmentDtos,
            Map<String, SysOrgDepartmentDto> departmentDtoMap) {
        this.sysOrgDepartmentDtos = sysOrgDepartmentDtos;
        this.departmentDtoMap = departmentDtoMap;

        structureMap = new HashMap<>();
    }

    @Override
    public Structure processing() {
        Structure rootStructure = new DefaultStructure();

        try {
            for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {

                Structure structure = structureMap.get(
                        sysOrgDepartmentDto.getDepartmentNumber());
                Structure parentStructure = structureMap.get(
                        sysOrgDepartmentDto.getFdParentid());
                if (structure == null) {
                    structure = new DefaultStructure();
                    structure.setValue(sysOrgDepartmentDto.getFdId());
                    structureMap.put(sysOrgDepartmentDto.getDepartmentNumber(), structure);
                }
                if (parentStructure == null && sysOrgDepartmentDto.getFdParentid() != null) {
                    parentStructure = new DefaultStructure();
                    SysOrgDepartmentDto parentSysOrgDepartmentDto =
                            departmentDtoMap.get(sysOrgDepartmentDto.getFdParentid());
                    parentStructure.setValue(parentSysOrgDepartmentDto.getFdId());
                    structureMap.put(parentSysOrgDepartmentDto.getDepartmentNumber(),
                            parentStructure);
                }

                if (parentStructure != null) {
                    parentStructure.addSub(structure);
                }
                else {
                    rootStructure.addSub(structure);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return rootStructure;
    }
}
