package com.hwagain.sync;

import com.hwagain.sync.service.SyncSchedulingService;
import com.jeramtough.jtlog.facade.L;
import com.jeramtough.jtlog.with.WithLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.ApplicationArguments;
import org.springframework.boot.ApplicationRunner;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

/**
 * Created on 2019/7/5 10:40
 * by @author WeiBoWen
 */
@Component
public class ApplicationStarter implements ApplicationRunner, WithLogger {

    private final Environment environment;
    private final SyncSchedulingService syncSchedulingService;

    @Autowired
    public ApplicationStarter(Environment environment,
                              SyncSchedulingService syncSchedulingService) {
        this.environment = environment;
        this.syncSchedulingService = syncSchedulingService;
    }

    @Override
    public void run(ApplicationArguments args) throws Exception {
        Properties properties = new Properties();
        FileInputStream in = new FileInputStream("." + File.separator + "sync.properties");
        properties.load(in);

        boolean isSyncOnceStarted = Boolean.parseBoolean(
                properties.getProperty("isSyncOnceStarted"));
        if (isSyncOnceStarted) {
            getLogger().info("执行同步任务开始");
            syncSchedulingService.executeSyncDepartmentTask();
            syncSchedulingService.executeSyncEmployeeTask();
            getLogger().info("执行同步任务结束");
        }

        in.close();
    }
}
