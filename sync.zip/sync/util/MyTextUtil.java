package com.hwagain.sync.util;

/**
 * Created on 2019/6/17 17:14
 * by @author WeiBoWen
 */
public class MyTextUtil {

    /**
     * 去掉字符串两头空格
     *
     * @param textContent 字符串
     */
    public static String trim(String textContent) {
        textContent = textContent.trim();
        //这里判断是不是全角空格
        while (textContent.startsWith("　")) {
            textContent = textContent.substring(1, textContent.length()).trim();
        }
        while (textContent.endsWith("　")) {
            textContent = textContent.substring(0, textContent.length() - 1).trim();
        }
        return textContent;
    }
}
