package com.hwagain.sync.component.dingtalk;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

/**
 * Created on 2019/6/11 9:41
 * by @author JeramTough
 */
@Component
public class DingTalkConfig {

    private String appKey;

    private String appSecret;

    private String corpId;

    private String ssoSecret;

    public DingTalkConfig() throws Exception {
        Properties properties = new Properties();
        FileInputStream in = new FileInputStream("." + File.separator + "sync.properties");
        properties.load(in);

        appKey = properties.getProperty("appKey");
        appSecret = properties.getProperty("appSecret");

        in.close();
    }

    public String getAppKey() {
        return appKey;
    }

    public void setAppKey(String appKey) {
        this.appKey = appKey;
    }

    public String getAppSecret() {
        return appSecret;
    }

    public void setAppSecret(String appSecret) {
        this.appSecret = appSecret;
    }

    public String getCorpId() {
        return corpId;
    }

    public void setCorpId(String corpId) {
        this.corpId = corpId;
    }

    public String getSsoSecret() {
        return ssoSecret;
    }

    public void setSsoSecret(String ssoSecret) {
        this.ssoSecret = ssoSecret;
    }
}
