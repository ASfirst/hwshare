package com.hwagain.sync.component.dingtalk;

import com.dingtalk.api.response.OapiUserGetResponse;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;

import javax.validation.constraints.NotNull;

/**
 * Created on 2019/6/11 14:40
 * by @author JeramTough
 */

public class DingtalkEmployeeProcessor {

    public @NotNull DingtalkEmployee processing(OapiUserGetResponse response){
        DingtalkEmployee dingtalkEmployee=new DingtalkEmployee();
        dingtalkEmployee.setAvatar(response.getAvatar());
        dingtalkEmployee.setDepartment(response.getDepartment());
        dingtalkEmployee.setEmail(response.getEmail());
        dingtalkEmployee.setExtattr(response.getExtattr());
        dingtalkEmployee.setHiredDate(response.getHiredDate());
        dingtalkEmployee.setIsActived(response.getActive());
        dingtalkEmployee.setIsAdmin(response.getIsAdmin());
        dingtalkEmployee.setIsBoss(response.getIsBoss());
        dingtalkEmployee.setJobnumber(response.getJobnumber());
        dingtalkEmployee.setMobile(response.getMobile());
        dingtalkEmployee.setName(response.getName());
        dingtalkEmployee.setOrderInDepts(response.getOrderInDepts());
        dingtalkEmployee.setOrgEmail(response.getOrgEmail());
        dingtalkEmployee.setPosition(response.getPosition());
        dingtalkEmployee.setRemark(response.getRemark());
        dingtalkEmployee.setTel(response.getTel());
        dingtalkEmployee.setUnionid(response.getUnionid());
        dingtalkEmployee.setUserId(response.getUserid());
        dingtalkEmployee.setWorkPlace(response.getWorkPlace());
        return dingtalkEmployee;
    }

}
