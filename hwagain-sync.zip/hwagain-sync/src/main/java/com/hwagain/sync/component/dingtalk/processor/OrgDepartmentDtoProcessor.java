package com.hwagain.sync.component.dingtalk.processor;

import com.hwagain.framework.api.org.dto.SysOrgDepartmentDto;
import com.hwagain.sync.component.proxy.SysOrgDepartmentProxy;
import com.hwagain.sync.component.structure.DefaultStructure;
import com.hwagain.sync.component.structure.Structure;
import com.jeramtough.jtlog.facade.L;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created on 2019-06-12 20:59
 * by @author JeramTough
 */
public class OrgDepartmentDtoProcessor implements StructureProcessor {

    private List<SysOrgDepartmentDto> sysOrgDepartmentDtos;

    //以华劲部门departmentNumber作为键
    private Map<String, SysOrgDepartmentDto> departmentDtoMap;

    // //以华劲部门departmentNumber作为键
    private Map<String, Structure> structureMap;

    @Deprecated
    public OrgDepartmentDtoProcessor(
            List<SysOrgDepartmentDto> sysOrgDepartmentDtos) {
        this.sysOrgDepartmentDtos = sysOrgDepartmentDtos;
        departmentDtoMap = new HashMap<>();
        structureMap = new HashMap<>();

        init();
    }

    public OrgDepartmentDtoProcessor(SysOrgDepartmentProxy sysOrgDepartmentProxy) {
        structureMap = new HashMap<>();

        this.sysOrgDepartmentDtos = sysOrgDepartmentProxy.getSysOrgDepartmentDtos();
        this.departmentDtoMap = sysOrgDepartmentProxy.getDepartmentNumberDepartmentDtoMap();
    }

    protected void init() {
        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            //因为根部门parentId不为空，而是 ，-。-
            if (sysOrgDepartmentDto.getFdParentid().equals(" ")) {
                sysOrgDepartmentDto.setFdParentid(null);
            }
            departmentDtoMap.put(sysOrgDepartmentDto.getDepartmentNumber(),
                    sysOrgDepartmentDto);
        }
    }

    @Override
    public Structure processing() {
        Structure rootStructure = new DefaultStructure();

        try {
            for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {

                Structure structure = structureMap.get(
                        sysOrgDepartmentDto.getDepartmentNumber());
                Structure parentStructure = structureMap.get(
                        sysOrgDepartmentDto.getFdParentid());
                if (structure == null) {
                    structure = new DefaultStructure();
                    structure.setValue(sysOrgDepartmentDto.getFdId());
                    structureMap.put(sysOrgDepartmentDto.getDepartmentNumber(), structure);
                }
                if (parentStructure == null && sysOrgDepartmentDto.getFdParentid() != null) {
                    parentStructure = new DefaultStructure();
                    SysOrgDepartmentDto parentSysOrgDepartmentDto =
                            departmentDtoMap.get(sysOrgDepartmentDto.getFdParentid());
                    parentStructure.setValue(parentSysOrgDepartmentDto.getFdId());
                    structureMap.put(parentSysOrgDepartmentDto.getDepartmentNumber(),
                            parentStructure);
                }

                if (parentStructure != null) {
                    parentStructure.addSub(structure);
                }
                else {
                    rootStructure.addSub(structure);
                }
            }
        }
        catch (Exception e) {
            e.printStackTrace();
        }

        return rootStructure;
    }
}
