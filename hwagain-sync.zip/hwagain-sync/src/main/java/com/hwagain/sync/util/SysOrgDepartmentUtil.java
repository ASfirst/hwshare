package com.hwagain.sync.util;

import com.hwagain.framework.api.org.dto.SysOrgDepartmentDto;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.jeramtough.jtlog.facade.L;

import java.util.ArrayList;
import java.util.List;

/**
 * Created on 2019/6/12 14:53
 * by @author WeiBoWen
 */
public class SysOrgDepartmentUtil {

    public static DingtalkDepartment toDingtalkDepartment(
            SysOrgDepartmentDto sysOrgDepartmentDto) {
        DingtalkDepartment dingtalkEmployee = new DingtalkDepartment();
        dingtalkEmployee.setSourceIdentifier(sysOrgDepartmentDto.getFdId());
        dingtalkEmployee.setOrder(sysOrgDepartmentDto.getFdOrder().longValue());
        dingtalkEmployee.setName(sysOrgDepartmentDto.getDisplayName());
        return dingtalkEmployee;
    }

    public static List<DingtalkDepartment> toDingtalkDepartments(
            List<SysOrgDepartmentDto> sysOrgDepartmentDtos) {
        List<DingtalkDepartment> dingtalkDepartments = new ArrayList<>();
        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            dingtalkDepartments.add(toDingtalkDepartment(sysOrgDepartmentDto));
        }
        return dingtalkDepartments;
    }
}
