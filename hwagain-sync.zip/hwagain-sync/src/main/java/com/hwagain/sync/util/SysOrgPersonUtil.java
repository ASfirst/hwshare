package com.hwagain.sync.util;

import com.hwagain.framework.api.org.dto.SysOrgDepartmentDto;
import com.hwagain.framework.api.org.dto.SysOrgPersonDto;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;
import com.jeramtough.jtlog.facade.L;

import java.util.Collections;

/**
 * 关于SysOrgPersonDto的工具类Util
 * Created on 2019/6/11 16:30
 * by @author WeiBoWen
 */
public class SysOrgPersonUtil {

    /**
     * 将华劲员工对象转换成钉钉员工对象
     *
     * @param sysOrgPersonDto 华劲员工
     * @return 钉钉员工
     */
    public static DingtalkEmployee toDingtalkEmployee(SysOrgPersonDto sysOrgPersonDto,
                                                      DingtalkDepartment dingtalkDepartment) {
        DingtalkEmployee dingtalkEmployee = new DingtalkEmployee();
        //工号后两位
        String sign = "";
        if (sysOrgPersonDto.getFdEmployeeNumber() != null) {
            sign = sysOrgPersonDto.getFdEmployeeNumber().substring(
                    sysOrgPersonDto.getFdEmployeeNumber().length() - 2);
        }
        else {
            L.arrive();
        }

        dingtalkEmployee.setName(sysOrgPersonDto.getFdName() + sign);
        dingtalkEmployee.setUserId(sysOrgPersonDto.getFdId());
        dingtalkEmployee.setEmail(sysOrgPersonDto.getFdEmail());
        dingtalkEmployee.setDepartment(Collections.singletonList(dingtalkDepartment.getId()));
        dingtalkEmployee.setMobile(sysOrgPersonDto.getFdMobile());
        dingtalkEmployee.setHiredDate(sysOrgPersonDto.getFdCreateTime());
        dingtalkEmployee.setPosition(sysOrgPersonDto.getFdPositionName());
        dingtalkEmployee.setJobnumber(sysOrgPersonDto.getFdEmployeeNumber());

        return dingtalkEmployee;
    }

    /**
     * 比较华劲员工是否和钉钉员工是同一个人
     *
     * @param sysOrgPersonDto  华劲员工
     * @param dingtalkEmployee 钉钉员工
     * @return 是否是同一个员工
     */
    public static boolean equalDingtalkEmployee(SysOrgPersonDto sysOrgPersonDto,
                                                DingtalkEmployee dingtalkEmployee) {
        return sysOrgPersonDto.getFdEmployeeNumber().equals(dingtalkEmployee.getJobnumber());
    }


    /**
     * 华劲员工是否以更新，是否需要修改钉钉员工信息
     *
     * @param sysOrgPersonDto  华劲员工
     * @param dingtalkEmployee 钉钉员工
     * @return 是否是同一个员工
     */
    public static boolean isModified(SysOrgPersonDto sysOrgPersonDto,
                                     DingtalkEmployee dingtalkEmployee,
                                     DingtalkDepartment oldDingtalkDepartment,
                                     DingtalkDepartment currentDingtalkDepartment) {

        if (!currentDingtalkDepartment.getSourceIdentifier().equals(
                oldDingtalkDepartment.getSourceIdentifier())) {
            return true;
        }

        if (!dingtalkEmployee.getName().equals(sysOrgPersonDto.getFdName())) {
            return true;
        }

        if (!dingtalkEmployee.getUserId().equals(sysOrgPersonDto.getFdId())) {
            return true;
        }

        if (!dingtalkEmployee.getEmail().equals(sysOrgPersonDto.getFdEmail())) {
            return true;
        }

        if (!dingtalkEmployee.getMobile().equals(
                sysOrgPersonDto.getFdMobile())) {
            return true;
        }

        if (!dingtalkEmployee.getHiredDate().equals(
                sysOrgPersonDto.getFdCreateTime())) {
            return true;
        }

        if (!dingtalkEmployee.getPosition().equals(
                sysOrgPersonDto.getFdPortalName())) {
            return true;
        }
        return false;
    }
}
