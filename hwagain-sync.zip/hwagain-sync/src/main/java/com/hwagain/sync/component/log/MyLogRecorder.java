package com.hwagain.sync.component.log;

import com.jeramtough.jtlog.recorder.FileLogRecorder;

import java.io.File;

/**
 * Created on 2019/6/19 10:44
 * by @author WeiBoWen
 */
public class MyLogRecorder extends FileLogRecorder {


    public MyLogRecorder() {
        super(new File("." + File.separator + "log" + File.separator + "hw-sync.log"));
    }


}
