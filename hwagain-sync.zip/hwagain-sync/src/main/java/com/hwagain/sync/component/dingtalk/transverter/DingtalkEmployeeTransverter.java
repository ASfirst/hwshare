package com.hwagain.sync.component.dingtalk.transverter;

import com.alibaba.fastjson.JSON;
import com.dingtalk.api.request.OapiUserCreateRequest;
import com.dingtalk.api.request.OapiUserUpdateRequest;
import com.dingtalk.api.response.OapiUserGetResponse;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;

import javax.validation.constraints.NotNull;

/**
 * Created on 2019/6/11 14:40
 * by @author JeramTough
 */

public class DingtalkEmployeeTransverter {

    public @NotNull
    DingtalkEmployee getDingtalkEmployee(OapiUserGetResponse response) {
        DingtalkEmployee dingtalkEmployee = new DingtalkEmployee();
        dingtalkEmployee.setAvatar(response.getAvatar());
        dingtalkEmployee.setDepartment(response.getDepartment());
        dingtalkEmployee.setEmail(response.getEmail());
        dingtalkEmployee.setExtattr(response.getExtattr());
        dingtalkEmployee.setHiredDate(response.getHiredDate());
        dingtalkEmployee.setIsActived(response.getActive());
        dingtalkEmployee.setIsAdmin(response.getIsAdmin());
        dingtalkEmployee.setIsBoss(response.getIsBoss());
        dingtalkEmployee.setJobnumber(response.getJobnumber());
        dingtalkEmployee.setMobile(response.getMobile());
        dingtalkEmployee.setName(response.getName());
        dingtalkEmployee.setOrderInDepts(response.getOrderInDepts());
        dingtalkEmployee.setOrgEmail(response.getOrgEmail());
        dingtalkEmployee.setPosition(response.getPosition());
        dingtalkEmployee.setRemark(response.getRemark());
        dingtalkEmployee.setTel(response.getTel());
        dingtalkEmployee.setUnionid(response.getUnionid());
        dingtalkEmployee.setUserId(response.getUserid());
        dingtalkEmployee.setWorkPlace(response.getWorkPlace());
        return dingtalkEmployee;
    }

    public OapiUserCreateRequest getOapiUserCreateRequest(DingtalkEmployee dingtalkEmployee) {
        OapiUserCreateRequest request = new OapiUserCreateRequest();
        request.setUserid(dingtalkEmployee.getUserId());
        request.setMobile(dingtalkEmployee.getMobile());
        request.setName(dingtalkEmployee.getName());
        request.setEmail(dingtalkEmployee.getEmail());
        request.setExtattr(dingtalkEmployee.getExtattr());
        request.setHiredDate(dingtalkEmployee.getHiredDate().getTime());
        request.setPosition(dingtalkEmployee.getPosition());
        request.setJobnumber(dingtalkEmployee.getJobnumber());
        request.setTel(dingtalkEmployee.getTel());
        request.setWorkPlace(dingtalkEmployee.getWorkPlace());
        request.setRemark(dingtalkEmployee.getRemark());
        request.setOrgEmail(dingtalkEmployee.getOrgEmail());
        request.setOrderInDepts(dingtalkEmployee.getOrderInDepts());

        // 需要用字符串， "[100,200]" 这种格式
        request.setDepartment(JSON.toJSONString(dingtalkEmployee.getDepartment()));
        return request;
    }

    public OapiUserUpdateRequest getOapiUserUpdateRequest(DingtalkEmployee dingtalkEmployee) {
        OapiUserUpdateRequest request = new OapiUserUpdateRequest();
        request.setUserid(dingtalkEmployee.getUserId());
        request.setMobile(dingtalkEmployee.getMobile());
        request.setName(dingtalkEmployee.getName());
        request.setEmail(dingtalkEmployee.getEmail());
        request.setExtattr(dingtalkEmployee.getExtattr());
        request.setHiredDate(dingtalkEmployee.getHiredDate().getTime());
        request.setPosition(dingtalkEmployee.getPosition());
        request.setJobnumber(dingtalkEmployee.getJobnumber());
        request.setTel(dingtalkEmployee.getTel());
        request.setWorkPlace(dingtalkEmployee.getWorkPlace());
        request.setRemark(dingtalkEmployee.getRemark());
        request.setOrgEmail(dingtalkEmployee.getOrgEmail());
        request.setDepartment(dingtalkEmployee.getDepartment());
        request.setOrderInDepts(dingtalkEmployee.getOrderInDepts());
        return request;
    }

}
