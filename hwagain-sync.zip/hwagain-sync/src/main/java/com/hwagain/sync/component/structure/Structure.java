package com.hwagain.sync.component.structure;

import java.util.List;

/**
 * Created on 2019-06-12 21:06
 * by @author JeramTough
 */
public interface Structure {

    boolean isRoot();

    boolean hasSubs();

    Structure[] getSubs();

    Structure getParent();

    void setParent(Structure parentStructure);

    void addSub(Structure structure);

    Object getValue();

    void setValue(Object value);

    int getLevel();

    void setLevel(int level);

}
