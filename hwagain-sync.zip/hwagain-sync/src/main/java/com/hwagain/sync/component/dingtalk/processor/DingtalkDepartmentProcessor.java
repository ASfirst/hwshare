package com.hwagain.sync.component.dingtalk.processor;

import com.alibaba.fastjson.JSON;
import com.dingtalk.api.request.OapiUserCreateRequest;
import com.dingtalk.api.request.OapiUserUpdateRequest;
import com.dingtalk.api.response.OapiDepartmentListResponse;
import com.dingtalk.api.response.OapiUserGetResponse;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * Created on 2019/6/11 14:40
 * by @author JeramTough
 */

public class DingtalkDepartmentProcessor {

    public @NotNull
    DingtalkDepartment getDingtalkDepartment(
            OapiDepartmentListResponse.Department department) {
        DingtalkDepartment dingtalkEmployee = new DingtalkDepartment();
        dingtalkEmployee.setId(department.getId());
        dingtalkEmployee.setName(department.getName());
        dingtalkEmployee.setOrder(0L);
        dingtalkEmployee.setParentid(department.getParentid());
        dingtalkEmployee.setSourceIdentifier(department.getSourceIdentifier());
        return dingtalkEmployee;
    }

    public @NotNull
    List<DingtalkDepartment> getDingtalkDepartmentList(
            List<OapiDepartmentListResponse.Department> departmentList) {

        List<DingtalkDepartment> dingtalkEmployee = new ArrayList<>();
        for (OapiDepartmentListResponse.Department department : departmentList) {
            dingtalkEmployee.add(getDingtalkDepartment(department));
        }
        return dingtalkEmployee;
    }


}
