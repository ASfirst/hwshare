package com.hwagain.sync.action;

import com.hwagain.sync.service.SyncSchedulingService;
import com.jeramtough.jtlog.with.WithLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created on 2019/6/11 11:16
 * by @author JeramTough
 */
@Controller
public class SyncController implements WithLogger {

    private SyncSchedulingService syncSchedulingService;
    private static ScheduledExecutorService scheduledExecutorService;

    static {
        scheduledExecutorService = new ScheduledThreadPoolExecutor(50);
    }

    @Autowired
    public SyncController(SyncSchedulingService syncSchedulingService) {
        this.syncSchedulingService = syncSchedulingService;
    }

    /**
     * 手动更新员工
     */
    @RequestMapping(value = "/manuallySyncEmployee",
            method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public String manuallySyncEmployee() {
        syncSchedulingService.executeSyncEmployeeTask();
        return "1";
    }

    /**
     * 手动更新部门
     */
    @RequestMapping(value = "/manuallySyncDepartment",
            method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public String manuallySyncDepartment() {
        syncSchedulingService.executeSyncDepartmentTask();
        return "2";
    }

    /**
     * 手动更新
     */
    @RequestMapping(value = "/manuallySync",
            method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public String manuallySync() {
        getLogger().info("手动执行同步任务开始");
        syncSchedulingService.executeSyncDepartmentTask();
        syncSchedulingService.executeSyncEmployeeTask();
        getLogger().info("手动执行同步任务结束");
        return "3";
    }

    @RequestMapping(value = "/startTask",
            method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public String startTask() {
        //每两小时执行一次
        long period = 1000 * 60 * 60 * 1;
        scheduledExecutorService.scheduleAtFixedRate(() -> {
                    syncSchedulingService.executeSyncDepartmentTask();
                    syncSchedulingService.executeSyncEmployeeTask();
                }, 5000, period,
                TimeUnit.MILLISECONDS);

        return "4";
    }

}
