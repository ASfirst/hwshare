package com.hwagain.sync.action;

import com.hwagain.sync.service.SyncSchedulingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created on 2019/6/11 11:16
 * by @author JeramTough
 */
@Controller
public class SyncController {

    SyncSchedulingService syncSchedulingService;

    @Autowired
    public SyncController(SyncSchedulingService syncSchedulingService) {
        this.syncSchedulingService = syncSchedulingService;
    }

    @RequestMapping(value = "/manuallySyncEmployee",
            method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public String manuallySyncEmployee() {
        syncSchedulingService.executeSyncEmployeeTask();
        return "1";
    }

    @RequestMapping(value = "/manuallySyncDepartment",
            method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public String manuallySyncDepartment() {
        syncSchedulingService.executeSyncDepartmentTask();
        return "2";
    }

}
