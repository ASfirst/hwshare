package com.hwagain.sync.action;

import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.sync.service.SyncSchedulingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.hwagain.framework.core.response.Response;

/**
 * Created on 2019/6/11 11:16
 * by @author JeramTough
 */
@Controller
public class SyncController {

    SyncSchedulingService syncSchedulingService;

    @Autowired
    public SyncController(SyncSchedulingService syncSchedulingService) {
        this.syncSchedulingService = syncSchedulingService;
    }

    @RequestMapping(value="/manuallySync",method={RequestMethod.GET,RequestMethod.POST})
    @ResponseBody
    public Response manuallySync(){
        syncSchedulingService.executeTimedSyncTask();
        Response response= SuccessResponseData.newInstance("test");
        return response;
    }

}
