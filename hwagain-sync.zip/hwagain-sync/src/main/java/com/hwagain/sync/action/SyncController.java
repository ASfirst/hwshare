package com.hwagain.sync.action;

import com.hwagain.framework.core.response.SuccessResponseData;
import com.hwagain.sync.service.SyncSchedulingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import com.hwagain.framework.core.response.Response;

/**
 * Created on 2019/6/11 11:16
 * by @author JeramTough
 */
@Controller
public class SyncController {

    SyncSchedulingService syncSchedulingService;

    @Autowired
    public SyncController(SyncSchedulingService syncSchedulingService) {
        this.syncSchedulingService = syncSchedulingService;
    }

    @RequestMapping(value = "/manuallySyncEmployee",
            method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public Response manuallySyncEmployee() {
        syncSchedulingService.executeSyncEmployeeTask();
        Response response = SuccessResponseData.newInstance("开始手动更新钉钉员工通讯录");
        return response;
    }

    @RequestMapping(value = "/manuallySyncDepartment",
            method = {RequestMethod.GET, RequestMethod.POST})
    @ResponseBody
    public Response manuallySyncDepartment() {
        syncSchedulingService.executeSyncDepartmentTask();
        Response response = SuccessResponseData.newInstance("开始手动更新钉钉部门信息");
        return response;
    }

}
