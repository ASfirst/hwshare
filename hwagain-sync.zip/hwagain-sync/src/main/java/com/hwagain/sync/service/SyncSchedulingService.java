package com.hwagain.sync.service;

/**
 * Created on 2019/6/11 9:33
 * by @author JeramTough
 */
public interface SyncSchedulingService {

    /**
     * 执行定时同步任务
     */
    void executeTimedSyncTask();
}
