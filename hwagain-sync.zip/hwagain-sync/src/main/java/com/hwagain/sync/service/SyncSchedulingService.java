package com.hwagain.sync.service;

/**
 * Created on 2019/6/11 9:33
 * by @author JeramTough
 */
public interface SyncSchedulingService {

    /**
     * 执行同步员工信息任务
     */
    void executeSyncEmployeeTask();

    /**
     * 执行同步部门信息任务
     */
    void executeSyncDepartmentTask();
}
