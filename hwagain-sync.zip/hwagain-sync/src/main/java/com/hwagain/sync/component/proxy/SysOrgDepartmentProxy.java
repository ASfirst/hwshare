package com.hwagain.sync.component.proxy;

import com.hwagain.framework.api.org.api.ISysOrgDepartmentApi;
import com.hwagain.framework.api.org.api.ISysOrgService;
import com.hwagain.framework.api.org.dto.SysOrgDepartmentDto;
import com.hwagain.framework.api.org.dto.SysOrgPersonDto;
import com.hwagain.framework.core.exception.CustomException;
import com.hwagain.sync.component.dingtalk.processor.OrgDepartmentDtoProcessor;
import com.hwagain.sync.component.dingtalk.processor.StructureProcessor;
import com.hwagain.sync.component.log.MyLogRecorder;
import com.hwagain.sync.component.structure.SortType;
import com.hwagain.sync.component.structure.Structure;
import com.hwagain.sync.component.structure.Structures;
import com.jeramtough.jtlog.annotation.LogConfiguration;
import com.jeramtough.jtlog.facade.L;
import com.jeramtough.jtlog.with.WithLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;

/**
 * ISysOrgDepartmentApi的代理对象，处理一些坑
 * <p>
 * Created on 2019/6/13 14:42
 * by @author WeiBoWen
 */
@Component
@LogConfiguration(logRecorders = MyLogRecorder.class)
public class SysOrgDepartmentProxy implements ISysOrgDepartmentApi, WithLogger {

    private ISysOrgDepartmentApi sysOrgDepartmentService;
    private ISysOrgService sysOrgService;

    private List<SysOrgDepartmentDto> sysOrgDepartmentDtos;

    private Map<String, Integer> employeeCountOfDepartmentMap;

    //以华劲部门departmentNumber作为键
    private Map<String, SysOrgDepartmentDto> departmentNumberDepartmentDtoMap;
    private Map<String, SysOrgDepartmentDto> fIdDepartmentDtoMap;


    @Autowired
    public SysOrgDepartmentProxy(ISysOrgService sysOrgService,
                                 ISysOrgDepartmentApi sysOrgDepartmentService) {
        this.sysOrgDepartmentService = sysOrgDepartmentService;
        this.sysOrgService = sysOrgService;
        employeeCountOfDepartmentMap = new HashMap<>();
    }

    /**
     * 获取最新的sysOrgDepartmentDtos对象
     */
    public void obtainLatest() {
        sysOrgDepartmentDtos = sysOrgDepartmentService.getListAll();

        departmentNumberDepartmentDtoMap = new HashMap<>(sysOrgDepartmentDtos.size());
        fIdDepartmentDtoMap = new HashMap<>(sysOrgDepartmentDtos.size());

        List<SysOrgPersonDto> sysOrgPersonDtos = sysOrgService.findPersonAll();

        for (SysOrgPersonDto sysOrgPersonDto : sysOrgPersonDtos) {
            //统计每个部门的员工数

            if (sysOrgPersonDto.getFdParentid() != null) {
                int countOfDepartment =
                        employeeCountOfDepartmentMap.get(
                                sysOrgPersonDto.getFdParentid()) == null ?
                                0 : employeeCountOfDepartmentMap.get(
                                sysOrgPersonDto.getFdParentid());
                countOfDepartment++;
                employeeCountOfDepartmentMap.put(sysOrgPersonDto.getFdParentid(),
                        countOfDepartment);
            }
        }


        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            //去除非法字符
            String departmentName = sysOrgDepartmentDto.getDisplayName().replace("-", " I ");
            departmentName = departmentName.replace("、", " I ");
            sysOrgDepartmentDto.setDisplayName(departmentName);

            //因为根部门parentId不为空，而是 ，-。-
            if (sysOrgDepartmentDto.getFdParentid().equals(" ")) {
                sysOrgDepartmentDto.setFdParentid(null);
            }
            departmentNumberDepartmentDtoMap.put(sysOrgDepartmentDto.getDepartmentNumber(),
                    sysOrgDepartmentDto);
            fIdDepartmentDtoMap.put(sysOrgDepartmentDto.getFdId(), sysOrgDepartmentDto);
        }

        Set<SysOrgDepartmentDto> removedDepartments = new HashSet<>();

        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            SysOrgDepartmentDto parentSysOrgDepartmentDto =
                    departmentNumberDepartmentDtoMap.get(
                            sysOrgDepartmentDto.getFdParentid());
            //去掉没有上级部门的部门
            if (parentSysOrgDepartmentDto == null &&
                    !sysOrgDepartmentDto.getDepartmentNumber().equals("10001")) {
                removedDepartments.add(sysOrgDepartmentDto);
                getLogger().verbose("洗掉没有上级部门的部门【%s】", sysOrgDepartmentDto.getDisplayName());
            }

        }

        //执行去除
        for (SysOrgDepartmentDto sysOrgDepartmentDto : removedDepartments) {
            sysOrgDepartmentDtos.remove(sysOrgDepartmentDto);
            departmentNumberDepartmentDtoMap.remove(sysOrgDepartmentDto.getDepartmentNumber());
            fIdDepartmentDtoMap.remove(sysOrgDepartmentDto.getFdId());
        }
        removedDepartments.clear();

        Structure structure = getStructure();
        List<List<Structure>> sortedStructures = Structures.getAll(structure,
                SortType.ASCENDING);

        for (Structure structureGo : sortedStructures.get(0)) {
            String hwId = (String) structureGo.getValue();
            SysOrgDepartmentDto sysOrgDepartmentDto = getfIdDepartmentDtoMap().get(
                    hwId);
            if (sysOrgDepartmentDto != null) {
                Integer count = employeeCountOfDepartmentMap.get(
                        sysOrgDepartmentDto.getDepartmentNumber());
                if (count == null || count == 0) {
                    removedDepartments.add(sysOrgDepartmentDto);
                }
            }
        }

        for (int i = 1; i < sortedStructures.size(); i++) {
            for (Structure structureGo : sortedStructures.get(i)) {
                String hwId = (String) structureGo.getValue();
                if (hwId != null) {
                    SysOrgDepartmentDto sysOrgDepartmentDto = getfIdDepartmentDtoMap().get(
                            hwId);
                    Integer count = employeeCountOfDepartmentMap.get(
                            sysOrgDepartmentDto.getDepartmentNumber());
                    boolean isRemoved = false;
                    if (count == null || count == 0) {
                        isRemoved = true;
                        Structure[] subStructures = structureGo.getSubs();
                        for (Structure structureGoo : subStructures) {
                            String hwId1 = (String) structureGoo.getValue();
                            SysOrgDepartmentDto sysOrgDepartmentDto1 =
                                    getfIdDepartmentDtoMap().get(
                                            hwId1);
                            if (!removedDepartments.contains(sysOrgDepartmentDto1)) {
                                isRemoved = false;
                                break;
                            }
                        }
                    }

                    if (isRemoved) {
                        removedDepartments.add(sysOrgDepartmentDto);
                        getLogger().verbose("洗掉没有员工的部门【%s】,它所在的层级[%d]",
                                sysOrgDepartmentDto.getDisplayName(),
                                structureGo.getLevel());
                    }
                }
            }
        }

        for (SysOrgDepartmentDto sysOrgDepartmentDto : removedDepartments) {
            Integer count = employeeCountOfDepartmentMap.get(
                    sysOrgDepartmentDto.getDepartmentNumber());
            if (count != null && count > 0) {
                L.debugs(count, sysOrgDepartmentDto.getDepartmentNumber());
            }
        }

        L.arrive();

        //执行去除
        for (SysOrgDepartmentDto sysOrgDepartmentDto : removedDepartments) {
            sysOrgDepartmentDtos.remove(sysOrgDepartmentDto);
            departmentNumberDepartmentDtoMap.remove(sysOrgDepartmentDto.getDepartmentNumber());
            fIdDepartmentDtoMap.remove(sysOrgDepartmentDto.getFdId());
        }
        removedDepartments.clear();
    }

    public SysOrgDepartmentDto getSysOrgDepartmentDtoByDepartmentNumber(
            String departmentNumber) {
        return departmentNumberDepartmentDtoMap.get(departmentNumber);
    }

    public SysOrgDepartmentDto getSysOrgDepartmentDtoByFdId(String fdId) {
        return fIdDepartmentDtoMap.get(fdId);
    }

    public List<SysOrgDepartmentDto> getSysOrgDepartmentDtos() {
        return sysOrgDepartmentDtos;
    }

    public Map<String, SysOrgDepartmentDto> getDepartmentNumberDepartmentDtoMap() {
        return departmentNumberDepartmentDtoMap;
    }

    public Map<String, SysOrgDepartmentDto> getfIdDepartmentDtoMap() {
        return fIdDepartmentDtoMap;
    }

    public Structure getStructure() {
        StructureProcessor structureProcessor =
                new OrgDepartmentDtoProcessor(sysOrgDepartmentDtos,
                        departmentNumberDepartmentDtoMap);
        Structure structure = structureProcessor.processing();
        return structure;
    }

    @Override
    public void insert(List<SysOrgDepartmentDto> list) {
        sysOrgDepartmentService.insert(list);
    }

    @Override
    public List<SysOrgDepartmentDto> getListAll() {
        return getSysOrgDepartmentDtos();
    }

    @Override
    public String getMaxId() {
        return sysOrgDepartmentService.getMaxId();
    }

    @Override
    public SysOrgDepartmentDto getParentIdByFdId(String s) {
        return sysOrgDepartmentService.getParentIdByFdId(s);
    }

    @Override
    public String getDepartmentNameByFdId(String s) {
        return sysOrgDepartmentService.getDepartmentNameByFdId(s);
    }

    @Override
    public SysOrgDepartmentDto getDeptByCode(String s) throws CustomException {
        return getSysOrgDepartmentDtoByDepartmentNumber(s);
    }
}
