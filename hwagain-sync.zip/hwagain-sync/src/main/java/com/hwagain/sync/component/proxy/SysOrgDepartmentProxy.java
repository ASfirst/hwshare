package com.hwagain.sync.component.proxy;

import com.hwagain.framework.api.org.api.ISysOrgDepartmentApi;
import com.hwagain.framework.api.org.dto.SysOrgDepartmentDto;
import com.hwagain.framework.core.exception.CustomException;
import org.apache.commons.collections.map.FixedSizeMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * ISysOrgDepartmentApi的代理对象，处理一些坑
 * <p>
 * Created on 2019/6/13 14:42
 * by @author WeiBoWen
 */
@Component
public class SysOrgDepartmentProxy implements ISysOrgDepartmentApi {

    private ISysOrgDepartmentApi sysOrgDepartmentService;

    private List<SysOrgDepartmentDto> sysOrgDepartmentDtos;

    //以华劲部门departmentNumber作为键
    private Map<String, SysOrgDepartmentDto> departmentNumberDepartmentDtoMap;
    private Map<String, SysOrgDepartmentDto> fIdDepartmentDtoMap;


    @Autowired
    public SysOrgDepartmentProxy(
            ISysOrgDepartmentApi sysOrgDepartmentService) {
        this.sysOrgDepartmentService = sysOrgDepartmentService;
    }

    /**
     * 获取最新的sysOrgDepartmentDtos对象
     */
    public void obtainLatest() {
        sysOrgDepartmentDtos = sysOrgDepartmentService.getListAll();
        departmentNumberDepartmentDtoMap = new HashMap<>(sysOrgDepartmentDtos.size());
        fIdDepartmentDtoMap = new HashMap<>(sysOrgDepartmentDtos.size());

        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            //因为根部门parentId不为空，而是 ，-。-
            if (sysOrgDepartmentDto.getFdParentid().equals(" ")) {
                sysOrgDepartmentDto.setFdParentid(null);
            }
            departmentNumberDepartmentDtoMap.put(sysOrgDepartmentDto.getDepartmentNumber(),
                    sysOrgDepartmentDto);
            fIdDepartmentDtoMap.put(sysOrgDepartmentDto.getFdId(), sysOrgDepartmentDto);
        }

        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            SysOrgDepartmentDto parentSysOrgDepartmentDto =
                    departmentNumberDepartmentDtoMap.get(
                            sysOrgDepartmentDto.getFdParentid());
            //TODO:如果找不到上级部分,并且不为华劲集团总公司，先放到10002部门先
            if (parentSysOrgDepartmentDto == null &&
                    !sysOrgDepartmentDto.getDepartmentNumber().equals("10001")) {
                sysOrgDepartmentDto.setFdParentid("10002");
            }
        }
    }

    public SysOrgDepartmentDto getSysOrgDepartmentDtoByDepartmentNumber(
            String departmentNumber) {
        return departmentNumberDepartmentDtoMap.get(departmentNumber);
    }

    public SysOrgDepartmentDto getSysOrgDepartmentDtoByFdId(String fdId) {
        return fIdDepartmentDtoMap.get(fdId);
    }

    public List<SysOrgDepartmentDto> getSysOrgDepartmentDtos() {
        return sysOrgDepartmentDtos;
    }

    public Map<String, SysOrgDepartmentDto> getDepartmentNumberDepartmentDtoMap() {
        return departmentNumberDepartmentDtoMap;
    }

    public Map<String, SysOrgDepartmentDto> getfIdDepartmentDtoMap() {
        return fIdDepartmentDtoMap;
    }

    @Override
    public void insert(List<SysOrgDepartmentDto> list) {
        sysOrgDepartmentService.insert(list);
    }

    @Override
    public List<SysOrgDepartmentDto> getListAll() {
        return getSysOrgDepartmentDtos();
    }

    @Override
    public String getMaxId() {
        return sysOrgDepartmentService.getMaxId();
    }

    @Override
    public SysOrgDepartmentDto getParentIdByFdId(String s) {
        return sysOrgDepartmentService.getParentIdByFdId(s);
    }

    @Override
    public String getDepartmentNameByFdId(String s) {
        return sysOrgDepartmentService.getDepartmentNameByFdId(s);
    }

    @Override
    public SysOrgDepartmentDto getDeptByCode(String s) throws CustomException {
        return getSysOrgDepartmentDtoByDepartmentNumber(s);
    }
}
