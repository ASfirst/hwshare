package com.hwagain.sync.component.dingtalk.transverter;

import com.dingtalk.api.request.OapiDepartmentUpdateRequest;
import com.dingtalk.api.response.OapiDepartmentGetResponse;
import com.dingtalk.api.response.OapiDepartmentListResponse;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;

import javax.validation.constraints.NotNull;
import java.util.ArrayList;
import java.util.List;

/**
 * Created on 2019/6/11 14:40
 * by @author JeramTough
 */

public class DingtalkDepartmentTransverter {

    public @NotNull
    DingtalkDepartment getDingtalkDepartment(
            OapiDepartmentListResponse.Department department) {
        DingtalkDepartment dingtalkDepartment = new DingtalkDepartment();
        dingtalkDepartment.setId(department.getId());
        dingtalkDepartment.setName(department.getName());
        dingtalkDepartment.setOrder(0L);
        dingtalkDepartment.setParentid(department.getParentid());
        dingtalkDepartment.setSourceIdentifier(department.getSourceIdentifier());
        return dingtalkDepartment;
    }

    public @NotNull
    DingtalkDepartment getDingtalkDepartment(OapiDepartmentGetResponse response) {
        DingtalkDepartment dingtalkDepartment = new DingtalkDepartment();
        dingtalkDepartment.setId(response.getId());
        dingtalkDepartment.setName(response.getName());
        dingtalkDepartment.setOrder(response.getOrder());
        dingtalkDepartment.setParentid(response.getParentid());
        dingtalkDepartment.setSourceIdentifier(response.getSourceIdentifier());
        return dingtalkDepartment;
    }

    public @NotNull
    List<DingtalkDepartment> getDingtalkDepartmentList(
            List<OapiDepartmentListResponse.Department> departmentList) {

        List<DingtalkDepartment> dingtalkEmployee = new ArrayList<>();
        for (OapiDepartmentListResponse.Department department : departmentList) {
            dingtalkEmployee.add(getDingtalkDepartment(department));
        }
        return dingtalkEmployee;
    }

    public @NotNull
    OapiDepartmentUpdateRequest getOapiDepartmentUpdateRequest(
            DingtalkDepartment dingtalkDepartment) {
        OapiDepartmentUpdateRequest request = new OapiDepartmentUpdateRequest();
        request.setId(dingtalkDepartment.getId());
        request.setParentid(dingtalkDepartment.getParentid() + "");
        request.setOrder(dingtalkDepartment.getOrder() + "");
        request.setName(dingtalkDepartment.getName());
        request.setCreateDeptGroup(false);
        return request;
    }


}
