package com.hwagain.sync.action;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import com.hwagain.sync.component.log.MyLogRecorder;
import com.hwagain.sync.service.SyncSchedulingService;
import com.jeramtough.jtlog.annotation.LogConfiguration;
import com.jeramtough.jtlog.lang.DefaultBoolean;
import com.jeramtough.jtlog.with.WithLogger;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * <p>
 * 定时任务-PS职务数据
 * </p>
 *
 * @author hanj
 * @since 2018-06-15
 */

@Configurable
@EnableScheduling
@Component
@LogConfiguration(isEnabled = DefaultBoolean.TRUE, logRecorders = MyLogRecorder.class)
public class SyncScheduling implements WithLogger {


    protected static ExecutorService executorService = null;

    private SyncSchedulingService syncSchedulingService;

    static {
        int processCount = 50;
        executorService = new ThreadPoolExecutor(processCount / 2 + 1, processCount * 2 + 1,
                5L, TimeUnit.MINUTES,
                new LinkedBlockingQueue<Runnable>());
    }

    public SyncScheduling(SyncSchedulingService syncSchedulingService) {
        this.syncSchedulingService = syncSchedulingService;
    }


    @Scheduled(cron = "0 0 2 ? * *") // 每天2点执行
//    @Scheduled(cron = "0 0 0/2 * * ?")
    public void execute() {
        getLogger().info("开始执行周期任务");
        executorService.submit(() -> {
            getLogger().info("开始同步部门任务");
            syncSchedulingService.executeSyncDepartmentTask();
            getLogger().info("开始同步员工任务");
            syncSchedulingService.executeSyncEmployeeTask();
        });
        getLogger().info("执行周期任务完成");
    }
}
