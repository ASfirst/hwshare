package com.hwagain.sync.action;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

/**
 * <p>
 * 定时任务-PS职务数据
 * </p>
 *
 * @author hanj
 * @since 2018-06-15
 */

@Configurable
@EnableScheduling
@Component
public class SyncScheduling{
	private final static Logger logger = LoggerFactory.getLogger(SyncScheduling.class);
	
	
	protected static ExecutorService executorService = null;
	
	static {
		int processCount = 50;
		executorService = new ThreadPoolExecutor(processCount / 2 + 1, processCount * 2 + 1, 5L, TimeUnit.MINUTES,
				new LinkedBlockingQueue<Runnable>());
	}
	

//	@Scheduled(cron = "0 0 2 ? * *") // 每天2点执行
	@Scheduled(cron = "0/30 * * * * ?")
	public void execute() {
		logger.info("开始执行插入。。。");
		logger.info("执行完成。。。");
	}
}
