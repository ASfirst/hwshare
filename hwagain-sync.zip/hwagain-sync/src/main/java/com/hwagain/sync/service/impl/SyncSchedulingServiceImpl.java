package com.hwagain.sync.service.impl;

import com.dingtalk.api.response.OapiDepartmentListResponse;
import com.hwagain.framework.api.org.api.ISysOrgService;
import com.hwagain.framework.api.org.dto.SysOrgPersonDto;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;
import com.hwagain.sync.component.dingtalk.net.DingTalkHttpClient;
import com.hwagain.sync.component.dingtalk.net.MyDingTalkHttpClient;
import com.hwagain.sync.service.SyncSchedulingService;
import com.hwagain.sync.util.SysOrgPersonUtil;
import com.jeramtough.jtlog.facade.L;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created on 2019/6/11 9:36
 * by @author JeramTough
 */
@Service
public class SyncSchedulingServiceImpl implements SyncSchedulingService {

    private ISysOrgService sysOrgService;
    private DingTalkHttpClient dingTalkHttpClient;

    @Autowired
    public SyncSchedulingServiceImpl(
            ISysOrgService sysOrgService,
            MyDingTalkHttpClient dingTalkHttpClient) {
        this.sysOrgService = sysOrgService;
        this.dingTalkHttpClient = dingTalkHttpClient;
    }

    @Override
    public void executeTimedSyncTask() {
        //所有【化劲】员工信息list集合
        List<SysOrgPersonDto> sysOrgPersonDtos = sysOrgService.findPersonAll();
        //以工号为键值的【钉钉】员工信息map集合
        Map<String, DingtalkEmployee> dingtalkEmployeeMap = dingTalkHttpClient
                .getAllEmployees();
        //所有钉钉应用部门信息List集合
        List<OapiDepartmentListResponse.Department> departments =
                dingTalkHttpClient.getDepartmentList(1);

        //新增到钉钉应用的员工集合
        List<DingtalkEmployee> newDingtalkEmployees = new ArrayList<>();
        //需要更新信息的员工集合
        List<DingtalkEmployee> updateDingtalkEmployees = new ArrayList<>();
        //被删除从钉钉应用的员工集合
        List<DingtalkEmployee> deletedDingtalkEmployees = new ArrayList<>();
        //新增到钉钉应用的部门信息集合，以部门名作为键值，至于删除和修改部门信息就上后台管理页面修改吧
        Map<String,OapiDepartmentListResponse.Department> newDepartmentMap=new HashMap<>();

        for (SysOrgPersonDto sysOrgPersonDto : sysOrgPersonDtos) {
            //如果钉钉应用系统里边不存在该用户
            boolean isContained =
                    dingtalkEmployeeMap.containsKey(sysOrgPersonDto.getFdEmployeeNumber());
            if (!isContained) {
                DingtalkEmployee newDingtalkEmployee =
                        SysOrgPersonUtil.toDingtalkEmployee(sysOrgPersonDto);
                newDingtalkEmployees.add(newDingtalkEmployee);
            }
            else {
                DingtalkEmployee dingtalkEmployee =
                        dingtalkEmployeeMap.get(sysOrgPersonDto.getFdEmployeeNumber());
                //如果该用户信息在化劲员系统里面已经更新过
                boolean isModified = SysOrgPersonUtil.isModified(sysOrgPersonDto,
                        dingtalkEmployee);
                if (isModified) {
                    dingtalkEmployee = SysOrgPersonUtil.toDingtalkEmployee(sysOrgPersonDto);
                    updateDingtalkEmployees.add(dingtalkEmployee);
                }
            }

            dingtalkEmployeeMap.remove(sysOrgPersonDto.getFdEmployeeNumber());
        }

        //如果化劲员工系统里面不存在而钉钉应用还存在该用户，则需要删除
        if (dingtalkEmployeeMap.size() > 0) {
            deletedDingtalkEmployees = new ArrayList<>(
                    dingtalkEmployeeMap.values());
        }

        L.debugs(newDingtalkEmployees.size(), updateDingtalkEmployees.size(),
                deletedDingtalkEmployees.size());
    }
}
