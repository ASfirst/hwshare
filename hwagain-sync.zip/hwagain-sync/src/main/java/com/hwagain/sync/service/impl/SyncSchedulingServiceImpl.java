package com.hwagain.sync.service.impl;

import com.hwagain.framework.api.org.dto.SysOrgDepartmentDto;
import com.hwagain.framework.api.org.dto.SysOrgPersonDto;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;
import com.hwagain.sync.component.dingtalk.net.DingTalkHttpClient;
import com.hwagain.sync.component.dingtalk.net.MyDingTalkHttpClient;
import com.hwagain.sync.component.proxy.SysOrgDepartmentProxy;
import com.hwagain.sync.component.proxy.SysOrgServiceProxy;
import com.hwagain.sync.component.structure.SortType;
import com.hwagain.sync.component.structure.Structure;
import com.hwagain.sync.component.structure.Structures;
import com.hwagain.sync.service.SyncSchedulingService;
import com.hwagain.sync.util.SysOrgDepartmentUtil;
import com.hwagain.sync.util.SysOrgPersonUtil;
import com.jeramtough.jtlog.facade.L;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

/**
 * Created on 2019/6/11 9:36
 * by @author WeiBoWen
 */
@Service
public class SyncSchedulingServiceImpl implements SyncSchedulingService {

    private final SysOrgServiceProxy sysOrgServiceProxy;
    private final SysOrgDepartmentProxy sysOrgDepartmentProxy;
    private final DingTalkHttpClient dingTalkHttpClient;

    @Autowired
    public SyncSchedulingServiceImpl(
            SysOrgServiceProxy sysOrgServiceProxy,
            SysOrgDepartmentProxy sysOrgDepartmentProxy,
            MyDingTalkHttpClient dingTalkHttpClient) {
        this.sysOrgServiceProxy = sysOrgServiceProxy;
        this.sysOrgDepartmentProxy = sysOrgDepartmentProxy;
        this.dingTalkHttpClient = dingTalkHttpClient;
    }

    @Override
    public void executeSyncEmployeeTask() {

        try {
            //刷新token
            dingTalkHttpClient.refreshTokenByAppKey();

            //用代理对象从华劲系统中拉取最新的数据对象
            sysOrgServiceProxy.obtainLatest();

            //所有【华劲】员工信息list集合
            List<SysOrgPersonDto> sysOrgPersonDtos = sysOrgServiceProxy.getSysOrgPersonDtos();

            //以工号为键值的【钉钉】员工信息map集合
            Map<String, DingtalkEmployee> dingtalkEmployeeMap = dingTalkHttpClient
                    .getAllEmployees();

            //所有【钉钉】应用部门信息List集合
            List<DingtalkDepartment> dingtalkDepartments =
                    dingTalkHttpClient.getAllSubDepartmentList();

            //以华劲部门Id作为键
            Map<String, DingtalkDepartment> hwDepartmentIdKeyDingtalkDepartmentMap = new HashMap<>();

            //新增到钉钉应用的员工集合
            List<DingtalkEmployee> newDingtalkEmployees = new ArrayList<>();
            //需要更新信息的员工集合
            List<DingtalkEmployee> updateDingtalkEmployees = new ArrayList<>();
            //被删除从钉钉应用的员工集合
            List<DingtalkEmployee> deletedDingtalkEmployees = new ArrayList<>();


            for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
                hwDepartmentIdKeyDingtalkDepartmentMap.put(
                        dingtalkDepartment.getSourceIdentifier(),
                        dingtalkDepartment);
            }

            for (SysOrgPersonDto sysOrgPersonDto : sysOrgPersonDtos) {
                //如果钉钉应用系统里边不存在该用户
                boolean isContained =
                        dingtalkEmployeeMap.containsKey(sysOrgPersonDto.getFdEmployeeNumber());
                SysOrgDepartmentDto sysOrgDepartmentDto = sysOrgDepartmentProxy
                        .getSysOrgDepartmentDtoByDepartmentNumber(
                                sysOrgPersonDto.getFdParentid());
                String hwDepartmentId = sysOrgDepartmentDto.getFdId();

                if (!isContained) {
                    DingtalkDepartment dingtalkDepartment =
                            hwDepartmentIdKeyDingtalkDepartmentMap.get(hwDepartmentId);
                    DingtalkEmployee newDingtalkEmployee =
                            SysOrgPersonUtil.toDingtalkEmployee(sysOrgPersonDto,
                                    dingtalkDepartment);
                    newDingtalkEmployees.add(newDingtalkEmployee);
                }
                else {
                    DingtalkEmployee dingtalkEmployee =
                            dingtalkEmployeeMap.get(sysOrgPersonDto.getFdEmployeeNumber());
                    Long dingtalkDepartmentId = dingtalkEmployee.getDepartment().get(0);
                    DingtalkDepartment currentDingtalkDepartment =
                            hwDepartmentIdKeyDingtalkDepartmentMap.get(
                                    hwDepartmentId);
                    //从云上拉取旧的部门信息
                    DingtalkDepartment oldDingtalkDepartment =
                            dingTalkHttpClient.getDepartment(dingtalkDepartmentId);
                    //如果该用户信息在华劲员系统里面已经更新过
                    boolean isModified = SysOrgPersonUtil.isModified(sysOrgPersonDto,
                            dingtalkEmployee, oldDingtalkDepartment,
                            currentDingtalkDepartment);
                    if (isModified) {
                        dingtalkEmployee = SysOrgPersonUtil.toDingtalkEmployee(sysOrgPersonDto,
                                currentDingtalkDepartment);
                        updateDingtalkEmployees.add(dingtalkEmployee);
                    }
                }

                dingtalkEmployeeMap.remove(sysOrgPersonDto.getFdEmployeeNumber());
            }

            //如果华劲员工系统里面不存在而钉钉应用还存在该用户，则需要删除
            if (dingtalkEmployeeMap.size() > 0) {
                deletedDingtalkEmployees = new ArrayList<>(dingtalkEmployeeMap.values());
            }

            L.debugs(newDingtalkEmployees.size(), updateDingtalkEmployees.size(),
                    deletedDingtalkEmployees.size());


            //开始更新操作
            dingTalkHttpClient.deleteBundleEmployees(deletedDingtalkEmployees);
            dingTalkHttpClient.createBundleEmployees(newDingtalkEmployees);
            dingTalkHttpClient.updateBundleEmployees(updateDingtalkEmployees);
        }
        catch (Exception e) {
            e.printStackTrace();
            L.error("执行同步员工任务出错\n" + e.getMessage());
            StringBuffer stringBuffer = new StringBuffer(e.toString() + "\n");
            StackTraceElement[] messages = e.getStackTrace();
            int length = messages.length;
            for (int i = 0; i < length; i++) {
                stringBuffer.append("\t"+messages[i].toString()+"\n");
            }
            L.error(stringBuffer.toString());
        }


    }

    @Override
    public void executeSyncDepartmentTask() {
        try {
            dingTalkHttpClient.refreshTokenByAppKey();

            //从华劲系统中拉取最新的数据对象
            sysOrgDepartmentProxy.obtainLatest();

            //所有【华劲】部门信息list集合
            List<SysOrgDepartmentDto> sysOrgDepartmentDtos = sysOrgDepartmentProxy.getSysOrgDepartmentDtos();

            //以华劲部门Id作为键的部门信息map集合
            Map<String, DingtalkDepartment> hwIdDingtalkDepartmentMap = new HashMap<>();

            //需要更新的钉钉应用的华劲部门Id集合
            Set<String> updateHwDepartmentIds = new HashSet<>();
            //需要被删除的临时钉钉部门集合
            Map<String, DingtalkDepartment> hwIdKeyDeletedDingtalkDepartments = new HashMap<>();


            //创建钉钉部门
            createDingtalkDepartment(sysOrgDepartmentDtos, hwIdDingtalkDepartmentMap);

            for (DingtalkDepartment dingtalkDepartment : hwIdDingtalkDepartmentMap.values()) {
                if (dingtalkDepartment.getName().contains("TEMP")) {
                    updateHwDepartmentIds.add(dingtalkDepartment.getSourceIdentifier());
                }
                hwIdKeyDeletedDingtalkDepartments.put(dingtalkDepartment.getSourceIdentifier(),
                        dingtalkDepartment);
            }

            for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
                if (hwIdKeyDeletedDingtalkDepartments.containsKey(
                        sysOrgDepartmentDto.getFdId())) {
                    hwIdKeyDeletedDingtalkDepartments.remove(sysOrgDepartmentDto.getFdId());
                }
            }

            //树形结构处理器，将华劲部门Dto树形结构化。
            Structure structure = sysOrgDepartmentProxy.getStructure();
            //升序排序，从最后边的部门信息开始更新
            List<Structure> structures = Structures.getSubsAndSort(structure,
                    SortType.ASCENDING);

            List<DingtalkDepartment> sortNewDingtalkDepartments = new ArrayList<>();
            for (Structure structure1 : structures) {
                String hwDepartmentId = structure1.getValue().toString();

                SysOrgDepartmentDto sysOrgDepartmentDto =
                        sysOrgDepartmentProxy.getSysOrgDepartmentDtoByFdId(
                                hwDepartmentId);

                DingtalkDepartment dingtalkDepartment = SysOrgDepartmentUtil.toDingtalkDepartment(
                        sysOrgDepartmentDto);
                Long dingtalkParentId = 1L;
                if (sysOrgDepartmentDto.getFdParentid() != null) {
                    String hwParentDepartmentId =
                            sysOrgDepartmentProxy.getSysOrgDepartmentDtoByDepartmentNumber(
                                    sysOrgDepartmentDto.getFdParentid()).getFdId();
                    dingtalkParentId =
                            hwIdDingtalkDepartmentMap.get(hwParentDepartmentId).getId();
                }

                Long dingtalkId = hwIdDingtalkDepartmentMap.get(hwDepartmentId).getId();
                dingtalkDepartment.setId(dingtalkId);
                dingtalkDepartment.setParentid(dingtalkParentId);
                sortNewDingtalkDepartments.add(dingtalkDepartment);
            }

            //TODO:现在是所有部门每次都更新一遍，不管华劲系统是否有变化，未来在写具体的判断是否需要更新


            //开始执行更新操作，从最底层的部门开始更新，单队列更新不用并发，确保成功率最大
            dingTalkHttpClient.updateBundleDepartments(sortNewDingtalkDepartments);
            for (DingtalkDepartment dingtalkDepartment : sortNewDingtalkDepartments) {
                dingTalkHttpClient.updateDepartment(dingtalkDepartment);
            }

            //开始执行删除操作，单队列更新不用并发，确保成功率最大
            for (DingtalkDepartment dingtalkDepartment : hwIdKeyDeletedDingtalkDepartments.values()) {
                //先删除员工
                List<String> employeeIds =
                        dingTalkHttpClient.getDeptMemberList(dingtalkDepartment.getId());
                for (String employeeId : employeeIds) {
                    DingtalkEmployee dingtalkEmployee = new DingtalkEmployee();
                    dingtalkEmployee.setUserId(employeeId);
                    dingTalkHttpClient.deleteEmployee(dingtalkEmployee);
                }
                //后删除部门
                dingTalkHttpClient.deleteDepartment(dingtalkDepartment);
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            L.error("执行同步部门任务出错\n" + e.getMessage());

            StringBuffer stringBuffer = new StringBuffer(e.toString() + "\n");
            StackTraceElement[] messages = e.getStackTrace();
            int length = messages.length;
            for (int i = 0; i < length; i++) {
                stringBuffer.append("\t"+messages[i].toString()+"\n");
            }
            L.error(stringBuffer.toString());
        }

    }

    //*********************

    /**
     * 往钉钉应用里创建部门
     */
    private void createDingtalkDepartment(List<SysOrgDepartmentDto> sysOrgDepartmentDtos,
                                          Map<String, DingtalkDepartment> hwIdDingtalkDepartmentMap) {
        List<DingtalkDepartment> newDingtalkDepartments = new ArrayList<>();
        //重新拉取最新的钉钉应用系统中部门信息集合
        List<DingtalkDepartment> dingtalkDepartments =
                dingTalkHttpClient.getAllSubDepartmentList();

        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            hwIdDingtalkDepartmentMap.put(dingtalkDepartment.getSourceIdentifier(),
                    dingtalkDepartment);
        }

        //遍历出华劲系统存在的部门，而钉钉应用中不存在的部门信息
        for (SysOrgDepartmentDto sysOrgDepartmentDto : sysOrgDepartmentDtos) {
            if (!hwIdDingtalkDepartmentMap.containsKey(sysOrgDepartmentDto.getFdId())) {
                DingtalkDepartment newDingtalkDepartment =
                        SysOrgDepartmentUtil.toDingtalkDepartment(sysOrgDepartmentDto);
                newDingtalkDepartment.setName(
                        "TEMP" + newDingtalkDepartment.getSourceIdentifier());
                newDingtalkDepartments.add(newDingtalkDepartment);
            }
        }

        //开始执行创建部门操作
        dingTalkHttpClient.createdBundleDepartments(
                newDingtalkDepartments);

        if (newDingtalkDepartments.size() > 0) {
            //并发调用不保证每个都能执行成功，如果是失败数大于0，进入重创
            createDingtalkDepartment(sysOrgDepartmentDtos, hwIdDingtalkDepartmentMap);
        }
    }

}
