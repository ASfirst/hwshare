package com.hwagain.sync.component.dingtalk.net;

import com.dingtalk.api.DefaultDingTalkClient;
import com.dingtalk.api.request.OapiDepartmentListRequest;
import com.dingtalk.api.request.OapiGettokenRequest;
import com.dingtalk.api.request.OapiUserGetDeptMemberRequest;
import com.dingtalk.api.request.OapiUserGetRequest;
import com.dingtalk.api.response.OapiDepartmentListResponse;
import com.dingtalk.api.response.OapiGettokenResponse;
import com.dingtalk.api.response.OapiUserGetDeptMemberResponse;
import com.dingtalk.api.response.OapiUserGetResponse;
import com.hwagain.sync.component.dingtalk.DingTalkConfig;
import com.hwagain.sync.component.dingtalk.DingtalkEmployeeProcessor;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;
import com.jeramtough.jtlog.with.WithLogger;
import com.taobao.api.ApiException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

/**
 * Created on 2019/6/11 8:20
 * by @author JeramTough
 */
@Component("dingTalkHttpClient")
public class MyDingTalkHttpClient implements DingTalkHttpClient, WithLogger {

    private String appKey;
    private String appSecret;
    private String accessToken;
    private DefaultDingTalkClient dingTalkClient;
    private DingtalkEmployeeProcessor dingtalkEmployeeProcessor;

    @Autowired
    public MyDingTalkHttpClient(DingTalkConfig dingTalkConfig) {
        this(dingTalkConfig.getAppKey(), dingTalkConfig.getAppSecret());
    }

    public MyDingTalkHttpClient(String appKey, String appSecret) {
        this.appKey = appKey;
        this.appSecret = appSecret;

        init();
    }

    protected void init() {
        dingTalkClient = new DefaultDingTalkClient("https://oapi.dingtalk" +
                ".com/gettoken");
        accessToken = getAccessToken();
        dingtalkEmployeeProcessor = new DingtalkEmployeeProcessor();
    }

    protected String getAccessToken() {
        OapiGettokenRequest request = new OapiGettokenRequest();
        request.setAppkey(appKey);
        request.setAppsecret(appSecret);
        request.setHttpMethod("GET");
        try {
            OapiGettokenResponse response = dingTalkClient.execute(request);
            if (response.getErrcode() == 0) {
                return response.getAccessToken();
            }
            else {
                return null;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    public List<OapiDepartmentListResponse.Department> getDepartmentList(int departmentId) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/department/list");
        OapiDepartmentListRequest request = new OapiDepartmentListRequest();
        request.setId(departmentId + "");
        //递归查询设为true
        request.setFetchChild(false);
        request.setHttpMethod("GET");
        try {
            OapiDepartmentListResponse response = dingTalkClient.execute(request,
                    accessToken);
            if (response.getErrcode() == 0) {
                return response.getDepartment();
            }
            else {
                return null;
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
            return null;
        }
    }


    public List<String> getDeptMemberList(Long departmentId) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/getDeptMember");
        OapiUserGetDeptMemberRequest req = new OapiUserGetDeptMemberRequest();
        req.setDeptId(departmentId + "");
        req.setHttpMethod("GET");
        OapiUserGetDeptMemberResponse response = null;
        try {
            response = dingTalkClient.execute(req, accessToken);
        }
        catch (ApiException e) {
            e.printStackTrace();
        }

        if (response != null && response.getErrcode() == 0) {
            return response.getUserIds();
        }
        else {
            return null;
        }
    }


    public DingtalkEmployee getDingtalkEmployee(String userId) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/get");
        OapiUserGetRequest request = new OapiUserGetRequest();
        request.setUserid(userId);
        request.setHttpMethod("GET");
        OapiUserGetResponse response = null;
        try {
            response = dingTalkClient.execute(request, accessToken);
        }
        catch (ApiException e) {
            e.printStackTrace();
        }

        if (response != null && response.getErrcode() == 0) {
            return dingtalkEmployeeProcessor.processing(response);
        }
        else {
            return null;
        }
    }

    @Override
    public Map<String, DingtalkEmployee> getAllEmployees() {
        //由于钉钉api调用有频率限制，并发调用数还是20以内好了
        int processCount = 20;
        ExecutorService executorService = executorService = new ThreadPoolExecutor(
                processCount / 2 + 1, processCount * 2 + 1, 5L, TimeUnit.MINUTES,
                new LinkedBlockingQueue<Runnable>());
        List<String> userIds = new ArrayList<>();
        Map<String, DingtalkEmployee> dingtalkEmployeeMap = new HashMap<>(30);
        List<OapiDepartmentListResponse.Department> departments = getDepartmentList(1);
        for (OapiDepartmentListResponse.Department department : departments) {
            List<String> tempUserIds = getDeptMemberList(department.getId());
            userIds.addAll(tempUserIds);
        }
        getLogger().verbose("所有部门UserId获取成功，开始获取钉钉员工信息详情\n。。。");

        for (String userId : userIds) {
            executorService.submit(() -> {
                DingtalkEmployee dingtalkEmployee = getDingtalkEmployee(userId);
                getLogger().verbose("成功获取userId[" + userId + "]的职工信息");
                dingtalkEmployeeMap.put(dingtalkEmployee.getJobnumber(), dingtalkEmployee);
            });
        }

        long basicTimeConsuming=userIds.size()*10+5;
        try {
            executorService.awaitTermination(basicTimeConsuming,TimeUnit.SECONDS);
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        finally {
            executorService.shutdown();
        }
        return dingtalkEmployeeMap;
    }
}
