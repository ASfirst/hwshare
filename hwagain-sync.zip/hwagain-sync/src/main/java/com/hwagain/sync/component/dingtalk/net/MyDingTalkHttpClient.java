package com.hwagain.sync.component.dingtalk.net;

import com.dingtalk.api.DefaultDingTalkClient;
import com.dingtalk.api.request.*;
import com.dingtalk.api.response.*;
import com.hwagain.sync.component.dingtalk.DingTalkConfig;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.hwagain.sync.component.dingtalk.transverter.DingtalkDepartmentTransverter;
import com.hwagain.sync.component.dingtalk.transverter.DingtalkEmployeeTransverter;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;
import com.jeramtough.jtlog.facade.L;
import com.jeramtough.jtlog.with.WithLogger;
import com.taobao.api.ApiException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Created on 2019/6/11 8:20
 * by @author JeramTough
 */
@Component("dingTalkHttpClient")
public class MyDingTalkHttpClient implements DingTalkHttpClient, WithLogger {

    private String appKey;
    private String appSecret;
    private String accessToken;
    private DefaultDingTalkClient dingTalkClient;
    private DingtalkEmployeeTransverter dingtalkEmployeeTransverter;
    private DingtalkDepartmentTransverter dingtalkDepartmentTransverter;

    @Autowired
    public MyDingTalkHttpClient(DingTalkConfig dingTalkConfig) {
        this(dingTalkConfig.getAppKey(), dingTalkConfig.getAppSecret());
    }

    public MyDingTalkHttpClient(String appKey, String appSecret) {
        this.appKey = appKey;
        this.appSecret = appSecret;

        init();
    }

    protected void init() {
        dingTalkClient = new DefaultDingTalkClient("https://oapi.dingtalk" +
                ".com/gettoken");
        accessToken = getAccessToken();
        dingtalkEmployeeTransverter = new DingtalkEmployeeTransverter();
        dingtalkDepartmentTransverter = new DingtalkDepartmentTransverter();
    }

    protected String getAccessToken() {
        OapiGettokenRequest request = new OapiGettokenRequest();
        request.setAppkey(appKey);
        request.setAppsecret(appSecret);
        request.setHttpMethod("GET");
        try {
            OapiGettokenResponse response = dingTalkClient.execute(request);
            if (response.getErrcode() == 0) {
                return response.getAccessToken();
            }
            else {
                return null;
            }
        }
        catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    @Override
    public List<String> getDeptMemberList(Long departmentId) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/getDeptMember");
        OapiUserGetDeptMemberRequest req = new OapiUserGetDeptMemberRequest();
        req.setDeptId(departmentId + "");
        req.setHttpMethod("GET");
        OapiUserGetDeptMemberResponse response = null;
        try {
            response = dingTalkClient.execute(req, accessToken);
            if (response != null && response.getErrcode() == 0) {
                getLogger().debug("获取[%d]的职员Id列表成功", departmentId);
                return response.getUserIds();
            }
            else {
                getLogger().warn("获取[%d]的职员Id列表失败,因为%s", departmentId,
                        response != null ? response.getErrmsg() : null);
            }

        }
        catch (ApiException e) {
            e.printStackTrace();
            getLogger().error("获取[%d]的职员Id列表失败,因为服务器响应为null");
        }
        return new ArrayList<>();
    }


    @Override
    public DingtalkEmployee getDingtalkEmployee(String userId) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/get");
        OapiUserGetRequest request = new OapiUserGetRequest();
        request.setUserid(userId);
        request.setHttpMethod("GET");
        OapiUserGetResponse response = null;
        try {
            response = dingTalkClient.execute(request, accessToken);
        }
        catch (ApiException e) {
            e.printStackTrace();
        }

        if (response != null && response.getErrcode() == 0) {
            return dingtalkEmployeeTransverter.getDingtalkEmployee(response);
        }
        else {
            return null;
        }
    }

    @Override
    public Map<String, DingtalkEmployee> getAllEmployees() {
        Map<String, DingtalkEmployee> dingtalkEmployeeMap = new HashMap<>(1000);
        ExecutorService executorService = getExecutorService();

        if (true) {
            return dingtalkEmployeeMap;
        }

        List<String> userIds = new ArrayList<>();

        List<DingtalkDepartment> departments = getDepartmentList(1);
        for (int i = 0; i < departments.size(); i++) {
            DingtalkDepartment dingtalkDepartment = departments.get(i);
            List<String> tempUserIds = getDeptMemberList(dingtalkDepartment.getId());
            userIds.addAll(tempUserIds);
            getLogger().debug("获取部门人员Id列表完毕，剩余[%d]个部门", departments.size() - i - 1);
        }

        CountDownLatch latch = new CountDownLatch(userIds.size());

        getLogger().debug("所有部门UserId获取成功，开始获取钉钉员工信息详情\n。。。");

        for (String userId : userIds) {
            executorService.submit(() -> {
                DingtalkEmployee dingtalkEmployee = getDingtalkEmployee(userId);
                getLogger().debug("成功获取userId[" + userId + "]的钉钉职工信息");
                dingtalkEmployeeMap.put(dingtalkEmployee.getJobnumber(), dingtalkEmployee);
                latch.countDown();
            });
        }

        executorService.shutdown();
        try {
            latch.await();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        return dingtalkEmployeeMap;
    }


    @Override
    public int createBundleEmployees(List<DingtalkEmployee> dingtalkEmployees) {
        return doBundleEmployeeOperation(dingtalkEmployees, 0);
    }

    @Override
    public boolean createEmployee(DingtalkEmployee dingtalkEmployee) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/create");
        OapiUserCreateRequest request =
                dingtalkEmployeeTransverter.getOapiUserCreateRequest(dingtalkEmployee);
        String errMessage = "";
        try {
            OapiUserCreateResponse response = dingTalkClient.execute(request, accessToken);
            if (response.isSuccess() && response.getErrcode() == 0) {
                getLogger().debug("创建新钉钉员工UserId[%s]【成功】", dingtalkEmployee.getUserId());
                return true;
            }
            errMessage = response.getErrmsg();
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        getLogger().warn("创建新钉钉员工UserId[%s]【失败】，因为%s", dingtalkEmployee.getUserId(),
                errMessage);
        return false;
    }

    @Override
    public boolean updateEmployee(DingtalkEmployee dingtalkEmployee) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/update");
        OapiUserUpdateRequest request =
                dingtalkEmployeeTransverter.getOapiUserUpdateRequest(dingtalkEmployee);

        String errMessage = "";
        try {
            OapiUserUpdateResponse response = dingTalkClient.execute(request, accessToken);
            if (response.isSuccess() && response.getErrcode() == 0) {
                getLogger().debug("更新钉钉员工UserId[%s]信息【成功】", dingtalkEmployee.getUserId());
                return true;
            }
            errMessage = response.getErrmsg();
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        getLogger().warn("更新钉钉员工UserId[%s]信息【失败】,因为%s", dingtalkEmployee.getUserId(),
                errMessage);
        return false;
    }

    @Override
    public int updateBundleEmployees(List<DingtalkEmployee> dingtalkEmployees) {
        return doBundleEmployeeOperation(dingtalkEmployees, 1);
    }

    @Override
    public boolean deleteEmployee(DingtalkEmployee dingtalkEmployee) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/user/delete");
        OapiUserDeleteRequest request = new OapiUserDeleteRequest();
        request.setUserid(dingtalkEmployee.getUserId());
        request.setHttpMethod("GET");

        String errMessage = "";
        try {
            OapiUserDeleteResponse response = dingTalkClient.execute(request, accessToken);
            if (response.isSuccess() && response.getErrcode() == 0) {
                getLogger().debug("删除钉钉员工UserId[%s]信息【成功】", dingtalkEmployee.getUserId());
                return true;
            }
            errMessage = response.getErrmsg();
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        getLogger().warn("删除钉钉员工UserId[%s]信息【失败】，因为%s", dingtalkEmployee.getUserId(),
                errMessage);
        return false;
    }

    @Override
    public int deleteBundleEmployees(List<DingtalkEmployee> dingtalkEmployees) {
        return doBundleEmployeeOperation(dingtalkEmployees, 2);
    }

    @Override
    public List<DingtalkDepartment> getDepartmentList(int departmentId) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/department/list");
        OapiDepartmentListRequest request = new OapiDepartmentListRequest();
        request.setId(departmentId + "");
        //递归查询设为true
        request.setFetchChild(true);
        request.setHttpMethod("GET");
        try {
            OapiDepartmentListResponse response = dingTalkClient.execute(request,
                    accessToken);
            if (response.getErrcode() == 0) {
                return dingtalkDepartmentTransverter.getDingtalkDepartmentList(
                        response.getDepartment());
            }
            else {
                return null;
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean createdDepartment(DingtalkDepartment dingtalkDepartment) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/department/create");
        OapiDepartmentCreateRequest request = new OapiDepartmentCreateRequest();
        request.setParentid("1");
        request.setCreateDeptGroup(false);
        request.setName(dingtalkDepartment.getName());
        request.setSourceIdentifier(dingtalkDepartment.getSourceIdentifier());
        OapiDepartmentCreateResponse response = null;
        try {
            response = dingTalkClient.execute(request, accessToken);
            if (response != null && response.getErrcode() == 0) {
                getLogger().debug("创建部门[%s]成功",
                        dingtalkDepartment.getSourceIdentifier() + "_" + dingtalkDepartment.getName());
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        if (response != null && response.getErrcode() == 0) {
            return true;
        }
        getLogger().warn("创建部门[%s]失败%s", dingtalkDepartment.getSourceIdentifier(),
                response != null ? ",因为" + response.getErrmsg() : "");
        return false;
    }

    @Override
    public boolean updateDepartment(DingtalkDepartment dingtalkDepartment) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/department/update");
        OapiDepartmentUpdateRequest request =
                dingtalkDepartmentTransverter.getOapiDepartmentUpdateRequest(
                        dingtalkDepartment);
        try {
            OapiDepartmentUpdateResponse response = dingTalkClient.execute(request,
                    accessToken);
            if (response != null && response.getErrcode() == 0) {
                getLogger().debug("更新部门[%d-%s]成功", dingtalkDepartment.getId(),
                        dingtalkDepartment.getName());
                return true;
            }
            else {
                getLogger().debug("更新部门[%d-%s]失败，因为%s", dingtalkDepartment.getId(),
                        dingtalkDepartment.getName(),
                        response != null ? response.getErrmsg() : null);
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
            getLogger().debug("更新部门[%d-%s]失败，因为服务器响应为null", dingtalkDepartment.getId(),
                    dingtalkDepartment.getName());
        }
        return false;
    }


    @Override
    public int createdBundleDepartments(
            List<DingtalkDepartment> dingtalkDepartments) {

        AtomicInteger failedCount = new AtomicInteger();

        if (dingtalkDepartments.size() == 0) {
            return failedCount.get();
        }

        CountDownLatch latch = new CountDownLatch(dingtalkDepartments.size());
        ExecutorService executorService = getExecutorService();

        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            executorService.submit(() -> {
                boolean isSuccessful = createdDepartment(dingtalkDepartment);
                if (!isSuccessful) {
                    failedCount.getAndIncrement();
                }
                getLogger().debug("剩余部门创建数为[%d]",
                        latch.getCount() - 1);
                latch.countDown();
            });
        }

        try {
            executorService.shutdown();
            latch.await();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }

        return failedCount.get();
    }

    @Deprecated
    public int createdBundleDepartments(Collection<DingtalkDepartment> dingtalkDepartments) {
        int failedCount = 0;
        int index = 0;
        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            if (!createdDepartment(dingtalkDepartment)) {
                failedCount++;
            }
            getLogger().debug("正在创建第[%d]个部门，剩余为创建数[%d]", index,
                    dingtalkDepartments.size() - 1 - index);
            index++;
        }
        return failedCount;
    }

    @Override
    public boolean deleteDepartment(DingtalkDepartment dingtalkDepartment) {
        dingTalkClient.resetServerUrl("https://oapi.dingtalk.com/department/delete");
        OapiDepartmentDeleteRequest request = new OapiDepartmentDeleteRequest();
        request.setId(dingtalkDepartment.getId() + "");
        request.setHttpMethod("GET");
        try {
            OapiDepartmentDeleteResponse response = dingTalkClient.execute(request,
                    accessToken);
            if (response != null && response.getErrcode() == 0) {
                getLogger().debug(
                        "删除部门[%s]成功",
                        dingtalkDepartment.getSourceIdentifier() + dingtalkDepartment.getName()
                );
                return true;
            }
            else {
                getLogger().warn("删除部门[%s]失败,因为%s", dingtalkDepartment.getName(),
                        response != null ? response.getErrmsg() : "请求失败response为null");
            }
        }
        catch (ApiException e) {
            e.printStackTrace();
        }
        getLogger().warn("删除部门[%s]失败", dingtalkDepartment.getName());
        return false;
    }

    //*************

    private ExecutorService getExecutorService() {
        //由于钉钉api调用有频率限制，并发调用数还是10以内好了
        int processCount = 10;
        ExecutorService executorService = executorService = new ThreadPoolExecutor(
                processCount / 2 + 1, Integer.MAX_VALUE, 1800L, TimeUnit.MINUTES,
                new LinkedBlockingQueue<Runnable>());
        return executorService;
    }

    private int doBundleEmployeeOperation(List<DingtalkEmployee> dingtalkEmployees, int sign) {

        if (dingtalkEmployees.size() == 0) {
            return 0;
        }

        int failCount = 0;
        ExecutorService executorService = getExecutorService();
        List<Future<Boolean>> futures = new ArrayList<>();
        CountDownLatch latch = new CountDownLatch(dingtalkEmployees.size());

        for (DingtalkEmployee dingtalkEmployee : dingtalkEmployees) {
            futures.add(executorService.submit((Callable<Boolean>) () -> {
                boolean isSuccessful = false;
                switch (sign) {
                    case 0:
                        isSuccessful = createEmployee(dingtalkEmployee);
                        break;
                    case 1:
                        isSuccessful = updateEmployee(dingtalkEmployee);
                        break;
                    case 2:
                        isSuccessful = deleteEmployee(dingtalkEmployee);
                        break;
                    default:
                        break;
                }
                L.debug(latch.getCount());
                latch.countDown();
                return isSuccessful;
            }));
        }

        try {
            executorService.shutdown();
            latch.await();
        }
        catch (InterruptedException e) {
            e.printStackTrace();
        }
        finally {
            for (Future<Boolean> future : futures) {
                try {
                    if (future.get() == null || !future.get()) {
                        failCount++;
                    }
                }
                catch (InterruptedException | ExecutionException e) {
                    e.printStackTrace();
                }
            }
        }

        return failCount;
    }

}
