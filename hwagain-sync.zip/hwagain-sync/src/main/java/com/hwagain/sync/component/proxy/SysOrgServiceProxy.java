package com.hwagain.sync.component.proxy;

import com.hwagain.framework.api.org.api.ISysOrgService;
import com.hwagain.framework.api.org.dto.SysOrgPersonDto;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;
import com.jeramtough.jtlog.facade.L;
import com.jeramtough.jtlog.with.WithLogger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Created on 2019/6/14 10:21
 * by @author WeiBoWen
 */
@Component
public class SysOrgServiceProxy implements WithLogger {

    private final ISysOrgService sysOrgService;
    private final SysOrgDepartmentProxy sysOrgDepartmentProxy;
    private Map<String, SysOrgPersonDto> fdIdKeySysOrgPersonDtoMap;

    @Autowired
    public SysOrgServiceProxy(ISysOrgService sysOrgService,
                              SysOrgDepartmentProxy sysOrgDepartmentProxy) {
        this.sysOrgService = sysOrgService;
        this.sysOrgDepartmentProxy = sysOrgDepartmentProxy;

        fdIdKeySysOrgPersonDtoMap = new HashMap<>();
    }

    private List<SysOrgPersonDto> sysOrgPersonDtos;

    public void obtainLatest() {
        sysOrgDepartmentProxy.obtainLatest();

        List<SysOrgPersonDto> sysOrgPersonDtos = sysOrgService.findPersonAll();

        this.sysOrgPersonDtos = new ArrayList<>(sysOrgPersonDtos.size());

        //将没有员工编号和没有对应部门的【华劲】员工去掉
        for (SysOrgPersonDto sysOrgPersonDto : sysOrgPersonDtos) {

            fdIdKeySysOrgPersonDtoMap.put(sysOrgPersonDto.getFdParentid(), sysOrgPersonDto);

            if (sysOrgPersonDto.getFdEmployeeNumber() != null) {
                if (sysOrgDepartmentProxy.getSysOrgDepartmentDtoByDepartmentNumber(
                        sysOrgPersonDto.getFdParentid()) != null) {
                    if (sysOrgPersonDto.getFdIsAvailable() == 1) {
                        this.sysOrgPersonDtos.add(sysOrgPersonDto);
                    }
                    else {
                        getLogger().verbose("洗掉一个离职的华劲员工[%s]", sysOrgPersonDto.getFdName());
                    }
                }
                else {
                    getLogger().verbose("洗掉一个没有对应部门的华劲员工[%s]", sysOrgPersonDto.getFdName());
                }
            }
            else {
                getLogger().verbose("洗掉一个没有工号的华劲员工[%s]", sysOrgPersonDto.getFdName());
            }
        }

        //TODO:先拿10个做测试
        List<SysOrgPersonDto> sysOrgPersonDtosTemp = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            sysOrgPersonDtosTemp.add(this.sysOrgPersonDtos.get(i));
        }

        //TODO:测试更新
      /*  for (SysOrgPersonDto sysOrgPersonDto : this.sysOrgPersonDtos) {
            sysOrgPersonDto.setFdName(sysOrgPersonDto.getFdName() + "I改");
            sysOrgPersonDto.setFdParentid("10001");
        }*/

        //TODO:删除测试
        /*sysOrgPersonDtosTemp = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            sysOrgPersonDtosTemp.add(this.sysOrgPersonDtos.get(i));
        }*/

        this.sysOrgPersonDtos = sysOrgPersonDtosTemp;
    }

    public List<SysOrgPersonDto> getSysOrgPersonDtos() {
        return sysOrgPersonDtos;
    }

    public SysOrgPersonDto getOrgPersonDtoById(String fdId) {
        return fdIdKeySysOrgPersonDtoMap.get(fdId);
    }
}
