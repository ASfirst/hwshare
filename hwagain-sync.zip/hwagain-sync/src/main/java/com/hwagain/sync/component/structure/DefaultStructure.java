package com.hwagain.sync.component.structure;

import java.util.*;

/**
 * Created on 2019-06-12 21:09
 * by @author JeramTough
 */
public class DefaultStructure implements Structure {

    private Object value;
    private Set<Structure> subStructures;
    private Structure parentStructure;


    public static List<Structure> getSubsAndSort(Structure rootStructure, SortType sortType) {
        if (!rootStructure.isRoot()) {
            throw new IllegalArgumentException("The structure must be root");
        }

        List<Structure> sortedStructures = new ArrayList<>();
        LinkedList<Structure> tempStructures = new LinkedList<>();

        if (rootStructure.hasSubs()) {
            Structure[] structures = rootStructure.getSubs();
            for (Structure structure : structures) {
                if (structure.hasSubs()) {
                    tempStructures.add(structure);
//                    System.out.println("添加有子结构:" + structure.getValue());
                }
                else {
//                    System.out.println("添加没有子结构:" + structure.getValue());
                }
                sortedStructures.add(structure);
            }

            Structure tempStructure;
            while (!tempStructures.isEmpty()) {
                tempStructure = tempStructures.removeFirst();
                structures = tempStructure.getSubs();
                for (Structure structure2 : structures) {
                    if (structure2.hasSubs()) {
                        tempStructures.add(structure2);
//                        System.out.println("添加有子结构:" + structure2.getValue());
                    }
                    else {
//                        System.out.println("添加没有子结构:" + structure2.getValue());
                    }
                    sortedStructures.add(structure2);
                }
            }

            if (sortType == SortType.ASCENDING) {
                Collections.reverse(sortedStructures);
            }
        }

        return sortedStructures;
    }

    public DefaultStructure() {
        subStructures = new HashSet<>();
    }

    @Override
    public boolean isRoot() {
        return parentStructure == null;
    }

    @Override
    public boolean hasSubs() {
        return subStructures.size() > 0;
    }

    @Override
    public Structure[] getSubs() {
        return subStructures.toArray(new Structure[0]);
    }

    @Override
    public Structure getParent() {
        return parentStructure;
    }

    @Override
    public void setParent(Structure parentStructure) {
        this.parentStructure = parentStructure;
    }

    @Override
    public void addSub(Structure structure) {
        subStructures.add(structure);
        structure.setParent(this);
    }

    @Override
    public Object getValue() {
        return value;
    }


    @Override
    public void setValue(Object value) {
        this.value = value;
    }

    //***************

}
