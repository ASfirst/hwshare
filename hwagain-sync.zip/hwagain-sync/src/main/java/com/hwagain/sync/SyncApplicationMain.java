package com.hwagain.sync;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jdbc.DataSourceAutoConfiguration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;
import org.springframework.context.annotation.ImportResource;
import org.springframework.scheduling.annotation.EnableAsync;

@SpringBootApplication(scanBasePackages = { "com.hwagain" })
@EnableAspectJAutoProxy(proxyTargetClass = true)
@EnableAutoConfiguration(exclude={DataSourceAutoConfiguration.class})
@EnableAsync
@ImportResource({"classpath:dubboConsumer.xml"})
public class SyncApplicationMain {
	

	public static void main(final String[] args) throws Exception {
		SpringApplication.run(SyncApplicationMain.class, args);
		System.err.println("启动成功");
	}

}