package com.hwagain.sync.component.dingtalk.net;

import com.dingtalk.api.response.OapiDepartmentListResponse;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;

import java.util.List;
import java.util.Map;

/**
 * 钉钉网络通信客户端，负责调用钉钉的API
 * Created on 2019/6/11 15:03
 * by @author JeramTough
 */
public interface DingTalkHttpClient {

    /**
     * 获取部门列表
     *
     * @param departmentId 1为根部门
     */
    List<OapiDepartmentListResponse.Department> getDepartmentList(int departmentId);


    /**
     * 获取部门用户userid列表
     *
     * @param departmentId 部門Id
     * @return 用户userid列表
     */
    List<String> getDeptMemberList(Long departmentId);

    /**
     * 获取职工详情信息
     *
     * @param userId 用户ID
     */
    DingtalkEmployee getDingtalkEmployee(String userId);

    /**
     * 获取所有部门的所有职工详情信息
     * @return 以工号作为键值的员工对象集合
     */
    Map<String, DingtalkEmployee> getAllEmployees();

}

