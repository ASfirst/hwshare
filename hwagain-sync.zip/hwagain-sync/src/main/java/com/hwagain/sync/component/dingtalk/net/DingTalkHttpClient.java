package com.hwagain.sync.component.dingtalk.net;

import com.dingtalk.api.response.OapiDepartmentListResponse;
import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;

import java.util.Collection;
import java.util.List;
import java.util.Map;

/**
 * 钉钉网络通信客户端，负责调用钉钉的API
 * Created on 2019/6/11 15:03
 * by @author JeramTough
 */
public interface DingTalkHttpClient {


    /**
     * 获取部门用户userid列表
     *
     * @param departmentId 部門Id
     * @return 用户userid列表
     */
    List<String> getDeptMemberList(Long departmentId);

    /**
     * 获取职工详情信息
     *
     * @param userId 用户ID
     */
    DingtalkEmployee getDingtalkEmployee(String userId);

    /**
     * 获取所有部门的所有职工详情信息
     *
     * @return 以工号作为键值的员工对象集合
     */
    Map<String, DingtalkEmployee> getAllEmployees();

    /**
     * 创建新员工
     *
     * @param dingtalkEmployee 钉钉员工Bean
     * @return 是否成功
     */
    boolean createEmployee(DingtalkEmployee dingtalkEmployee);

    /**
     * 批量并发创建新员工
     *
     * @param dingtalkEmployees 钉钉员工集合
     * @return 失败数
     */
    int createBundleEmployees(List<DingtalkEmployee> dingtalkEmployees);

    /**
     * 更新员工信息
     *
     * @param dingtalkEmployee 钉钉员工Bean
     * @return 是否成功
     */
    boolean updateEmployee(DingtalkEmployee dingtalkEmployee);

    /**
     * 批量并发更新新员工信息
     *
     * @param dingtalkEmployees 钉钉员工集合
     * @return 失败数
     */
    int updateBundleEmployees(List<DingtalkEmployee> dingtalkEmployees);

    /**
     * 删除员工信息
     *
     * @param dingtalkEmployee 钉钉员工Bean
     * @return 是否成功
     */
    boolean deleteEmployee(DingtalkEmployee dingtalkEmployee);

    /**
     * 批量并发删除新员工信息
     *
     * @param dingtalkEmployees 钉钉员工集合
     * @return 失败数
     */
    int deleteBundleEmployees(List<DingtalkEmployee> dingtalkEmployees);

    /**
     * 获取部门列表
     *
     * @param departmentId 1为根部门
     */
    List<DingtalkDepartment> getDepartmentList(int departmentId);

    /**
     * @param dingtalkDepartment 钉钉部门Bean
     * @return 是否成功
     */
    boolean createdDepartment(DingtalkDepartment dingtalkDepartment);

    boolean updateDepartment(DingtalkDepartment dingtalkDepartment);

    /**
     * 批量并发创建钉钉部门
     *
     * @param dingtalkDepartments 钉钉部门集合
     * @return 失败数
     */
    int createdBundleDepartments(List<DingtalkDepartment> dingtalkDepartments);

    /**
     * 已过时
     * 批量并发创建钉钉部门
     *
     * @param dingtalkDepartments 钉钉部门集合
     * @return 失败数
     */
    @Deprecated
    int createdBundleDepartments(Collection<DingtalkDepartment> dingtalkDepartments);

    /**
     * 删除该部门
     *
     * @param dingtalkDepartment 钉钉部门Bean
     * @return 是否成功
     */
    boolean deleteDepartment(DingtalkDepartment dingtalkDepartment);
}

