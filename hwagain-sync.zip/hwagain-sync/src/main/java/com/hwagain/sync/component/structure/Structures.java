package com.hwagain.sync.component.structure;

import com.jeramtough.jtlog.facade.L;

import java.util.*;

/**
 * Created on 2019/6/18 10:28
 * by @author WeiBoWen
 */
public class Structures {

    public static List<Structure> getSubsAndSort(Structure rootStructure, SortType sortType) {
        if (!rootStructure.isRoot()) {
            throw new IllegalArgumentException("The structure must be root");
        }

        List<Structure> sortedStructures = new ArrayList<>();
        LinkedList<Structure> tempStructures = new LinkedList<>();

        if (rootStructure.hasSubs()) {
            Structure[] structures = rootStructure.getSubs();
            for (Structure structure : structures) {
                if (structure.hasSubs()) {
                    tempStructures.add(structure);
//                    System.out.println("添加有子结构:" + structure.getValue());
                }
                else {
//                    System.out.println("添加没有子结构:" + structure.getValue());
                }
                sortedStructures.add(structure);
            }

            Structure tempStructure;
            while (!tempStructures.isEmpty()) {
                tempStructure = tempStructures.removeFirst();
                structures = tempStructure.getSubs();
                for (Structure structure2 : structures) {
                    if (structure2.hasSubs()) {
                        tempStructures.add(structure2);
//                        System.out.println("添加有子结构:" + structure2.getValue());
                    }
                    else {
//                        System.out.println("添加没有子结构:" + structure2.getValue());
                    }
                    sortedStructures.add(structure2);
                }
            }

            if (sortType == SortType.ASCENDING) {
                Collections.reverse(sortedStructures);
            }
        }

        return sortedStructures;
    }

    public static List<List<Structure>> getAll(Structure rootStructure, SortType sortType) {
        List<Structure> sortStructures = getSubsAndSort(rootStructure, sortType);
        Map<Integer, List<Structure>> integerListMap = new HashMap<>();

        for (Structure structure : sortStructures) {
            List<Structure> structures1 = integerListMap.get(structure.getLevel());
            if (structures1 == null) {
                structures1 = new ArrayList<>();
            }
            structures1.add(structure);
            integerListMap.put(structure.getLevel(), structures1);
        }

        integerListMap.put(0,
                Collections.singletonList(rootStructure));

        List<List<Structure>> allStructures = new ArrayList<>();
        for (int i = 0; i <integerListMap.size(); i++) {
            allStructures.add(integerListMap.get(i));
        }

        if (sortType == SortType.ASCENDING) {
            Collections.reverse(allStructures);
        }
        return allStructures;
    }

}
