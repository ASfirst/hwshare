package com.hwagain.sync;

import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.hwagain.sync.component.dingtalk.net.MyDingTalkHttpClient;
import com.jeramtough.jtlog.facade.L;
import org.junit.Test;

import java.util.List;

/**
 * Created on 2019-06-10 23:24
 * by @author JeramTough
 */
public class TestMain {

    MyDingTalkHttpClient dingTalkHttpClient = new MyDingTalkHttpClient
            (null, null, "ding30aa094244892778",
                    "3-woU33zJCFEUKg3N7WoaUAKAWzWkALT0In2wIMCzyx_4wuuD0PSMLhUWUzWB-tH");

    @Test
    public void test() {
       /* List<DingtalkDepartment> dingtalkDepartments = dingTalkHttpClient.getSubDepartmentList(
                1);*/
//        L.debug(dingtalkDepartments.size());
       /* List<Long> ids = dingTalkHttpClient.getAllSubDepartmentIdList();
        for (Long id : ids) {
            L.p(id + "\n");
        }*/
        List<DingtalkDepartment> dingtalkDepartments = dingTalkHttpClient.getSubDepartmentList(
                1);
        L.debug(dingtalkDepartments.size());
    }


    @Test
    public void exceptionTest() {
        try {
            throw new NullPointerException("dasfasdfsadf");
        }
        catch (Exception e) {
//            e.printStackTrace();
            L.p(getExceptionDetail(e));
        }
    }

    public String getExceptionDetail(Exception e) {
        StringBuffer stringBuffer = new StringBuffer(e.toString() + "\n");
        StackTraceElement[] messages = e.getStackTrace();
        int length = messages.length;
        for (int i = 0; i < length; i++) {
            stringBuffer.append("\t" + messages[i].toString() + "\n");
        }
        return stringBuffer.toString();
    }
   /* @Test
    public void test() {


    }

    @Test
    public void testUser() {
        dingTalkHttpClient.getDingtalkEmployee("28111455511037145");
    }

    @Test
    public void testUser1() {
        Map<String, DingtalkEmployee> dingtalkEmployeeMap = dingTalkHttpClient.getAllEmployees();
        L.debug(dingtalkEmployeeMap.size());
    }

    @Test
    public void deleteAllDepartment() {
        List<DingtalkDepartment> dingtalkDepartments = dingTalkHttpClient.getSubDepartmentList(
                1);
        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            dingTalkHttpClient.deleteDepartment(dingtalkDepartment);
        }
    }


    @Test
    public void deleteAllDepartment1() {
        List<DingtalkDepartment> dingtalkDepartments = dingTalkHttpClient.getSubDepartmentList(
                1);
        long failedCount = dingTalkHttpClient.deleteBundleDepartments(dingtalkDepartments);
        L.debug(failedCount);
    }

    @Test
    public void deleteAllEmployee() {
        List<DingtalkEmployee> dingtalkEmployees =
                new ArrayList<>(dingTalkHttpClient.getAllEmployees().values());
        dingTalkHttpClient.deleteBundleEmployees(dingtalkEmployees);
    }

    @Test
    public void updateDepartment() {
        List<DingtalkDepartment> dingtalkDepartments = dingTalkHttpClient.getSubDepartmentList(
                1);
        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
           *//* if (dingtalkDepartment.getName().contains("柳城、雒容片区")){
                dingtalkDepartment.setSourceIdentifier("yasila");
                dingtalkDepartment.setName("抛弃");
               dingTalkHttpClient.updateDepartment(dingtalkDepartment);
            }*//*
            //118534449
            if (dingtalkDepartment.getName().contains("抛弃")) {
                L.debug(dingtalkDepartment.toString());
                dingtalkDepartment.setSourceIdentifier("yasila");
                dingtalkDepartment.setName("抛弃");
                dingTalkHttpClient.updateDepartment(dingtalkDepartment);
            }
        }
        L.debug(dingTalkHttpClient.getDepartment(118534449L));
    }

    @Test
    public void testDate() {
        String a = " 13978494529";
        L.debugs(a, MyTextUtil.trim(a));
    }

    @Test
    public void testLevel() {
        Structure structure = new DefaultStructure();
        Structure structure1 = new DefaultStructure();
        Structure structure2 = new DefaultStructure();
        Structure structure3 = new DefaultStructure();
        Structure structure4 = new DefaultStructure();
        Structure structure5 = new DefaultStructure();
        Structure structure6 = new DefaultStructure();
        Structure structure7 = new DefaultStructure();
        Structure structure8 = new DefaultStructure();

        structure.addSub(structure1);
        structure.addSub(structure2);
        structure1.addSub(structure3);
        structure1.addSub(structure4);
        structure2.addSub(structure5);
        structure2.addSub(structure6);
        structure3.addSub(structure7);

        List<Structure> structures = Structures.getSubsAndSort(structure, SortType.ASCENDING);
        for (Structure structure9 : structures) {
            L.debug(structure9.getLevel());
        }
        L.debug(structure.getLevel());

        List<List<Structure>> allStructures = Structures.getAll(structure, SortType.ASCENDING);
        for (List<Structure> structureList : allStructures) {
            for (int i = 0; i < structureList.size(); i++) {
                Structure structure9 = structureList.get(i);
                L.debugs(i, structure9.getLevel());
            }
        }

    }

    @Test
    public void tokenTest() {
        for (; ; ) {
            DefaultDingTalkClient client = new DefaultDingTalkClient(
                    "https://oapi.dingtalk.com/gettoken");
            OapiGettokenRequest request = new OapiGettokenRequest();
            request.setAppkey("dinglrrzez6pyestdyja");
            request.setAppsecret(
                    "lKpccJz-h_aKKiszegvA5-YlufdgejZe98yvpU0YRZ4U0ogDGxjBBco1lcXY1Eg8");
            request.setHttpMethod("GET");
            try {
                OapiGettokenResponse response = client.execute(request);
                L.debug(response.getErrcode(), response.getErrmsg());
            }
            catch (ApiException e) {
                e.printStackTrace();
            }
        }

    }

    @Test
    public void tokenTest1 () {
        for (; ; ) {
            dingTalkHttpClient.refreshTokenByAppKey();
        }

    }

    @Test
    public void fileTest () {
        File file=new File("."+File.separator + "log" + File.separator + "hw-sync.log");
        Logger logger=LoggerManager.getLogger(this.getClass());
        logger.getLogContext().getLogRecorders().add(new MyLogRecorder());
        logger.debug("dadsfasfaf");

    }*/
}
