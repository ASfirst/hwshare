package com.hwagain.sync;

import com.hwagain.sync.component.dingtalk.bean.DingtalkDepartment;
import com.hwagain.sync.component.dingtalk.bean.DingtalkEmployee;
import com.hwagain.sync.component.dingtalk.net.MyDingTalkHttpClient;
import com.jeramtough.jtlog.facade.L;
import org.junit.Test;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created on 2019-06-10 23:24
 * by @author JeramTough
 */
public class TestMain {

    MyDingTalkHttpClient dingTalkHttpClient = new MyDingTalkHttpClient
            ("dingjiclvajudn0rg7la",
                    "WbpagUtNdaUCZnQqx-OKKcagGvUXMxr1fOnajPupg9Jcg0UN5q_OKA7gfll5sDiw");

    @Test
    public void test() {


    }

    @Test
    public void testUser() {
        dingTalkHttpClient.getDingtalkEmployee("28111455511037145");
    }

    @Test
    public void testUser1() {
        Map<String, DingtalkEmployee> dingtalkEmployeeMap = dingTalkHttpClient.getAllEmployees();
        L.debug(dingtalkEmployeeMap.size());
    }

    @Test
    public void deleteAllDepartment() {
        List<DingtalkDepartment> dingtalkDepartments = dingTalkHttpClient.getSubDepartmentList(
                1);
        for (DingtalkDepartment dingtalkDepartment : dingtalkDepartments) {
            dingTalkHttpClient.deleteDepartment(dingtalkDepartment);
        }
    }

   /* @Test
    public void deleteAllDepartment1() {
        List<DingtalkDepartment> dingtalkDepartments = dingTalkHttpClient.getSubDepartmentList(
                1);
        dingTalkHttpClient.deleteBundleDepartments(dingtalkDepartments);
    }*/

    @Test
    public void deleteAllEmployee() {
        List<DingtalkEmployee> dingtalkEmployees =
                new ArrayList<>(dingTalkHttpClient.getAllEmployees().values());
        dingTalkHttpClient.deleteBundleEmployees(dingtalkEmployees);
    }


}
