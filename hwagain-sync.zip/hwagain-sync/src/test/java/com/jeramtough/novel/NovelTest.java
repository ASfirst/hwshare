package com.jeramtough.novel;

import com.jeramtough.jtlog.annotation.LogConfiguration;
import com.jeramtough.jtlog.config.SimpleLogConfigDefaultValues;
import com.jeramtough.jtlog.facade.L;
import com.jeramtough.jtlog.jtlogger.Logger;
import com.jeramtough.jtlog.jtlogger.LoggerManager;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.junit.Test;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.util.ArrayList;
import java.util.List;

/**
 * Created on 2019/6/26 16:34
 * by @author WeiBoWen
 */
@LogConfiguration(maxLengthOfRow = 20)
public class NovelTest {

    @Test
    public void test() {
       /* String url = "https://www.biquge.info/26_26516/11938050.html";
        NovelClient novelClient = new NovelClient();
        String novel = novelClient.open(url);
        L.debug(novel);*/

    }


}

